#!/usr/bin/env bash
# One-time installer for DGS Auto Editor on macOS (Apple Silicon & Intel).
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

echo "========================================================"
echo "  DGS Auto Editor — macOS Native Setup & Auto-Sync"
echo "========================================================"

export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

if ! command -v brew >/dev/null 2>&1; then
    echo "[1/5] Installing Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
fi

echo "[2/5] Installing native dependencies (mpv, ffmpeg, node, tesseract, python@3.11)..."
brew install mpv ffmpeg node tesseract python@3.11

mkdir -p "$ROOT/native_editor/vendor/mpv-mac"
BREW_PREFIX="$(brew --prefix)"
if [ -f "$BREW_PREFIX/lib/libmpv.dylib" ]; then
    ln -sf "$BREW_PREFIX/lib/libmpv.dylib" "$ROOT/native_editor/vendor/mpv-mac/libmpv.dylib"
    ln -sf "$BREW_PREFIX/lib/libmpv.dylib" "$ROOT/native_editor/vendor/mpv-mac/libmpv.2.dylib"
fi

echo "[3/5] Creating clean Mac Python 3.11 environment (.venv_mac)..."
PY311="$BREW_PREFIX/opt/python@3.11/bin/python3.11"
if [ ! -x "$PY311" ]; then
    PY311="$(command -v python3)"
fi
rm -rf "$ROOT/.venv_mac"
"$PY311" -m venv "$ROOT/.venv_mac"
"$ROOT/.venv_mac/bin/pip" install --upgrade pip wheel
"$ROOT/.venv_mac/bin/pip" install \
    PySide6 \
    python-mpv \
    faster-whisper \
    openpyxl \
    numpy \
    Pillow \
    sherpa-onnx

echo "[4/5] Installing chapter engine Node packages..."
if [ -d "$ROOT/hostinger_deploy" ]; then
    (cd "$ROOT/hostinger_deploy" && npm install --omit=dev --no-audit --no-fund)
fi

chmod +x "$ROOT/Open DGS Editor (Mac).command" "$ROOT/Install DGS Editor (Mac).command" 2>/dev/null || true

echo "[5/5] Creating Mac Desktop launcher..."
DESK_CMD="$HOME/Desktop/DGS Auto Editor.command"
cat > "$DESK_CMD" <<EOF
#!/usr/bin/env bash
exec "$ROOT/Open DGS Editor (Mac).command" "\$@"
EOF
chmod +x "$DESK_CMD"
xattr -cr "$DESK_CMD" 2>/dev/null || true

# Also update DGS Auto Editor.app to delegate through Terminal so macOS TCC allows folder access
for APP_DIR in "$ROOT/DGS Auto Editor.app" "$HOME/Desktop/DGS Auto Editor.app"; do
    rm -rf "$APP_DIR"
    mkdir -p "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"
    cat > "$APP_DIR/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleExecutable</key>
    <string>DGSAutoEditor</string>
    <key>CFBundleIdentifier</key>
    <string>com.dgeniussolutions.autoeditor</string>
    <key>CFBundleName</key>
    <string>DGS Auto Editor</string>
    <key>CFBundleDisplayName</key>
    <string>DGS Auto Editor</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleShortVersionString</key>
    <string>0.10.0</string>
    <key>NSHighResolutionCapable</key>
    <true/>
</dict>
</plist>
EOF
    cat > "$APP_DIR/Contents/MacOS/DGSAutoEditor" <<EOF
#!/usr/bin/env bash
open -a Terminal "$ROOT/Open DGS Editor (Mac).command"
EOF
    chmod +x "$APP_DIR/Contents/MacOS/DGSAutoEditor"
    xattr -cr "$APP_DIR" 2>/dev/null || true
done

echo ""
echo "========================================================"
echo "  Setup Complete!"
echo "  Double-click 'DGS Auto Editor.command' or 'DGS Auto Editor'"
echo "  on your Mac Desktop anytime to open!"
echo "========================================================"
