@echo off
setlocal
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
cd /d "%ROOT%"

echo ========================================================
echo   DGS Auto Editor — Windows Setup ^& Auto-Sync
echo ========================================================

REM 1. If portable python311 is already bundled, skip Python install
if exist "%ROOT%\python311\pythonw.exe" (
    echo [1/4] Portable Python 3.11 is already bundled in "%ROOT%\python311".
    goto :check_node
)

REM 2. Check or install Python 3.11 via winget
set "PY311="
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set "PY311=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
) else (
    where python >nul 2>&1 && for /f "delims=" %%P in ('where python') do if not defined PY311 set "PY311=%%P"
)
if not defined PY311 (
    echo [1/4] Installing Python 3.11 via winget...
    winget install -e --id Python.Python.3.11 --accept-package-agreements --accept-source-agreements
    if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PY311=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
)

if not exist "%ROOT%\backend\.venv\Scripts\python.exe" (
    echo [2/4] Creating Python virtual environment and installing packages...
    "%PY311%" -m venv "%ROOT%\backend\.venv"
    "%ROOT%\backend\.venv\Scripts\pip.exe" install --upgrade pip wheel
    "%ROOT%\backend\.venv\Scripts\pip.exe" install PySide6 python-mpv faster-whisper openpyxl numpy Pillow sherpa-onnx
)

:check_node
if not exist "%ROOT%\native_editor\vendor\node\node.exe" (
    where node >nul 2>&1 || (
        echo [3/4] Installing Node.js LTS via winget...
        winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
    )
)

if not exist "%ROOT%\hostinger_deploy\node_modules" (
    echo [3/4] Installing engine Node packages...
    pushd "%ROOT%\hostinger_deploy"
    call npm install --omit=dev --no-audit --no-fund
    popd
)

echo [4/4] Creating "DGS Auto Editor" shortcut on your Windows Desktop...
powershell -NoProfile -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\DGS Auto Editor.lnk'); $s.TargetPath = '%ROOT%\Open DGS Editor.bat'; $s.WorkingDirectory = '%ROOT%'; $s.Description = 'DGS Auto Editor (Auto-Sync)'; $s.Save()"

echo.
echo ========================================================
echo   Setup Complete!
echo   Double-click "DGS Auto Editor" on your Desktop or
echo   "Open DGS Editor.bat" anytime to open.
echo   Every launch automatically syncs updates from GitHub!
echo ========================================================
pause
