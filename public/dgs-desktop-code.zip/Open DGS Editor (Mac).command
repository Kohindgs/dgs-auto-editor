#!/usr/bin/env bash
# Launch DGS Auto Editor on macOS with automatic GitHub code sync.

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT" || exit 1

export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"
export DYLD_FALLBACK_LIBRARY_PATH="$ROOT/native_editor/vendor/mpv-mac:/opt/homebrew/lib:/usr/local/lib:${DYLD_FALLBACK_LIBRARY_PATH:-}"
export PYTHONPATH="$ROOT"
export PYTHONIOENCODING="utf-8"

# First-time setup check (.venv_mac avoids colliding with copied Windows backend/.venv)
if [ ! -x "$ROOT/.venv_mac/bin/python" ]; then
    echo "Setting up clean Mac Python environment (.venv_mac)..."
    bash "$ROOT/Install DGS Editor (Mac).command"
fi

PY="$ROOT/.venv_mac/bin/python"

# Stop any prior instance so only one timeline is active in memory
pkill -f "python.*-m dgs_studio" 2>/dev/null || true
sleep 0.5

# Pull latest code update published from the master PC (silent if offline)
"$PY" -m dgs_studio.core.update_check --auto-sync --timeout 5

echo "Opening DGS Auto Editor..."
nohup "$PY" -m dgs_studio "$@" >/tmp/dgs_auto_editor.log 2>&1 &
APP_PID=$!
sleep 2
if ! kill -0 "$APP_PID" 2>/dev/null; then
    echo ""
    echo "DGS Auto Editor exited during startup. Error details:"
    echo "--------------------------------------------------------"
    cat /tmp/dgs_auto_editor.log
    echo "--------------------------------------------------------"
    read -r -p "Press Return to close..."
    exit 1
fi
echo "DGS Auto Editor is running (PID $APP_PID)."
