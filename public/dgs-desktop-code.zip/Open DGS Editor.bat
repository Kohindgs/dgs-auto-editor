@echo off
setlocal
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
cd /d "%ROOT%"

REM Only one editor may run — a second window keeps an old timeline in memory.
powershell -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' -and $_.CommandLine -like '*-m dgs_studio*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; Start-Sleep -Seconds 1"

REM Locate Python 3.11 (prefer bundled portable python311, then user Python311 + venv site-packages)
set "PY_HOME="
if exist "%ROOT%\python311\pythonw.exe" (
    set "PY_HOME=%ROOT%\python311"
) else if exist "%LOCALAPPDATA%\Programs\Python\Python311\pythonw.exe" (
    set "PY_HOME=%LOCALAPPDATA%\Programs\Python\Python311"
) else if exist "C:\Users\Kohin\AppData\Local\Programs\Python\Python311\pythonw.exe" (
    set "PY_HOME=C:\Users\Kohin\AppData\Local\Programs\Python\Python311"
)

if exist "%ROOT%\backend\.venv" set "VIRTUAL_ENV=%ROOT%\backend\.venv"
if defined PY_HOME set "PYTHONHOME=%PY_HOME%"
set "PYTHONPATH=%ROOT%;%ROOT%\backend\.venv\Lib\site-packages;%ROOT%\python311\Lib\site-packages"
set "PYTHONIOENCODING=utf-8"

if defined PY_HOME (
    set "PY_CONSOLE=%PY_HOME%\python.exe"
    set "PY_GUI=%PY_HOME%\pythonw.exe"
) else if exist "%ROOT%\backend\.venv\Scripts\python.exe" (
    set "PY_CONSOLE=%ROOT%\backend\.venv\Scripts\python.exe"
    set "PY_GUI=%ROOT%\backend\.venv\Scripts\pythonw.exe"
) else (
    set "PY_CONSOLE=python"
    set "PY_GUI=pythonw"
)

REM Auto-sync latest code update from GitHub on secondary PCs before opening (skip blocking wait on master D:\AI Editor)
if /I not "%ROOT%"=="D:\AI Editor" (
    "%PY_CONSOLE%" -m dgs_studio.core.update_check --auto-sync --timeout 4
)

start "DGS Auto Editor" "%PY_GUI%" -m dgs_studio %*
