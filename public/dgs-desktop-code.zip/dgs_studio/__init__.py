"""DGS Auto Editor ??? native Windows & Mac program (no browser, no local address)."""

__version__ = "0.10.1-native.3"
