from dgs_studio.app import main

raise SystemExit(main())
