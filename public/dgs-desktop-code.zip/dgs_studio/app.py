"""Start the editor.

    python -m dgs_studio [--project <id or folder>] [--at <seconds>]
                         [--shot <png> [--wait <ms>]] [--play <seconds>]

``--shot`` saves a picture of the window and closes it (used for checks).
``--play`` plays from ``--at`` for that many seconds, prints what is heard
and on screen, then closes.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# Force Qt 6 to use the system's exact fractional scaling factor without integer rounding
os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
os.environ.setdefault("QT_SCALE_FACTOR_ROUNDING_POLICY", "PassThrough")

if sys.platform == "win32":
    try:
        import ctypes

        try:
            # Windows 10/11 Per-Monitor V2 DPI Awareness (-4)
            ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except Exception:  # noqa: BLE001
            # Windows 8.1 / 10 Per-Monitor DPI Awareness (2)
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:  # noqa: BLE001
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:  # noqa: BLE001
            pass

from . import paths


def _find_project(arg: str | None) -> Path | None:
    from .core.project_store import list_projects

    if arg:
        p = Path(arg)
        if (p / "meta" / "timeline.json").is_file():
            return p
        for base in paths.projects_dirs():
            if (base / arg / "meta" / "timeline.json").is_file():
                return base / arg
        return None
    items = list_projects()
    return items[0].root if items else None


def screen_shot(win, path: str) -> None:
    """Real screen pixels; ``QWidget.grab`` re-renders the OpenGL preview offscreen and can differ."""
    g = win.frameGeometry()
    win.screen().grabWindow(0, g.x(), g.y(), g.width(), g.height()).save(path)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="dgs_studio")
    ap.add_argument("--project")
    ap.add_argument("--at", type=float, default=0.0)
    ap.add_argument("--shot")
    ap.add_argument("--wait", type=int, default=2500)
    ap.add_argument("--play", type=float, default=0.0)
    args = ap.parse_args(argv)

    paths.prepare_dlls()
    from PySide6.QtCore import QLocale, Qt, QTimer
    from PySide6.QtGui import QFont, QGuiApplication, QIcon, QSurfaceFormat
    from PySide6.QtWidgets import QApplication

    QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    fmt = QSurfaceFormat.defaultFormat()
    if sys.platform == "darwin":
        fmt.setVersion(3, 2)
        fmt.setProfile(QSurfaceFormat.OpenGLContextProfile.CoreProfile)
    fmt.setSamples(4)
    fmt.setSwapInterval(1)
    QSurfaceFormat.setDefaultFormat(fmt)

    app = QApplication(sys.argv[:1])
    app.setApplicationName("D'Auto Aline")
    app.setOrganizationName("DGenius Solutions")
    screen = QGuiApplication.primaryScreen()
    dpr = float(screen.devicePixelRatio()) if screen is not None else 1.0
    ui_font = QFont(".AppleSystemUIFont" if sys.platform == "darwin" else "Segoe UI", 10)
    ui_font.setStyleStrategy(
        QFont.StyleStrategy.PreferAntialias | QFont.StyleStrategy.PreferQuality
    )
    if sys.platform == "win32" and dpr <= 1.25:
        ui_font.setHintingPreference(QFont.HintingPreference.PreferFullHinting)
    else:
        ui_font.setHintingPreference(QFont.HintingPreference.PreferVerticalHinting)
    app.setFont(ui_font)
    if sys.platform == "win32":
        try:
            import ctypes

            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("DGeniusSolutions.DAutoAline.Studio.1")
        except Exception:  # noqa: BLE001
            pass
    import locale

    locale.setlocale(locale.LC_NUMERIC, "C")  # libmpv refuses to start under a comma-decimal locale
    QLocale.setDefault(QLocale.c())

    from . import theme
    from .ui.main_window import MainWindow

    theme.ensure_daa_logo_file(paths.app_logo())
    daa_icon = QIcon()
    for sz in (16, 32, 48, 64, 128, 256):
        daa_icon.addPixmap(theme.render_daa_neon_icon(sz))
    app.setWindowIcon(daa_icon)
    app.setStyleSheet(theme.QSS)
    win = MainWindow()
    win.setWindowIcon(daa_icon)
    screen = QGuiApplication.primaryScreen()
    if screen is not None:
        avail = screen.availableGeometry()
        rw = max(1100, min(1480, int(avail.width() * 0.86)))
        rh = max(700, min(880, int(avail.height() * 0.86)))
        rx = avail.x() + (avail.width() - rw) // 2
        ry = avail.y() + (avail.height() - rh) // 2
        win.setGeometry(rx, ry, rw, rh)
    win.showMaximized()
    win.raise_()
    win.activateWindow()
    root = _find_project(args.project)
    if root is not None:
        win.open_project(root)
        if args.at:
            win.seek(args.at)
    elif args.project:
        print(f"project not found: {args.project}", file=sys.stderr)

    if args.play > 0:
        samples: list[dict] = []

        def sample() -> None:
            idx = win.index
            t = win.clock.position()
            heard = idx.heard_at(t) if idx else None
            pl = win.audio._players.get(heard.kind) if heard else None
            samples.append({
                "t": round(t, 3),
                "clip": (idx.clip_at(t) or {}).get("screen") if idx else None,
                "picture": Path(win.preview.surface.path).name if win.preview.surface.path else "",
                "heard": f"{heard.kind}:{heard.slot}@{heard.offset:.2f}" if heard else None,
                "mpv_pos": round(pl.time_pos, 2) if pl is not None and pl.time_pos is not None else None,
            })

        timer = QTimer()
        timer.timeout.connect(sample)

        def start() -> None:
            win.clock.play()
            timer.start(500)

        def finish() -> None:
            timer.stop()
            win.clock.pause()
            print(json.dumps(samples, ensure_ascii=False, indent=1))
            if args.shot:
                screen_shot(win, args.shot)
            if win.project:
                win.project.dirty = False
            win.close()

        QTimer.singleShot(800, start)
        QTimer.singleShot(800 + int(args.play * 1000), finish)
    elif args.shot:
        def shot() -> None:
            screen_shot(win, args.shot)
            if win.project:
                win.project.dirty = False
            win.close()

        QTimer.singleShot(args.wait, shot)
    code = app.exec()
    win.shutdown()
    from PySide6.QtCore import QCoreApplication, QEvent

    win.deleteLater()
    QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    return code
