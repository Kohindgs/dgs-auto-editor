"""Lesson engine. No Qt imports here."""
