"""Import one video, place the brand logo, and write an SRT from the speech.

The speech modules stay separate: English is heard by the English whisper
script, Marathi by the Marathi recogniser. The SRT is a text file. Nothing
in this module draws words onto the picture.

After speech is heard, ``build_editable_chapter_from_video`` can turn the same
upload into a normal editable chapter: one timeline screen per spoken cue,
shared video trims, and a pulled-out VO track for Export / Filmora.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import uuid
from pathlib import Path

from .. import paths
from .plan import logo_box

_NOISE = re.compile(r"^[\[(].*[\])]$")
_SRT_TIME = re.compile(
    r"^(?:(\d+):)?(\d{1,2}):(\d{1,2})[,.:](\d{1,3})$"
)


def marathi_model_dir() -> Path | None:
    """The IndicConformer folder, the same one the chapter engine uses."""
    home = os.environ.get("DGS_AUDIO_ALIGN_HOME") or str(Path.home() / "dgs_audio_align")
    env = os.environ.get("DGS_MR_MODEL")
    candidates = [
        Path(env) if env else None,
        Path(home) / "models" / "indicconformer-mr",
        paths.data_dir() / "models" / "indicconformer-mr",
    ]
    for folder in candidates:
        if folder and (folder / "model.int8.onnx").is_file() and (folder / "tokens.txt").is_file():
            return folder
    return None


def probe_video(path: Path) -> dict:
    """Width, height and duration of the picture stream."""
    ffprobe = paths.ffprobe_exe()
    if ffprobe is None:
        raise RuntimeError("ffprobe is not installed with this program")
    proc = subprocess.run(
        [
            str(ffprobe), "-v", "error",
            "-show_entries", "format=duration",
            "-show_entries", "stream=width,height,codec_type,duration,nb_frames,avg_frame_rate,r_frame_rate,sample_aspect_ratio,codec_name,sample_rate,channels",
            "-of", "json", str(path),
        ],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=60,
    )
    if proc.returncode != 0:
        raise RuntimeError("This file could not be read as a video")
    try:
        data = json.loads(proc.stdout or "{}")
    except ValueError as exc:
        raise RuntimeError("This file could not be read as a video") from exc
    width = height = frames = 0
    duration = 0.0
    fps = 0.0
    for stream in data.get("streams") or []:
        if stream.get("codec_type") != "video" or width:
            continue
        width = int(stream.get("width") or 0)
        height = int(stream.get("height") or 0)
        fps = _rate(stream.get("avg_frame_rate")) or _rate(stream.get("r_frame_rate"))
        try:
            frames = int(stream.get("nb_frames") or 0)
        except (TypeError, ValueError):
            frames = 0
        try:
            duration = float(stream.get("duration") or 0)
        except (TypeError, ValueError):
            duration = 0.0
    if not duration:
        try:
            duration = float((data.get("format") or {}).get("duration") or 0)
        except (TypeError, ValueError):
            duration = 0.0
    if width < 2 or height < 2 or duration <= 0:
        raise RuntimeError("This file has no picture to place a logo on")
    if frames <= 0 and fps > 0:
        frames = max(1, int(round(duration * fps)))
    return {"width": width, "height": height, "duration": duration, "fps": fps, "frames": frames}


def _rate(text) -> float:
    raw = str(text or "")
    if "/" in raw:
        num, den = raw.split("/", 1)
        try:
            den_f = float(den)
            return float(num) / den_f if den_f else 0.0
        except ValueError:
            return 0.0
    try:
        return float(raw)
    except ValueError:
        return 0.0


def fitted_frame(widget_w: float, widget_h: float, video_w: float, video_h: float) -> tuple[float, float, float, float]:
    """The real video rectangle inside the preview. Black bars stay outside it."""
    if widget_w < 2 or widget_h < 2:
        return 0.0, 0.0, max(0.0, widget_w), max(0.0, widget_h)
    if video_w < 2 or video_h < 2:
        return 0.0, 0.0, widget_w, widget_h
    scale = min(widget_w / video_w, widget_h / video_h)
    dw = video_w * scale
    dh = video_h * scale
    return (widget_w - dw) / 2, (widget_h - dh) / 2, dw, dh


FRAME_W = 1920
FRAME_H = 1080


def logo_overlay(video_w: int, video_h: int, logo: Path, transform: dict) -> tuple[str, int, int, int, int]:
    """Fit the picture inside Filmora's 16:9 frame and lock the logo to that frame."""
    nat_w, nat_h = _image_size(logo)
    left, top, lw, lh = logo_box(transform, FRAME_W, FRAME_H, nat_w, nat_h)
    lw -= lw % 2
    lh -= lh % 2
    lw = max(2, min(lw, FRAME_W))
    lh = max(2, min(lh, FRAME_H))
    left = max(0, min(int(left), FRAME_W - lw))
    top = max(0, min(int(top), FRAME_H - lh))
    sharp = "flags=lanczos+accurate_rnd+full_chroma_int"
    if video_w == FRAME_W and video_h == FRAME_H:
        src = "[0:v]"
        fit = ""
    else:
        # The picture keeps its shape. Bars fill the rest of the 16:9 frame. Nothing is stretched.
        fit = (
            f"[0:v]scale={FRAME_W}:{FRAME_H}:force_original_aspect_ratio=decrease:{sharp},"
            f"pad={FRAME_W}:{FRAME_H}:(ow-iw)/2:(oh-ih)/2:black,setsar=1[bg];"
        )
        src = "[bg]"
    # Overlay ends in yuv420p so libx264 high profile can encode (format=auto becomes 4:4:4).
    filt = (
        f"{fit}[1:v]scale={lw}:{lh}:{sharp},format=rgba[lg];"
        f"{src}[lg]overlay={left}:{top}:format=yuv420:eof_action=repeat:repeatlast=1,"
        f"format=yuv420p[vout]"
    )
    return filt, left, top, lw, lh


def _image_size(path: Path) -> tuple[int, int]:
    ffprobe = paths.ffprobe_exe()
    if ffprobe is None:
        return 0, 0
    proc = subprocess.run(
        [
            str(ffprobe), "-v", "error",
            "-select_streams", "v:0",
            "-show_entries", "stream=width,height",
            "-of", "json", str(path),
        ],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=30,
    )
    try:
        stream = (json.loads(proc.stdout or "{}").get("streams") or [{}])[0]
        return int(stream.get("width") or 0), int(stream.get("height") or 0)
    except (ValueError, TypeError, IndexError):
        return 0, 0


def export_command(video: Path, logo: Path, transform: dict, dest: Path, size: dict) -> list[str]:
    """The ffmpeg line for a logo-on-video file. No subtitle filter is included."""
    ffmpeg = paths.ffmpeg_exe()
    if ffmpeg is None:
        raise RuntimeError("ffmpeg is not installed with this program")
    filt, _left, _top, _lw, _lh = logo_overlay(size["width"], size["height"], logo, transform)
    return [
        str(ffmpeg), "-y", "-i", str(video), "-i", str(logo),
        "-filter_complex", filt,
        "-map", "[vout]", "-map", "0:a?",
        "-c:v", "libx264", "-preset", "slow", "-crf", "12", "-profile:v", "high",
        "-pix_fmt", "yuv420p",
        "-sws_flags", "lanczos+accurate_rnd+full_chroma_int",
        "-fps_mode", "passthrough",
        "-c:a", "copy", "-map_metadata", "0", "-movflags", "+faststart",
        "-progress", "pipe:1", "-nostats",
        str(dest),
    ]


def copy_command(video: Path, dest: Path) -> list[str]:
    """Keep the picture and the sound as they are when the logo is off."""
    ffmpeg = paths.ffmpeg_exe()
    if ffmpeg is None:
        raise RuntimeError("ffmpeg is not installed with this program")
    return [
        str(ffmpeg), "-y", "-i", str(video),
        "-map", "0", "-c", "copy", "-map_metadata", "0", "-movflags", "+faststart",
        "-progress", "pipe:1", "-nostats",
        str(dest),
    ]


def hear(video: Path, language: str) -> list[dict]:
    """Words with start and end, from the module that matches ``language``."""
    lang = "mr" if str(language).lower() in ("mr", "marathi") else "en"
    if lang == "mr":
        return _hear_marathi(video)
    return _hear_english(video)


def _python() -> str:
    return str(paths.python_exe())


def _hear_english(video: Path) -> list[dict]:
    script = paths.ROOT / "native_editor" / "engine" / "native_hear.py"
    if not script.is_file():
        raise RuntimeError("The English speech module is not installed")
    proc = subprocess.run(
        [_python(), str(script), str(video), "en", "base", "cpu", "int8", "", "1"],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=20 * 60,
        env={**os.environ, "PYTHONIOENCODING": "utf-8"},
    )
    if proc.returncode != 0:
        raise RuntimeError(_tail(proc.stderr or proc.stdout) or "English speech detection failed")
    return _words_from_json(proc.stdout)


def _hear_marathi(video: Path) -> list[dict]:
    model = marathi_model_dir()
    script = paths.ROOT / "hostinger_deploy" / "marathi-align-worker.py"
    if model is None or not script.is_file():
        raise RuntimeError("The Marathi speech model is not installed")
    ffmpeg = paths.ffmpeg_exe()
    env = {**os.environ, "PYTHONIOENCODING": "utf-8", "DGS_MR_ASR_HOME": str(model.parent.parent)}
    if ffmpeg:
        env["DGS_FFMPEG_BIN"] = str(ffmpeg)
    proc = subprocess.run(
        [_python(), str(script), str(video), str(model)],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=20 * 60,
        env=env,
    )
    line = ""
    error = ""
    for raw in (proc.stdout or "").splitlines():
        text = raw.strip()
        if text.startswith("RESULT "):
            line = text[7:]
        elif text.startswith("ERROR "):
            error = text[6:]
    if proc.returncode != 0 or not line:
        msg = error or _tail(proc.stderr)
        if "Too few Marathi" in msg:
            raise RuntimeError("Not enough Marathi speech was heard to write an SRT")
        raise RuntimeError(msg or "Marathi speech detection failed")
    try:
        data = json.loads(line)
    except ValueError as exc:
        raise RuntimeError("Marathi speech detection returned nothing usable") from exc
    return _clean_words(data.get("words") or [])


def _words_from_json(stdout: str) -> list[dict]:
    line = ""
    for raw in stdout.splitlines():
        text = raw.strip()
        if text.startswith("{"):
            line = text
    if not line:
        raise RuntimeError("No speech was heard in this video")
    try:
        data = json.loads(line)
    except ValueError as exc:
        raise RuntimeError("Speech detection returned nothing usable") from exc
    if data.get("error"):
        raise RuntimeError(str(data["error"]))
    words = _clean_words(data.get("words") or [])
    if not words:
        raise RuntimeError("No speech was heard in this video")
    return words


def _clean_words(raw) -> list[dict]:
    out = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        word = str(item.get("word") or item.get("text") or "").strip()
        if not word or _NOISE.match(word):
            continue
        try:
            start = float(item.get("start"))
            end = float(item.get("end"))
        except (TypeError, ValueError):
            continue
        if end < start:
            end = start + 0.08
        out.append({"word": word, "start": start, "end": max(start + 0.04, end)})
    out.sort(key=lambda w: w["start"])
    return out


def wrap_lines(text: str, width: int = 42) -> list[str]:
    lines: list[str] = []
    cur = ""
    for word in text.split():
        nxt = f"{cur} {word}".strip()
        if cur and len(nxt) > width:
            lines.append(cur)
            cur = word
        else:
            cur = nxt
    if cur:
        lines.append(cur)
    return lines


def words_to_cues(words: list[dict]) -> list[dict]:
    """Phrase cues, the way an auto-caption list is broken: a pause, a sentence, or two lines."""
    cues: list[dict] = []
    buf: list[dict] = []

    def flush() -> None:
        if not buf:
            return
        text = " ".join(w["word"] for w in buf).strip()
        lines = wrap_lines(text)
        cues.append({
            "start": round(buf[0]["start"], 3),
            "end": round(buf[-1]["end"], 3),
            "text": "\n".join(lines),
        })
        buf.clear()

    for word in words:
        if buf:
            gap = word["start"] - buf[-1]["end"]
            joined = " ".join(w["word"] for w in buf + [word])
            dur = word["end"] - buf[0]["start"]
            previous = buf[-1]["word"]
            sentence = previous.endswith((".", "?", "!")) and len(buf) >= 3
            if gap >= 0.5 or dur > 6.0 or len(wrap_lines(joined)) > 2 or sentence:
                flush()
        buf.append(word)
    flush()
    for i, cue in enumerate(cues):
        nxt = cues[i + 1]["start"] if i + 1 < len(cues) else cue["end"] + 1
        cue["end"] = round(min(max(cue["end"], cue["start"] + 0.4), nxt - 0.02), 3)
        if cue["end"] <= cue["start"]:
            cue["end"] = round(cue["start"] + 0.3, 3)
    return [c for c in cues if c["text"].strip()]


def format_srt_time(sec: float) -> str:
    ms_total = max(0, int(round(float(sec) * 1000)))
    ms = ms_total % 1000
    s_total = ms_total // 1000
    s = s_total % 60
    m_total = s_total // 60
    m = m_total % 60
    h = m_total // 60
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def parse_srt_time(text: str) -> float | None:
    raw = str(text or "").strip()
    match = _SRT_TIME.match(raw)
    if match:
        h = int(match.group(1) or 0)
        m = int(match.group(2))
        s = int(match.group(3))
        ms = int(match.group(4).ljust(3, "0"))
        return h * 3600 + m * 60 + s + ms / 1000
    try:
        value = float(raw)
    except ValueError:
        return None
    return value if value >= 0 else None


def extract_audio_track(video: Path, dest: Path) -> Path:
    """Pull the soundtrack out as stereo MP3 for the chapter VO lane."""
    ffmpeg = paths.ffmpeg_exe()
    if ffmpeg is None:
        raise RuntimeError("ffmpeg is not installed with this program")
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.is_file():
        try:
            dest.unlink()
        except OSError:
            pass
    proc = subprocess.run(
        [
            str(ffmpeg), "-y", "-i", str(video),
            "-vn", "-map", "0:a:0?",
            "-ac", "2", "-ar", "44100", "-b:a", "192k",
            str(dest),
        ],
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=30 * 60,
    )
    err = _tail(proc.stderr or proc.stdout)
    if proc.returncode != 0 or not dest.is_file() or dest.stat().st_size < 64:
        if dest.is_file():
            try:
                dest.unlink()
            except OSError:
                pass
        if "does not contain any stream" in (proc.stderr or "") or "Output file does not contain any stream" in (proc.stderr or ""):
            raise RuntimeError("This video has no soundtrack to pull out as VO")
        raise RuntimeError(err or "Could not pull the voice from this video")
    return dest


def store_uploaded_video(video: Path, dest_dir: Path) -> Path:
    """Copy the upload into the chapter ``media/videos`` folder (same name when free)."""
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    src = Path(video)
    if src.parent.resolve() == dest_dir.resolve() and src.is_file():
        return src
    same = dest_dir / src.name
    if same.is_file():
        try:
            if same.resolve() == src.resolve() or same.stat().st_size == src.stat().st_size:
                return same
        except OSError:
            pass
    dest = next_free(same)
    if src.resolve() != dest.resolve():
        shutil.copy2(src, dest)
    return dest


def cues_to_scene_clips(cues: list[dict], duration: float, video_path: str) -> tuple[list[dict], list[dict]]:
    """One Video 1 screen per spoken cue, covering 0 → duration with no gaps.

    Each cue owns ``[cue.start, next.start)``. The first screen starts at 0 so
    lead-in silence stays on Scene 1; the last screen runs to the file end.
    """
    total = max(0.2, float(duration or 0))
    cleaned: list[dict] = []
    for cue in cues or []:
        text = str(cue.get("text") or "").strip()
        try:
            start = float(cue.get("start"))
            end = float(cue.get("end"))
        except (TypeError, ValueError):
            continue
        if end <= start:
            end = start + 0.3
        cleaned.append({"start": max(0.0, start), "end": min(total, max(end, start + 0.3)), "text": text})
    cleaned.sort(key=lambda c: c["start"])

    mid = uuid.uuid4().hex
    name = Path(video_path).name
    if not cleaned:
        clip = {
            "screen": "screen_1",
            "media_id": mid,
            "media_path": video_path,
            "kind": "video",
            "start": 0.0,
            "end": round(total, 3),
            "duration": round(total, 3),
            "source_in": 0.0,
            "source_out": round(total, 3),
            "script_text": "",
            "vo_text": "",
            "caption_text": "",
            "narration_in": 0.0,
            "narration_out": round(total, 3),
            "fit": "passthrough",
            "filename": name,
        }
        scene = {
            "screen": "screen_1",
            "scene_no": 1,
            "index": 1,
            "section": "story",
            "text": "1",
            "voiceover_text": "",
            "voiceover_raw": "",
            "onscreen_text": "",
            "visual_type": "Video",
            "visual_direction": name,
            "duration": round(total, 3),
            "audio_start": 0.0,
            "audio_end": round(total, 3),
            "is_poem": False,
        }
        return [clip], [scene]

    # Contiguous ranges: start at previous end (0 for the first cue).
    ranges: list[tuple[float, float, float, float, str]] = []
    for i, cue in enumerate(cleaned):
        cue_s = float(cleaned[i]["start"])
        cue_e = float(cleaned[i]["end"])
        start = 0.0 if i == 0 else cue_s
        end = float(cleaned[i + 1]["start"]) if i + 1 < len(cleaned) else total
        end = max(end, cue_e, start + 0.2)
        if i + 1 >= len(cleaned):
            end = max(end, total)
        ranges.append((start, end, cue_s, cue_e, cue["text"]))

    fixed: list[tuple[float, float, float, float, str]] = []
    cursor = 0.0
    for i, (start, end, cue_s, cue_e, text) in enumerate(ranges):
        start = 0.0 if i == 0 else max(cursor, start)
        end = max(start + 0.2, end)
        if i + 1 >= len(ranges):
            end = max(end, total)
        s_fix = round(start, 3)
        e_fix = round(min(end, total) if i + 1 < len(ranges) else max(end, total), 3)
        cs_fix = round(max(s_fix, min(cue_s, e_fix - 0.15)), 3)
        ce_fix = round(min(e_fix, max(cue_e, cs_fix + 0.15)), 3)
        fixed.append((s_fix, e_fix, cs_fix, ce_fix, text))
        cursor = fixed[-1][1]
    if fixed and fixed[-1][1] < total - 0.001:
        s, _, cs, ce, text = fixed[-1]
        fixed[-1] = (s, round(total, 3), cs, ce, text)

    clips: list[dict] = []
    scenes: list[dict] = []
    for i, (start, end, cue_s, cue_e, text) in enumerate(fixed):
        n = i + 1
        screen = f"screen_{n}"
        line = text.replace("\n", " ").strip()
        dur = round(max(0.2, end - start), 3)
        sec_label = line if line else f"Scene {n}"
        clips.append({
            "screen": screen,
            "media_id": mid,
            "media_path": video_path,
            "kind": "video",
            "start": start,
            "end": end,
            "duration": dur,
            "source_in": start,
            "source_out": end,
            "section": sec_label,
            "script_text": line,
            "vo_text": line,
            "caption_text": text,
            "narration_in": start,
            "narration_out": end,
            "cue_in": cue_s,
            "cue_out": cue_e,
            "fit": "passthrough",
            "filename": name,
        })
        scenes.append({
            "screen": screen,
            "scene_no": n,
            "index": n,
            "section": sec_label,
            "text": line or str(n),
            "voiceover_text": line,
            "voiceover_raw": line,
            "onscreen_text": line,
            "visual_type": "Video",
            "visual_direction": name,
            "duration": dur,
            "audio_start": cue_s,
            "audio_end": cue_e,
            "is_poem": False,
        })
    return clips, scenes


def build_editable_chapter_from_video(
    project,
    video: Path,
    cues: list[dict],
    *,
    language: str = "en",
    duration: float | None = None,
) -> dict:
    """Turn an uploaded video + speech cues into a normal editable chapter.

    Copies the video into the chapter folder, extracts VO audio, builds one
    timeline screen per cue (same file, different ``source_in`` / ``source_out``),
    and leaves logo / Export / Filmora on the usual chapter path.
    """
    src = Path(video)
    if not src.is_file():
        raise RuntimeError("The uploaded video is missing on this PC")
    info = probe_video(src)
    total = float(duration if duration is not None else info.get("duration") or 0)
    if total <= 0:
        raise RuntimeError("This video has no usable length")

    dest_video = store_uploaded_video(src, project.root / "media" / "videos")
    vo_note = ""
    try:
        vo_path = extract_audio_track(src, project.root / "voiceover" / "VO.mp3")
    except (OSError, RuntimeError) as exc:
        vo_path = None
        vo_note = str(exc) or "Could not pull the voice from this video"

    clips, scenes = cues_to_scene_clips(cues, total, str(dest_video.resolve()))
    shared_id = str(clips[0].get("media_id") or uuid.uuid4().hex)
    for clip in clips:
        clip["media_id"] = shared_id
    media_items = [{
        "id": shared_id,
        "filename": Path(dest_video).name,
        "path": str(dest_video.resolve()),
        "kind": "video",
        "screen": clips[0].get("screen"),
        "local_only": True,
        "duration": round(total, 3),
    }]

    lang = "mr" if str(language).lower() in ("mr", "marathi") else "en"
    indexed_cues: list[dict] = []
    for idx, c in enumerate(clips):
        text = str(c.get("caption_text") or c.get("vo_text") or "").strip()
        if not text:
            continue
        cs = float(c.get("cue_in") if c.get("cue_in") is not None else c["start"])
        ce = float(c.get("cue_out") if c.get("cue_out") is not None else c["end"])
        indexed_cues.append({
            "index": len(indexed_cues) + 1,
            "screen": c["screen"],
            "start": round(cs, 3),
            "end": round(max(cs + 0.2, ce), 3),
            "text": text,
        })
    if not indexed_cues and cues:
        for idx, cue in enumerate(cues):
            indexed_cues.append({
                "index": idx + 1,
                "screen": f"screen_{idx + 1}",
                "start": float(cue.get("start") or 0),
                "end": float(cue.get("end") or 0),
                "text": str(cue.get("text") or "").strip(),
            })

    project.title = src.stem
    project.plan["title"] = src.stem
    project.plan["project_id"] = project.pid
    project.plan["clips"] = clips
    project.plan["total_duration"] = round(total, 3)
    project.plan["srt_cues"] = indexed_cues
    project.plan["narration_segments"] = [
        {
            "screen": c["screen"],
            "start": c["start"],
            "end": c["end"],
            "narration_in": c["narration_in"],
            "narration_out": c["narration_out"],
            "script_text": c.get("script_text") or c.get("vo_text") or "",
            "vo_text": c.get("vo_text") or "",
        }
        for c in clips
    ]
    project.plan["language"] = lang
    project.plan["language_choice"] = lang
    project.plan["align_engine"] = "marathi" if lang == "mr" else "english_word"
    project.plan["has_poem"] = False
    project.plan["manual_override"] = True
    project.plan["from_uploaded_video"] = True
    sync_summary = f"SYNC OK · {len(clips)}/{len(clips)} scenes aligned to VO ({round(total, 1)}s)"
    project.plan["sync_report"] = {
        "ok": True,
        "total_scenes": len(clips),
        "aligned_scenes": len(clips),
        "vo_duration": round(total, 3),
        "summary": sync_summary,
        "issues": [],
    }
    project.plan["qa_summary"] = sync_summary
    project.plan["align_note"] = sync_summary
    project.plan.pop("video_srt", None)
    project.plan.pop("vo_pieces", None)

    if vo_path is not None:
        vo_abs = str(vo_path.resolve())
        project.plan["voiceover_path"] = vo_abs
        project.plan["voiceover_slots"] = [{
            "slot": 1,
            "filename": vo_path.name,
            "path": vo_abs,
            "start": 0.0,
            "end": round(total, 3),
            "duration": round(total, 3),
            "local_only": True,
        }]
        project.plan["vo_pieces"] = [
            {
                "id": f"vo-{c['screen']}",
                "slot": 1,
                "screen": c["screen"],
                "filename": vo_path.name,
                "vo_text": c.get("vo_text") or "",
                "start": c["start"],
                "end": c["end"],
                "source_in": c["start"],
                "source_out": c["end"],
            }
            for c in clips
        ]
        project.voiceover = {
            "path": vo_abs,
            "filename": vo_path.name,
            "duration": round(total, 3),
            "local_only": True,
            "slot": 1,
            "slots": [{
                "slot": 1,
                "filename": vo_path.name,
                "path": vo_abs,
                "duration": round(total, 3),
                "start_offset": 0.0,
                "end_offset": round(total, 3),
            }],
        }
        project.links["voiceover"] = vo_abs
        project.links.setdefault("vo_slots", {})["1"] = vo_abs
    else:
        project.plan.pop("voiceover_path", None)
        project.plan.pop("voiceover_slots", None)
        project.voiceover = {}
        project.links.pop("voiceover", None)

    project.scenes = scenes
    project.media = media_items
    project.script_meta = {
        "format": "uploaded_video",
        "filename": src.name,
        "scene_count": len(scenes),
        "poem": {"has_poem": False},
        "vo_files": [{"slot": 1, "filename": vo_path.name}] if vo_path is not None else [],
        "language": lang,
    }
    project.links.setdefault("videos", {})
    project.links.setdefault("media", {})
    for clip in clips:
        project.links["videos"][str(clip.get("screen"))] = str(dest_video.resolve())
        project.links["media"][str(clip.get("media_id"))] = str(dest_video.resolve())

    # ``Project.save`` keeps timeline / media / links only — write the script + VO
    # sidecars the same way ``set_script`` / slot seeding do.
    from .project_store import _write  # local helper used across the store

    _write(project.meta / "script.json", scenes)
    _write(project.meta / "script_meta.json", project.script_meta)
    _write(project.meta / "voiceover.json", project.voiceover if isinstance(project.voiceover, dict) else {})

    project.dirty = True
    project.save()
    return {
        "scenes": len(scenes),
        "duration": round(total, 3),
        "video": str(dest_video),
        "voiceover": str(vo_path) if vo_path is not None else "",
        "cues": len(cues or []),
        "vo_note": vo_note,
    }


def format_srt(cues: list[dict]) -> str:
    blocks = []
    n = 0
    for cue in cues:
        text = str(cue.get("text") or "").strip()
        if not text:
            continue
        try:
            start = float(cue.get("start"))
            end = float(cue.get("end"))
        except (TypeError, ValueError):
            continue
        if end <= start:
            end = start + 0.3
        n += 1
        blocks.append(f"{n}\n{format_srt_time(start)} --> {format_srt_time(end)}\n{text}\n")
    return "\n".join(blocks)


def next_free(path: Path) -> Path:
    """``Name (2)`` when ``Name`` is already on disk. Same rule as a chapter export."""
    if not path.exists():
        return path
    stem = re.sub(r" \(\d+\)$", "", path.stem)
    for n in range(2, 1000):
        candidate = path.with_name(f"{stem} ({n}){path.suffix}")
        if not candidate.exists():
            return candidate
    return path


def next_free_pair(video: Path) -> tuple[Path, Path]:
    """A video and its SRT share one name, and both move to ``Name (2)`` together."""
    srt = video.with_suffix(".srt")
    if not video.exists() and not srt.exists():
        return video, srt
    stem = re.sub(r" \(\d+\)$", "", video.stem)
    for n in range(2, 1000):
        candidate = video.with_name(f"{stem} ({n}){video.suffix}")
        sidecar = candidate.with_suffix(".srt")
        if not candidate.exists() and not sidecar.exists():
            return candidate, sidecar
    return video, srt


def _tail(text: str) -> str:
    lines = [ln.strip() for ln in str(text or "").splitlines() if ln.strip()]
    return lines[-1][:400] if lines else ""
