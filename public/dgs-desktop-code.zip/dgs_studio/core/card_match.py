"""Match the text printed on each card against the script, for English and Marathi.

Port of ``frontend/src/cardTextQa.ts``. The browser version skips Devanagari
scenes; here a scene's words are its English words plus its Devanagari words,
so English chapters score exactly as before and Marathi cards are matched too.

Devanagari words are compared after removing the halant, nukta, danda and
zero-width joiners and treating chandrabindu as anusvara, because Tesseract
often drops or adds those marks (``पिवळ्या`` reads as ``पिवळया``).

A card is flagged only on positive proof: its text fits a *different* script
line (or the blank/answer partner of its own line) far better than its own.
Cards whose lettering OCR cannot read never raise a bubble.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

DEVANAGARI_RE = re.compile("[\u0900-\u097F]")
_DIGITS_RE = re.compile("^[\u0966-\u096F0-9]+$")
_TOKEN_RE = re.compile("[\u0900-\u097F]+|[\u0600-\u06FF]+|[^\\W_]+(?:'[^\\W_]+)?")
_DEV_DROP = re.compile("[\u094D\u093C\u0964\u0965\u200C\u200D\u0966-\u096F]")

EN_FUNCTION_WORDS = {
    "the", "and", "for", "are", "but", "not", "you", "all", "any", "can", "had",
    "her", "was", "one", "our", "out", "has", "his", "how", "its", "let", "may",
    "new", "now", "old", "see", "two", "way", "who", "boy", "did", "get", "him",
    "man", "put", "say", "she", "too", "use", "that", "with", "have", "this",
    "will", "your", "from", "they", "know", "want", "been", "good", "much",
    "some", "time", "very", "when", "come", "here", "just", "like", "long",
    "make", "many", "more", "only", "over", "such", "take", "than", "them",
    "well", "were", "what", "into", "there", "their", "about", "would", "these",
    "other", "words", "which", "could", "write", "first", "water", "after",
    "where", "right", "think", "three", "years", "place", "sound", "great",
    "again", "still", "every", "small", "found", "those", "never",
    "mishka", "om",
}

_MR_FUNCTION_RAW = [
    "आणि", "व", "हे", "ही", "हा", "ते", "ती", "तो", "या", "आहे", "आहेत", "होते", "होता", "होती",
    "की", "ना", "तर", "पण", "म्हणजे", "मध्ये", "ला", "ने", "चा", "ची", "चे", "च्या", "एक", "काय",
    "का", "जणू", "उदा", "किंवा", "त्या", "त्याचे", "त्याची", "आपण", "आम्ही", "तुम्ही", "मी", "तू",
    "कसे", "कशी", "कोण", "कुठे", "नाही", "सर्व", "खूप", "आता", "पुढे", "येथे", "तेथे", "असे", "अशी",
]

META_NOTE_PATTERNS = [
    "no on-screen",
    "no onscreen",
    "no additional text",
    "image illustrates",
    "six insect drawings",
    "dotted blanks underneath",
    "observe the pictures",
    "instrumental",
]


def dev_norm(word: str) -> str:
    return _DEV_DROP.sub("", word).replace("\u0901", "\u0902")


MR_FUNCTION_WORDS = {dev_norm(w) for w in _MR_FUNCTION_RAW}


def _is_dev(word: str) -> bool:
    return bool(word) and "\u0900" <= word[0] <= "\u097F"


def tokens(text: str) -> list[str]:
    text = (text or "").replace("\u200C", "").replace("\u200D", "")
    return [t.lower() for t in _TOKEN_RE.findall(text)]


def eng_words(text: str) -> list[str]:
    out = []
    for t in tokens(text):
        clean = re.sub("[^a-z]", "", t.lower())
        if len(clean) >= 2 and not _DIGITS_RE.match(clean):
            out.append(clean)
    return out


def dev_words(text: str) -> list[str]:
    out = []
    for t in tokens(text):
        if not DEVANAGARI_RE.match(t):
            continue
        w = dev_norm(t)
        if len(w) >= 2:
            out.append(w)
    return out


def _dev_compact(text: str) -> str:
    return dev_norm("".join(ch for ch in (text or "") if "\u0900" <= ch <= "\u097F"))


def clean_expected_card_text(raw: str) -> str:
    text = (raw or "").strip()
    if not text or text in ("—", "-", "–", "None", "none", "N/A"):
        return ""
    low = text.lower()
    if any(p in low for p in META_NOTE_PATTERNS):
        return ""
    return re.sub(r"\b(top|bottom|left|right)\s+row\s*:\s*", " ", text, flags=re.I | re.A).strip()


def has_blank_placeholder(text: str) -> bool:
    return bool(text) and bool(re.search(r"(\.{3,}|_{3,}|…{2,}|\[blank\])", text, re.I))


def ocr_has_visual_blank(ocr: str) -> bool:
    if not ocr:
        return False
    if re.search(r"(\.{4,}|_{4,})", ocr):
        return True
    for tok in ocr.split():
        clean = re.sub("[^a-zA-Z0-9@]", "", tok)
        if len(clean) >= 7:
            c = sum(1 for ch in clean.lower() if ch in "oce09@s")
            if c / len(clean) >= 0.8:
                return True
    return False


def card_same(a: str, b: str) -> bool:
    if not a or not b:
        return False
    if a == b:
        return True
    if min(len(a), len(b)) >= 4 and abs(len(a) - len(b)) <= 1 and (b in a or a in b):
        return True
    if len(a) >= 5 and len(b) >= 4 and abs(len(a) - len(b)) <= 2:
        if a[1:] == b or b[1:] == a or a[:-1] == b or b[:-1] == a:
            return True
        mid = a[1:-1]
        if mid and (mid in b or b in mid):
            return True
    return False


def clean_ocr_preview(ocr: str) -> str:
    keep = {"a", "i", "to", "in", "on", "at", "of", "or", "is", "it", "my", "no", "so", "up", "we", "go", "do", "om", "an", "by", "he", "me", "oh"}
    words = []
    for tok in (ocr or "").split():
        alnum = re.sub("[^a-zA-Z0-9\u0900-\u097F]", "", tok)
        if len(alnum) >= 7:
            c = sum(1 for ch in alnum.lower() if ch in "oce09@s")
            if c / len(alnum) >= 0.8:
                words.append("............")
                continue
        if DEVANAGARI_RE.search(tok):
            if len(alnum) >= 2:
                words.append(tok)
            continue
        alpha = re.sub("[^a-zA-Z'-]", "", tok)
        if len(alpha) >= 3 or alpha.lower() in keep:
            words.append(tok)
    preview = " ".join(words)
    return preview[:160] if preview else "(no readable text on card)"


# Profiles --------------------------------------------------------------------


@dataclass
class Profile:
    screen: str
    ost: str
    words: list[str]
    blank: bool
    answer_words: list[str] = field(default_factory=list)
    counterpart: str | None = None


@dataclass
class Ocr:
    words: list[str]
    compact: str
    dev_compact: str
    visual_blank: bool
    raw: str


def prep_ocr(raw: str) -> Ocr:
    raw = raw or ""
    return Ocr(
        words=eng_words(raw) + dev_words(raw),
        compact=re.sub("[^a-z]", "", raw.lower()),
        dev_compact=_dev_compact(raw),
        visual_blank=ocr_has_visual_blank(raw),
        raw=raw,
    )


def word_in_ocr(want: str, o: Ocr) -> bool:
    w = want.lower().strip()
    if not w:
        return True
    if any(card_same(w, g) for g in o.words):
        return True
    compact = o.dev_compact if _is_dev(w) else o.compact
    if len(w) >= 3 and w in compact:
        return True
    if len(w) >= 4 and w[1:] in compact:
        return True
    return False


def _profile_words(ost: str) -> list[str]:
    seen: dict[str, None] = {}
    for w in eng_words(ost):
        if len(w) >= 3:
            seen.setdefault(w)
    for w in dev_words(ost):
        seen.setdefault(w)
    return list(seen)


def build_profiles(scenes: list[dict]) -> dict[str, Profile]:
    base = []
    for s in scenes:
        ost = clean_expected_card_text(str(s.get("onscreen_text") or ""))
        base.append(Profile(
            screen=str(s.get("screen") or ""),
            ost=ost,
            words=_profile_words(ost),
            blank=has_blank_placeholder(str(s.get("onscreen_text") or "")),
        ))
    # Pair each fill-in-the-blank prompt with the nearest following answer slide.
    for i, b in enumerate(base):
        if not b.blank or len(b.words) < 2:
            continue
        for a in base[i + 1:i + 4]:
            if a.blank or not a.words:
                continue
            shared = sum(1 for w in b.words if w in a.words)
            extra = [w for w in a.words if w not in b.words]
            if shared >= max(2, len(b.words) - 1) and extra:
                b.counterpart, a.counterpart = a.screen, b.screen
                b.answer_words = extra
                a.answer_words = extra
                break
    return {p.screen: p for p in base}


def _vocab_len(w: str) -> int:
    return 3 if _is_dev(w) else 4


def build_vocab(profiles: dict[str, Profile]) -> set[str]:
    return {w for p in profiles.values() for w in p.words if len(w) >= _vocab_len(w)}


def fit(p: Profile, o: Ocr, vocab: set[str]) -> float:
    """0..1: how well an OCR'd picture fits a script line."""
    if len(p.words) < 2:
        return 0.0
    matched = sum(1 for w in p.words if word_in_ocr(w, o))
    score = matched / len(p.words)
    own = set(p.words)
    extras = 0
    for w in set(o.words):
        if len(w) >= _vocab_len(w) and w not in own and w in vocab and w not in EN_FUNCTION_WORDS and w not in MR_FUNCTION_WORDS:
            extras += 1
    score -= min(0.5, extras * 0.12)
    if p.answer_words:
        def seen(w: str) -> bool:
            compact = o.dev_compact if _is_dev(w) else o.compact
            return word_in_ocr(w, o) or (len(w) >= 5 and w[:4] in compact)

        ans_seen = any(seen(w) for w in p.answer_words)
        if p.blank:
            if ans_seen:
                score -= 0.5
            elif o.visual_blank:
                score += 0.05
        elif not ans_seen and o.visual_blank:
            score -= 0.5
    return max(0.0, min(1.0, score))


@dataclass
class Evidence:
    belongs_to: Profile
    cur: float
    other: float
    kind: str  # other_scene | answer_shown | blank_shown


def coverage(p: Profile, o: Ocr) -> float:
    """Share of the line's own words printed on the card (no penalties)."""
    if not p.words:
        return 0.0
    return sum(1 for w in p.words if word_in_ocr(w, o)) / len(p.words)


def mismatch_evidence(p: Profile, o: Ocr, profiles: dict[str, Profile], vocab: set[str]) -> Evidence | None:
    # No expected card text means nothing to prove a mismatch against.
    if len(p.words) < 2:
        return None
    cur = fit(p, o, vocab)
    if cur >= 0.8:
        return None
    best, best_fit = None, 0.0
    for q in profiles.values():
        if q.screen == p.screen or len(q.words) < 3 or q.ost.lower() == p.ost.lower():
            continue
        f = fit(q, o, vocab)
        if f > best_fit:
            best, best_fit = q, f
    if not best or best_fit < 0.75 or best_fit < cur + 0.3:
        return None
    kind = "other_scene"
    if p.counterpart == best.screen:
        kind = "answer_shown" if p.blank else "blank_shown"
    if kind == "other_scene" and not _proves_other_line(p, best, o):
        return None
    return Evidence(best, cur, best_fit, kind)


def _share_on_card(words: list[str], o: Ocr) -> float:
    return sum(1 for w in words if word_in_ocr(w, o)) / len(words) if words else 0.0


def _proves_other_line(p: Profile, q: Profile, o: Ocr) -> bool:
    """The card must carry q's own words and not p's own words.

    Rules out build-up cards (the whole line is still printed), answer cards
    that repeat their question, and lines that quote a shorter line.
    """
    if coverage(p, o) >= 0.9:
        return False
    fw = EN_FUNCTION_WORDS | MR_FUNCTION_WORDS
    q_only = [w for w in q.words if w not in p.words and w not in fw]
    if not q_only or _share_on_card(q_only, o) < 0.5:
        return False
    p_only = [w for w in p.words if w not in q.words and w not in fw]
    return not (p_only and _share_on_card(p_only, o) >= 0.5)


# Issues and swaps ------------------------------------------------------------


def _image_no(screen: str) -> int | None:
    m = re.search(r"(\d+)$", screen or "")
    return int(m.group(1)) if m else None


def _label(screen: str) -> str:
    n = _image_no(screen)
    return f"Scene {n if n is not None else screen.replace('screen_', '')}"


def _tc(sec: float) -> str:
    s = max(0, int(sec or 0))
    return f"{s // 60:02d}:{s % 60:02d}"


def _image_clips(clips: list[dict]):
    for c in clips:
        if c.get("fit") == "missing" or (c.get("kind") or "") != "image" or not c.get("media_id"):
            continue
        yield c


def build_card_text_issues(clips: list[dict], scenes: list[dict], ocr_texts: dict[str, str]) -> list[dict]:
    profiles = build_profiles(scenes)
    vocab = build_vocab(profiles)
    by_screen = {str(s.get("screen")): s for s in scenes}
    issues, seen = [], set()
    for clip in _image_clips(clips):
        screen = str(clip.get("screen") or "")
        scene, p = by_screen.get(screen), profiles.get(screen)
        raw = ocr_texts.get(str(clip["media_id"]))
        if not scene or not p or raw is None:
            continue
        key = f"{screen}|{clip['media_id']}"
        if key in seen:
            continue
        seen.add(key)
        ev = mismatch_evidence(p, prep_ocr(raw), profiles, vocab)
        if not ev:
            continue
        start, end = float(clip.get("start") or 0), float(clip.get("end") or 0)
        tc = f"{_tc(start)}–{_tc(end)}"
        pic = clip.get("filename") or f"Image {_image_no(screen)}"
        line = ev.belongs_to.ost[:90]
        if ev.kind == "answer_shown":
            detail = f'This is a fill-in-the-blank line, but {pic} already shows the answer ("{line}") — that picture belongs to {_label(ev.belongs_to.screen)}.'
        elif ev.kind == "blank_shown":
            detail = f'VO gives the answer here, but {pic} still shows the blank ("{line}") — that picture belongs to {_label(ev.belongs_to.screen)}.'
        else:
            detail = f'{pic} shows {_label(ev.belongs_to.screen)}\'s line ("{line}"), not this scene\'s line.'
        issues.append({
            "kind": "card_text",
            "severity": "warning",
            "screen": screen,
            "image_no": _image_no(screen),
            "time": start,
            "end": end,
            "timecode": tc,
            "message": f"{_label(screen)} ({tc}): {detail}",
            "expected": (p.ost or str(scene.get("voiceover_text") or ""))[:180],
            "found": clean_ocr_preview(raw)[:180],
            "missing_words": [],
            "source": "ocr_native",
        })
    return issues


_MATRA_RE = re.compile("[\u093E-\u094C\u0962\u0963]")
_BASE_DROP = re.compile("[\u093E-\u094C\u094D\u093C\u0901\u0902\u0903\u0962\u0963]")


def _dev_base(word: str) -> str:
    return _BASE_DROP.sub("", dev_norm(word))


def _matra_seq(word: str) -> str:
    return "".join(_MATRA_RE.findall(word))


def build_matra_issues(clips: list[dict], scenes: list[dict], ocr_texts: dict[str, str], skip_screens: set[str] | None = None) -> list[dict]:
    """A card shows a different vowel sign on a word that otherwise matches the narration.

    A matra the reader simply failed to see is not flagged. Both the script word
    and the card word must contain a vowel sign, and the rest of the line must
    still match this scene.
    """
    skip = skip_screens or set()
    by_screen = {str(s.get("screen")): s for s in scenes}
    issues = []
    for clip in _image_clips(clips):
        screen = str(clip.get("screen") or "")
        if screen in skip:
            continue
        scene = by_screen.get(screen)
        raw = ocr_texts.get(str(clip.get("media_id") or ""))
        if not scene or raw is None:
            continue
        script = dev_words(str(scene.get("voiceover_text") or scene.get("onscreen_text") or ""))
        seen = prep_ocr(raw)
        card = [w for w in seen.words if DEVANAGARI_RE.match(w)]
        bases = [_dev_base(w) for w in script]
        strong = [b for b in bases if len(b) >= 2]
        if len(strong) < 2 or not card:
            continue
        card_bases = {_dev_base(w) for w in card}
        if sum(1 for b in strong if b in card_bases) / len(strong) < 0.6:
            continue
        pairs = []
        used: set[int] = set()
        for sw in script:
            base, matra = _dev_base(sw), _matra_seq(sw)
            if len(base) < 2 or not matra:
                continue
            for i, ow in enumerate(card):
                if i in used or _dev_base(ow) != base:
                    continue
                other = _matra_seq(ow)
                if other and other != matra:
                    pairs.append((sw, ow))
                    used.add(i)
                    break
        if not pairs:
            continue
        start, end = float(clip.get("start") or 0), float(clip.get("end") or 0)
        tc = f"{_tc(start)}–{_tc(end)}"
        shown = ", ".join(f'"{a}" → "{b}"' for a, b in pairs[:4])
        issues.append({
            "kind": "card_text",
            "severity": "warning",
            "screen": screen,
            "image_no": _image_no(screen),
            "time": start,
            "end": end,
            "timecode": tc,
            "message": f"{_label(screen)} ({tc}): Wrong matra on the card — narration has {shown}.",
            "expected": str(scene.get("voiceover_text") or "")[:180],
            "found": clean_ocr_preview(raw)[:180],
            "missing_words": [],
            "source": "ocr_native",
        })
    return issues


_SWAP_KEYS = ("media_id", "media_path", "filename", "kind", "fit")


@dataclass
class AutoMatch:
    screen: str
    from_id: str
    to: dict  # {id, filename, path}
    score: float


def propose_auto_matches(clips: list[dict], scenes: list[dict], images: list[dict], ocr_texts: dict[str, str]) -> list[AutoMatch]:
    """Clear-cut picture swaps only. Pictures on correct scenes are never moved."""
    profiles = build_profiles(scenes)
    vocab = build_vocab(profiles)
    ocr_by_id = {img["id"]: prep_ocr(ocr_texts[img["id"]]) for img in images if img["id"] in ocr_texts}

    suspects: list[tuple[str, str, float]] = []
    for c in _image_clips(clips):
        screen, mid = str(c.get("screen") or ""), str(c["media_id"])
        p, o = profiles.get(screen), ocr_by_id.get(mid) or (prep_ocr(ocr_texts[mid]) if mid in ocr_texts else None)
        if not p or not o or any(s[0] == screen for s in suspects):
            continue
        ev = mismatch_evidence(p, o, profiles, vocab)
        if ev:
            suspects.append((screen, mid, ev.cur))
    if not suspects:
        return []

    suspect_screens = {s[0] for s in suspects}
    used_on_good = {str(c["media_id"]) for c in clips if c.get("media_id") and str(c.get("screen")) not in suspect_screens}
    pool = [img for img in images if img["id"] in ocr_by_id and img["id"] not in used_on_good]

    proposals = []
    for screen, cur_id, cur in suspects:
        p = profiles[screen]
        scored = sorted(((img, fit(p, ocr_by_id[img["id"]], vocab)) for img in pool), key=lambda x: -x[1])
        if not scored:
            continue
        best_img, best_f = scored[0]
        if best_img["id"] == cur_id or best_f < 0.8 or best_f < cur + 0.3:
            continue
        if len(scored) > 1 and scored[1][1] > best_f - 0.15:
            continue
        proposals.append(AutoMatch(screen, cur_id, best_img, best_f))
    proposals.sort(key=lambda m: -m.score)
    taken, out = set(), []
    for m in proposals:
        if m.to["id"] in taken:
            continue
        taken.add(m.to["id"])
        out.append(m)
    return out


def apply_auto_matches(clips: list[dict], matches: list[AutoMatch]) -> list[dict]:
    """Swap every clip of the scene that showed the wrong picture. Returns the undo list."""
    by_screen = {m.screen: m for m in matches}
    undo = []
    for i, c in enumerate(clips):
        m = by_screen.get(str(c.get("screen") or ""))
        if not m or str(c.get("media_id") or "") != m.from_id:
            continue
        undo.append({"index": i, "screen": c.get("screen"), "had": {k: k in c for k in _SWAP_KEYS},
                     **{k: c.get(k) for k in _SWAP_KEYS}})
        c["media_id"] = m.to["id"]
        c["media_path"] = m.to.get("path")
        c["filename"] = m.to.get("filename")
        c["kind"] = "image"
        c["fit"] = "hold"
    return undo


def undo_auto_matches(clips: list[dict], undo: list[dict]) -> int:
    n = 0
    for u in undo:
        i = int(u.get("index", -1))
        if not (0 <= i < len(clips)) or clips[i].get("screen") != u.get("screen"):
            continue
        c = clips[i]
        for k in _SWAP_KEYS:
            if u["had"].get(k):
                c[k] = u.get(k)
            else:
                c.pop(k, None)
        n += 1
    return n


def script_looks_indic(scenes: list[dict]) -> bool:
    sample = " ".join(
        f"{s.get('voiceover_text') or ''} {s.get('onscreen_text') or ''} {s.get('text') or ''}" for s in scenes[:40]
    )
    return len(DEVANAGARI_RE.findall(sample)) >= 12
