"""Deep VO + card QA: spelling, missing/extra card words, words said wrongly.

Port of ``frontend/src/voAndCardDeepQa.ts`` ``buildDeepVoAndCardIssues``.
English chapters only. Marathi / Devanagari is skipped so English Whisper
never scores those cards. Half-eaten-word bubbles need waveform RMS at the
cut; without that energy they are not raised (no false positives).
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from . import card_match
from .card_match import EN_FUNCTION_WORDS, clean_expected_card_text, eng_words, has_blank_placeholder, word_in_ocr
from .plan import scene_label

KNOWN_TYPOS = {
    "caterpiller": "caterpillar",
    "caterpillers": "caterpillars",
    "catapillar": "caterpillar",
    "catapilla": "caterpillar",
    "taxy": "taxi",
    "mosqito": "mosquito",
    "mosquitos": "mosquitoes",
    "buterfly": "butterfly",
    "butterfy": "butterfly",
    "colision": "collision",
    "collison": "collision",
    "vehical": "vehicle",
    "vehicals": "vehicles",
    "obstacels": "obstacles",
    "obsticles": "obstacles",
    "convesation": "conversation",
    "conversaton": "conversation",
    "cleanlines": "cleanliness",
    "imortance": "importance",
    "importence": "importance",
    "diffrent": "different",
    "beautifull": "beautiful",
    "sentenses": "sentences",
    "picturs": "pictures",
    "creatur": "creatures",
    "insecst": "insects",
    "folow": "follow",
    "mornig": "morning",
    "gardn": "garden",
    "colourfull": "colourful",
    "colorfull": "colorful",
}

VALID_WORDS = set(EN_FUNCTION_WORDS) | {
    "mishka", "om", "jane", "lear", "talley", "tally", "suno", "balbharati", "sundharam",
    "garden", "walk", "walks", "walking", "ready", "like", "likes", "observe", "creatures",
    "because", "learn", "live", "move", "moves", "moving", "think", "insects", "insect",
    "follow", "following", "rules", "while", "human", "traffic", "their", "senses", "help",
    "around", "obstacles", "other", "read", "enjoy", "summer", "time", "street", "many",
    "bugs", "bug", "run", "down", "with", "tiny", "little", "feet", "ants", "ant", "shiny",
    "taxi", "cabs", "cab", "fast", "comes", "caterpillar", "bus", "slow", "travels", "past",
    "sure", "must", "some", "very", "special", "vision", "never", "seen", "mobile",
    "collision", "path", "inside", "here", "that", "behaves", "vehicle", "vehicles",
    "things", "bumping", "into", "each", "baby", "butterfly", "butterflies", "pictures",
    "write", "name", "names", "mosquito", "fly", "frame", "sentences", "using", "given",
    "words", "along", "leaf", "find", "colourful", "colorful", "flowers", "flower", "crawl",
    "green", "stem", "imagine", "draw", "your", "own", "city", "showing", "different",
    "types", "poet", "uses", "describe", "short", "paragraph", "express", "views",
    "beautiful", "near", "school", "trees", "tree", "every", "morning", "watch", "birds",
    "bird", "harm", "keep", "clean", "water", "plants", "plant", "complete", "conversation",
    "look", "looks", "busy", "right", "those", "will", "bump", "teacher", "highlight",
    "importance", "nature", "cleanliness", "caring", "motivate", "them", "underneath",
    "dotted", "blanks", "drawings", "illustrates", "additional", "bottom", "possible",
    "answer", "question", "heading", "lyrics", "subtitles", "screen", "scene",
}

EQUIV = {
    "colorful": "colourful", "colourful": "colourful",
    "tally": "talley", "talley": "talley",
    "leer": "lear", "lea": "lear", "lear": "lear",
    "catapilla": "caterpillar", "caterpiller": "caterpillar", "taxy": "taxi",
}

HOMOPHONES = {
    ("ant", "and"), ("and", "ant"),
    ("lear", "lea"), ("lea", "lear"), ("lear", "leer"), ("leer", "lear"),
    ("talley", "tally"), ("tally", "talley"),
    ("its", "it"), ("it", "its"),
}


def _canon(w: str) -> str:
    clean = re.sub("[^a-z]", "", (w or "").lower())
    return EQUIV.get(clean) or KNOWN_TYPOS.get(clean) or clean


def _edit(a: str, b: str) -> int:
    if a == b:
        return 0
    if abs(len(a) - len(b)) > 2:
        return 3
    dp = list(range(len(a) + 1))
    for j, cb in enumerate(b, 1):
        prev, dp[0] = dp[0], j
        for i, ca in enumerate(a, 1):
            tmp = dp[i]
            dp[i] = prev if ca == cb else 1 + min(prev, dp[i], dp[i - 1])
            prev = tmp
    return dp[-1]


def _phonetic(a: str, b: str) -> bool:
    raw_a, raw_b = re.sub("[^a-z]", "", a.lower()), re.sub("[^a-z]", "", b.lower())
    if (raw_a, raw_b) in HOMOPHONES:
        return True
    ca, cb = _canon(raw_a), _canon(raw_b)
    if not ca or not cb:
        return False
    if ca == cb or (ca, cb) in HOMOPHONES:
        return True
    if min(len(ca), len(cb)) >= 4 and _edit(ca, cb) <= 1:
        return True
    return min(len(ca), len(cb)) >= 3 and (ca + "s" == cb or cb + "s" == ca)


def _vo_tokens(text: str) -> list[str]:
    out = []
    for m in re.findall(r"[a-z]+(?:'[a-z]+)?", (text or "").lower()):
        clean = re.sub("[^a-z]", "", m)
        if len(clean) >= 2 or clean in ("a", "i"):
            out.append(clean)
    return out


def _raw_alpha(text: str) -> list[str]:
    return [w for w in re.split(r"[^A-Za-z]+", text or "") if len(w.strip()) >= 2]


def _tc(sec: float) -> str:
    s = max(0, int(sec or 0))
    return f"{s // 60:02d}:{s % 60:02d}"


def load_heard_words(project) -> list[dict]:
    plan = project.plan if project else {}
    for key in ("heard_vo_words", "align_words", "words"):
        raw = plan.get(key)
        if isinstance(raw, list) and raw:
            return [w for w in raw if isinstance(w, dict) and w.get("text")]
    root = getattr(project, "root", None)
    if not root:
        return []
    path = Path(root) / "meta" / "heard_words.json"
    if not path.is_file():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    raw = data.get("vo") if isinstance(data, dict) else data
    return [w for w in (raw or []) if isinstance(w, dict) and w.get("text")]


def _typos(words: list[str], vocab: set[str]) -> list[tuple[str, str]]:
    found, seen = [], set()
    for raw in words:
        w = raw.lower()
        if len(w) < 4 or w in seen:
            continue
        seen.add(w)
        if w in KNOWN_TYPOS:
            found.append((raw, KNOWN_TYPOS[w]))
            continue
        if w in VALID_WORDS or w in vocab:
            continue
        match = next((c for c in vocab if len(c) >= 5 and abs(len(c) - len(w)) <= 1 and _edit(w, c) == 1), None)
        if match:
            found.append((raw, match))
    return found


def build_deep_vo_and_card_issues(
    clips: list[dict],
    scenes: list[dict],
    ocr_texts: dict[str, str],
    already_flagged: set[str] | None = None,
    asr_words: list[dict] | None = None,
) -> list[dict]:
    if not scenes or card_match.script_looks_indic(scenes):
        return []
    flagged = already_flagged or set()
    issues: list[dict] = []
    by_screen = {str(s.get("screen")): s for s in scenes}
    scene_index = {str(s.get("screen")): i for i, s in enumerate(scenes)}
    vocab = set(VALID_WORDS)
    for w in asr_words or []:
        clean = re.sub("[^a-z]", "", str(w.get("text") or "").lower())
        if len(clean) >= 4 and clean not in KNOWN_TYPOS:
            vocab.add(clean)
    chapter_vocab = set()
    for s in scenes:
        for w in eng_words(f"{s.get('voiceover_text') or ''} {s.get('onscreen_text') or ''}"):
            if len(w) >= 4:
                chapter_vocab.add(w)
    seen: set[str] = set()
    skip = {"mishka", "om", "teacher", "top", "bottom", "row"}

    for clip in clips:
        screen = str(clip.get("screen") or "")
        scene = by_screen.get(screen)
        if not scene:
            continue
        sample = f"{scene.get('onscreen_text') or ''}{scene.get('voiceover_text') or ''}"
        if card_match.DEVANAGARI_RE.search(sample):
            continue
        start, end = float(clip.get("start") or 0), float(clip.get("end") or 0)
        tc = f"{_tc(start)}–{_tc(end)}"
        pic = clip.get("filename") or f"Image {card_match._image_no(screen) or screen}"
        raw_ocr = ocr_texts.get(str(clip.get("media_id") or "")) if clip.get("media_id") else None
        ocr = card_match.prep_ocr(raw_ocr or "") if raw_ocr is not None else None
        ocr_words = ocr.words if ocr else []
        ost_clean = clean_expected_card_text(str(scene.get("onscreen_text") or ""))
        vo_text = str(scene.get("voiceover_text") or clip.get("vo_text") or "").strip()
        is_blank = has_blank_placeholder(str(scene.get("onscreen_text") or "")) or has_blank_placeholder(vo_text)

        if (
            screen not in flagged
            and f"{screen}:missing_extra" not in seen
            and clip.get("fit") != "missing"
            and clip.get("kind") == "image"
            and raw_ocr is not None
            and ost_clean
            and not is_blank
            and not scene.get("is_poem")
            and ocr is not None
        ):
            vo_content = [w for w in eng_words(vo_text) if len(w) >= 3 and w not in skip]
            ost_words = [w for w in eng_words(ost_clean) if len(w) >= 3 and w not in skip]
            readable = [w for w in ost_words if word_in_ocr(w, ocr)]
            if len(readable) >= 3:
                ost_set = {_canon(w) for w in ost_words}
                vo_set = {_canon(w) for w in vo_content}
                missing_vs_vo = [
                    w for w in vo_content
                    if len(w) >= 4 and w not in EN_FUNCTION_WORDS and _canon(w) not in ost_set and not word_in_ocr(w, ocr)
                ]
                missing_ocr = [w for w in vo_content if len(w) >= 4 and w not in EN_FUNCTION_WORDS and not word_in_ocr(w, ocr)]
                effective_missing = list(dict.fromkeys(missing_vs_vo)) or (list(dict.fromkeys(missing_ocr)) if len(missing_ocr) >= 3 else [])
                extra = [
                    w for w in ost_words
                    if len(w) >= 3 and _canon(w) not in vo_set and word_in_ocr(w, ocr)
                ]
                if effective_missing or extra:
                    seen.add(f"{screen}:missing_extra")
                    parts = []
                    if effective_missing:
                        parts.append(f'Missing text in {pic} as per VO: "{", ".join(effective_missing)}"')
                    if extra:
                        parts.append(f'Word{"s" if len(extra) != 1 else ""} in {pic} not in VO: "{", ".join(dict.fromkeys(extra))}"')
                    issues.append(_bubble(clip, screen, tc, f"{scene_label(screen)} ({tc}): {' · '.join(parts)}.", vo_text, ost_clean or raw_ocr, "card_text"))

        if f"{screen}:spelling" not in seen:
            typos = _typos(_raw_alpha(ost_clean) + _raw_alpha(vo_text) + ocr_words, vocab | chapter_vocab)
            if typos:
                seen.add(f"{screen}:spelling")
                ost_low = {w.lower() for w in _raw_alpha(ost_clean)}
                on_card = clip.get("kind") == "image" and any(
                    t[0].lower() in ost_low or (ocr and word_in_ocr(t[0], ocr)) for t in typos
                )
                desc = ", ".join(f'"{w}" → "{r}"' for w, r in typos)
                issues.append(_bubble(
                    clip, screen, tc,
                    f"{scene_label(screen)} ({tc}): Spelling mistake {'on ' + str(pic) if on_card else 'in script'} — {desc}.",
                    f'Correct spelling: "{", ".join(r for _, r in typos)}"',
                    ost_clean if on_card else vo_text or ost_clean,
                    "card_text",
                ))

        nin, nout = clip.get("narration_in"), clip.get("narration_out")
        try:
            nin_f, nout_f = (float(nin), float(nout)) if nin is not None and nout is not None else (None, None)
        except (TypeError, ValueError):
            nin_f = nout_f = None
        if (
            f"{screen}:vo" not in seen
            and asr_words
            and nin_f is not None
            and nout_f is not None
            and nout_f > nin_f + 0.2
            and not scene.get("is_poem")
            and vo_text
        ):
            spoken = [w for w in asr_words if float(w.get("end") or 0) > nin_f + 0.06 and float(w.get("start") or 0) < nout_f - 0.06]
            spoken_text = " ".join(str(w.get("text") or "") for w in spoken).strip()
            exp, spk = _vo_tokens(vo_text), _vo_tokens(spoken_text)
            if len(spoken) >= 2 and len(exp) >= 3 and len(spk) >= 2:
                unexpected = [sw for sw in spk if not any(_phonetic(sw, ew) for ew in exp)]
                missing = [ew for ew in exp if not any(_phonetic(ew, sw) for sw in spk)]
                if unexpected and missing:
                    wrong, right = unexpected[0], missing[0]
                    i = scene_index.get(screen, 0)
                    adj = set(_vo_tokens(f"{scenes[i - 1].get('voiceover_text') if i else ''} {scenes[i + 1].get('voiceover_text') if i + 1 < len(scenes) else ''}"))
                    if wrong not in adj or (len(exp) <= 7 and len(spk) == len(exp)):
                        seen.add(f"{screen}:vo")
                        issues.append(_bubble(
                            clip, screen, tc,
                            f'{scene_label(screen)} ({tc}): Word said wrongly in VO — speaker says "{wrong}" instead of "{right}" ("{spoken_text}").',
                            vo_text, f'Spoken in VO: "{spoken_text}"', "vo_mismatch",
                        ))
    return issues


def _bubble(clip: dict, screen: str, tc: str, message: str, expected: str, found: str, kind: str) -> dict:
    return {
        "kind": kind,
        "severity": "warning",
        "screen": screen,
        "time": float(clip.get("start") or 0),
        "end": float(clip.get("end") or 0),
        "timecode": tc,
        "message": message,
        "expected": (expected or "")[:180],
        "found": (found or "")[:180],
        "source": "ocr_native",
    }


def save_heard_words(root: Path, vo: list | None, poem: list | None) -> None:
    path = Path(root) / "meta" / "heard_words.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"vo": vo or [], "poem": poem or []}, ensure_ascii=False), encoding="utf-8")
