"""Video 1 and voice-lane edits. Port of ``TimelineEditor.tsx`` + ``voPieces.ts``.

Picture edits never move the VO. Voice edits never move the pictures.
"""

from __future__ import annotations

import copy
from pathlib import Path


def r3(n: float) -> float:
    return round(float(n) * 1000) / 1000


def snapshot(plan: dict) -> dict:
    return copy.deepcopy(plan)


def apply_clips(plan: dict, clips: list[dict]) -> dict:
    cleaned = []
    for c in clips:
        start = max(0.0, r3(c.get("start") or 0))
        end = max(start + 0.2, r3(c.get("end") or start + 0.2))
        cleaned.append({**c, "start": start, "end": end, "duration": r3(end - start)})
    cleaned.sort(key=lambda c: float(c.get("start") or 0))
    max_clip = max((float(c["end"]) for c in cleaned), default=0.0)
    segs = plan.get("narration_segments") or []
    max_narr = max((float(s.get("end") or 0) for s in segs), default=0.0)
    plan["clips"] = cleaned
    plan["manual_override"] = True
    plan["total_duration"] = max(float(plan.get("total_duration") or 0), max_clip, max_narr)
    return plan


def resolve_overwrites(clips: list[dict], active_idx: int, new_start: float, new_end: float) -> list[dict]:
    active = {**clips[active_idx], "start": new_start, "end": new_end, "duration": max(0.2, new_end - new_start)}
    out = []
    for i, c in enumerate(clips):
        if i == active_idx:
            out.append(active)
            continue
        a, b = float(c.get("start") or 0), float(c.get("end") or 0)
        if b <= new_start + 0.01 or a >= new_end - 0.01:
            out.append(c)
            continue
        if a >= new_start - 0.02 and b <= new_end + 0.02:
            continue
        if a < new_end and b > new_end + 0.2:
            out.append({**c, "start": new_end, "duration": max(0.2, b - new_end)})
            continue
        if a < new_start - 0.2 and b > new_start:
            out.append({**c, "end": new_start, "duration": max(0.2, new_start - a)})
    out.sort(key=lambda c: float(c.get("start") or 0))
    return out


def _segs(plan: dict) -> list[dict]:
    segs = plan.get("narration_segments")
    return segs if isinstance(segs, list) and segs else list(plan.get("clips") or [])


def delete_clip(plan: dict, idx: int) -> dict:
    clips = list(plan.get("clips") or [])
    if not (0 <= idx < len(clips)):
        return plan
    clips.pop(idx)
    return apply_clips(plan, clips)


def delete_and_elongate_previous(plan: dict, screen: str) -> dict:
    clips = list(plan.get("clips") or [])
    segs = _segs(plan)
    seg = next((s for s in segs if str(s.get("screen")) == screen), None)
    target = next((c for c in clips if str(c.get("screen")) == screen), None)
    cover_end = max(float(seg.get("end") or 0) if seg else 0, float(target.get("end") or 0) if target else 0)
    cover_start = float(seg.get("start") if seg and seg.get("start") is not None else (target.get("start") if target else 0) or 0)
    remaining = [c for c in clips if str(c.get("screen")) != screen]
    prev_idx = -1
    for i, c in enumerate(remaining):
        if float(c.get("start") or 0) < cover_start + 0.05:
            prev_idx = i
    if prev_idx >= 0 and cover_end > float(remaining[prev_idx].get("start") or 0) + 0.2:
        prev = remaining[prev_idx]
        end = max(float(prev.get("end") or 0), cover_end)
        remaining[prev_idx] = {**prev, "end": end, "duration": max(0.2, end - float(prev.get("start") or 0))}
    elif remaining and cover_end > 0:
        first = remaining[0]
        start = min(float(first.get("start") or 0), cover_start)
        remaining[0] = {**first, "start": start, "duration": max(0.2, float(first.get("end") or 0) - start)}
    return apply_clips(plan, remaining)


def elongate_right(plan: dict, idx: int) -> dict:
    clips = list(plan.get("clips") or [])
    if not (0 <= idx < len(clips)):
        return plan
    clip = clips[idx]
    segs = _segs(plan)
    next_seg = next((s for s in segs if float(s.get("end") or 0) > float(clip.get("end") or 0) + 0.08), None)
    next_clip = clips[idx + 1] if idx + 1 < len(clips) else None
    target = float(clip.get("end") or 0) + 2.0
    if next_seg:
        target = float(next_seg.get("end") or target)
    elif next_clip:
        target = float(next_clip.get("end") or target)
    return apply_clips(plan, resolve_overwrites(clips, idx, float(clip.get("start") or 0), target))


def elongate_left(plan: dict, idx: int) -> dict:
    clips = list(plan.get("clips") or [])
    if not (0 <= idx < len(clips)):
        return plan
    clip = clips[idx]
    segs = [s for s in _segs(plan) if float(s.get("start") or 0) < float(clip.get("start") or 0) - 0.08]
    prev_seg = segs[-1] if segs else None
    prev_clip = clips[idx - 1] if idx > 0 else None
    target = max(0.0, float(clip.get("start") or 0) - 2.0)
    if prev_seg:
        target = float(prev_seg.get("start") or target)
    elif prev_clip:
        target = float(prev_clip.get("start") or target)
    return apply_clips(plan, resolve_overwrites(clips, idx, target, float(clip.get("end") or 0)))


def fit_to_vo(plan: dict, idx: int) -> dict:
    clips = list(plan.get("clips") or [])
    if not (0 <= idx < len(clips)):
        return plan
    clip = clips[idx]
    own = next((s for s in _segs(plan) if str(s.get("screen")) == str(clip.get("screen"))), None)
    new_start = min(float(clip.get("start") or 0), float(own.get("start") or 0)) if own else float(clip.get("start") or 0)
    new_end = max(float(clip.get("end") or 0), float(own.get("end") or 0)) if own else float(clip.get("end") or 0)
    prev_end = float(clips[idx - 1].get("end") or 0) if idx > 0 else 0.0
    next_start = float(clips[idx + 1].get("start") or 0) if idx + 1 < len(clips) else float(plan.get("total_duration") or new_end)
    if new_end < next_start - 0.05:
        new_end = next_start
    elif new_start > prev_end + 0.05:
        new_start = prev_end
    return apply_clips(plan, resolve_overwrites(clips, idx, new_start, new_end))


def split_clip(plan: dict, idx: int, at: float) -> dict:
    clips = list(plan.get("clips") or [])
    if not (0 <= idx < len(clips)):
        return plan
    clip = clips[idx]
    a, b = float(clip.get("start") or 0), float(clip.get("end") or 0)
    if at <= a + 0.25 or at >= b - 0.25:
        return plan
    left = {**clip, "end": r3(at), "duration": r3(at - a)}
    right = {**clip, "start": r3(at), "duration": r3(b - at)}
    clips[idx : idx + 1] = [left, right]
    return apply_clips(plan, clips)


def trim_in(plan: dict, idx: int, at: float) -> dict:
    """``[`` — new start at the playhead."""
    clips = list(plan.get("clips") or [])
    if not (0 <= idx < len(clips)):
        return plan
    clip = clips[idx]
    end = float(clip.get("end") or 0)
    start = max(0.0, min(end - 0.25, at))
    src_in = float(clip.get("source_in") or 0)
    if clip.get("kind") == "video":
        clip = {**clip, "source_in": r3(src_in + max(0.0, start - float(clip.get("start") or 0)))}
        clips[idx] = clip
    return apply_clips(plan, resolve_overwrites(clips, idx, start, end))


def trim_out(plan: dict, idx: int, at: float) -> dict:
    """``]`` — new end at the playhead."""
    clips = list(plan.get("clips") or [])
    if not (0 <= idx < len(clips)):
        return plan
    clip = clips[idx]
    start = float(clip.get("start") or 0)
    end = max(start + 0.25, at)
    return apply_clips(plan, resolve_overwrites(clips, idx, start, end))


def replace_media(plan: dict, screen: str, item: dict, *, clip_index: int | None = None) -> dict:
    clips = list(plan.get("clips") or [])
    kind = item.get("kind") or "image"
    fit = "hold" if kind == "image" else "passthrough"
    patch = {
        "media_id": item.get("id"),
        "media_path": item.get("path"),
        "filename": item.get("filename"),
        "kind": kind,
        "fit": fit,
        "manual_media_replace": True,
        "missing_words": [],
    }
    matched = False
    for idx, c in enumerate(clips):
        if not isinstance(c, dict):
            continue
        if (clip_index is not None and idx == clip_index) or (screen and str(c.get("screen")) == screen):
            dur = r3(max(0.2, float(c.get("end") or 0) - float(c.get("start") or 0)))
            clips[idx] = {
                **c,
                **patch,
                "duration": dur,
                "source_in": 0.0,
                "source_out": dur,
            }
            matched = True
    if not matched:
        segs = _segs(plan)
        seg = next((s for s in segs if str(s.get("screen")) == screen), None)
        start = float(seg.get("start") or 0) if seg else 0.0
        end = float(seg.get("end") or start + 3) if seg else start + 3
        clips.append({
            "screen": screen, "start": start, "end": end, "duration": max(0.2, end - start),
            "source_in": 0, "source_out": max(0.2, end - start),
            "script_text": (seg or {}).get("script_text") or "",
            "vo_text": (seg or {}).get("vo_text") or "",
            "narration_in": (seg or {}).get("narration_in"),
            "narration_out": (seg or {}).get("narration_out"),
            **patch,
        })
    return apply_clips(plan, clips)


def commit_vo(plan: dict, pieces: list[dict]) -> dict:
    plan["vo_pieces"] = pieces
    plan["manual_override"] = True
    return plan


def split_vo(plan: dict, piece_id: str, at: float) -> dict:
    pieces = [dict(p) for p in (plan.get("vo_pieces") or [])]
    idx = next((i for i, p in enumerate(pieces) if str(p.get("id")) == piece_id), -1)
    if idx < 0:
        return plan
    piece = pieces[idx]
    a, b = float(piece.get("start") or 0), float(piece.get("end") or 0)
    if at <= a + 0.12 or at >= b - 0.12:
        return plan
    span = b - a
    src_in, src_out = float(piece.get("source_in") or 0), float(piece.get("source_out") or span)
    src_cut = src_in + ((at - a) / span) * (src_out - src_in)
    left = {**piece, "id": f"{piece_id}-L{int(at * 1000)}", "end": r3(at), "source_out": r3(src_cut)}
    right = {**piece, "id": f"{piece_id}-R{int(at * 1000)}", "start": r3(at), "source_in": r3(src_cut)}
    pieces[idx : idx + 1] = [left, right]
    return commit_vo(plan, pieces)


def delete_vo(plan: dict, piece_id: str) -> dict:
    pieces = [p for p in (plan.get("vo_pieces") or []) if str(p.get("id")) != piece_id]
    removed = next((p for p in (plan.get("vo_pieces") or []) if str(p.get("id")) == piece_id), None)
    commit_vo(plan, pieces)
    span = 0.0
    if removed:
        span = float(removed.get("end") or 0) - float(removed.get("start") or 0)
    if 0.05 < span <= 8.0:
        from .repeat_vo import close_long_gaps
        close_long_gaps(plan)
    return plan


def replace_vo_section(
    plan: dict,
    piece_id: str,
    path: str,
    duration: float,
    *,
    tl_start: float | None = None,
    tl_end: float | None = None,
    screen: str | None = None,
) -> dict:
    """Swap the audio for one scene / voice cut. Other scenes keep the master VO.

    Filmora-style chapters often have one long ``vo_pieces`` row for the whole
    file. When ``tl_start``/``tl_end`` mark one scene inside that row, the piece
    is split so only that scene gets ``replace_path``.
    """
    pieces = [dict(p) for p in (plan.get("vo_pieces") or [])]
    idx = next((i for i, p in enumerate(pieces) if str(p.get("id")) == piece_id), -1)
    if idx < 0:
        return plan
    piece = pieces[idx]
    start = float(piece.get("start") or 0)
    end = float(piece.get("end") or start)
    span = max(0.12, end - start)
    src_in = float(piece.get("source_in") or 0)
    src_out = float(piece.get("source_out") or (src_in + span))
    rate = (src_out - src_in) / span if span > 0.001 else 1.0

    # Scene window inside a long master VO → split, replace only the middle.
    use_window = (
        tl_start is not None
        and tl_end is not None
        and float(tl_end) > float(tl_start) + 0.05
        and span >= 8.0
        and float(tl_start) >= start - 0.02
        and float(tl_end) <= end + 0.02
        and (float(tl_end) - float(tl_start)) + 0.35 < span
    )
    if use_window:
        cut_a = max(start, min(end - 0.12, float(tl_start)))
        cut_b = max(cut_a + 0.12, min(end, float(tl_end)))
        room = max(0.12, cut_b - cut_a)
        play = max(0.12, min(room, float(duration or room)))
        mid_end = r3(cut_a + play)
        mid_id = f"{piece_id}-S{int(cut_a * 1000)}"
        mid = {
            **piece,
            "id": mid_id,
            "start": r3(cut_a),
            "end": mid_end,
            "source_in": 0.0,
            "source_out": r3(play),
            "replace_path": str(path),
            "filename": Path(path).name,
        }
        if screen:
            mid["screen"] = screen
        out: list[dict] = []
        if cut_a > start + 0.12:
            left = {
                **{k: v for k, v in piece.items() if k != "replace_path"},
                "id": f"{piece_id}-L{int(cut_a * 1000)}",
                "start": r3(start),
                "end": r3(cut_a),
                "source_in": r3(src_in),
                "source_out": r3(src_in + (cut_a - start) * rate),
            }
            out.append(left)
        out.append(mid)
        if end > mid_end + 0.12:
            right = {
                **{k: v for k, v in piece.items() if k != "replace_path"},
                "id": f"{piece_id}-R{int(mid_end * 1000)}",
                "start": mid_end,
                "end": r3(end),
                "source_in": r3(src_in + (mid_end - start) * rate),
                "source_out": r3(src_out),
            }
            out.append(right)
        pieces[idx : idx + 1] = out
        commit_vo(plan, pieces)
        from .repeat_vo import close_long_gaps

        close_long_gaps(plan)
        return plan

    room = span
    play = max(0.12, min(room, float(duration or room)))
    piece["replace_path"] = str(path)
    piece["filename"] = Path(path).name
    piece["source_in"] = 0.0
    piece["source_out"] = r3(play)
    piece["end"] = r3(start + play)
    if screen:
        piece["screen"] = screen
    pieces[idx] = piece
    commit_vo(plan, pieces)
    from .repeat_vo import close_long_gaps

    close_long_gaps(plan)
    return plan


def trim_vo(plan: dict, piece_id: str, edge: str, at: float) -> dict:
    pieces = [dict(p) for p in (plan.get("vo_pieces") or [])]
    piece = next((p for p in pieces if str(p.get("id")) == piece_id), None)
    if not piece:
        return plan
    slot = int(piece.get("slot") or 1)
    same = sorted((p for p in pieces if p is not piece and int(p.get("slot") or 1) == slot), key=lambda p: float(p.get("start") or 0))
    prev_end = max((float(p.get("end") or 0) for p in same if float(p.get("end") or 0) <= float(piece.get("start") or 0) + 0.02), default=0.0)
    nexts = [float(p.get("start") or 0) for p in same if float(p.get("start") or 0) >= float(piece.get("end") or 0) - 0.02]
    next_start = min(nexts) if nexts else None
    start, end = float(piece.get("start") or 0), float(piece.get("end") or 0)
    src_in, src_out = float(piece.get("source_in") or 0), float(piece.get("source_out") or (end - start))
    span = end - start
    rate = (src_out - src_in) / span if span > 0.001 else 1.0
    if edge == "start":
        start = max(prev_end, min(end - 0.12, at))
        src_in = max(0.0, min(src_out - 0.08, src_in + (start - float(piece.get("start") or 0)) * rate))
    else:
        cap = next_start if next_start is not None else at
        end = max(start + 0.12, min(cap, at))
        src_out = max(src_in + 0.08, src_out + (end - float(piece.get("end") or 0)) * rate)
    for p in pieces:
        if str(p.get("id")) == piece_id:
            p.update(start=r3(start), end=r3(end), source_in=r3(src_in), source_out=r3(src_out))
    return commit_vo(plan, pieces)
