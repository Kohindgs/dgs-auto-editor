"""Write OCR / timeline picture swaps back into the linked source folder.

Port of ``frontend/src/imageRenumber.ts`` ``buildRenamePlan`` + ``renameInFolder``.
Originals are copied once into ``_dgs_backup_originals/``.
"""

from __future__ import annotations

import re
import shutil
from pathlib import Path

from .project_store import IMAGE_EXT


def _scene_no(screen: str) -> int | None:
    m = re.search(r"(\d+)$", str(screen or ""))
    return int(m.group(1)) if m else None


def _renamed(filename: str, n: int) -> str:
    p = Path(filename)
    return f"{n}{p.suffix.lower() or '.png'}"


def image_folder(project) -> Path | None:
    raw = (project.links or {}).get("image_folder") or (project.links or {}).get("source_folder")
    if not raw:
        return None
    p = Path(str(raw))
    if not p.is_dir():
        return None
    for name in ("Scene Images", "scene images", "images", "Images"):
        sub = p / name
        if sub.is_dir():
            return sub
    return p


def remember_folder(project, folder: Path, kind: str | None) -> None:
    folder = folder.resolve()
    project.links["source_folder"] = str(folder if folder.name.lower() not in ("scene images", "scene videos", "images", "videos", "vo") else folder.parent)
    if kind in (None, "images"):
        project.links["image_folder"] = str(folder)
    if kind in (None, "videos"):
        project.links["video_folder"] = str(folder)
    project.dirty = True


def _backup_once(folder: Path, name: str) -> None:
    src = folder / name
    if not src.is_file():
        return
    bak = folder / "_dgs_backup_originals"
    bak.mkdir(exist_ok=True)
    dest = bak / name
    if not dest.exists():
        shutil.copy2(src, dest)


def apply_swaps_to_folder(project, matches) -> list[str]:
    """Rename/copy swapped pictures so ``N.png`` is the picture now on Scene N."""
    folder = image_folder(project)
    if folder is None:
        return []
    notes = []
    used: dict[str, set[str]] = {}
    for c in project.clips:
        mid = str(c.get("media_id") or "")
        if mid:
            used.setdefault(mid, set()).add(str(c.get("screen") or ""))
    for m in matches:
        n = _scene_no(m.screen)
        if n is None:
            continue
        src_name = m.to.get("filename") or ""
        src_path = Path(m.to.get("path") or "")
        if not src_path.is_file():
            continue
        dest_name = _renamed(src_name, n)
        dest = folder / dest_name
        if dest.resolve() == src_path.resolve():
            continue
        _backup_once(folder, dest_name)
        _backup_once(folder, src_name)
        action = "copy" if len(used.get(m.to["id"], set())) > 1 else "rename"
        try:
            if action == "copy":
                shutil.copy2(src_path, dest)
            else:
                # Two-step so A.png ↔ B.png circular swaps don't clobber.
                tmp = folder / f"_dgs_tmp_{dest_name}"
                shutil.copy2(src_path, tmp)
                if dest.exists():
                    dest.unlink()
                tmp.rename(dest)
            notes.append(f"{m.screen}: {src_name} → {dest_name} in {folder.name}")
            project._link_map("media")[m.to["id"]] = str(dest)
            project._link_map("images")[m.screen] = str(dest)
        except OSError as e:
            notes.append(f"{m.screen}: could not write {dest_name} ({e})")
    if notes:
        project.dirty = True
    return notes
