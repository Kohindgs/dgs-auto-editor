"""Media Pack — download chapter pictures/videos/VO, then upload to replace.

Filmora-style rules:
- Picture / video replace keeps the timeline clip (screen, start/end). Only the
  source file changes.
- VO section replace keeps the voice block on the timeline and swaps the audio
  inside it (trim to the block if the new file is longer).
- Full VO / Poem file replace swaps the library audio (like Filmora Media
  Library → Replace) and remaps every piece that used that slot onto the new file.
"""

from __future__ import annotations

import json
import re
import shutil
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from .edits import r3, replace_media, replace_vo_section
from .project_store import IMAGE_EXT, VIDEO_EXT, AUDIO_EXT, Project

_SCENE_FILE = re.compile(r"^(?:scene[_\s-]*)?(\d+)\.", re.I)
_VO_FILE = re.compile(r"^(?:vo|narration)[_\s-]*(\d+)\.", re.I)
_POEM_FILE = re.compile(r"^(?:poem|song)[_\s-]*(\d+)\.", re.I)


@dataclass
class PackItem:
    kind: str  # image | video | narration | poem
    screen: str = ""
    slot: int = 0
    filename: str = ""
    src: str = ""
    rel: str = ""


@dataclass
class PackReport:
    copied: list[str] = field(default_factory=list)
    replaced: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)
    folder: str = ""

    def summary(self) -> str:
        bits = []
        if self.copied:
            bits.append(f"{len(self.copied)} downloaded")
        if self.replaced:
            bits.append(f"{len(self.replaced)} replaced")
        if self.missing:
            bits.append(f"{len(self.missing)} missing on disk")
        if self.skipped:
            bits.append(f"{len(self.skipped)} skipped")
        return " · ".join(bits) or "Nothing changed"


def _safe_name(name: str) -> str:
    return re.sub(r'[<>:"/\\|?*]+', "_", str(name or "file")).strip() or "file"


def _screen_num(screen: str) -> int | None:
    m = re.search(r"(\d+)", str(screen or ""))
    return int(m.group(1)) if m else None


def _copy(src: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if src.resolve() == dest.resolve():
        return
    shutil.copy2(src, dest)


def collect_pack_items(proj: Project) -> list[PackItem]:
    """Every picture, video, narration VO and poem file used by this chapter."""
    items: list[PackItem] = []
    seen: set[str] = set()
    for clip in proj.clips or []:
        if not isinstance(clip, dict):
            continue
        screen = str(clip.get("screen") or "")
        path = str(clip.get("media_path") or "")
        if not path:
            mid = str(clip.get("media_id") or "")
            for m in proj.media or []:
                if isinstance(m, dict) and str(m.get("id")) == mid:
                    path = str(m.get("path") or "")
                    break
            if not path and mid:
                path = str(proj._link_map("media").get(mid) or "")
        if not path:
            continue
        key = f"media:{screen}:{path}"
        if key in seen:
            continue
        seen.add(key)
        kind = str(clip.get("kind") or "image")
        if kind not in ("image", "video"):
            kind = "video" if Path(path).suffix.lower() in VIDEO_EXT else "image"
        n = _screen_num(screen) or (len(items) + 1)
        ext = Path(path).suffix.lower() or (".mp4" if kind == "video" else ".png")
        fname = _safe_name(Path(path).name) if Path(path).name else f"{n}{ext}"
        # Prefer scene-number names so round-trip matching is easy.
        if not _SCENE_FILE.match(fname):
            fname = f"{n}{ext}" if kind == "image" else f"Scene {n}{ext}"
        folder = "videos" if kind == "video" else "images"
        items.append(PackItem(kind=kind, screen=screen, filename=fname, src=path, rel=f"{folder}/{fname}"))

    for sl in proj.slots or []:
        if not isinstance(sl, dict):
            continue
        n = int(sl.get("slot") or 1)
        path = proj.slot_path(n)
        if not path:
            continue
        key = f"vo:{n}:{path}"
        if key in seen:
            continue
        seen.add(key)
        ext = Path(path).suffix.lower() or ".mp3"
        fname = f"VO_{n}{ext}"
        items.append(PackItem(kind="narration", slot=n, filename=fname, src=path, rel=f"voiceover/{fname}"))

    for sl in proj.poem_slots() or []:
        if not isinstance(sl, dict):
            continue
        n = int(sl.get("slot") or 1)
        path = proj.poem_slot_path(n)
        if not path:
            continue
        key = f"poem:{n}:{path}"
        if key in seen:
            continue
        seen.add(key)
        ext = Path(path).suffix.lower() or ".mp3"
        fname = f"Poem_{n}{ext}"
        items.append(PackItem(kind="poem", slot=n, filename=fname, src=path, rel=f"poem/{fname}"))
    return items


def export_media_pack(proj: Project, dest: Path) -> PackReport:
    """Copy every linked picture/video/VO into ``dest`` for editing in other apps."""
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    items = collect_pack_items(proj)
    report = PackReport(folder=str(dest))
    manifest = {
        "project_id": proj.pid,
        "title": proj.title,
        "version": 1,
        "items": [],
    }
    used_rel: set[str] = set()
    for it in items:
        src = Path(it.src)
        if not src.is_file():
            report.missing.append(it.filename or it.src)
            continue
        rel = it.rel.replace("\\", "/")
        if rel.lower() in used_rel:
            # Same scene name twice (e.g. two clips) — keep a unique copy.
            stem = Path(rel).stem
            parent = str(Path(rel).parent).replace("\\", "/")
            alt = f"{parent}/{stem}_{it.screen or it.slot}{Path(rel).suffix}"
            n = 2
            while alt.lower() in used_rel:
                alt = f"{parent}/{stem}_{it.screen or it.slot}_{n}{Path(rel).suffix}"
                n += 1
            rel = alt
            it.rel = rel
            it.filename = Path(rel).name
        used_rel.add(rel.lower())
        out = dest / rel
        try:
            _copy(src, out)
            report.copied.append(rel)
            manifest["items"].append({
                "kind": it.kind,
                "screen": it.screen,
                "slot": it.slot,
                "filename": it.filename,
                "rel": rel,
            })
        except OSError as e:
            report.skipped.append(f"{rel}: {e}")
    (dest / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    readme = dest / "README.txt"
    readme.write_text(
        "DGS Media Pack\n"
        "==============\n"
        "Edit files here in Filmora, Photoshop, or any other app.\n"
        "Keep the same filenames (or keep manifest.json).\n"
        "In DGS Auto Editor: Media → Media Pack → Upload / Replace from folder.\n"
        "\n"
        "Filmora-style VO replace:\n"
        "- VO_1.mp3 replaces the whole narration library file (timeline blocks stay).\n"
        "- Or use VO / Replace → Replace… on one voice section to swap only that block.\n",
        encoding="utf-8",
    )
    return report


def _match_screen(proj: Project, path: Path, meta: dict | None) -> str | None:
    if meta and meta.get("screen"):
        return str(meta["screen"])
    m = _SCENE_FILE.match(path.name)
    if not m:
        return None
    n = int(m.group(1))
    for c in proj.clips or []:
        if _screen_num(str(c.get("screen") or "")) == n:
            return str(c.get("screen"))
    return f"screen_{n}"


def import_media_pack(proj: Project, folder: Path, *, duration_of=None) -> PackReport:
    """Replace chapter media from a Media Pack folder (or any folder of scene files).

    Matching order: manifest.json → Scene N / N.ext → VO_N / Poem_N.
    Timeline clip times are kept (Filmora Media Library replace behaviour).
    """
    folder = Path(folder)
    report = PackReport(folder=str(folder))
    if not folder.is_dir():
        report.skipped.append("Folder not found")
        return report

    by_rel: dict[str, dict] = {}
    manifest_path = folder / "manifest.json"
    if manifest_path.is_file():
        try:
            data = json.loads(manifest_path.read_text(encoding="utf-8"))
            for row in data.get("items") or []:
                if isinstance(row, dict) and row.get("rel"):
                    by_rel[str(row["rel"]).replace("\\", "/").lower()] = row
        except (OSError, json.JSONDecodeError):
            pass

    # Walk images / videos / voiceover / poem / root
    files: list[Path] = []
    for sub in ("images", "videos", "voiceover", "poem", "."):
        base = folder if sub == "." else folder / sub
        if not base.is_dir():
            continue
        for p in sorted(base.iterdir()):
            if p.is_file() and p.name.lower() not in ("manifest.json", "readme.txt"):
                files.append(p)

    for path in files:
        ext = path.suffix.lower()
        rel = str(path.relative_to(folder)).replace("\\", "/")
        meta = by_rel.get(rel.lower())
        kind = (meta or {}).get("kind") or ""

        if ext in AUDIO_EXT or kind in ("narration", "poem"):
            slot = int((meta or {}).get("slot") or 0)
            if not slot:
                m = _VO_FILE.match(path.name)
                if m:
                    slot = int(m.group(1))
                    kind = "narration"
                else:
                    m = _POEM_FILE.match(path.name)
                    if m:
                        slot = int(m.group(1))
                        kind = "poem"
            if kind == "poem" or (kind != "narration" and _POEM_FILE.match(path.name)):
                slot = slot or 1
                try:
                    dest = _stage_into_project(proj, path, "voiceover", f"poem_{slot}_{path.name}")
                    proj.set_poem_slot_path(slot, dest)
                    _remap_slot_pieces(proj.plan, slot, str(dest), duration_of, poem=True)
                    report.replaced.append(f"Poem {slot} ← {path.name}")
                except OSError as e:
                    report.skipped.append(f"{path.name}: {e}")
                continue
            if kind == "narration" or _VO_FILE.match(path.name) or slot:
                slot = slot or 1
                try:
                    dest = _stage_into_project(proj, path, "voiceover", f"slot_{slot}_{path.name}")
                    proj.set_slot_path(slot, dest)
                    _remap_slot_pieces(proj.plan, slot, str(dest), duration_of, poem=False)
                    report.replaced.append(f"VO {slot} ← {path.name}")
                except OSError as e:
                    report.skipped.append(f"{path.name}: {e}")
                continue
            report.skipped.append(path.name)
            continue

        if ext not in IMAGE_EXT and ext not in VIDEO_EXT and kind not in ("image", "video"):
            report.skipped.append(path.name)
            continue
        screen = _match_screen(proj, path, meta)
        if not screen:
            report.skipped.append(path.name)
            continue
        media_kind = kind if kind in ("image", "video") else ("video" if ext in VIDEO_EXT else "image")
        try:
            sub = "videos" if media_kind == "video" else "images"
            dest = _stage_into_project(proj, path, f"media/{sub}", path.name)
            mid = uuid.uuid4().hex
            item = {
                "id": mid,
                "filename": dest.name,
                "path": str(dest),
                "kind": media_kind,
                "screen": screen,
                "local_only": True,
            }
            proj._link_map("media")[mid] = str(dest)
            proj._link_map(sub)[screen] = str(dest)
            # Replace or append media index entry for this screen
            kept = []
            for m in proj.media or []:
                if not isinstance(m, dict):
                    continue
                if str(m.get("screen") or "") == screen and str(m.get("kind") or "") == media_kind:
                    continue
                kept.append(m)
            kept.append(item)
            proj.media = kept
            replace_media(proj.plan, screen, item)
            report.replaced.append(f"{screen} ← {path.name}")
        except OSError as e:
            report.skipped.append(f"{path.name}: {e}")

    if report.replaced:
        proj.dirty = True
        proj.plan["manual_override"] = True
        try:
            media_path = proj.meta / "media.json"
            media_path.parent.mkdir(parents=True, exist_ok=True)
            media_path.write_text(json.dumps(proj.media, ensure_ascii=False, indent=2), encoding="utf-8")
        except OSError:
            pass
    return report


def _stage_into_project(proj: Project, src: Path, subdir: str, name: str) -> Path:
    dest_dir = proj.root / subdir
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / _safe_name(name)
    _copy(src, dest)
    return dest


def _remap_slot_pieces(plan: dict, slot: int, path: str, duration_of, *, poem: bool) -> None:
    """Filmora library replace: same timeline blocks, new source file."""
    if poem:
        return  # poem pieces are rebuilt from poem slots on play; path is enough
    pieces = plan.get("vo_pieces")
    if not isinstance(pieces, list) or not pieces:
        return
    new_dur = None
    if callable(duration_of):
        try:
            new_dur = float(duration_of(Path(path)) or 0)
        except Exception:
            new_dur = None
    for piece in pieces:
        if not isinstance(piece, dict):
            continue
        if int(piece.get("slot") or 1) != int(slot):
            continue
        # Clear a prior section-level replace so the new library file is used.
        piece.pop("replace_path", None)
        piece["filename"] = Path(path).name
        start = float(piece.get("start") or 0)
        end = float(piece.get("end") or start)
        room = max(0.12, end - start)
        src_in = float(piece.get("source_in") or 0)
        src_out = float(piece.get("source_out") or (src_in + room))
        need = max(0.12, src_out - src_in)
        if new_dur and new_dur > 0.05:
            # Keep the same in-point when possible; trim if the new take is shorter.
            play = min(need, max(0.12, new_dur - src_in))
            piece["source_in"] = r3(min(src_in, max(0.0, new_dur - 0.12)))
            piece["source_out"] = r3(float(piece["source_in"]) + play)
            piece["end"] = r3(start + play)
        else:
            piece["source_out"] = r3(float(piece.get("source_in") or 0) + room)


def replace_vo_block(plan: dict, piece_id: str, path: Path, duration: float) -> dict:
    """Filmora-style: keep the voice block, swap only the audio inside it."""
    return replace_vo_section(plan, piece_id, str(path), duration)
