"""Reading the chapter plan: what is on screen and what is heard at time t.

Ported from ``frontend/src/playbackEngine.ts`` (``narrFileAt``),
``frontend/src/voPieces.ts`` and ``hostinger_deploy/nativeEngine.js``
(``narrSource``). Narration uses one merged clock across the VO files: each
slot sits at its ``start_offset`` (the previous files plus a 0.5 s gap).
"""

from __future__ import annotations

from bisect import bisect_right
from dataclasses import dataclass
from pathlib import Path

from .project_store import DEFAULT_LOGO_TRANSFORM, Project, normalize_logo_transform

FPS = 30


def fmt_tc(t: float, fps: int = FPS) -> str:
    t = max(0.0, float(t or 0))
    frames = int(round(t * fps))
    ff = frames % fps
    s = frames // fps
    return f"{s // 3600:02d}:{(s // 60) % 60:02d}:{s % 60:02d}:{ff:02d}"


def fmt_short(t: float) -> str:
    t = max(0.0, float(t or 0))
    m = int(t // 60)
    return f"{m:02d}:{t - m * 60:05.2f}"


def num(v) -> float | None:
    if v is None or v == "":
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


POEM_PRESETS = {
    "badge_pill": {"font_family": "Segoe UI", "text_color": "#ffffff", "bg_color": "#0f172a", "bg_opacity": 0.88, "border_color": "#38bdf8", "border_width": 2, "border_radius": 24, "box_shadow": True},
    "neon_glow": {"font_family": "Trebuchet MS", "text_color": "#38bdf8", "bg_color": "#020617", "bg_opacity": 0.82, "border_color": "#06b6d4", "border_width": 2, "border_radius": 14, "box_shadow": True},
    "karaoke_box": {"font_family": "Arial", "text_color": "#facc15", "bg_color": "#000000", "bg_opacity": 0.92, "border_color": "#eab308", "border_width": 3, "border_radius": 12, "box_shadow": True},
    "pastel_banner": {"font_family": "Georgia", "text_color": "#1e1b4b", "bg_color": "#fef08a", "bg_opacity": 0.94, "border_color": "#f59e0b", "border_width": 2, "border_radius": 20, "box_shadow": True},
    "comic_pop": {"font_family": "Comic Sans MS", "text_color": "#ffffff", "bg_color": "#ec4899", "bg_opacity": 0.96, "border_color": "#000000", "border_width": 3.5, "border_radius": 16, "box_shadow": True},
    "clean_subtitle": {"font_family": "Verdana", "text_color": "#ffffff", "bg_color": "#000000", "bg_opacity": 0.65, "border_color": "#475569", "border_width": 1, "border_radius": 8, "box_shadow": False},
}

DEFAULT_POEM_OVERLAY = {
    "enabled": True,
    "locked": False,
    "font_family": "Nirmala UI",
    "font_weight": 400,
    "font_size_px": 28,
    "preset_style": "badge_pill",
    "text_color": "#ffffff",
    "bg_color": "#0f172a",
    "bg_opacity": 0.88,
    "border_color": "#38bdf8",
    "border_width": 2.0,
    "border_none": False,
    "border_radius": 24.0,
    "text_style": "shadow",
    "text_shadow": True,
    "text_shadow_soft": 6,
    "stroke_color": "#111111",
    "box_shadow": True,
    "shadow_color": "#000000",
    "shadow_soft": 6,
    "bg_none": False,
    "text_align": "center",
    "x_pct": 10.0,
    "y_pct": 72.0,
    "w_pct": 80.0,
    "h_pct": 20.0,
    "word_balls": False,
    "ball_color": "#facc15",
    "changeover": "fade",
    "apply_all": True,
}


def normalize_poem_overlay(raw: dict | None) -> dict:
    """One look for every poem screen. Unknown values fall back to the default."""
    src = raw if isinstance(raw, dict) else {}
    preset = str(src.get("preset_style") or "")
    base = dict(POEM_PRESETS.get(preset) or {})
    out = dict(DEFAULT_POEM_OVERLAY)
    out.update(base)
    out["preset_style"] = preset if preset in POEM_PRESETS else "badge_pill"

    def num(key, lo, hi, default):
        try:
            v = float(src[key]) if key in src and src[key] is not None else float(default)
        except (TypeError, ValueError):
            v = float(default)
        return max(lo, min(hi, v))

    for key in ("font_family", "text_color", "bg_color", "border_color", "shadow_color", "stroke_color", "ball_color"):
        if src.get(key):
            out[key] = str(src[key])[:32] if key != "font_family" else str(src[key])[:80]
    out["font_size_px"] = int(num("font_size_px", 14, 72, out["font_size_px"]))
    out["font_weight"] = int(num("font_weight", 100, 900, src.get("font_weight", out.get("font_weight", 400))))
    out["bg_opacity"] = num("bg_opacity", 0, 1, out["bg_opacity"])
    out["border_width"] = num("border_width", 0, 12, out["border_width"])
    out["border_none"] = bool(src.get("border_none"))
    if out["border_none"]:
        out["border_width"] = 0.0
    out["border_radius"] = num("border_radius", 0, 48, out["border_radius"])
    out["x_pct"] = num("x_pct", 0, 90, out["x_pct"])
    out["y_pct"] = num("y_pct", 0, 90, out["y_pct"])
    out["w_pct"] = num("w_pct", 20, 100, out["w_pct"])
    out["h_pct"] = num("h_pct", 8, 60, out["h_pct"])
    out["enabled"] = src.get("enabled") is not False
    out["locked"] = bool(src.get("locked"))
    out["bg_none"] = bool(src.get("bg_none"))
    if out["bg_none"]:
        out["bg_opacity"] = 0.0
    kind = str(src.get("text_style") or out.get("text_style") or "shadow")
    out["text_style"] = kind if kind in ("plain", "shadow", "outline", "sticker", "lift", "glow") else "shadow"
    out["text_shadow"] = bool(src["text_shadow"]) if "text_shadow" in src else bool(out.get("text_shadow", True))
    out["text_shadow_soft"] = int(num("text_shadow_soft", 0, 24, src.get("text_shadow_soft", out.get("text_shadow_soft", 6))))
    out["box_shadow"] = bool(src.get("box_shadow", out["box_shadow"]))
    out["shadow_soft"] = int(num("shadow_soft", 0, 24, src.get("shadow_soft", out.get("shadow_soft", 6))))
    out["word_balls"] = bool(src.get("word_balls"))
    align = src.get("text_align")
    out["text_align"] = align if align in ("left", "center", "right") else "center"
    change = src.get("changeover")
    out["changeover"] = change if change in ("none", "fade", "slide", "pop") else "fade"
    out["apply_all"] = src.get("apply_all") is not False
    hidden = []
    raw_hidden = src.get("hidden_screens")
    if isinstance(raw_hidden, list):
        for item in raw_hidden:
            name = str(item or "").strip()
            if name and name not in hidden and len(hidden) < 200:
                hidden.append(name[:80])
    out["hidden_screens"] = hidden
    return out


# Filled by PlanIndex so every UI / QA call to scene_label() gets Section names
# from the master script (global for the open chapter).
_SCENE_NAMES: dict[str, str] = {}
_CHAPTER_TITLE: str = ""
_GENERIC_SECTIONS = frozenset({
    "", "story", "poem", "narration", "scene", "scenes", "content", "body", "main",
})


def set_scene_catalog(scenes: list | None, *, title: str = "", clips: list | None = None) -> None:
    """Remember Section / title names for the open chapter (all labels use this)."""
    global _SCENE_NAMES, _CHAPTER_TITLE
    names: dict[str, str] = {}
    printed = ""
    for sc in scenes or []:
        if not isinstance(sc, dict):
            continue
        key = str(sc.get("screen") or "")
        if not key:
            continue
        names[key] = _display_name_for_scene(sc)
        sec = str(sc.get("section") or "").strip().lower()
        ost = str(sc.get("onscreen_text") or sc.get("script_text") or "").strip().split("\n", 1)[0].strip()
        # Prefer the title card's printed words (e.g. My Word Family) over the file name.
        if not printed and "title" in sec and ost and len(ost) < 80:
            printed = ost
    # Clips fill gaps (Filmora / chapters with weak Section cells).
    for clip in clips or []:
        if not isinstance(clip, dict):
            continue
        key = str(clip.get("screen") or "")
        if not key:
            continue
        tip = _display_name_for_clip(clip)
        if tip and (not names.get(key) or names[key].lower() in _GENERIC_SECTIONS):
            names[key] = tip
        if not printed:
            low = str(clip.get("section") or "").lower()
            ost = str(clip.get("script_text") or clip.get("vo_text") or "").strip().split("\n", 1)[0].strip()
            if "title" in low and ost and len(ost) < 80:
                printed = ost
    _SCENE_NAMES = names
    _CHAPTER_TITLE = printed or str(title or "").strip()


def chapter_title() -> str:
    """On-screen chapter title from the script (e.g. My Word Family), if known."""
    return _CHAPTER_TITLE


def screen_title(screen: str) -> str:
    """Section / printed title for one screen (no ``Scene N`` prefix)."""
    return _SCENE_NAMES.get(str(screen or ""), "") or ""


def _clean_line(text: str, limit: int = 60) -> str:
    line = str(text or "").replace("\n", " ").strip()
    if not line:
        return ""
    return line if len(line) <= limit else line[: max(1, limit - 1)] + "…"


def _display_name_for_scene(scene: dict) -> str:
    """Master-script screen name: Section, printed title, or first spoken/on-screen line."""
    section = str(scene.get("section") or "").strip()
    ost_one = _clean_line(scene.get("onscreen_text") or scene.get("script_text") or "", 70)
    vo_one = _clean_line(scene.get("voiceover_text") or scene.get("vo_text") or "", 50)
    low = section.lower()
    # Title cards: show the printed title, never a bare "Chapter title".
    if "title" in low and ost_one:
        return ost_one
    if section and low not in _GENERIC_SECTIONS:
        return section
    return ost_one or vo_one or (section if low not in _GENERIC_SECTIONS else "")


def _display_name_for_clip(clip: dict) -> str:
    """Fallback title from a timeline clip when script Section is missing/generic."""
    section = str(clip.get("section") or "").strip()
    low = section.lower()
    ost = _clean_line(clip.get("script_text") or clip.get("onscreen_text") or "", 70)
    vo = _clean_line(clip.get("vo_text") or clip.get("voiceover_text") or "", 50)
    if "title" in low and ost:
        return ost
    if section and low not in _GENERIC_SECTIONS:
        return section
    return ost or vo or ""


def scene_label(screen: str, *, short: bool = False) -> str:
    """Global screen label: ``Scene N · Section`` (or title text on a title card)."""
    s = str(screen or "")
    if s.startswith("missing_vo_"):
        return "Missing card"
    if s.startswith("screen_"):
        base = s.replace("screen_", "Scene ")
        short_base = s.replace("screen_", "S")
    else:
        base = s or "Scene"
        short_base = base
    name = _SCENE_NAMES.get(s) or ""
    if not name:
        return short_base if short else base
    if short:
        tip = name if len(name) <= 36 else name[:33] + "…"
        return f"{short_base} · {tip}"
    return f"{base} · {name}"


def media_block_label(clip: dict, *, kind: str = "", filename: str = "", short: bool = True) -> str:
    """Timeline / Media title for an image or video clip."""
    screen = str(clip.get("screen") or "")
    title = scene_label(screen, short=short)
    name = _SCENE_NAMES.get(screen) or _display_name_for_clip(clip)
    file_stem = Path(str(filename or clip.get("filename") or "")).stem
    # Bare "S5" / "Scene 5" → append title or file name so the block is readable.
    if " · " not in title:
        tip = name or file_stem
        n = screen.replace("screen_", "") if screen.startswith("screen_") else ""
        # Avoid "S5 · 5" — prefer Scene 5 or a real file name.
        if tip and n and (tip == n or tip.isdigit()):
            tip = file_stem if file_stem and not file_stem.isdigit() else (f"Scene {n}" if n else tip)
        if tip:
            tip = tip if len(tip) <= 36 else tip[:33] + "…"
            title = f"{title} · {tip}"
    kind = kind or str(clip.get("kind") or "image")
    if short:
        return title
    tag = "Video" if kind == "video" else "Image"
    return f"{title} · {tag}"


def vo_block_label(piece: dict, clips: list | None = None) -> str:
    """Timeline title for a cut VO block: scene section / spoken line, not only VO.mp3."""
    screen = str(piece.get("screen") or "")
    if not screen and clips:
        mid = (float(piece.get("start") or 0) + float(piece.get("end") or 0)) * 0.5
        for clip in clips:
            if not isinstance(clip, dict):
                continue
            a, b = float(clip.get("start") or 0), float(clip.get("end") or 0)
            if a <= mid <= b + 0.001:
                screen = str(clip.get("screen") or "")
                break
    title = scene_label(screen, short=True) if screen else ""
    raw = str(piece.get("filename") or piece.get("vo_text") or "").replace("\n", " ").strip()
    # Skip bare audio filenames — those are not titles.
    if raw and Path(raw).suffix.lower() in {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".wma"}:
        raw = ""
    if raw.lower() in {"voice", "narration", "vo", "vo 1", "vo1"}:
        raw = ""
    if title and raw and raw not in title:
        tip = raw if len(raw) <= 40 else raw[:37] + "…"
        return f"{title}: {tip}"
    if title:
        return title
    return raw or "Voice"


@dataclass(frozen=True)
class Heard:
    kind: str  # "narration" | "poem"
    slot: int
    path: str
    offset: float


class PlanIndex:
    """Fast lookups over one chapter. Rebuild it after an edit."""

    def __init__(self, project: Project) -> None:
        self.project = project
        plan = project.plan
        self.clips = sorted(project.clips, key=lambda c: float(c.get("start") or 0))
        # Global labels for this chapter: Section names + printed title (+ clip text fallback).
        set_scene_catalog(
            project.scenes,
            title=str(project.title or plan.get("title") or ""),
            clips=self.clips,
        )
        self._starts = [float(c.get("start") or 0) for c in self.clips]
        segs = plan.get("narration_segments")
        self.segments = segs if isinstance(segs, list) and segs else self.clips
        self.poem_start = float(plan.get("poem_start_time") or 0)
        self.poem_end = float(plan.get("poem_end_time") or 0)
        self.has_poem = bool(plan.get("has_poem")) and self.poem_end > self.poem_start + 0.2
        self.duration = max(
            float(plan.get("total_duration") or 0),
            max((float(c.get("end") or 0) for c in self.clips), default=0.0),
        )
        self.vo_edited = isinstance(plan.get("vo_pieces"), list)
        self.files = [project.clip_file(c) for c in self.clips]
        slot_ids = {int(s.get("slot") or 1) for s in project.slots} | {1}
        self._slot_paths = {n: project.slot_path(n) for n in slot_ids}
        self.poem_file = project.poem_path()

    def slot_file(self, slot: int) -> str:
        return self._slot_paths.get(int(slot), "")

    # Pictures --------------------------------------------------------------

    def clip_index_at(self, t: float) -> int:
        if not self.clips:
            return -1
        i = bisect_right(self._starts, t) - 1
        if i < 0:
            return -1
        if t < float(self.clips[i].get("end") or 0):
            return i
        if i == len(self.clips) - 1:
            return i
        # A join, or a gap of a few frames, stays on a card. Going blank here
        # is what stopped the picture at every intersection.
        nxt = float(self.clips[i + 1].get("start") or 0)
        if t >= nxt - 0.001 or nxt - t < 0.12:
            return i + 1
        return -1

    def clip_at(self, t: float) -> dict | None:
        i = self.clip_index_at(t)
        return self.clips[i] if i >= 0 else None

    def source_time(self, clip: dict, t: float) -> tuple[float, float]:
        """(time in the video file, playback speed)."""
        start = float(clip.get("start") or 0)
        end = float(clip.get("end") or start)
        clip_dur = max(0.05, end - start)
        src_in = float(clip.get("source_in") or 0)
        src_out = num(clip.get("source_out"))
        span = src_out - src_in if src_out is not None and src_out > src_in + 0.05 else clip_dur
        local = max(0.0, t - start)
        # A question card stays up through the pause after the words. Time the
        # take to those words, then hold the last frame for the pause.
        line = clip_dur
        hold_after = False
        ni = num(clip.get("narration_in"))
        no = num(clip.get("narration_out"))
        if ni is not None and no is not None and no > ni + 0.05 and (no - ni) + 0.20 < clip_dur:
            line = max(0.05, no - ni)
            hold_after = True
        # A video shorter than its line plays slower, so the picture is still
        # moving when the words end. The rate is the file span over the line.
        short_video = (
            clip.get("kind") == "video"
            and span + 0.12 < line
            and span >= line * 0.20
        )
        play = span
        rate = 1.0
        if clip.get("fit") in ("stretch", "passthrough") or short_video:
            rate = span / line if line else 1.0
            if rate > 4.0:
                rate = 4.0
        elif hold_after and span > line + 0.12:
            # A little long: speed up to 1.28x and drop the frames past that.
            rate = min(1.28, span / line)
            play = line * rate
        if hold_after and local >= line - 0.001:
            return src_in + min(play, span), 0.0
        if rate != 1.0:
            return src_in + min(play, local * rate), rate
        return src_in + min(local, span), 1.0

    # Sound -----------------------------------------------------------------

    def in_poem(self, t: float) -> bool:
        return self.has_poem and self.poem_start - 0.02 <= t < self.poem_end - 0.02

    def merged_narration_time(self, t: float) -> float | None:
        if self.in_poem(t):
            return None
        if not self.segments and not self.vo_edited:
            return t
        for seg in self.segments:
            s = float(seg.get("start") or 0)
            if not (s <= t < float(seg.get("end") or 0)):
                continue
            ni = num(seg.get("narration_in"))
            no = num(seg.get("narration_out"))
            if ni is None or no is None or no - ni <= 0.05:
                continue
            spoken = no - ni
            local = max(0.0, t - s)
            if local > spoken + 0.08:
                return None
            return ni + min(local, spoken)
        return None

    def heard_at(self, t: float) -> Heard | None:
        p = self.project
        if self.in_poem(t):
            heard = self._poem_heard(t)
            if heard:
                return heard
            path = self.poem_file
            if not path:
                return None
            return Heard("poem", 1, path, max(0.0, t - self.poem_start))
        if self.vo_edited:
            for piece in p.plan.get("vo_pieces") or []:
                a = float(piece.get("start") or 0)
                b = float(piece.get("end") or 0)
                if a <= t <= b + 0.001:
                    slot = int(piece.get("slot") or 1)
                    path = str(piece.get("replace_path") or "")
                    if not path or not Path(path).is_file():
                        path = self.slot_file(slot)
                    if not path:
                        return None
                    span = max(0.0, float(piece.get("source_out") or 0) - float(piece.get("source_in") or 0))
                    return Heard("narration", slot, path, float(piece.get("source_in") or 0) + min(t - a, span))
            return None
        merged = self.merged_narration_time(t)
        if merged is None:
            return None
        slots = p.slots
        if len(slots) >= 2:
            for sl in slots:
                a = float(sl.get("start_offset") or 0)
                b = float(sl.get("end_offset") or a + float(sl.get("duration") or 0))
                if a - 0.08 <= merged < b + 0.2:
                    slot = int(sl.get("slot") or 1)
                    path = self.slot_file(slot)
                    return Heard("narration", slot, path, max(0.0, merged - a)) if path else None
            return None
        slot = int(slots[0].get("slot") or 1) if slots else 1
        path = self.slot_file(slot)
        return Heard("narration", slot, path, merged) if path else None

    def poem_blocks(self) -> list[dict]:
        """One block per poem file, placed in order inside the poem window."""
        if not self.has_poem:
            return []
        slots = self.project.poem_slots()
        if len(slots) <= 1:
            name = str((slots[0].get("filename") if slots else "") or self.project.poem_vo.get("filename") or "Poem")
            return [{"slot": 1, "start": self.poem_start, "end": self.poem_end, "filename": name}]
        out = []
        for sl in slots:
            slot = int(sl.get("slot") or 1)
            a = self.poem_start + float(sl.get("start_offset") or 0)
            b = self.poem_start + float(sl.get("end_offset") or float(sl.get("duration") or 0))
            if b <= a + 0.05:
                continue
            out.append({"slot": slot, "start": a, "end": min(self.poem_end, b), "filename": sl.get("filename") or f"Poem {slot}"})
        return out or [{"slot": 1, "start": self.poem_start, "end": self.poem_end, "filename": "Poem"}]

    def _poem_heard(self, t: float) -> Heard | None:
        slots = self.project.poem_slots()
        if len(slots) <= 1:
            return None
        local = t - self.poem_start
        for sl in slots:
            a = float(sl.get("start_offset") or 0)
            b = float(sl.get("end_offset") or a + float(sl.get("duration") or 0))
            if a - 0.02 <= local < b - 0.001:
                slot = int(sl.get("slot") or 1)
                path = self.project.poem_slot_path(slot)
                if not path:
                    return None
                return Heard("poem", slot, path, max(0.0, local - a))
        return None

    def poem_lyric_at(self, t: float) -> str:
        """On-screen Poem text — only while a real lyric is being sung.

        Silent before the song, during the instrumental intro, on the
        \"Listen and sing.\" heading, and after the song ends.
        """
        if not self.in_poem(t):
            return ""
        plan = self.project.plan if isinstance(self.project.plan, dict) else {}
        lyric_start = float(plan.get("poem_lyric_start") or 0)
        if lyric_start > self.poem_start + 0.15 and t < lyric_start - 0.02:
            return ""
        clip = self.clip_at(t)
        if not clip:
            return ""
        overlay = plan.get("poem_overlay") if isinstance(plan.get("poem_overlay"), dict) else {}
        if overlay.get("enabled") is False:
            return ""
        hidden = {str(s) for s in (overlay.get("hidden_screens") or [])}
        screen = str(clip.get("screen") or "")
        if screen in hidden:
            return ""
        # Heading / lesson cards that sit next to the song never own Poem text.
        scene = next((s for s in (self.project.scenes or []) if str(s.get("screen") or "") == screen), None)
        if isinstance(scene, dict) and not (scene.get("is_poem") or scene.get("audio_start") is not None):
            return ""
        text = str(clip.get("vo_text") or clip.get("caption_text") or "").strip()
        low = text.lower()
        if not text or "instrumental" in low:
            return ""
        if "listen and sing" in low:
            return ""
        return text

    def caption_at(self, t: float) -> str:
        """The subtitle line whose picture time covers t. Empty outside a cue."""
        cues = self.project.plan.get("srt_cues")
        if not isinstance(cues, list):
            return ""
        # Same gate as Poem text: no poem-window captions until the first sung word.
        if self.has_poem:
            lyric_start = float(self.project.plan.get("poem_lyric_start") or 0)
            if lyric_start > self.poem_start + 0.15 and self.poem_start - 0.02 <= t < lyric_start - 0.02:
                return ""
        for cue in cues:
            if not isinstance(cue, dict):
                continue
            a = float(cue.get("start") or 0)
            b = float(cue.get("end") or 0)
            # End is exclusive so a heading cue cannot flash on the next card.
            if a - 0.02 <= t < b - 0.001:
                text = str(cue.get("text") or "").strip()
                if "listen and sing" in text.lower() and (
                    self.in_poem(t) or t >= self.poem_start - 0.05
                ):
                    return ""
                return text
        return ""

    # Voice lane ------------------------------------------------------------

    def vo_pieces(self) -> list[dict]:
        plan = self.project.plan
        if isinstance(plan.get("vo_pieces"), list):
            return plan["vo_pieces"]
        hole = (self.poem_start, self.poem_end) if self.has_poem else None
        slots = [s for s in (plan.get("voiceover_slots") or []) if float(s.get("end") or 0) > float(s.get("start") or 0) + 0.05]
        if len(slots) >= 2:
            out = []
            for s in slots:
                a = float(s.get("start") or 0)
                b = float(s.get("end") or 0)
                span = max(0.12, b - a)
                out.extend(_split_hole({
                    "id": f"vo-slot-{s.get('slot')}",
                    "slot": int(s.get("slot") or 1),
                    "filename": s.get("filename") or f"VO {s.get('slot')}",
                    "start": a,
                    "end": b,
                    "source_in": 0.0,
                    "source_out": span,
                }, hole))
            return out
        out = []
        for seg in self.segments:
            ni = num(seg.get("narration_in"))
            no = num(seg.get("narration_out"))
            if ni is None or no is None or no - ni < 0.05:
                continue
            start = float(seg.get("start") or 0)
            end = min(float(seg.get("end") or start), start + (no - ni))
            if end <= start + 0.05:
                continue
            out.extend(_split_hole({
                "id": f"vo-{seg.get('screen')}",
                "slot": 1,
                "screen": seg.get("screen"),
                "filename": seg.get("vo_text") or seg.get("script_text") or "Narration",
                "start": start,
                "end": end,
                # File cut that plays under this picture (needed for Download cut VO).
                "source_in": float(ni),
                "source_out": float(no),
            }, hole))
        return out


def _split_hole(piece: dict, hole: tuple[float, float] | None) -> list[dict]:
    if not hole:
        return [piece]
    a, b = piece["start"], piece["end"]
    hs, he = hole
    if he <= a + 0.05 or hs >= b - 0.05:
        return [piece]
    src_in = float(piece.get("source_in") or 0)
    src_out = float(piece.get("source_out") or (src_in + max(0.12, b - a)))
    span = max(0.12, b - a)
    rate = (src_out - src_in) / span

    def _slice(new_a: float, new_b: float, suffix: str) -> dict:
        local_in = src_in + (new_a - a) * rate
        local_out = src_in + (new_b - a) * rate
        return {
            **piece,
            "id": f"{piece['id']}-{suffix}",
            "start": new_a,
            "end": new_b,
            "source_in": round(local_in, 3),
            "source_out": round(local_out, 3),
        }

    out = []
    if hs > a + 0.12:
        out.append(_slice(a, hs, "before"))
    if he < b - 0.12:
        out.append(_slice(he, b, "after"))
    return out


def logo_box(raw_transform, canvas_w: float, canvas_h: float, nat_w: float, nat_h: float) -> tuple[int, int, int, int]:
    """(left, top, width, height) in canvas pixels. Port of ``computeLogoBox`` in ``types.ts``."""
    t = normalize_logo_transform(raw_transform)
    sw = max(0.01, t["scale_w"] / 100)
    sh = max(0.01, t["scale_h"] / 100)
    logo_w = max(16, round(canvas_w * sw))
    aspect = nat_h / nat_w if nat_w > 0 and nat_h > 0 else 0.36
    logo_h = max(10, round(canvas_w * sw * aspect * (sh / sw)))
    d = DEFAULT_LOGO_TRANSFORM
    dx = ((t["pos_x"] - d["pos_x"]) - (t["anchor_x"] - d["anchor_x"]) * sw) / 1920
    dy = (-(t["pos_y"] - d["pos_y"]) + (t["anchor_y"] - d["anchor_y"]) * sh) / 1080
    left = round(canvas_w - logo_w - canvas_w * (15 / 1920) + dx * canvas_w)
    top = round(canvas_h * (19 / 1080) + dy * canvas_h)
    return left, top, logo_w, logo_h


def qa_key(issue: dict) -> str:
    """Same key as ``getQaIssueKey`` in ``frontend/src/types.ts``."""
    return f"{issue.get('screen')}::{issue.get('kind')}::{str(issue.get('message') or '')[:120]}"
