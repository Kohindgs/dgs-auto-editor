"""Chapter folders in the same layout the DGS editor already writes.

``<data>/projects/<id>/meta/*.json`` stays the source of truth, so a chapter
saved by the current editor opens here and the other way round.

Files that were linked only inside the browser are not on disk. Their new
locations are kept in ``meta/native_links.json`` instead of rewriting
``media.json``.
"""

from __future__ import annotations

import json
import os
import re
import tempfile
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from .. import paths

IMAGE_EXT = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".jfif"}
VIDEO_EXT = {".mp4", ".mov", ".webm", ".mkv", ".avi", ".m4v", ".mpg", ".mpeg", ".wmv"}
AUDIO_EXT = {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".opus", ".wma"}

DEFAULT_LOGO_TRANSFORM = {
    "scale_w": 10.0,
    "scale_h": 10.0,
    "lock_aspect": True,
    "pos_x": 1034.21,
    "pos_y": 565.98,
    "anchor_x": 1900.0,
    "anchor_y": 1065.0,
    "rotate": 0.0,
}


def _read(path: Path, default):
    try:
        with path.open(encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def _write(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name, suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _resolve_disk_path(p) -> str:
    """Absolute path for chapter JSON that may store workspace-relative media."""
    if not p:
        return ""
    raw = Path(str(p))
    try:
        if raw.is_file():
            return str(raw.resolve())
    except OSError:
        pass
    text = str(p).replace("/", "\\") if os.name == "nt" else str(p)
    data = paths.data_dir()
    roots = [data.parent, data, paths.ROOT]
    stripped = text
    for prefix in ("dgs_data\\", "dgs_data/", "data\\", "data/"):
        if stripped.lower().startswith(prefix):
            stripped = stripped[len(prefix) :]
            break
    candidates = [root / text for root in roots] + [data / stripped, data.parent / "dgs_data" / stripped]
    for cand in candidates:
        try:
            if cand.is_file():
                return str(cand.resolve())
        except OSError:
            continue
    return ""


def _exists(p) -> bool:
    try:
        return bool(_resolve_disk_path(p) or (p and Path(str(p)).is_file()))
    except OSError:
        return False


def normalize_logo_transform(raw) -> dict:
    r = raw if isinstance(raw, dict) else {}
    out = dict(DEFAULT_LOGO_TRANSFORM)
    for key in ("scale_w", "scale_h"):
        try:
            v = float(r.get(key))
            if 0.5 < v <= 200:
                out[key] = round(v, 2)
        except (TypeError, ValueError):
            pass
    for key in ("pos_x", "pos_y", "anchor_x", "anchor_y", "rotate"):
        try:
            out[key] = round(float(r.get(key)), 2)
        except (TypeError, ValueError):
            pass
    if isinstance(r.get("lock_aspect"), bool):
        out["lock_aspect"] = r["lock_aspect"]
    return out


def _newest_by_screen(folders: list[Path], exts: set[str]) -> dict[str, Path]:
    """The newest file in ``folders`` for each scene number. Backups are ignored."""
    found: dict[str, Path] = {}
    stamps: dict[str, float] = {}
    for folder in folders:
        if not folder.is_dir():
            continue
        for path in folder.rglob("*"):
            if not path.is_file() or path.suffix.lower() not in exts:
                continue
            if "_dgs_backup_originals" in path.parts:
                continue
            number = screen_number(path.name)
            if number is None:
                continue
            screen = f"screen_{number}"
            try:
                stamp = path.stat().st_mtime
            except OSError:
                continue
            if screen not in found or stamp >= stamps.get(screen, 0):
                found[screen] = path
                stamps[screen] = stamp
    return found


def _newer_of(image: Path | None, video: Path | None) -> tuple[Path | None, str]:
    """A scene video stays on that scene. A picture is used only when the scene has no video."""
    if video is not None:
        return video, "video"
    if image is not None:
        return image, "image"
    return None, "image"


def screen_number(name: str) -> int | None:
    """Scene index from a file name.

    ``48_screen_50.jpg`` / ``46_screen_47.png`` (OCR renames) map to the
    explicit ``screen_N`` suffix. Plain ``12.jpg`` / ``Scene 3.mp4`` use the
    first number in the stem.
    """
    stem = Path(name).stem
    tagged = re.search(r"(?i)(?:^|[_-])screen[_-]?0*(\d+)$", stem)
    if tagged:
        return int(tagged.group(1))
    m = re.match(r"^\D*(\d+)", stem)
    return int(m.group(1)) if m else None


def _is_export_part_path(raw) -> bool:
    """True for encode leftovers: exports/.../part_N.mp4 or diag part_N.mp4 files."""
    text = str(raw or "").replace("/", "\\").lower()
    name = Path(text).name
    if re.match(r"part_\d+\.(mp4|mov|mkv|webm)$", name):
        return True
    if "\\exports\\" in text and "\\parts\\" in text:
        return True
    if "\\dgs_studio_test\\" in text or "\\blank_parts\\" in text or "\\blank_verify\\" in text:
        return True
    return False


def _project_id_in_path(raw) -> str | None:
    m = re.search(r"[\\/]projects[\\/]([a-f0-9]{12})[\\/]", str(raw or "").replace("/", "\\"), flags=re.I)
    return m.group(1).lower() if m else None


@dataclass
class ProjectSummary:
    pid: str
    root: Path
    title: str
    mtime: float
    scenes: int
    duration: float


@dataclass
class Project:
    pid: str
    root: Path
    title: str
    plan: dict
    scenes: list
    media: list
    voiceover: dict
    poem_vo: dict
    logo: dict
    script_meta: dict
    links: dict = field(default_factory=dict)
    dirty: bool = False

    @property
    def meta(self) -> Path:
        return self.root / "meta"

    @property
    def clips(self) -> list[dict]:
        return self.plan.setdefault("clips", [])

    @property
    def duration(self) -> float:
        return float(self.plan.get("total_duration") or 0)

    @property
    def media_by_id(self) -> dict[str, dict]:
        return {str(m.get("id")): m for m in self.media if isinstance(m, dict) and m.get("id")}

    # Media -----------------------------------------------------------------

    def _link_map(self, key: str) -> dict:
        return self.links.setdefault(key, {})

    def clip_file(self, clip: dict) -> tuple[str, str]:
        """Return (path, kind) for the picture that belongs on screen."""
        kind = "video" if clip.get("kind") == "video" else "image"
        screen = str(clip.get("screen") or "")
        mid = str(clip.get("media_id") or "")
        media = self.media_by_id.get(mid, {})
        for cand in (
            self._link_map("media").get(mid),
            clip.get("media_path"),
            media.get("path"),
            self._link_map("videos" if kind == "video" else "images").get(screen),
        ):
            resolved = _resolve_disk_path(cand)
            if resolved and self._path_belongs_here(resolved):
                return resolved, _kind_of(resolved, kind)
        # Foreign / export-part leftovers: fall back to this chapter's own folder.
        own, own_kind = self._own_file_for_screen(screen)
        if own is not None:
            return str(own.resolve()), own_kind
        if kind == "video":
            still = self._link_map("images").get(screen)
            resolved = _resolve_disk_path(still)
            if resolved and self._path_belongs_here(resolved):
                return resolved, "image"
        return "", "missing"

    def media_file(self, mid: str) -> str:
        """Path on disk for one media item (linked copy first)."""
        mid = str(mid or "")
        for cand in (self._link_map("media").get(mid), self.media_by_id.get(mid, {}).get("path")):
            if _exists(cand):
                return str(cand)
        return ""

    def image_media(self) -> list[dict]:
        """Project pictures that exist on disk: ``{id, filename, path}``."""
        out = []
        for m in self.media:
            if not isinstance(m, dict) or not m.get("id"):
                continue
            path = self.media_file(m["id"])
            if path and Path(path).suffix.lower() in IMAGE_EXT:
                out.append({"id": str(m["id"]), "filename": str(m.get("filename") or Path(path).name), "path": path})
        return out

    def set_script(self, scenes: list[dict], script_meta: dict, source: Path | None = None) -> None:
        """Store an imported script the way ``handleScriptFile`` does.

        Drops the previous chapter's align clocks so poem/narration timing from
        another script cannot stick to this one. Media folder links stay.
        """
        if source is not None:
            dest_dir = self.root / "script"
            dest_dir.mkdir(parents=True, exist_ok=True)
            dest = dest_dir / source.name
            if source.resolve() != dest.resolve():
                dest.write_bytes(source.read_bytes())
        self.scenes = scenes
        self.script_meta = script_meta
        _write(self.meta / "script.json", scenes)
        _write(self.meta / "script_meta.json", script_meta)
        wipe_timeline_for_new_script(self, script_meta)
        self.seed_vo_slots_from_script()

    def seed_vo_slots_from_script(self) -> None:
        """Create empty VO slots from the Audio Manifest so Auto-align waits for every file."""
        files = self.script_meta.get("vo_files") if isinstance(self.script_meta, dict) else None
        if not isinstance(files, list) or not files:
            # Older chapters: re-read the workbook’s Audio Manifest once.
            script_name = str((self.script_meta or {}).get("filename") or "")
            cand = self.root / "script" / script_name if script_name else None
            if cand and cand.is_file():
                try:
                    from .script_import import read_script

                    files = (read_script(cand, require_master=False).meta or {}).get("vo_files") or []
                    if files:
                        self.script_meta["vo_files"] = files
                        _write(self.meta / "script_meta.json", self.script_meta)
                except Exception:
                    files = []
        if not isinstance(files, list) or not files:
            return
        existing = {int(s.get("slot") or 0): dict(s) for s in self.slots if isinstance(s, dict)}
        slots = []
        for item in files:
            if not isinstance(item, dict):
                continue
            n = int(item.get("slot") or 0)
            name = str(item.get("filename") or "").strip()
            if n < 1 or not name:
                continue
            cur = existing.get(n) or {}
            slots.append({
                **cur,
                "slot": n,
                "filename": name,
                "path": cur.get("path") if _exists(cur.get("path")) else None,
                "duration": cur.get("duration") or 0,
            })
        if not slots:
            return
        if not isinstance(self.voiceover, dict):
            self.voiceover = {}
        self.voiceover["slots"] = sorted(slots, key=lambda s: int(s.get("slot") or 0))
        if not self.voiceover.get("filename") and slots:
            self.voiceover["filename"] = slots[0].get("filename") or ""
        _write(self.meta / "voiceover.json", self.voiceover)
        self.dirty = True

    def link_folder(self, folder: Path, kind: str | None = None) -> dict:
        """Point clips at files in ``folder`` by exact name, then by scene number."""
        by_name: dict[str, Path] = {}
        images: dict[str, Path] = {}
        videos: dict[str, Path] = {}
        audio: list[Path] = []
        for p in folder.rglob("*"):
            if not p.is_file() or "_dgs_backup_originals" in p.parts:
                continue
            ext = p.suffix.lower()
            if ext in IMAGE_EXT and kind in (None, "images"):
                by_name.setdefault(p.name.lower(), p)
                n = screen_number(p.name)
                if n is not None:
                    images.setdefault(f"screen_{n}", p)
            elif ext in VIDEO_EXT and kind in (None, "videos"):
                by_name.setdefault(p.name.lower(), p)
                n = screen_number(p.name)
                if n is not None:
                    videos.setdefault(f"screen_{n}", p)
            elif ext in AUDIO_EXT and kind is None:
                audio.append(p)
        added = self.ingest_files(list(by_name.values()), kind)
        report = {"named": added, "added": added, "images": len(images), "videos": len(videos), "audio": []}
        if audio:
            report["audio"] = self._link_audio_guess(audio)
        from .folder_sync import remember_folder

        remember_folder(self, folder, kind)
        self.dirty = True
        return report

    def refresh_linked_media(self) -> dict:
        """Re-read the linked picture and video folders.

        The newest file for a scene number replaces the one already on that scene.
        A picture does not replace a video, and a video does not replace a picture.
        """
        image_dirs, video_dirs = self._linked_media_dirs()
        if not image_dirs and not video_dirs:
            return {"ok": False, "images": 0, "videos": 0, "updated": 0}
        images = _newest_by_screen(image_dirs, IMAGE_EXT)
        videos = _newest_by_screen(video_dirs, VIDEO_EXT)
        before = {str(c.get("screen") or ""): str(c.get("media_path") or "") for c in self.clips}
        self.ingest_files([*images.values(), *videos.values()], None)
        self._prefer_newest_scene_file(images, videos)
        updated = sum(
            1 for c in self.clips
            if str(c.get("media_path") or "") != before.get(str(c.get("screen") or ""), "")
        )
        self.dirty = True
        return {"ok": True, "images": len(images), "videos": len(videos), "updated": updated}

    def _prefer_newest_scene_file(self, images: dict[str, Path], videos: dict[str, Path]) -> None:
        """The newest picture or video for a scene number is the one on that scene."""
        by_name: dict[str, dict] = {}
        for item in self.media:
            if isinstance(item, dict) and item.get("filename"):
                by_name[str(item["filename"]).lower()] = item
        by_screen: dict[str, list[dict]] = {}
        for clip in self.clips:
            by_screen.setdefault(str(clip.get("screen") or ""), []).append(clip)
        for screen in set(images) | set(videos):
            for clip in by_screen.get(screen, []):
                if clip.get("manual_media_replace"):
                    cur_path = str(clip.get("media_path") or "")
                    if cur_path and Path(cur_path).is_file():
                        continue
                chosen, kind = _newer_of(images.get(screen), videos.get(screen))
                if chosen is None:
                    continue
                item = by_name.get(chosen.name.lower())
                if not item:
                    continue
                clip["media_path"] = str(chosen)
                clip["media_id"] = str(item.get("id") or "")
                clip["filename"] = chosen.name
                clip["kind"] = kind

    def _linked_media_dirs(self) -> tuple[list[Path], list[Path]]:
        image_dirs: list[Path] = []
        video_dirs: list[Path] = []
        img = Path(str(self.links.get("image_folder") or ""))
        vid = Path(str(self.links.get("video_folder") or ""))
        src = Path(str(self.links.get("source_folder") or ""))
        if img.is_dir():
            image_dirs.append(img)
        elif src.is_dir():
            for name in ("Scene Images", "scene images", "images", "Images"):
                sub = src / name
                if sub.is_dir():
                    image_dirs.append(sub)
                    break
            else:
                image_dirs.append(src)
        if vid.is_dir():
            video_dirs.append(vid)
        elif src.is_dir():
            for name in ("Scene Videos", "scene videos", "videos", "Videos"):
                sub = src / name
                if sub.is_dir():
                    video_dirs.append(sub)
                    break
        return image_dirs, video_dirs

    def link_files(self, files: list[Path], kind: str) -> int:
        """Add picked pictures or videos. A scene number in the name lands on that scene."""
        return self.ingest_files(files, kind, allow_cross_kind=True)

    def ingest_files(self, files: list[Path], kind: str | None = None, *, allow_cross_kind: bool = False) -> int:
        """Store files the user just chose, and put each one on its scene when the name has a number.

        The chosen file replaces the picture already on that scene. A new chapter
        with no scenes yet still keeps the files, so the Media tab can show them.
        """
        allowed = IMAGE_EXT if kind == "images" else VIDEO_EXT if kind == "videos" else None
        by_name: dict[str, dict] = {}
        for m in self.media:
            if isinstance(m, dict) and m.get("filename"):
                by_name[str(m["filename"]).lower()] = m
        by_screen: dict[str, list[dict]] = {}
        for clip in self.clips:
            by_screen.setdefault(str(clip.get("screen") or ""), []).append(clip)
        added = 0
        for f in files:
            if not isinstance(f, Path):
                f = Path(f)
            if not f.is_file():
                continue
            # Never ingest another chapter's export leftovers as this chapter's media.
            if _is_export_part_path(f) or (
                (_project_id_in_path(f) or "") not in ("", self.pid.lower())
            ):
                continue
            ext = f.suffix.lower()
            if allowed is not None and ext not in allowed:
                continue
            if ext in IMAGE_EXT:
                file_kind, key = "image", "images"
            elif ext in VIDEO_EXT:
                file_kind, key = "video", "videos"
            else:
                continue
            item = by_name.get(f.name.lower())
            if item is None:
                item = {"id": uuid.uuid4().hex}
                self.media.append(item)
                by_name[f.name.lower()] = item
            mid = str(item.get("id") or uuid.uuid4().hex)
            item.update({"id": mid, "filename": f.name, "path": str(f), "kind": file_kind, "local_only": True})
            self._link_map("media")[mid] = str(f)
            n = screen_number(f.name)
            if n is not None:
                screen = f"screen_{n}"
                item["screen"] = screen
                self._link_map(key)[screen] = str(f)
                if allow_cross_kind:
                    other_key = "images" if key == "videos" else "videos"
                    self._link_map(other_key).pop(screen, None)
                for clip in by_screen.get(screen, []):
                    clip_kind = "video" if clip.get("kind") == "video" else "image"
                    existing = str(clip.get("media_path") or "")
                    if allow_cross_kind or clip_kind == file_kind or not existing or not Path(existing).is_file():
                        clip["media_path"] = str(f)
                        clip["media_id"] = mid
                        clip["filename"] = f.name
                        clip["kind"] = file_kind
                        clip["fit"] = "hold" if file_kind == "image" else "passthrough"
                        if allow_cross_kind and clip_kind != file_kind:
                            dur = round(max(0.2, float(clip.get("end") or 0) - float(clip.get("start") or 0)), 3)
                            clip["source_in"] = 0.0
                            clip["source_out"] = dur
                            clip["manual_media_replace"] = True
            added += 1
        if added:
            self.dirty = True
            _write(self.meta / "media.json", self.media)
        return added

    def reset_logo(self) -> None:
        self.links.pop("logo", None)
        self.set_logo_transform(dict(DEFAULT_LOGO_TRANSFORM))

    def _link_audio_guess(self, files: list[Path]) -> list[str]:
        from .script_import import audio_name_key

        linked: list[str] = []
        by_name = {p.name.lower(): p for p in files}
        by_key: dict[str, Path] = {}
        for p in files:
            by_key.setdefault(audio_name_key(p.name), p)
        # Seed expected slots from the master script before matching names.
        self.seed_vo_slots_from_script()
        for sl in self.slots:
            want = str(sl.get("filename") or "")
            hit = by_name.get(want.lower()) or by_key.get(audio_name_key(want))
            if hit:
                self.set_slot_path(int(sl.get("slot") or 1), hit)
                linked.append(f"VO {sl.get('slot')}: {hit.name}")
        poem_name = str(self.poem_vo.get("filename") or "")
        if poem_name:
            hit = by_name.get(poem_name.lower()) or by_key.get(audio_name_key(poem_name))
            if hit:
                self.set_poem_path(hit)
                linked.append(f"Poem: {hit.name}")
        # Folder has Marathi VO 1 / VO 2 even when the script has not listed them yet.
        if not linked:
            numbered = []
            for p in files:
                m = re.search(r"(?:^|[^a-z0-9])(?:vo|voiceover|marathi\s*vo)\s*(\d+)\b", p.stem, re.I)
                if m:
                    numbered.append((int(m.group(1)), p))
            for n, p in sorted(numbered):
                self.set_slot_path(n, p)
                linked.append(f"VO {n}: {p.name}")
        return linked

    # Audio -----------------------------------------------------------------

    @property
    def slots(self) -> list[dict]:
        raw = self.voiceover.get("slots") if isinstance(self.voiceover, dict) else None
        if isinstance(raw, list) and raw:
            return sorted((s for s in raw if isinstance(s, dict)), key=lambda s: int(s.get("slot") or 0))
        plan_slots = self.plan.get("voiceover_slots")
        if isinstance(plan_slots, list) and plan_slots:
            return sorted((s for s in plan_slots if isinstance(s, dict)), key=lambda s: int(s.get("slot") or 0))
        return []

    def slot_path(self, slot: int) -> str:
        cand = self._link_map("vo_slots").get(str(slot))
        if _exists(cand):
            return str(cand)
        for sl in self.slots:
            if int(sl.get("slot") or 0) == int(slot) and _exists(sl.get("path")):
                return str(sl["path"])
        if not self.slots or len(self.slots) == 1:
            for cand in (self.links.get("voiceover"), self.voiceover.get("path"), self.plan.get("voiceover_path")):
                if _exists(cand):
                    return str(cand)
        return ""

    def set_slot_path(self, slot: int, path: Path) -> None:
        self._link_map("vo_slots")[str(slot)] = str(path)
        if not self.slots or len(self.slots) == 1:
            self.links["voiceover"] = str(path)
        self.dirty = True

    def poem_path(self) -> str:
        return self.poem_slot_path(1) or self._poem_single_path()

    def _poem_single_path(self) -> str:
        for cand in (self.links.get("poem"), self.poem_vo.get("path"), self.plan.get("poem_voiceover_path")):
            if _exists(cand):
                return str(cand)
        return ""

    def poem_slots(self) -> list[dict]:
        raw = self.poem_vo.get("slots") if isinstance(self.poem_vo, dict) else None
        if isinstance(raw, list) and raw:
            return sorted((s for s in raw if isinstance(s, dict)), key=lambda s: int(s.get("slot") or 0))
        path = self._poem_single_path()
        if path or self.poem_vo.get("filename"):
            return [{
                "slot": 1,
                "filename": self.poem_vo.get("filename") or "Poem",
                "path": path,
                "duration": self.poem_vo.get("duration") or 0,
                "start_offset": 0,
            }]
        return []

    def poem_slot_path(self, slot: int) -> str:
        cand = self._link_map("poem_slots").get(str(slot))
        if _exists(cand):
            return str(cand)
        for sl in self.poem_slots():
            if int(sl.get("slot") or 0) == int(slot) and _exists(sl.get("path")):
                return str(sl["path"])
        if int(slot) == 1:
            return self._poem_single_path()
        return ""

    def set_poem_slot_path(self, slot: int, path: Path) -> None:
        self._link_map("poem_slots")[str(int(slot))] = str(path)
        if int(slot) == 1:
            self.links["poem"] = str(path)
        self.dirty = True

    def set_poem_path(self, path: Path) -> None:
        self.set_poem_slot_path(1, path)

    # Logo ------------------------------------------------------------------

    @property
    def logo_enabled(self) -> bool:
        v = self.plan.get("logo_enabled")
        if isinstance(v, bool):
            return v
        v = self.logo.get("enabled")
        return v if isinstance(v, bool) else True

    def set_logo_enabled(self, on: bool) -> None:
        self.plan["logo_enabled"] = bool(on)
        self.logo["enabled"] = bool(on)
        self.dirty = True

    @property
    def logo_transform(self) -> dict:
        return normalize_logo_transform(self.plan.get("logo_transform") or self.logo.get("transform"))

    def set_logo_transform(self, t: dict) -> None:
        norm = normalize_logo_transform(t)
        self.plan["logo_transform"] = norm
        self.logo["transform"] = norm
        self.dirty = True

    def logo_file(self) -> str:
        for cand in (self.links.get("logo"), self.logo.get("path"), self.plan.get("logo_path")):
            if _exists(cand):
                return str(cand)
        d = paths.default_logo()
        return str(d) if d else ""

    def set_logo_file(self, path: Path) -> None:
        self.links["logo"] = str(path)
        self.dirty = True

    # Plan flags ------------------------------------------------------------

    def flag(self, key: str) -> bool:
        return bool(self.plan.get(key))

    def set_flag(self, key: str, on: bool) -> None:
        self.plan[key] = bool(on)
        self.dirty = True

    def _path_belongs_here(self, raw) -> bool:
        """True when the file is safe for this chapter.

        Rejected: export ``part_N`` leftovers, diag folders, other project ids.
        Allowed: this chapter folder, linked source folders, and normal user
        media outside ``dgs_data`` (e.g. ``Downloads\\Chapter 3.8\\…``).
        """
        text = str(raw or "").replace("/", "\\").lower()
        if not text:
            return False
        if _is_export_part_path(text):
            return False
        other = _project_id_in_path(text)
        if other and other != self.pid.lower():
            return False
        try:
            if not Path(str(raw)).is_file():
                return False
        except OSError:
            return False
        mine = str(self.root.resolve()).replace("/", "\\").lower()
        if mine and mine in text:
            return True
        # Anything still under dgs_data that isn't this project is foreign.
        if "\\dgs_data\\" in text:
            return False
        # User source trees outside dgs_data (Downloads\\Chapter …) are fine.
        return True

    def _own_file_for_screen(self, screen: str) -> tuple[Path | None, str]:
        """Newest file (picture or video) for this screen inside this chapter only."""
        images = _newest_by_screen([self.root / "media" / "images"], IMAGE_EXT)
        videos = _newest_by_screen([self.root / "media" / "videos"], VIDEO_EXT)
        img_p = images.get(screen)
        vid_p = videos.get(screen)
        if img_p is not None and vid_p is not None:
            try:
                if img_p.stat().st_mtime > vid_p.stat().st_mtime + 0.05:
                    return img_p, "image"
            except OSError:
                pass
            return vid_p, "video"
        if vid_p is not None:
            return vid_p, "video"
        if img_p is not None:
            return img_p, "image"
        return None, "missing"

    def prefer_own_media_paths(self) -> int:
        """Replace export-part / other-project clip paths with this chapter's own files.

        Also drops foreign rows from ``media.json``. When a screen has no own
        replacement, the foreign path is cleared so another chapter's video
        cannot keep playing.
        """
        fixed = 0
        kept_media: list[dict] = []
        mine = str(self.root.resolve()).replace("/", "\\").lower()
        for m in self.media:
            if not isinstance(m, dict):
                continue
            raw = str(m.get("path") or "")
            text = raw.replace("/", "\\").lower()
            other = _project_id_in_path(raw)
            drop = False
            if raw and _is_export_part_path(raw):
                drop = True
            elif other and other != self.pid.lower():
                drop = True
            elif text and "\\dgs_data\\" in text and mine and mine not in text:
                drop = True
            if drop:
                fixed += 1
                continue
            kept_media.append(m)
        if len(kept_media) != len(self.media):
            self.media = kept_media
            self.dirty = True
        by_name = {
            str(m.get("filename") or "").lower(): m
            for m in self.media
            if isinstance(m, dict) and m.get("filename")
        }
        for clip in self.clips:
            if not isinstance(clip, dict):
                continue
            screen = str(clip.get("screen") or "")
            current = str(clip.get("media_path") or "")
            if self._path_belongs_here(current) and Path(current).is_file():
                continue
            foreign = bool(current) and not self._path_belongs_here(current)
            chosen, kind = self._own_file_for_screen(screen)
            if chosen is None:
                if foreign or _is_export_part_path(current):
                    clip["media_path"] = ""
                    clip["media_id"] = ""
                    clip["filename"] = ""
                    clip["fit"] = "missing"
                    fixed += 1
                continue
            item = by_name.get(chosen.name.lower())
            if item is None:
                item = {"id": uuid.uuid4().hex}
                self.media.append(item)
                by_name[chosen.name.lower()] = item
            mid = str(item.get("id") or uuid.uuid4().hex)
            abs_path = str(chosen.resolve())
            item.update(
                {
                    "id": mid,
                    "filename": chosen.name,
                    "path": abs_path,
                    "kind": kind,
                    "screen": screen,
                    "local_only": True,
                }
            )
            clip["media_path"] = abs_path
            clip["media_id"] = mid
            clip["filename"] = chosen.name
            clip["kind"] = kind
            if kind == "image":
                clip["fit"] = "hold"
                self._link_map("images")[screen] = abs_path
            else:
                if clip.get("fit") not in ("stretch", "passthrough", "hold", "trim"):
                    clip["fit"] = "trim"
                self._link_map("videos")[screen] = abs_path
            self._link_map("media")[mid] = abs_path
            fixed += 1
        # Drop link entries that point outside this chapter.
        for bucket in ("media", "images", "videos"):
            cleaned = {}
            for key, raw in list(self._link_map(bucket).items()):
                if self._path_belongs_here(raw):
                    cleaned[key] = raw
            if cleaned != self._link_map(bucket):
                self.links[bucket] = cleaned
                fixed += 1
        if fixed:
            self.dirty = True
        return fixed

    def absolutize_media_paths(self) -> int:
        """Rewrite relative media paths to absolute so the Node engine can find them."""
        fixed = self.prefer_own_media_paths()
        for clip in self.clips:
            if not isinstance(clip, dict):
                continue
            resolved = _resolve_disk_path(clip.get("media_path"))
            if resolved and resolved != str(clip.get("media_path") or ""):
                clip["media_path"] = resolved
                fixed += 1
        for item in self.media:
            if not isinstance(item, dict):
                continue
            resolved = _resolve_disk_path(item.get("path"))
            if resolved and resolved != str(item.get("path") or ""):
                item["path"] = resolved
                fixed += 1
        for key in ("videos", "images"):
            bucket = self._link_map(key)
            for screen, raw in list(bucket.items()):
                resolved = _resolve_disk_path(raw)
                if resolved and resolved != str(raw or ""):
                    bucket[screen] = resolved
                    fixed += 1
        if fixed:
            self.dirty = True
        return fixed

    def save(self) -> None:
        self.absolutize_media_paths()
        _write(self.meta / "timeline.json", self.plan)
        _write(self.meta / "media.json", self.media)
        _write(self.meta / "logo.json", self.logo)
        _write(self.meta / "native_links.json", self.links)
        # Keep the display name (video stem or chapter title) across reopen.
        if self.title:
            _write(self.meta / "last_export.json", {"title": self.title})
        self.dirty = False

    def refresh_meta(self) -> None:
        """Re-read the files the engine writes (media, VO, logo, script); keep the plan and links."""
        meta = self.meta
        media = _read(meta / "media.json", [])
        self.media = media if isinstance(media, list) else []
        for attr, name in (("voiceover", "voiceover.json"), ("poem_vo", "poem_voiceover.json"), ("logo", "logo.json"), ("script_meta", "script_meta.json")):
            v = _read(meta / name, {})
            setattr(self, attr, v if isinstance(v, dict) else {})
        scenes = _read(meta / "script.json", [])
        if isinstance(scenes, list) and scenes:
            self.scenes = scenes


def _kind_of(path: str, fallback: str) -> str:
    ext = Path(path).suffix.lower()
    if ext in VIDEO_EXT:
        return "video"
    if ext in IMAGE_EXT:
        return "image"
    return fallback


def _title(root: Path, script_meta: dict) -> str:
    last = _read(root / "meta" / "last_export.json", {})
    if isinstance(last, dict) and last.get("title"):
        return str(last["title"])
    plan = _read(root / "meta" / "timeline.json", {})
    if isinstance(plan, dict) and plan.get("title"):
        return str(plan["title"])
    name = str(script_meta.get("filename") or "") if isinstance(script_meta, dict) else ""
    if name:
        return Path(name).stem
    if isinstance(plan, dict) and plan.get("video_srt"):
        clips = plan.get("clips") or []
        if clips and isinstance(clips[0], dict) and clips[0].get("media_path"):
            return Path(str(clips[0]["media_path"])).stem
    return f"Project {root.name}"


def list_projects() -> list[ProjectSummary]:
    found: dict[str, ProjectSummary] = {}
    for base in paths.projects_dirs():
        if not base.is_dir():
            continue
        for folder in base.iterdir():
            tl_path = folder / "meta" / "timeline.json"
            if not tl_path.is_file():
                tl_path = folder / "meta" / "script_meta.json"
                if not tl_path.is_file():
                    continue
            key = str(folder.resolve()).lower()
            if key in found:
                continue
            script_meta = _read(folder / "meta" / "script_meta.json", {})
            scenes = int(script_meta.get("scene_count") or 0) if isinstance(script_meta, dict) else 0
            found[key] = ProjectSummary(
                pid=folder.name,
                root=folder,
                title=_title(folder, script_meta),
                mtime=tl_path.stat().st_mtime,
                scenes=scenes,
                duration=0.0,
            )
    return sorted(found.values(), key=lambda s: s.mtime, reverse=True)


def wipe_timeline_for_new_script(proj: "Project", script_meta: dict | None = None) -> None:
    """Clear align/poem clocks after a script change. Keep media and VO file links."""
    plan = proj.plan if isinstance(proj.plan, dict) else {}
    poem = (script_meta or {}).get("poem") if isinstance(script_meta, dict) else None
    if not isinstance(poem, dict):
        poem = {}
    plan["clips"] = []
    plan["total_duration"] = 0
    plan["narration_segments"] = []
    plan["vo_pieces"] = []
    plan["srt_cues"] = []
    plan["qa_issues"] = []
    plan["manual_override"] = False
    plan["has_poem"] = bool(poem.get("has_poem"))
    plan["poem_start_time"] = 0
    plan["poem_end_time"] = 0
    plan["poem_lyric_start"] = 0
    for key in (
        "align_engine", "poem_align_engine", "align_note", "qa_summary", "sync_report",
        "heard_vo_words", "heard_poem_words", "vo_repeat_report", "vo_joins",
        "vo_orphan_repeats", "narration_head_in", "narration_head_out",
        "narration_tail_in", "narration_tail_out", "poem_voiceover_path",
        "poem_overlay", "ignored_qa_keys", "video_srt",
    ):
        plan.pop(key, None)
    proj.plan = plan
    for name in ("heard_words.json", "subtitles.srt", "native_ocr.json", "qa.json"):
        path = proj.meta / name
        if path.is_file():
            try:
                path.unlink()
            except OSError:
                pass
    _write(proj.meta / "timeline.json", plan)
    proj.dirty = True


def _blank_plan(pid: str) -> dict:
    """Clean timeline for a brand-new chapter — no leftover poem/VO/align state."""
    return {
        "project_id": pid,
        "clips": [],
        "total_duration": 0,
        "logo_enabled": True,
        "has_poem": False,
        "poem_start_time": 0,
        "poem_end_time": 0,
        "poem_lyric_start": 0,
        "narration_segments": [],
        "vo_pieces": [],
        "voiceover_slots": [],
        "srt_cues": [],
        "qa_issues": [],
        "ignored_qa_keys": [],
        "manual_override": False,
        "vo_muted": False,
        "poem_muted": False,
    }


def clear_alignment_residue(proj: "Project", *, keep_script: bool = True) -> None:
    """Drop heard words, VO/poem links, and align clocks so a chapter starts clean.

    Used when opening a blank chapter or replacing the script. Does not touch
    another project on disk.
    """
    plan = proj.plan if isinstance(proj.plan, dict) else {}
    pid = proj.pid
    fresh = _blank_plan(pid)
    # Keep logo preference and any user title; wipe align/audio clocks.
    for key in (
        "clips", "total_duration", "has_poem", "poem_start_time", "poem_end_time",
        "poem_lyric_start", "narration_segments", "vo_pieces", "voiceover_slots",
        "srt_cues", "qa_issues", "manual_override", "align_engine", "poem_align_engine",
        "align_note", "qa_summary", "sync_report", "heard_vo_words", "heard_poem_words",
        "vo_repeat_report", "vo_joins", "vo_orphan_repeats", "narration_head_in",
        "narration_head_out", "narration_tail_in", "narration_tail_out",
        "poem_voiceover_path", "voiceover_path",
    ):
        if key in fresh:
            plan[key] = fresh[key]
        else:
            plan.pop(key, None)
    plan["project_id"] = pid
    plan.setdefault("logo_enabled", True)
    plan.setdefault("ignored_qa_keys", [])
    proj.plan = plan
    if not keep_script:
        proj.scenes = []
        proj.script_meta = {"format": "new", "scene_count": 0, "filename": ""}
        _write(proj.meta / "script.json", [])
        _write(proj.meta / "script_meta.json", proj.script_meta)
    proj.voiceover = {}
    proj.poem_vo = {}
    proj.media = []
    proj.links = {}
    plan.pop("poem_overlay", None)
    for name in (
        "voiceover.json", "poem_voiceover.json", "media.json", "native_links.json",
        "heard_words.json", "qa.json", "subtitles.srt", "native_ocr.json",
    ):
        path = proj.meta / name
        if path.is_file():
            try:
                path.unlink()
            except OSError:
                pass
    _write(proj.meta / "timeline.json", plan)
    _write(proj.meta / "voiceover.json", {})
    _write(proj.meta / "poem_voiceover.json", {})
    _write(proj.meta / "media.json", [])
    _write(proj.meta / "native_links.json", {})
    proj.dirty = True


def create_blank_project() -> Path:
    """A new empty chapter on disk, ready to open. No script and no media yet."""
    pid = uuid.uuid4().hex[:12]
    root = paths.data_dir() / "projects" / pid
    for sub in ("media/images", "media/videos", "script", "voiceover", "logo", "meta"):
        (root / sub).mkdir(parents=True, exist_ok=True)
    _write(root / "meta" / "timeline.json", _blank_plan(pid))
    _write(root / "meta" / "script.json", [])
    _write(root / "meta" / "script_meta.json", {"format": "new", "scene_count": 0, "filename": ""})
    _write(root / "meta" / "voiceover.json", {})
    _write(root / "meta" / "poem_voiceover.json", {})
    _write(root / "meta" / "media.json", [])
    _write(root / "meta" / "native_links.json", {})
    # No OCR / QA / Poem text residue files from a previous chapter.
    for name in ("heard_words.json", "qa.json", "subtitles.srt", "native_ocr.json"):
        path = root / "meta" / name
        if path.is_file():
            try:
                path.unlink()
            except OSError:
                pass
    return root


def script_engine(scenes: list) -> str:
    """English when the spoken lines are mostly Latin. Marathi when they are mostly Devanagari.

    A handful of Devanagari letters in an English chapter does not select the Marathi engine.
    """
    from .card_match import DEVANAGARI_RE

    rows = scenes if isinstance(scenes, list) else []
    bits = []
    for row in rows[:40]:
        if isinstance(row, dict):
            bits.append(str(row.get("voiceover_text") or ""))
            bits.append(str(row.get("onscreen_text") or ""))
            bits.append(str(row.get("text") or ""))
    sample = " ".join(bits)
    dev = len(DEVANAGARI_RE.findall(sample))
    lat = sum(ch.isascii() and ch.isalpha() for ch in sample)
    if dev >= 12 and dev > lat:
        return "mr"
    return "en"


def remember_chapter_language(plan: dict, scenes: list, force: bool = False) -> bool:
    """Write the engine onto the chapter so the next open uses the same one.

    A saved choice stays. A chapter with no choice follows the script. ``force``
    rewrites every chapter from its script, which is how the choice is first saved.
    """
    if not isinstance(plan, dict):
        return False
    rows = scenes if isinstance(scenes, list) else []
    want = script_engine(rows)
    choice = str(plan.get("language_choice") or "").strip().lower()
    if not force:
        if choice in ("en", "english"):
            want = "en"
        elif choice in ("mr", "hi", "marathi", "hindi"):
            want = "mr"
    changed = False
    if plan.get("language_choice") != want:
        plan["language_choice"] = want
        changed = True
    if want == "en" and plan.get("language") != "en":
        plan["language"] = "en"
        changed = True
    elif want == "mr" and plan.get("language") not in ("mr", "hi"):
        plan["language"] = "mr"
        changed = True
    engine = plan.get("align_engine")
    if want == "en" and engine == "audio_word":
        plan["align_engine"] = "english_word"
        changed = True
    elif want == "en" and engine == "marathi":
        plan.pop("align_engine", None)
        changed = True
    return changed


def clear_false_poem_window(proj: "Project") -> bool:
    """Drop a poem clock that has no poem file and no poem scenes.

    Filmora imports / bad Auto-align passes sometimes mark 0→VO-end as a poem
    window. Playback then mutes narration for the whole chapter. Clear it and
    rebuild the voice lane on the picture clock.
    """
    plan = proj.plan if isinstance(proj.plan, dict) else {}
    if not plan.get("has_poem"):
        return False
    poem_end = float(plan.get("poem_end_time") or 0)
    poem_start = float(plan.get("poem_start_time") or 0)
    if poem_end <= poem_start + 0.2:
        plan["has_poem"] = False
        plan["poem_start_time"] = 0
        plan["poem_end_time"] = 0
        plan["poem_lyric_start"] = 0
        return True
    if proj.poem_path():
        return False
    if any(isinstance(s, dict) and s.get("is_poem") for s in (proj.scenes or [])):
        return False
    meta_poem = (proj.script_meta or {}).get("poem") if isinstance(proj.script_meta, dict) else None
    if isinstance(meta_poem, dict) and meta_poem.get("has_poem"):
        return False
    plan["has_poem"] = False
    plan["poem_start_time"] = 0.0
    plan["poem_end_time"] = 0.0
    plan["poem_lyric_start"] = 0.0
    plan["poem_voiceover_path"] = None
    if isinstance(plan.get("poem"), dict):
        plan["poem"]["has_poem"] = False
        plan["poem"]["poem_uploaded"] = False
    plan["vo_pieces"] = []
    try:
        from .repeat_vo import ensure_voice_pieces

        ensure_voice_pieces(plan)
    except Exception:
        pass
    ends = [float(c.get("end") or 0) for c in (plan.get("clips") or [])]
    for piece in plan.get("vo_pieces") or []:
        if isinstance(piece, dict):
            ends.append(float(piece.get("end") or 0))
    if ends:
        plan["total_duration"] = round(max(ends), 3)
    plan["qa_issues"] = [
        q for q in (plan.get("qa_issues") or [])
        if not (isinstance(q, dict) and q.get("kind") == "missing_poem_vo")
    ]
    plan["manual_override"] = True
    proj.dirty = True
    return True


def load_project(root: Path) -> Project:
    meta = root / "meta"
    plan = _read(meta / "timeline.json", None)
    if not isinstance(plan, dict):
        if not (meta / "script_meta.json").is_file():
            raise ValueError(f"{root.name} has no timeline or script yet")
        plan = {"project_id": root.name, "clips": [], "total_duration": 0}
    script_meta = _read(meta / "script_meta.json", {})
    scenes = _read(meta / "script.json", [])
    if not isinstance(scenes, list) or not scenes:
        scenes = plan.get("scenes") if isinstance(plan.get("scenes"), list) else []
    media = _read(meta / "media.json", [])
    voiceover = _read(meta / "voiceover.json", {})
    poem_vo = _read(meta / "poem_voiceover.json", {})
    logo = _read(meta / "logo.json", {})
    links = _read(meta / "native_links.json", {})
    # Never rewrite cut clocks on Open. Auto-align owns timing. We only repair
    # media paths that point at export leftovers or another chapter's folder.
    proj = Project(
        pid=root.name,
        root=root,
        title=_title(root, script_meta if isinstance(script_meta, dict) else {}),
        plan=plan,
        scenes=scenes,
        media=media if isinstance(media, list) else [],
        voiceover=voiceover if isinstance(voiceover, dict) else {},
        poem_vo=poem_vo if isinstance(poem_vo, dict) else {},
        logo=logo if isinstance(logo, dict) else {},
        script_meta=script_meta if isinstance(script_meta, dict) else {},
        links=links if isinstance(links, dict) else {},
    )
    # Know every narration file the master script listed, before Link / Auto-align.
    try:
        proj.seed_vo_slots_from_script()
    except Exception:
        pass
    # Filmora import / bad align can leave a poem window with no poem file.
    try:
        if clear_false_poem_window(proj):
            proj.save()
    except Exception:
        pass
    # Drop export-part / other-project pictures so chapters cannot stay mixed.
    try:
        if proj.prefer_own_media_paths():
            proj.save()
    except Exception:
        pass
    return proj
