"""Server-style timeline QA: missing cards/videos, uncovered narration, missing poem VO.

``scanTimelineQA`` in ``server.js`` currently returns [] on the live site.
This native scan raises those proofs, then merges card OCR issues.
"""

from __future__ import annotations

import re
from pathlib import Path

from .plan import qa_key, scene_label

_VIDEO_EXPECT = re.compile(
    r"video|mp4|\banim\b|animation|documentary|cinematic|footage|motion\s*clip|व्हिडिओ|चलचित्र",
    re.I,
)


def _tc(sec: float) -> str:
    s = max(0, int(sec or 0))
    return f"00:{s // 60:02d}:{s % 60:02d}:00"


def expects_video(scene: dict | None) -> bool:
    """Script Visual Type asks for a video (documentary / cinematic / explicit video).

    Only the workbook Visual Type cell (and visual_type Image/Video) count.
    Free-form visual direction often says \"documentary shot\" on a still card.
    """
    if not isinstance(scene, dict):
        return False
    if str(scene.get("visual_type") or "").strip().lower() == "video":
        return True
    return bool(_VIDEO_EXPECT.search(str(scene.get("visual_handling") or "")))


def scan_timeline_qa(plan: dict, scenes: list[dict], files: list[tuple[str, str]] | None = None) -> list[dict]:
    issues: list[dict] = []
    clips = list(plan.get("clips") or [])
    segs = plan.get("narration_segments") if isinstance(plan.get("narration_segments"), list) else clips
    by_screen = {str(s.get("screen") or ""): s for s in (scenes or []) if isinstance(s, dict)}
    path_of = {}
    if files:
        for c, (path, _kind) in zip(clips, files):
            path_of[id(c)] = path

    flagged_missing: set[str] = set()
    for i, c in enumerate(clips):
        path = path_of.get(id(c)) or c.get("media_path") or ""
        missing = c.get("fit") == "missing" or not path or not Path(str(path)).is_file()
        if not missing:
            continue
        start, end = float(c.get("start") or 0), float(c.get("end") or 0)
        screen = str(c.get("screen") or "")
        flagged_missing.add(screen)
        wants_vid = expects_video(by_screen.get(screen))
        issues.append({
            "kind": "missing_card",
            "severity": "error",
            "screen": c.get("screen"),
            "time": start,
            "end": end,
            "timecode": f"{_tc(start)}–{_tc(end)}",
            "message": (
                f"{scene_label(c.get('screen'))}: Missing video. The script asks for a video here — click Replace to link Scene video."
                if wants_vid else
                f"{scene_label(c.get('screen'))}: Missing image. The line stays here — click the preview to replace the picture."
            ),
            "source": "native_scan",
        })

    # Script asks for a video, but only a still (or nothing) is on the timeline.
    for c in clips:
        if not isinstance(c, dict):
            continue
        screen = str(c.get("screen") or "")
        if not screen or screen in flagged_missing or screen.startswith("missing_vo_"):
            continue
        scene = by_screen.get(screen)
        if not expects_video(scene):
            continue
        if str(c.get("kind") or "") == "video":
            path = path_of.get(id(c)) or c.get("media_path") or ""
            if path and Path(str(path)).is_file():
                continue
        start, end = float(c.get("start") or 0), float(c.get("end") or 0)
        issues.append({
            "kind": "missing_card",
            "severity": "error",
            "screen": screen,
            "time": start,
            "end": end,
            "timecode": f"{_tc(start)}–{_tc(end)}",
            "message": (
                f"{scene_label(screen)}: Missing video as per the script "
                f"(documentary / cinematic). Only a still is linked — add "
                f"{scene_label(screen)}.mp4 or click Replace."
            ),
            "source": "native_scan",
        })

    for seg in segs:
        ni, no = seg.get("narration_in"), seg.get("narration_out")
        try:
            if ni is None or no is None or float(no) - float(ni) <= 0.05:
                continue
        except (TypeError, ValueError):
            continue
        a, b = float(seg.get("start") or 0), float(seg.get("end") or 0)
        mid = (a + b) / 2
        covered = any(float(c.get("start") or 0) - 0.08 <= mid < float(c.get("end") or 0) + 0.08 for c in clips)
        if covered:
            continue
        issues.append({
            "kind": "uncovered_narration",
            "severity": "warning",
            "screen": seg.get("screen"),
            "time": a,
            "end": b,
            "timecode": f"{_tc(a)}–{_tc(b)}",
            "message": f"{scene_label(seg.get('screen'))}: spoken VO has no picture covering this time.",
            "source": "native_scan",
        })

    poem_end = float(plan.get("poem_end_time") or 0)
    poem_start = float(plan.get("poem_start_time") or 0)
    needs_poem = bool(plan.get("has_poem")) and poem_end > poem_start + 0.2
    poem_path = plan.get("poem_voiceover_path")
    if needs_poem and not poem_path:
        issues.append({
            "kind": "missing_poem_vo",
            "severity": "error",
            "screen": plan.get("poem_first_screen") or "",
            "time": poem_start,
            "end": poem_end,
            "timecode": f"{_tc(poem_start)}–{_tc(poem_end)}",
            "message": "Poem VO is missing. Link the poem/song file so the lyric window has audio.",
            "source": "native_scan",
        })
    return issues


def merge_qa(plan: dict, extra: list[dict], files=None, scenes=None) -> list[dict]:
    stored = [
        i for i in (plan.get("qa_issues") or [])
        if isinstance(i, dict)
        and i.get("kind") not in ("card_text", "missing_card", "uncovered_narration", "missing_poem_vo")
    ]
    native = scan_timeline_qa(plan, scenes or [], files)
    seen = set()
    out = []
    for i in stored + native + extra:
        k = qa_key(i)
        if k in seen or poem_clock_false_sync(i, plan):
            continue
        seen.add(k)
        out.append(i)
    return out


def poem_clock_false_sync(issue: dict, plan: dict) -> bool:
    """A vo_sync bubble that only exists because the poem moved the picture clock."""
    if not isinstance(issue, dict) or issue.get("kind") != "vo_sync":
        return False
    span = float(plan.get("poem_end_time") or 0) - float(plan.get("poem_start_time") or 0)
    if span <= 0.5:
        return False
    if str(issue.get("screen") or "") == "timeline":
        last = float(issue.get("time") or 0)
        voice = float(issue.get("end") or 0)
        extra = sum(float(h.get("extra") or 0) for h in (plan.get("qa_holds") or []) if isinstance(h, dict))
        removed = sum(float(j.get("removed") or 0) for j in (plan.get("vo_joins") or []) if isinstance(j, dict))
        return abs((last - span) - voice) <= 1.0 or abs((last - span - extra + removed) - voice) <= 1.0
    picture = float(issue.get("time") or 0)
    voice = float(issue.get("end") or 0)
    if picture < float(plan.get("poem_end_time") or 0) - 0.05:
        return False
    extra = 0.0
    removed = 0.0
    for hold in plan.get("qa_holds") or []:
        if isinstance(hold, dict) and float(hold.get("file") or 0) < voice - 0.02:
            extra += float(hold.get("extra") or 0)
    for join in plan.get("vo_joins") or []:
        if isinstance(join, dict) and float(join.get("file") or 0) < voice - 0.02:
            removed += float(join.get("removed") or 0)
    return abs((voice + span) - picture) <= 0.35 or abs((voice + span + extra - removed) - picture) <= 0.45
