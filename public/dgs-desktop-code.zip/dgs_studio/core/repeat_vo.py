"""Silence a later hearing of a sentence the voice already said.

The narration file is not rewritten. The cut audio is left out of the voice
lane, and the later voice moves up so that cut does not leave a gap. A pause
of 4 seconds is kept. A sentence that already sits on more than one card is
left alone.
"""

from __future__ import annotations

import re
import struct
import subprocess
from pathlib import Path


def _r3(value: float) -> float:
    return round(float(value) + 0.0, 3)


def _picture_bounds(file_a: float, file_b: float, poem_start: float, span: float) -> tuple[float, float]:
    """Picture times for one file range that does not cross the poem insert."""
    after = span > 0 and file_a >= poem_start - 0.02
    if after:
        return file_a + span, file_b + span
    return file_a, file_b


def _split_at_poem(file_a: float, file_b: float, poem_start: float, span: float) -> list[tuple[float, float]]:
    if file_b <= file_a + 0.05:
        return []
    if span <= 0 or file_b <= poem_start + 0.02 or file_a >= poem_start - 0.02:
        return [(file_a, file_b)]
    out = []
    if poem_start > file_a + 0.05:
        out.append((file_a, poem_start))
    if file_b > poem_start + 0.05:
        out.append((poem_start, file_b))
    return out


def _subtract(ranges: list[tuple[float, float]], cuts: list[tuple[float, float]]) -> list[tuple[float, float]]:
    for c0, c1 in cuts:
        nxt: list[tuple[float, float]] = []
        for a, b in ranges:
            if c1 <= a + 0.02 or c0 >= b - 0.02:
                nxt.append((a, b))
                continue
            if c0 > a + 0.04:
                nxt.append((a, min(b, c0)))
            if c1 < b - 0.04:
                nxt.append((max(a, c1), b))
        ranges = [(a, b) for a, b in nxt if b > a + 0.05]
    return ranges


def _overlaps_other_card(plan: dict, card: str, start: float, end: float) -> bool:
    """Do not silence a span that is the spoken window of a different card."""
    for clip in plan.get("clips") or []:
        screen = str(clip.get("screen") or "")
        if not screen or screen.startswith("missing_vo_"):
            continue
        if card and screen == card:
            continue
        ni = clip.get("narration_in")
        no = clip.get("narration_out")
        if ni is None or no is None:
            continue
        if start < float(no) - 0.15 and end > float(ni) + 0.15:
            return True
    return False


def _hearing_rows(group: dict) -> list[dict]:
    rows: list[dict] = []
    keep = group.get("keep")
    if isinstance(keep, dict) and float(keep.get("end") or 0) > float(keep.get("start") or 0) + 0.05:
        rows.append(keep)
    for drop in group.get("drop") or []:
        if isinstance(drop, dict) and float(drop.get("end") or 0) > float(drop.get("start") or 0) + 0.05:
            rows.append(drop)
    return rows


def _hearing_on_screen(plan: dict, screen: str, start: float, end: float) -> bool:
    for clip in plan.get("clips") or []:
        if str(clip.get("screen") or "") != screen:
            continue
        try:
            ni = float(clip.get("narration_in"))
            no = float(clip.get("narration_out"))
        except (TypeError, ValueError):
            continue
        if start < no - 0.12 and end > ni + 0.12:
            return True
    return False


def _prefer_card_owned(plan: dict, groups: list) -> list:
    """Keep the first hearing of the line for its card; silence later copies.

    Script order wins (S1 then S2 then S3). A later repeat must not steal the
    keep just because the card was already parked on that later window. An
    early copy left under the previous card is listed in drop so it can be
    silenced even when it still overlaps that previous narration span.

    Exception — MCQ answer echo: the short answer card (e.g. \"Linen and cotton
    clothes.\") owns the later hearing after the options already said those
    words. Both must stay; clearing ``drop`` leaves the spoken answer.
    """
    out: list = []
    for group in groups or []:
        if not isinstance(group, dict) or group.get("kind") != "card":
            out.append(group)
            continue
        hearings = _hearing_rows(group)
        if len(hearings) < 2:
            out.append(group)
            continue
        ranked = sorted(hearings, key=lambda h: float(h.get("start") or 0))
        card = group.get("card")
        if isinstance(card, str) and card:
            early_on_card = _hearing_on_screen(
                plan, card, float(ranked[0].get("start") or 0), float(ranked[0].get("end") or 0)
            )
            later_hits = [
                h
                for h in ranked[1:]
                if _hearing_on_screen(plan, card, float(h.get("start") or 0), float(h.get("end") or 0))
            ]
            # Options said the same short answer first; answer card repeats it —
            # keep both. A long host sentence that merely contains a later short
            # restatement (Scene 111 → Scene 115) still drops the later copy.
            if later_hits and not early_on_card:
                early_words = len(str(ranked[0].get("text") or "").split())
                later_words = len(str(later_hits[0].get("text") or "").split())
                if early_words <= later_words + 3 and early_words <= 10:
                    out.append({**group, "keep": ranked[0], "drop": []})
                    continue
        best = ranked[0]
        new_keep = {
            "start": float(best.get("start") or 0),
            "end": float(best.get("end") or 0),
            "text": str(best.get("text") or ""),
        }
        new_drop = [
            {
                "start": float(h.get("start") or 0),
                "end": float(h.get("end") or 0),
                "text": str(h.get("text") or ""),
            }
            for h in ranked[1:]
        ]
        out.append({**group, "keep": new_keep, "drop": new_drop})
    return out


def cut_spans(plan: dict, groups: list) -> list[tuple[float, float]]:
    """File-time spans to silence. Shared groups contribute nothing."""
    spans: list[tuple[float, float]] = []
    preferred = _prefer_card_owned(plan, groups)
    for group in preferred:
        if not isinstance(group, dict):
            continue
        if group.get("kind") not in ("card", "no_card", "tag"):
            continue
        card = group.get("card")
        keep_end = float((group.get("keep") or {}).get("end") or 0)
        drops = sorted(group.get("drop") or [], key=lambda d: float((d or {}).get("start") or 0))
        for i, drop in enumerate(drops):
            if not isinstance(drop, dict):
                continue
            start = float(drop.get("start") or 0)
            end = float(drop.get("end") or 0)
            if end <= start + 0.08:
                continue
            keep_start = float((group.get("keep") or {}).get("start") or 0)
            orphan_before_keep = end <= keep_start + 0.08
            # A later screen's own line is not an extra hearing. An orphan
            # copy left under a previous card (before this keep) must still
            # be silenced — that overlap is the bug, not a reason to keep it.
            if not orphan_before_keep and _overlaps_other_card(
                plan, card if isinstance(card, str) else "", start, end
            ):
                continue
            # Do not pad before ``start`` — that ate the previous word's tail
            # (e.g. Scene 114 \"bag.\" was cut when Scene 115 restatement began
            # at the same instant). A short tail after ``end`` is enough.
            a = start
            if start >= keep_end - 0.05:
                a = max(a, keep_end + 0.02)
            b = end + WORD_TAIL
            if end <= keep_start + 0.05:
                b = min(b, keep_start - 0.04)
            if i + 1 < len(drops):
                nxt = float(drops[i + 1].get("start") or b)
                b = min(b, nxt - 0.04)
            if b > a + 0.08:
                spans.append((a, b))
    for orphan in plan.get("vo_orphan_repeats") or []:
        if not isinstance(orphan, dict):
            continue
        start = float(orphan.get("start") or 0)
        end = float(orphan.get("end") or 0)
        if end <= start + 0.08:
            continue
        # Orphan repeat left under the previous card — silence or delete it.
        spans.append((start, end + WORD_TAIL))
    spans.sort()
    return spans


def _slot_file_span(slot: dict) -> tuple[float, float] | None:
    offset = float(slot.get("start_offset") or 0)
    duration = float(slot.get("duration") or 0)
    if duration <= 0.05:
        end_offset = float(slot.get("end_offset") or 0)
        duration = end_offset - offset
    if duration <= 0.05:
        return None
    return offset, offset + duration


def apply_repeat_cuts(plan: dict, groups: list, poem_groups: list | None = None) -> int:
    """Punch narration holes for extra hearings. Returns how many were cut.

    Preference goes to the VO that sits on the card that owns the line. An
    orphan repeat left under a previous card is silenced. Pictures are not
    stretched onto a repeated hearing. The audio file is not rewritten.
    """
    narr = _prefer_card_owned(plan, [g for g in (groups or []) if isinstance(g, dict)])
    poem = [g for g in (poem_groups or []) if isinstance(g, dict)]
    plan["vo_repeat_report"] = {
        "narration": narr,
        "poem": poem,
        "orphans": [o for o in (plan.get("vo_orphan_repeats") or []) if isinstance(o, dict)],
    }
    spans = cut_spans(plan, narr)
    if not spans:
        return 0
    poem_start = float(plan.get("poem_start_time") or 0)
    poem_end = float(plan.get("poem_end_time") or 0)
    span = poem_end - poem_start if poem_end > poem_start + 0.2 and plan.get("has_poem") else 0.0
    pieces: list[dict] = []
    for slot in plan.get("voiceover_slots") or []:
        if not isinstance(slot, dict):
            continue
        file_span = _slot_file_span(slot)
        if not file_span:
            continue
        slot_no = int(slot.get("slot") or 1)
        offset = float(slot.get("start_offset") or 0)
        name = slot.get("filename") or f"VO {slot_no}"
        ranges = []
        for file_a, file_b in _split_at_poem(file_span[0], file_span[1], poem_start, span):
            ranges.extend(_subtract([(file_a, file_b)], spans))
        for n, (file_a, file_b) in enumerate(ranges):
            pic_a, pic_b = _picture_bounds(file_a, file_b, poem_start, span)
            pieces.append({
                "id": f"vo-s{slot_no}-{n}",
                "slot": slot_no,
                "filename": name,
                "start": _r3(pic_a),
                "end": _r3(pic_b),
                "source_in": _r3(file_a - offset),
                "source_out": _r3(file_b - offset),
            })
    pieces.sort(key=lambda p: (int(p["slot"]), float(p["start"])))
    plan["vo_pieces"] = pieces
    plan["manual_override"] = True
    return len(spans)


MAX_VOICE_GAP = 4.0
# A cut sits after the word, long enough for the last syllable to be heard.
WORD_TAIL = 0.18


def _shift_range(start: float, end: float, at: float, excess: float) -> tuple[float, float]:
    """Move the part of a range that sits at or after ``at`` earlier by ``excess``."""
    if end <= at + 0.02:
        return start, end
    if start >= at - 0.03:
        return start - excess, end - excess
    return start, end - excess


def _file_edge(plan: dict, piece: dict, edge: str) -> float:
    offset = _slot_offset(plan, int(piece.get("slot") or 1))
    key = "source_in" if edge == "in" else "source_out"
    return offset + float(piece.get(key) or 0)


def _note_join(plan: dict, file_at: float, removed: float) -> None:
    """Remember picture time removed after this voice-file moment.

    Later cards stay locked once sync subtracts the same amount.
    """
    if removed <= 0.02:
        return
    joins = [j for j in (plan.get("vo_joins") or []) if isinstance(j, dict)]
    joins.append({"file": _r3(file_at), "removed": _r3(removed)})
    plan["vo_joins"] = joins


def _shift_point_rows(rows, at: float, excess: float) -> None:
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        if row.get("start") is not None or row.get("end") is not None:
            s, e = _shift_range(float(row.get("start") or 0), float(row.get("end") or 0), at, excess)
            row["start"] = _r3(s)
            row["end"] = _r3(e)
        elif row.get("time") is not None and str(row.get("screen") or "") != "timeline":
            t = float(row.get("time") or 0)
            if t >= at - 0.03:
                row["time"] = _r3(t - excess)


def close_long_gaps(plan: dict, max_gap: float = MAX_VOICE_GAP, only_files: list | None = None) -> int:
    """A narration silence longer than 4 seconds closes down to 4 seconds.

    The poem window is the song, so it is left as it is. Pictures after the
    silence move with the voice, and the spoken file time of each line stays.
    """
    pieces = [dict(p) for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    if len(pieces) < 2:
        return 0
    pieces.sort(key=lambda p: (float(p.get("start") or 0), float(p.get("end") or 0)))
    poem_s = float(plan.get("poem_start_time") or 0)
    poem_e = float(plan.get("poem_end_time") or 0)
    has_poem = bool(plan.get("has_poem")) and poem_e > poem_s + 0.2
    closed = 0
    for i in range(len(pieces) - 1):
        gap_start = float(pieces[i].get("end") or 0)
        gap_end = float(pieces[i + 1].get("start") or 0)
        if has_poem and gap_start <= poem_s + 0.08 and gap_end >= poem_e - 0.08:
            continue
        gap = gap_end - gap_start
        if gap <= max_gap + 0.02:
            continue
        file_at = _file_edge(plan, pieces[i], "out")
        if only_files is not None:
            file_b = _file_edge(plan, pieces[i + 1], "in")
            if not any(b > file_at + 0.05 and a < file_b - 0.05 for a, b in only_files):
                continue
        excess = gap - max_gap
        _note_join(plan, file_at, excess)
        for piece in pieces[i + 1 :]:
            piece["start"] = _r3(float(piece.get("start") or 0) - excess)
            piece["end"] = _r3(float(piece.get("end") or 0) - excess)
        for clip in plan.get("clips") or []:
            if not isinstance(clip, dict):
                continue
            s, e = _shift_range(float(clip.get("start") or 0), float(clip.get("end") or 0), gap_end, excess)
            clip["start"] = _r3(s)
            clip["end"] = _r3(max(s + 0.2, e))
            clip["duration"] = _r3(float(clip["end"]) - float(clip["start"]))
            if clip.get("kind") != "video":
                clip["source_out"] = clip["duration"]
        for seg in plan.get("narration_segments") or []:
            if not isinstance(seg, dict):
                continue
            s, e = _shift_range(float(seg.get("start") or 0), float(seg.get("end") or 0), gap_end, excess)
            seg["start"] = _r3(s)
            seg["end"] = _r3(e)
        _shift_point_rows(plan.get("srt_cues"), gap_end, excess)
        _shift_point_rows(plan.get("qa_issues"), gap_end, excess)
        if has_poem and poem_s >= gap_end - 0.03:
            poem_s -= excess
            poem_e -= excess
            plan["poem_start_time"] = _r3(poem_s)
            plan["poem_end_time"] = _r3(poem_e)
        total = float(plan.get("total_duration") or 0)
        if total > 0:
            plan["total_duration"] = _r3(max(0.2, total - excess))
        closed += 1
    plan["vo_pieces"] = pieces
    if closed:
        plan["manual_override"] = True
    return closed


def close_break_gaps(plan: dict) -> int:
    """Join the voice where a cut left a gap. A 4-second pause stays.

    The poem window stays. Question-answer pauses and recording pauses that
    were already closed to 4 seconds stay. Every other break in the voice
    lane closes, and the later pictures move with the voice.
    """
    pieces = [dict(p) for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    if len(pieces) < 2:
        return 0
    pieces.sort(key=lambda p: (float(p.get("start") or 0), float(p.get("end") or 0)))
    poem_s = float(plan.get("poem_start_time") or 0)
    poem_e = float(plan.get("poem_end_time") or 0)
    has_poem = bool(plan.get("has_poem")) and poem_e > poem_s + 0.2
    closed = 0
    for i in range(len(pieces) - 1):
        gap_start = float(pieces[i].get("end") or 0)
        gap_end = float(pieces[i + 1].get("start") or 0)
        gap = gap_end - gap_start
        if gap <= 0.08:
            continue
        if has_poem and gap_start <= poem_s + 0.08 and gap_end >= poem_e - 0.08:
            continue
        if abs(gap - MAX_VOICE_GAP) <= 0.15:
            continue
        excess = gap
        _note_join(plan, _file_edge(plan, pieces[i], "out"), excess)
        for piece in pieces[i + 1 :]:
            piece["start"] = _r3(float(piece.get("start") or 0) - excess)
            piece["end"] = _r3(float(piece.get("end") or 0) - excess)
        for clip in plan.get("clips") or []:
            if not isinstance(clip, dict):
                continue
            s, e = _close_span(float(clip.get("start") or 0), float(clip.get("end") or 0), gap_start, gap_end, excess)
            clip["start"] = _r3(s)
            clip["end"] = _r3(max(s + 0.2, e))
            clip["duration"] = _r3(float(clip["end"]) - float(clip["start"]))
            if clip.get("kind") != "video":
                clip["source_out"] = clip["duration"]
        for key in ("narration_segments", "srt_cues"):
            for row in plan.get(key) or []:
                if not isinstance(row, dict) or row.get("start") is None:
                    continue
                s, e = _close_span(float(row.get("start") or 0), float(row.get("end") or 0), gap_start, gap_end, excess)
                row["start"] = _r3(s)
                row["end"] = _r3(e)
        for issue in plan.get("qa_issues") or []:
            if not isinstance(issue, dict) or issue.get("time") is None:
                continue
            if str(issue.get("screen") or "") == "timeline":
                continue
            t = float(issue.get("time") or 0)
            if t >= gap_end - 0.03:
                issue["time"] = _r3(t - excess)
            elif t > gap_start + 0.02:
                issue["time"] = _r3(gap_start)
        if has_poem and poem_s >= gap_end - 0.03:
            poem_s -= excess
            poem_e -= excess
            plan["poem_start_time"] = _r3(poem_s)
            plan["poem_end_time"] = _r3(poem_e)
        total = float(plan.get("total_duration") or 0)
        if total > 0:
            plan["total_duration"] = _r3(max(0.2, total - excess))
        closed += 1
    plan["vo_pieces"] = pieces
    _butt_ranges(plan.get("clips"))
    _butt_ranges(plan.get("narration_segments"))
    _butt_ranges(plan.get("srt_cues"))
    ends = [float(c.get("end") or 0) for c in (plan.get("clips") or []) if isinstance(c, dict)]
    if ends:
        plan["total_duration"] = _r3(max(ends))
    if closed:
        plan["manual_override"] = True
    return closed


def _butt_ranges(rows) -> None:
    """Close a sliver left between neighbours after several cuts move the clock."""
    ordered = [row for row in (rows or []) if isinstance(row, dict)]
    ordered.sort(key=lambda row: float(row.get("start") or 0))
    for prev, nxt in zip(ordered, ordered[1:]):
        gap = float(nxt.get("start") or 0) - float(prev.get("end") or 0)
        if 0.001 < gap <= 0.25:
            prev["end"] = _r3(float(nxt.get("start") or 0))
            if prev.get("duration") is not None or prev.get("start") is not None:
                prev["duration"] = _r3(float(prev["end"]) - float(prev.get("start") or 0))
            if prev.get("kind") not in (None, "video") and prev.get("source_out") is not None:
                prev["source_out"] = prev["duration"]


def _close_span(start: float, end: float, gap_start: float, gap_end: float, excess: float) -> tuple[float, float]:
    """Pull a range closed across a voice break. The 4-second pauses are not passed here."""
    if end <= gap_start + 0.02:
        return start, end
    if start >= gap_end - 0.03:
        return start - excess, end - excess
    if start >= gap_start - 0.02:
        return gap_start, end - excess
    return start, end - excess


def _slot_offset(plan: dict, slot_no: int) -> float:
    for slot in plan.get("voiceover_slots") or []:
        if isinstance(slot, dict) and int(slot.get("slot") or 1) == slot_no:
            return float(slot.get("start_offset") or 0)
    return 0.0


def _ensure_pieces(plan: dict) -> list[dict]:
    """Voice blocks for the whole narration, split so the poem stays a window."""
    existing = [dict(p) for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    if existing:
        return existing
    poem_start = float(plan.get("poem_start_time") or 0)
    poem_end = float(plan.get("poem_end_time") or 0)
    span = poem_end - poem_start if poem_end > poem_start + 0.2 and plan.get("has_poem") else 0.0
    pieces: list[dict] = []
    for slot in plan.get("voiceover_slots") or []:
        if not isinstance(slot, dict):
            continue
        file_span = _slot_file_span(slot)
        if not file_span:
            continue
        slot_no = int(slot.get("slot") or 1)
        offset = float(slot.get("start_offset") or 0)
        name = slot.get("filename") or f"VO {slot_no}"
        for n, (file_a, file_b) in enumerate(_split_at_poem(file_span[0], file_span[1], poem_start, span)):
            pic_a, pic_b = _picture_bounds(file_a, file_b, poem_start, span)
            pieces.append({
                "id": f"vo-s{slot_no}-{n}",
                "slot": slot_no,
                "filename": name,
                "start": _r3(pic_a),
                "end": _r3(pic_b),
                "source_in": _r3(file_a - offset),
                "source_out": _r3(file_b - offset),
            })
    pieces.sort(key=lambda p: (int(p["slot"]), float(p["start"])))
    return pieces


def ensure_voice_pieces(plan: dict) -> list[dict]:
    """A chapter with no repeat cut still needs voice blocks before pauses are cut."""
    pieces = _ensure_pieces(plan)
    if pieces and not plan.get("vo_pieces"):
        plan["vo_pieces"] = pieces
    return list(plan.get("vo_pieces") or pieces)


def punch_file_spans(plan: dict, spans: list[tuple[float, float]]) -> int:
    """Silence merged-file ranges. Picture time inside a block stays 1:1 with the file."""
    usable = [(a, b) for a, b in spans if b > a + 0.08]
    if not usable:
        return 0
    pieces = _ensure_pieces(plan)
    if not pieces:
        return 0
    rebuilt: list[dict] = []
    for piece in pieces:
        slot_no = int(piece.get("slot") or 1)
        offset = _slot_offset(plan, slot_no)
        file_a = offset + float(piece.get("source_in") or 0)
        file_b = offset + float(piece.get("source_out") or 0)
        if file_b <= file_a + 0.05:
            continue
        pic_a = float(piece.get("start") or 0)
        remain = _subtract([(file_a, file_b)], usable)
        for n, (fa, fb) in enumerate(remain):
            shift = fa - file_a
            rebuilt.append({
                **piece,
                "id": f"{piece.get('id')}-{n}",
                "start": _r3(pic_a + shift),
                "end": _r3(pic_a + shift + (fb - fa)),
                "source_in": _r3(fa - offset),
                "source_out": _r3(fb - offset),
            })
    rebuilt.sort(key=lambda p: (int(p.get("slot") or 1), float(p.get("start") or 0)))
    plan["vo_pieces"] = rebuilt
    plan["manual_override"] = True
    return len(usable)


def _drop_screen(rows, screens: set[str]) -> list:
    return [row for row in (rows or []) if not (isinstance(row, dict) and str(row.get("screen") or "") in screens)]


def drop_false_take_retakes(plan: dict) -> int:
    """Silence an in-scene false start / misread take when the speaker repeats the line.

    Covers both cases:
    - Case A: The false take sits at the start of the owning card (e.g. Scene 50
      first says "गाऊ आणि घेऊ हे यमक जुळणारे शब्द आहेत." 7/8 words, then says
      "गाऊ आणि जाऊ हे यमक जुळणारे शब्द आहेत." 8/8 words).
    - Case B: The false take was left at the tail of the previous card (e.g.
      Scene 49 says its own 8/8 line, followed by the 7/8 false take before
      Scene 50 starts).
    """
    heard = _heard_words(plan)
    if not heard:
        return 0
    ensure_voice_pieces(plan)
    clips = _lesson_clips(plan)
    if not clips:
        return 0
    spans: list[tuple[float, float]] = []
    for c_idx, clip in enumerate(clips):
        ni_raw, no_raw = clip.get("narration_in"), clip.get("narration_out")
        if ni_raw is None or no_raw is None:
            continue
        try:
            ni, no = float(ni_raw), float(no_raw)
        except (TypeError, ValueError):
            continue
        if no - ni < 5.0:
            continue
        toks = _line_tokens(clip)
        if len(toks) < 3:
            continue
        w_in = [w for w in heard if w[0] >= ni - 0.12 and w[1] <= no + 0.12]
        if len(w_in) < len(toks) + 2:
            continue
        takes: list[list[tuple[float, float, str]]] = []
        cur: list[tuple[float, float, str]] = []
        for w in w_in:
            if cur:
                gap = w[0] - cur[-1][1]
                end_restart = (
                    len(cur) >= 3
                    and _same_token(toks[-1], cur[-1][2])
                    and (_same_token(toks[0], w[2]) or gap >= 0.45)
                )
                if gap >= 0.65 or end_restart:
                    takes.append(cur)
                    cur = []
            cur.append(w)
        if cur:
            takes.append(cur)
        if len(takes) < 2:
            continue
        scored = []
        for idx, t in enumerate(takes):
            tt = [x[2] for x in t]
            hits = sum(1 for tok in toks if any(_same_token(tok, ht) for ht in tt))
            cov = hits / len(toks)
            scored.append((idx, t, hits, cov))
        screen = str(clip.get("screen") or "")
        # Case C: First take covers >= 75% of this card, and trailing take starts with
        # the next card's opening words (e.g. Scene 53 "पुस्तके वाचण्याचे चार फायदे." followed
        # by false start "उदाहरणार्थ, ज्ञान वाढते चार फायदे सांगा." before Scene 54's full
        # "उदाहरणार्थ, ज्ञान वाढते, नवे शब्द कळतात...").
        if (
            scored[0][3] >= 0.75
            and scored[0][2] >= 3
            and c_idx + 1 < len(clips)
        ):
            nxt_toks = _line_tokens(clips[c_idx + 1])
            tail_words = [x[2] for x in takes[-1]]
            if (
                len(nxt_toks) >= 3
                and len(tail_words) >= 2
                and _same_token(nxt_toks[0], tail_words[0])
                and _same_token(nxt_toks[1], tail_words[1])
            ):
                win_end = takes[-2][-1][1]
                nxt_start = takes[-1][0][0]
                new_no = _r3(min(nxt_start - 0.20, win_end + 0.40))
                if no > new_no + 0.5:
                    spans.append((new_no, no))
                    clip["narration_out"] = new_no
                    for row in plan.get("narration_segments") or []:
                        if isinstance(row, dict) and str(row.get("screen") or "") == screen:
                            row["narration_out"] = new_no
                    continue
        full = [s for s in scored if s[3] >= 0.65 and len(s[1]) >= 3]
        if len(full) < 2:
            continue
        best_hits = max(s[2] for s in full)
        if not any(s[2] < best_hits for s in full):
            continue
        winner = [s for s in full if s[2] == best_hits][-1]
        win_idx = winner[0]
        # Case A: Inferior false take(s) before the winning take on this card
        if win_idx > 0 and all(s[2] < best_hits for s in full if s[0] < win_idx):
            prev_end = takes[win_idx - 1][-1][1]
            win_start = winner[1][0][0]
            lead = max(0.25, min(0.56, takes[0][0][0] - ni))
            new_ni = _r3(max(prev_end + 0.20, win_start - lead))
            if new_ni > ni + 0.5:
                spans.append((ni, new_ni))
                clip["narration_in"] = new_ni
                for row in plan.get("narration_segments") or []:
                    if isinstance(row, dict) and str(row.get("screen") or "") == screen:
                        row["narration_in"] = new_ni
        # Case B: Inferior false take(s) trailing after the winning take on this card
        elif win_idx < len(takes) - 1 and all(s[2] < best_hits for s in full if s[0] > win_idx):
            win_end = winner[1][-1][1]
            nxt_start = takes[win_idx + 1][0][0]
            tail = max(0.25, min(0.60, no - takes[-1][-1][1]))
            new_no = _r3(min(nxt_start - 0.20, win_end + tail))
            if no > new_no + 0.5:
                spans.append((new_no, no))
                clip["narration_out"] = new_no
                for row in plan.get("narration_segments") or []:
                    if isinstance(row, dict) and str(row.get("screen") or "") == screen:
                        row["narration_out"] = new_no
    if not spans:
        return 0
    return punch_file_spans(plan, spans)


def silence_unscripted(plan: dict) -> int:
    """A sentence the script never wrote is taken out of the voice.

    The empty missing card goes with it. The picture before it holds across
    the short hole. A hole longer than 4 seconds is closed to 4 seconds.
    """
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict)]
    targets = [c for c in clips if str(c.get("screen") or "").startswith("missing_vo_")]
    if not targets:
        return 0
    spans = []
    for clip in targets:
        a = float(clip.get("narration_in") or 0)
        b = float(clip.get("narration_out") or 0)
        if b > a + 0.08:
            spans.append((a, b + 0.15))
    punch_file_spans(plan, spans)
    screens = {str(c.get("screen") or "") for c in targets}
    kept: list[dict] = []
    for clip in clips:
        if str(clip.get("screen") or "") in screens:
            if kept and abs(float(kept[-1].get("end") or 0) - float(clip.get("start") or 0)) < 0.08:
                prev = kept[-1]
                prev["end"] = _r3(float(clip.get("end") or prev.get("end") or 0))
                prev["duration"] = _r3(float(prev["end"]) - float(prev.get("start") or 0))
                if prev.get("kind") != "video":
                    prev["source_out"] = prev["duration"]
            continue
        kept.append(clip)
    plan["clips"] = kept
    plan["narration_segments"] = _drop_screen(plan.get("narration_segments"), screens)
    plan["srt_cues"] = _drop_screen(plan.get("srt_cues"), screens)
    plan["qa_issues"] = _drop_screen(plan.get("qa_issues"), screens)
    report = plan.get("sync_report")
    if isinstance(report, dict) and isinstance(report.get("issues"), list):
        report["issues"] = _drop_screen(report.get("issues"), screens)
    plan["manual_override"] = True
    return len(targets)


def cap_voice_pauses(plan: dict, words: list | None, max_gap: float = MAX_VOICE_GAP) -> int:
    """Any narration silence longer than 4 seconds, including one already in the
    recording, closes to 4 seconds. The poem window is not a pause.
    """
    poem_s = float(plan.get("poem_start_time") or 0)
    poem_e = float(plan.get("poem_end_time") or 0)
    has_poem = bool(plan.get("has_poem")) and poem_e > poem_s + 0.2
    ordered = sorted(
        (w for w in (words or []) if isinstance(w, dict)),
        key=lambda w: float(w.get("start") or 0),
    )
    cuts: list[tuple[float, float]] = []
    for i in range(len(ordered) - 1):
        a_end = float(ordered[i].get("end") or 0)
        b = float(ordered[i + 1].get("start") or 0)
        # Leave the end of the word in the voice. The pause starts after it.
        a = min(b - 0.06, a_end + WORD_TAIL)
        if b <= a + max_gap + 0.05:
            continue
        if has_poem and a < poem_e - 0.05 and b > poem_s + 0.05:
            continue
        cuts.append((a, b))
    punched = punch_file_spans(plan, cuts) if cuts else 0
    closed = close_long_gaps(plan, max_gap, only_files=cuts) if cuts and plan.get("vo_pieces") else 0
    return punched + closed


def repair_vo_piece_sync(plan: dict) -> int:
    """Keep edited VO pieces on the same clock as the pictures and word times.

    Playback with ``vo_edited`` maps timeline t → file as
    ``source_in + (t - piece.start)``. If ``piece.start`` is earlier than
    ``slot_offset + source_in``, the voice runs ahead of the cards (e.g. “In
    rural areas…” before Scene 70’s video, “while women wear sarees” under the
    rural take, “We have studied this” late). Rebuild each piece so
    ``start = offset + source_in`` and ``end = offset + source_out``.
    """
    if plan.get("has_poem") or plan.get("vo_joins") or plan.get("qa_holds"):
        return 0
    pieces = [p for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    if not pieces:
        return 0
    worst = 0.0
    for piece in pieces:
        offset = _slot_offset(plan, int(piece.get("slot") or 1))
        try:
            start = float(piece.get("start") or 0)
            src_in = float(piece.get("source_in") or 0)
        except (TypeError, ValueError):
            continue
        worst = max(worst, abs((offset + src_in) - start))
    if worst < 0.25:
        return 0
    # Prefer a clean slot rebuild when drift is large — gapped source_in with a
    # continuous timeline cannot be patched piece-by-piece without replaying cuts.
    # Keep the poem insert: never flatten head+tail into one VO piece that plays
    # through the song window.
    if worst >= 1.0:
        plan["vo_pieces"] = []
        rebuilt = _ensure_pieces(plan)
        if not rebuilt:
            return 0
        # Stable ids so a later sync pass can still see them as rebuilt pieces.
        for piece in rebuilt:
            piece["id"] = f"vo-slot-{int(piece.get('slot') or 1)}-sync-{piece.get('id')}"
        plan["vo_pieces"] = rebuilt
        plan["manual_override"] = True
        return len(rebuilt)
    rebuilt = []
    for piece in pieces:
        slot_no = int(piece.get("slot") or 1)
        offset = _slot_offset(plan, slot_no)
        try:
            src_in = float(piece.get("source_in") or 0)
            src_out = float(piece.get("source_out") or 0)
        except (TypeError, ValueError):
            continue
        if src_out <= src_in + 0.05:
            continue
        rebuilt.append({
            **piece,
            "start": _r3(offset + src_in),
            "end": _r3(offset + src_out),
            "source_in": _r3(src_in),
            "source_out": _r3(src_out),
        })
    rebuilt.sort(key=lambda p: (int(p.get("slot") or 1), float(p.get("start") or 0)))
    if not rebuilt:
        return 0
    plan["vo_pieces"] = rebuilt
    plan["manual_override"] = True
    return len(rebuilt)


def snap_vo_piece_heads(plan: dict) -> int:
    """Drop silent repeat-cut slivers and snap VO piece starts to their card start.

    After punching repeated takes, a VO piece can start 0.1–1.0s before its
    scene card (in the trailing silence of the previous cut) or leave a short
    silent sliver (<= 1.2s with no heard words) between two dropped repeats.
    """
    pieces = [dict(p) for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict)]
    if not pieces or not clips:
        return 0
    words = [w for w in (plan.get("heard_vo_words") or []) if isinstance(w, dict)]
    changed = 0
    cleaned: list[dict] = []
    for p in pieces:
        vs = float(p.get("start") or 0)
        ve = float(p.get("end") or vs)
        si = float(p.get("source_in") or 0)
        so = float(p.get("source_out") or si)
        dur = ve - vs
        slot = int(p.get("slot") or 1)
        off = _slot_offset(plan, slot)
        # 1. Drop short silent slivers (<= 1.2s) that have zero heard words
        if dur <= 1.25 and words and not p.get("replace_path"):
            fa, fb = off + si, off + so
            has_word = any(
                float(w.get("end") or 0) > fa + 0.04 and float(w.get("start") or 0) < fb - 0.04
                for w in words
            )
            if not has_word:
                changed += 1
                continue
        # 2. If piece starts slightly before the card that owns its midpoint,
        #    and that leading overhang is pure silence, trim it to the card start.
        mid = (vs + ve) * 0.5
        mid_clip = next(
            (c for c in clips if float(c.get("start") or 0) <= mid <= float(c.get("end") or 0) + 0.001),
            None,
        )
        if mid_clip is not None and not p.get("replace_path"):
            cs = float(mid_clip.get("start") or 0)
            overhang = cs - vs
            if 0.02 <= overhang <= 1.05 and (ve - cs) >= 0.25:
                fa, fb = off + si, off + si + overhang
                lead_has_word = any(
                    float(w.get("end") or 0) > fa + 0.04 and float(w.get("start") or 0) < fb - 0.04
                    for w in words
                )
                if not lead_has_word:
                    p["start"] = _r3(cs)
                    p["source_in"] = _r3(si + overhang)
                    changed += 1
        cleaned.append(p)
    if changed:
        plan["vo_pieces"] = cleaned
    return changed


def align_voice_pieces(plan: dict) -> int:
    """Put each heard range on the picture clock of the card that says it.

    Used when a question-answer pause was cut into the pictures and left in
    the voice, so the voice runs ahead of the cards. A chapter that already
    has those pauses as holes is left unchanged. The question picture stays
    up, and the answer starts when the answer words start.
    """
    pieces = [p for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    if not pieces or not _pause_left_in_voice(plan, pieces):
        return 0
    windows = _speech_windows(plan)
    allowed = _allowed_file_ranges(plan, pieces)
    if not windows or not allowed:
        return 0
    rebuilt: list[dict] = []
    for ni, no, pic, pic_end in windows:
        room = pic_end - pic
        play_end = min(no, ni + max(0.0, room))
        if play_end <= ni + 0.04:
            continue
        parts = []
        for fa, fb, slot_no, name, offset in allowed:
            a = max(ni, fa)
            b = min(play_end, fb)
            if b <= a + 0.04:
                continue
            parts.append((a, b, slot_no, name, offset))
        for a, b, slot_no, name, offset in parts:
            start = pic + (a - ni)
            if start >= pic_end - 0.04:
                continue
            end = min(pic_end, start + (b - a))
            if end <= start + 0.04:
                continue
            rebuilt.append({
                "id": f"vo-s{slot_no}-p{len(rebuilt)}",
                "slot": slot_no,
                "filename": name,
                "start": _r3(start),
                "end": _r3(end),
                "source_in": _r3(a - offset),
                "source_out": _r3((a - offset) + (end - start)),
            })
    rebuilt = _merge_voice_pieces(rebuilt)
    if not rebuilt or _same_voice_pieces(pieces, rebuilt):
        return 0
    plan["vo_pieces"] = rebuilt
    plan["manual_override"] = True
    return len(rebuilt)


def _pause_left_in_voice(plan: dict, pieces: list[dict]) -> bool:
    """True when a question-answer pause is still inside one voice block."""
    holds = [h for h in (plan.get("qa_holds") or []) if isinstance(h, dict)]
    if not holds:
        return False
    for piece in pieces:
        offset = _slot_offset(plan, int(piece.get("slot") or 1))
        try:
            fa = offset + float(piece.get("source_in") or 0)
            fb = offset + float(piece.get("source_out") or 0)
        except (TypeError, ValueError):
            continue
        for hold in holds:
            try:
                q = float(hold.get("file"))
                extra = float(hold.get("extra") or 0)
            except (TypeError, ValueError):
                continue
            answer = q + 4.0 - extra
            if answer <= q + 0.2:
                continue
            if fa + 0.2 < q and answer < fb - 0.2:
                return True
    return False


def _allowed_file_ranges(plan: dict, pieces: list[dict]) -> list[tuple]:
    """File ranges the voice is allowed to play. Cut audio stays out."""
    ranges = []
    for piece in pieces:
        slot_no = int(piece.get("slot") or 1)
        offset = _slot_offset(plan, slot_no)
        try:
            fa = offset + float(piece.get("source_in") or 0)
            fb = offset + float(piece.get("source_out") or 0)
        except (TypeError, ValueError):
            continue
        if fb <= fa + 0.04:
            continue
        ranges.append((fa, fb, slot_no, piece.get("filename") or f"VO {slot_no}", offset))
    return ranges


def _speech_windows(plan: dict) -> list[tuple[float, float, float, float]]:
    """(file start, file end, picture start, picture end) outside the poem."""
    poem_s = float(plan.get("poem_start_time") or 0)
    poem_e = float(plan.get("poem_end_time") or 0)
    has_poem = bool(plan.get("has_poem")) and poem_e > poem_s + 0.2
    windows = []
    for clip in plan.get("clips") or []:
        if not isinstance(clip, dict):
            continue
        start = float(clip.get("start") or 0)
        end = float(clip.get("end") or start)
        if has_poem and poem_s - 0.05 <= start < poem_e - 0.05:
            continue
        try:
            ni = float(clip.get("narration_in"))
            no = float(clip.get("narration_out"))
        except (TypeError, ValueError):
            continue
        if no <= ni + 0.04 or end <= start + 0.04:
            continue
        windows.append((ni, no, start, end))
    windows.sort(key=lambda w: (w[2], w[0]))
    return windows


def _merge_voice_pieces(pieces: list[dict]) -> list[dict]:
    pieces.sort(key=lambda p: (int(p.get("slot") or 1), float(p.get("start") or 0), float(p.get("source_in") or 0)))
    out: list[dict] = []
    for piece in pieces:
        if out:
            prev = out[-1]
            if int(prev.get("slot") or 1) == int(piece.get("slot") or 1):
                pic_gap = float(piece.get("start") or 0) - float(prev.get("end") or 0)
                src_gap = float(piece.get("source_in") or 0) - float(prev.get("source_out") or 0)
                if abs(pic_gap) <= 0.08 and abs(src_gap) <= 0.08:
                    prev["end"] = _r3(float(piece.get("end") or prev.get("end") or 0))
                    prev["source_out"] = _r3(float(piece.get("source_out") or prev.get("source_out") or 0))
                    continue
        out.append(piece)
    return out


def _poem_picture_span(plan: dict) -> tuple[float, float]:
    poem_s = float(plan.get("poem_start_time") or 0)
    poem_e = float(plan.get("poem_end_time") or 0)
    if plan.get("has_poem") and poem_e > poem_s + 0.2:
        return poem_s, poem_e
    return 0.0, 0.0


def _clip_on_poem_picture(plan: dict, clip: dict) -> bool:
    """True when this picture sits inside the song window (lyrics stay untouched)."""
    poem_s, poem_e = _poem_picture_span(plan)
    if poem_e <= poem_s:
        return False
    start = float(clip.get("start") or 0)
    return poem_s - 0.05 <= start < poem_e - 0.05


def _lesson_clips(plan: dict) -> list[dict]:
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict)]
    return [c for c in clips if not _clip_on_poem_picture(plan, c)]


def place_scene_words(plan: dict) -> int:
    """Put each scene's own words on that scene.

    A first word left in the pause before the scene is played on that scene.
    Once a question has been said, a later phrase that is the next scene's
    answer is not played again on the question. Lyric cards on the song
    clock are left alone; spoken lesson cards still get their own words.
    """
    heard = _heard_words(plan)
    pieces = [p for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    clips = _lesson_clips(plan)
    if not heard or not pieces or len(clips) < 2:
        return 0
    clips.sort(key=lambda c: float(c.get("start") or 0))
    changed = 0
    changed += _restore_leading_words(plan, clips, heard, pieces)
    changed += _drop_early_answers(plan, clips, heard, pieces)
    if changed:
        plan["manual_override"] = True
    return changed


def _heard_words(plan: dict) -> list[tuple[float, float, str]]:
    rows: list[tuple[float, float, str]] = []
    for word in plan.get("heard_vo_words") or []:
        if not isinstance(word, dict):
            continue
        try:
            ws = float(word.get("start"))
            we = float(word.get("end"))
        except (TypeError, ValueError):
            continue
        token = _norm_token(str(word.get("word") or word.get("text") or ""))
        if we > ws + 0.03 and token:
            rows.append((ws, we, token))
    rows.sort()
    return rows


def _norm_token(text: str) -> str:
    return re.sub(r"[^\w]+", "", text, flags=re.UNICODE)


def _line_tokens(clip: dict) -> list[str]:
    text = str(clip.get("vo_text") or clip.get("caption_text") or "")
    return [tok for tok in (_norm_token(part) for part in re.split(r"[\s।?.,!]+", text)) if tok]


def _same_token(script: str, heard: str) -> bool:
    if not script or not heard:
        return False
    if script == heard:
        return True
    if len(script) >= 4 and len(heard) >= 4 and (script in heard or heard in script):
        return True
    return False


def _section_text(clip: dict) -> str:
    lines = [ln.strip() for ln in str(clip.get("script_text") or "").splitlines() if ln.strip()]
    return lines[-1] if lines else ""


def _restore_leading_words(plan: dict, clips: list[dict], heard: list[tuple], pieces: list[dict]) -> int:
    restored = 0
    for index, clip in enumerate(clips):
        tokens = _line_tokens(clip)
        if not tokens:
            continue
        try:
            ni = float(clip.get("narration_in"))
        except (TypeError, ValueError):
            continue
        window = [w for w in heard if w[0] >= ni - 0.08 and w[1] <= float(clip.get("narration_out") or ni) + 0.15]
        if any(_same_token(tokens[0], token) for _a, _b, token in window):
            continue
        prev_end = 0.0
        if index:
            prev_hits = [w[1] for w in heard if w[1] <= ni + 0.02]
            if prev_hits:
                prev_end = max(prev_hits)
        t0 = max(ni - 0.55, prev_end + 0.2)
        if t0 >= ni - 0.1:
            continue
        path, offset = _piece_file(pieces, plan, ni)
        if not path:
            continue
        onset = _speech_onset(path, t0 - offset, ni - offset)
        if onset is None:
            continue
        onset += offset
        if onset >= ni - 0.08:
            continue
        if not _extend_piece_and_scene(plan, clips, index, ni, onset):
            continue
        restored += 1
    return restored


def _drop_early_answers(plan: dict, clips: list[dict], heard: list[tuple], pieces: list[dict]) -> int:
    from .scene_rules import _is_answer, _is_question

    dropped = 0
    for clip, nxt in zip(clips, clips[1:]):
        if not _is_question({"section": _section_text(clip)}) or not _is_answer({"section": _section_text(nxt)}):
            continue
        tokens = _line_tokens(clip)
        if not tokens:
            continue
        try:
            ni = float(clip.get("narration_in"))
            no = float(clip.get("narration_out"))
            nxt_ni = float(nxt.get("narration_in"))
        except (TypeError, ValueError):
            continue
        in_line = [w for w in heard if w[0] >= ni - 0.08 and w[1] <= no + 0.3]
        matched_end = None
        seen = set()
        for ws, we, token in in_line:
            if any(_same_token(tok, token) for tok in tokens):
                seen.add(next(tok for tok in tokens if _same_token(tok, token)))
                matched_end = we if matched_end is None else max(matched_end, we)
        if matched_end is None or len(seen) < max(1, len(tokens) - 1):
            continue
        later = [w for w in heard if w[0] >= matched_end + 0.4 and w[1] <= nxt_ni + 0.05]
        if not later:
            continue
        answer_tokens = _line_tokens(nxt)
        answers_next = any(
            _same_token(tok, token)
            for tok in answer_tokens
            if tok not in tokens
            for _a, _b, token in later
        )
        if not answers_next and not (len(seen) == len(tokens) and later[0][0] >= matched_end + 0.8):
            continue
        cut_at = matched_end + 0.12
        if cut_at >= no - 0.05 and not _piece_plays_past(pieces, plan, cut_at):
            continue
        if _end_piece_at(pieces, plan, cut_at):
            _set_narration_out(plan, str(clip.get("screen") or ""), cut_at)
            dropped += 1
    return dropped


def _piece_file(pieces: list[dict], plan: dict, file_t: float) -> tuple[str, float]:
    for piece in pieces:
        slot_no = int(piece.get("slot") or 1)
        offset = _slot_offset(plan, slot_no)
        fa = offset + float(piece.get("source_in") or 0)
        fb = offset + float(piece.get("source_out") or 0)
        if fa - 0.15 <= file_t <= fb + 0.15:
            path = _slot_path(plan, slot_no)
            return path, offset
    return "", 0.0


def _slot_path(plan: dict, slot_no: int) -> str:
    for slot in plan.get("voiceover_slots") or []:
        if isinstance(slot, dict) and int(slot.get("slot") or 1) == slot_no:
            return str(slot.get("path") or "")
    return ""


def _speech_onset(path: str, source_t: float, source_end: float) -> float | None:
    """First speech after a quiet moment, in seconds of the audio file."""
    if source_end <= source_t + 0.08 or not path or not Path(path).is_file():
        return None
    try:
        raw = subprocess.check_output(
            [
                "ffmpeg", "-v", "error",
                "-ss", f"{max(0.0, source_t):.3f}",
                "-t", f"{source_end - source_t:.3f}",
                "-i", path,
                "-ac", "1", "-ar", "8000", "-f", "f32le", "-",
            ],
            stderr=subprocess.DEVNULL,
        )
    except (OSError, subprocess.CalledProcessError):
        return None
    count = len(raw) // 4
    if count < 800:
        return None
    samples = struct.unpack("<" + "f" * count, raw[: count * 4])
    hop = 400
    quiet = False
    for index in range(0, len(samples) - hop, hop):
        chunk = samples[index:index + hop]
        rms = (sum(sample * sample for sample in chunk) / len(chunk)) ** 0.5
        if rms < 0.015:
            quiet = True
        elif quiet and rms >= 0.03:
            return source_t + max(0.0, index / 8000.0 - 0.04)
    return None


def _extend_piece_and_scene(plan: dict, clips: list[dict], index: int, old_file: float, new_file: float) -> bool:
    delta = old_file - new_file
    if delta <= 0.08:
        return False
    pieces = [p for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    host = None
    for piece in pieces:
        offset = _slot_offset(plan, int(piece.get("slot") or 1))
        fa = offset + float(piece.get("source_in") or 0)
        if abs(fa - old_file) <= 0.08:
            host = piece
            break
    if host is None:
        return False
    offset = _slot_offset(plan, int(host.get("slot") or 1))
    prev_end = 0.0
    for piece in pieces:
        if piece is host:
            continue
        other = _slot_offset(plan, int(piece.get("slot") or 1)) + float(piece.get("source_out") or 0)
        if other <= old_file + 0.02:
            prev_end = max(prev_end, other)
    if new_file < prev_end + 0.08:
        return False
    old_pic = float(host.get("start") or 0)
    host["source_in"] = _r3(new_file - offset)
    host["start"] = _r3(old_pic - delta)
    clip = clips[index]
    if abs(float(clip.get("start") or 0) - old_pic) <= 0.05:
        _set_span(clip, old_pic - delta, float(clip.get("end") or old_pic))
        _bump(clip, "narration_in", -delta)
        if index:
            prev = clips[index - 1]
            if abs(float(prev.get("end") or 0) - old_pic) <= 0.05:
                _set_span(prev, float(prev.get("start") or 0), old_pic - delta)
        # The picture boundary moves. The previous line's words stay where they ended.
        prev_screen = str(clips[index - 1].get("screen") or "") if index else ""
        this_screen = str(clip.get("screen") or "")
        for key in ("narration_segments", "srt_cues"):
            for row in plan.get(key) or []:
                if not isinstance(row, dict):
                    continue
                name = str(row.get("screen") or "")
                if prev_screen and name == prev_screen and abs(float(row.get("end") or 0) - old_pic) <= 0.03:
                    row["end"] = _r3(old_pic - delta)
                elif name == this_screen and abs(float(row.get("start") or 0) - old_pic) <= 0.03:
                    row["start"] = _r3(old_pic - delta)
                    _bump(row, "narration_in", -delta)
    return True


def _piece_plays_past(pieces: list[dict], plan: dict, file_t: float) -> bool:
    for piece in pieces:
        offset = _slot_offset(plan, int(piece.get("slot") or 1))
        fb = offset + float(piece.get("source_out") or 0)
        if fb > file_t + 0.08:
            fa = offset + float(piece.get("source_in") or 0)
            if fa < file_t:
                return True
    return False


def _end_piece_at(pieces: list[dict], plan: dict, file_t: float) -> bool:
    for piece in pieces:
        offset = _slot_offset(plan, int(piece.get("slot") or 1))
        fa = offset + float(piece.get("source_in") or 0)
        fb = offset + float(piece.get("source_out") or 0)
        if fa + 0.05 < file_t < fb - 0.05:
            piece["source_out"] = _r3(file_t - offset)
            piece["end"] = _r3(float(piece.get("start") or 0) + (file_t - fa))
            return True
    return False


def _set_narration_out(plan: dict, screen: str, file_t: float) -> None:
    if not screen:
        return
    for key in ("clips", "narration_segments"):
        for row in plan.get(key) or []:
            if isinstance(row, dict) and str(row.get("screen") or "") == screen:
                if row.get("narration_out") is not None:
                    row["narration_out"] = _r3(file_t)


def complete_words_at_cuts(plan: dict) -> int:
    """Every VO cut waits until the word has finished.

    The extra moment is taken from the silence after the cut. Later pictures
    stay where they are. A cut that is already past the word is left alone.
    """
    words = _heard_spans(plan)
    pieces = [p for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    if not words or not pieces:
        return 0
    pieces.sort(key=lambda p: (int(p.get("slot") or 1), float(p.get("start") or 0)))
    changed = 0
    for index, piece in enumerate(pieces):
        try:
            offset = _slot_offset(plan, int(piece.get("slot") or 1))
            edge = offset + float(piece.get("source_out") or 0)
        except (TypeError, ValueError):
            continue
        owner = None
        for ws, we in words:
            ends_here = we <= edge <= we + WORD_TAIL - 0.03 and ws < edge
            inside = ws + 0.02 < edge <= we + 0.02
            if ends_here or inside:
                if owner is None or we > owner[1]:
                    owner = (ws, we)
        if owner is None:
            continue
        _ws, we = owner
        if edge >= we + WORD_TAIL - 0.03:
            continue
        nxt = next((start for start, _end in words if start > we + 0.01), None)
        done = we + WORD_TAIL
        if nxt is not None:
            done = min(done, nxt - 0.05)
        if done <= edge + 0.03:
            continue
        later = pieces[index + 1] if index + 1 < len(pieces) else None
        room = 30.0 if later is None else float(later.get("start") or 0) - float(piece.get("end") or 0)
        take = min(done - edge, max(0.0, room - 0.02))
        if take <= 0.03:
            continue
        new_edge = edge + take
        piece["source_out"] = _r3(float(piece.get("source_out") or 0) + take)
        piece["end"] = _r3(float(piece.get("end") or 0) + take)
        for key in ("clips", "narration_segments"):
            for row in plan.get(key) or []:
                if isinstance(row, dict) and row.get("narration_out") is not None:
                    if abs(float(row.get("narration_out") or 0) - edge) <= 0.04:
                        row["narration_out"] = _r3(new_edge)
        changed += 1
    if changed:
        plan["manual_override"] = True
    return changed


def _insert_range(start: float, end: float, at: float, extra: float) -> tuple[float, float]:
    """Open ``extra`` seconds at ``at``. A card that covers that moment grows."""
    if end < at - 0.03:
        return start, end
    if start >= at - 0.03:
        return start + extra, end + extra
    return start, end + extra


def _trailing_speech(path: str, file_edge: float, next_file: float | None) -> float:
    """Seconds the sentence is still sounding after the cut.

    Zero when the cut is already in the quiet, or when the sound runs into
    the next heard word. The next sentence is not pulled back.
    """
    if not path or not Path(path).is_file():
        return 0.0
    room = 4.2
    if next_file is not None:
        room = next_file - file_edge - 0.28
    if room < 0.4:
        return 0.0
    room = min(4.2, room)
    try:
        raw = subprocess.check_output(
            [
                "ffmpeg", "-v", "error",
                "-ss", f"{max(0.0, file_edge):.3f}",
                "-t", f"{room:.3f}",
                "-i", path,
                "-ac", "1", "-ar", "8000", "-f", "f32le", "-",
            ],
            stderr=subprocess.DEVNULL,
        )
    except (OSError, subprocess.CalledProcessError):
        return 0.0
    count = len(raw) // 4
    if count < 1600:
        return 0.0
    samples = struct.unpack("<" + "f" * count, raw[: count * 4])
    hop = 800
    speech: list[bool] = []
    for index in range(0, len(samples) - hop, hop):
        chunk = samples[index:index + hop]
        rms = (sum(sample * sample for sample in chunk) / len(chunk)) ** 0.5
        speech.append(rms >= 0.025)
    if not any(speech[:5]):
        return 0.0
    quiet = 0
    last = None
    for index, on in enumerate(speech):
        if on:
            last = index
            quiet = 0
            continue
        quiet += 1
        if last is not None and quiet >= 4:
            extra = (last + 1) * 0.1 + 0.06
            if extra < 0.35:
                return 0.0
            return min(extra, room)
    return 0.0


def finish_cut_sentences(plan: dict) -> int:
    """Play the rest of a sentence the cut left in the silence.

    The heard-word list can stop while the voice is still saying the line.
    That tail is taken from the recording and put back on the same card.
    The pause after the sentence stays the same length, and later pictures
    move with the voice. Lyric cards on the song clock are left alone.
    """
    pieces = [p for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    words = _heard_spans(plan)
    if len(pieces) < 2 or not words:
        return 0
    poem_s, poem_e = _poem_picture_span(plan)
    pieces.sort(key=lambda p: (float(p.get("start") or 0), float(p.get("end") or 0)))
    finished = 0
    index = 0
    while index < len(pieces) - 1:
        piece = pieces[index]
        nxt = pieces[index + 1]
        try:
            pic_start = float(piece.get("start") or 0)
            if poem_e > poem_s and poem_s - 0.05 <= pic_start < poem_e - 0.05:
                index += 1
                continue
            gap_end = float(nxt.get("start") or 0)
            gap = gap_end - float(piece.get("end") or 0)
            offset = _slot_offset(plan, int(piece.get("slot") or 1))
            file_edge = float(piece.get("source_out") or 0)
            edge = offset + file_edge
        except (TypeError, ValueError):
            index += 1
            continue
        if gap < 0.4:
            index += 1
            continue
        nxt_word = next((start for start, _end in words if start > edge + 0.05), None)
        nxt_file = None if nxt_word is None else nxt_word - offset
        if nxt_file is not None and nxt_file <= file_edge + 0.2:
            index += 1
            continue
        if int(piece.get("slot") or 1) == int(nxt.get("slot") or 1):
            try:
                src_room = float(nxt.get("source_in") or 0) - file_edge
            except (TypeError, ValueError):
                src_room = 0.0
            if src_room < 0.45:
                index += 1
                continue
        else:
            src_room = 4.2
        extra = _trailing_speech(_slot_path(plan, int(piece.get("slot") or 1)), file_edge, nxt_file)
        extra = min(extra, max(0.0, src_room - 0.08))
        if extra < 0.35:
            index += 1
            continue
        for later in pieces[index + 1 :]:
            later["start"] = _r3(float(later.get("start") or 0) + extra)
            later["end"] = _r3(float(later.get("end") or 0) + extra)
        for clip in plan.get("clips") or []:
            if not isinstance(clip, dict):
                continue
            start, end = _insert_range(float(clip.get("start") or 0), float(clip.get("end") or 0), gap_end, extra)
            clip["start"] = _r3(start)
            clip["end"] = _r3(end)
            clip["duration"] = _r3(end - start)
            if clip.get("kind") not in (None, "video") and clip.get("source_out") is not None:
                clip["source_out"] = clip["duration"]
        for key in ("narration_segments", "srt_cues"):
            for row in plan.get(key) or []:
                if not isinstance(row, dict) or row.get("start") is None:
                    continue
                start, end = _insert_range(float(row.get("start") or 0), float(row.get("end") or 0), gap_end, extra)
                row["start"] = _r3(start)
                row["end"] = _r3(end)
        for issue in plan.get("qa_issues") or []:
            if not isinstance(issue, dict) or issue.get("time") is None:
                continue
            if str(issue.get("screen") or "") == "timeline":
                continue
            when = float(issue.get("time") or 0)
            if when >= gap_end - 0.03:
                issue["time"] = _r3(when + extra)
        total = float(plan.get("total_duration") or 0)
        if total > 0:
            plan["total_duration"] = _r3(total + extra)
        piece["source_out"] = _r3(file_edge + extra)
        piece["end"] = _r3(float(piece.get("end") or 0) + extra)
        new_edge = edge + extra
        for key in ("clips", "narration_segments"):
            for row in plan.get(key) or []:
                if isinstance(row, dict) and row.get("narration_out") is not None:
                    if abs(float(row.get("narration_out") or 0) - edge) <= 0.05:
                        row["narration_out"] = _r3(new_edge)
        finished += 1
        index += 1
    if finished:
        plan["vo_pieces"] = pieces
        plan["manual_override"] = True
    return finished


def _marathi_voice(plan: dict) -> bool:
    """The Marathi module only. An English chapter never takes this path."""
    lang = str(plan.get("language") or "").strip().lower()
    choice = str(plan.get("language_choice") or "").strip().lower()
    if lang in ("en", "english"):
        return False
    if lang in ("mr", "marathi", "hi", "hindi") or choice in ("mr", "marathi", "hi", "hindi"):
        return True
    return str(plan.get("align_engine") or "").strip().lower() == "marathi"


def _opening_speech(path: str, file_in: float, prev_out: float) -> float:
    """Speech in the gap that runs up to the start of this line.

    The first syllable is often still in the pause, before the first word
    the transcript marked. The previous sentence, on the far side of the
    quiet, is left where it is.
    """
    hole = file_in - prev_out
    if hole < 0.35 or not path or not Path(path).is_file():
        return 0.0
    dur = min(1.6, hole - 0.08)
    if dur < 0.3:
        return 0.0
    try:
        raw = subprocess.check_output(
            [
                "ffmpeg", "-v", "error",
                "-ss", f"{max(0.0, file_in - dur):.3f}",
                "-t", f"{dur:.3f}",
                "-i", path,
                "-ac", "1", "-ar", "8000", "-f", "f32le", "-",
            ],
            stderr=subprocess.DEVNULL,
        )
    except (OSError, subprocess.CalledProcessError):
        return 0.0
    count = len(raw) // 4
    if count < 1600:
        return 0.0
    samples = struct.unpack("<" + "f" * count, raw[: count * 4])
    hop = 800
    frames: list[float] = []
    for index in range(0, len(samples) - hop, hop):
        chunk = samples[index:index + hop]
        frames.append((sum(sample * sample for sample in chunk) / len(chunk)) ** 0.5)
    lead_frames = 0
    quiet = 0
    for rms in reversed(frames):
        if rms >= 0.025:
            if quiet >= 3 and lead_frames == 0:
                break
            lead_frames += 1 + quiet
            quiet = 0
        else:
            quiet += 1
            if lead_frames and quiet >= 3:
                break
    lead = lead_frames * 0.1
    if lead < 0.22:
        return 0.0
    return min(lead + 0.06, hole - 0.12, dur)


def keep_opening_words(plan: dict) -> int:
    """A Marathi line starts on its first word, including the syllable before the transcript.

    The extra moment is taken from the pause in front of the line. Later
    pictures stay where they are. The card for this line starts with the
    word. An English chapter is left as saved.
    """
    if not _marathi_voice(plan):
        return 0
    pieces = [p for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    if len(pieces) < 2:
        return 0
    pieces.sort(key=lambda p: (float(p.get("start") or 0), float(p.get("end") or 0)))
    poem_s = float(plan.get("poem_start_time") or 0)
    poem_e = float(plan.get("poem_end_time") or 0)
    has_poem = bool(plan.get("has_poem")) and poem_e > poem_s + 0.2
    restored = 0
    for index in range(1, len(pieces)):
        piece = pieces[index]
        prev = pieces[index - 1]
        if int(piece.get("slot") or 1) != int(prev.get("slot") or 1):
            continue
        try:
            old_start = float(piece.get("start") or 0)
            prev_end = float(prev.get("end") or 0)
            file_in = float(piece.get("source_in") or 0)
            prev_out = float(prev.get("source_out") or 0)
            offset = _slot_offset(plan, int(piece.get("slot") or 1))
        except (TypeError, ValueError):
            continue
        if old_start - prev_end < 0.35 or file_in - prev_out < 0.35:
            continue
        if has_poem and poem_s - 0.05 <= old_start <= poem_e + 0.05:
            continue
        lead = _opening_speech(_slot_path(plan, int(piece.get("slot") or 1)), file_in, prev_out)
        if lead < 0.22 or old_start - lead < prev_end + 0.08:
            continue
        if has_poem and old_start - lead < poem_e - 0.05 <= old_start:
            continue
        new_start = old_start - lead
        old_edge = offset + file_in
        piece["source_in"] = _r3(file_in - lead)
        piece["start"] = _r3(new_start)
        for clip in plan.get("clips") or []:
            if not isinstance(clip, dict):
                continue
            start = float(clip.get("start") or 0)
            end = float(clip.get("end") or 0)
            if abs(start - old_start) <= 0.06:
                clip["start"] = _r3(new_start)
                clip["duration"] = _r3(end - new_start)
                if clip.get("kind") not in (None, "video") and clip.get("source_out") is not None:
                    clip["source_out"] = clip["duration"]
            elif abs(end - old_start) <= 0.06 and start < old_start - 0.05:
                clip["end"] = _r3(new_start)
                clip["duration"] = _r3(new_start - start)
                if clip.get("kind") not in (None, "video") and clip.get("source_out") is not None:
                    clip["source_out"] = clip["duration"]
        for key in ("narration_segments", "srt_cues"):
            for row in plan.get(key) or []:
                if not isinstance(row, dict) or row.get("start") is None:
                    continue
                start = float(row.get("start") or 0)
                end = float(row.get("end") or 0)
                if abs(start - old_start) <= 0.06:
                    row["start"] = _r3(new_start)
                elif abs(end - old_start) <= 0.06 and start < old_start - 0.05:
                    row["end"] = _r3(new_start)
        for key in ("clips", "narration_segments"):
            for row in plan.get(key) or []:
                if isinstance(row, dict) and row.get("narration_in") is not None:
                    if abs(float(row.get("narration_in") or 0) - old_edge) <= 0.05:
                        row["narration_in"] = _r3(old_edge - lead)
        restored += 1
    if restored:
        plan["vo_pieces"] = pieces
        plan["manual_override"] = True
    return restored


def keep_words_whole(plan: dict) -> int:
    """A cut must let the word finish.

    Two cases are put back, and the later pictures move with that voice:
    - the word the cut lands on
    - a screen whose own line starts at the cut and was left out of the voice
    A sentence that continues after the cut stays as saved. Lyric cards on
    the song clock are skipped via _speech_windows; spoken cards still finish.
    """
    words = _heard_spans(plan)
    pieces = [p for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    windows = _speech_windows(plan)
    if not words or not pieces or not windows:
        return 0
    spans: list[tuple[float, float]] = []
    for piece in pieces:
        offset = _slot_offset(plan, int(piece.get("slot") or 1))
        edge = offset + float(piece.get("source_out") or 0)
        for ws, we in words:
            if ws <= edge + 0.02 and we > edge + 0.08 and _on_screen(windows, ws, we):
                spans.append((ws, we))
                break
        owning = [
            (ni, no) for ni, no, _pic, _end in windows
            if edge - 0.45 <= ni <= edge + 0.08 and no > edge + 0.12
        ]
        if not owning:
            continue
        ni, no = min(owning, key=lambda pair: abs(pair[0] - edge))
        tail = [
            (ws, we) for ws, we in words
            if ni - 0.04 <= ws and we <= no + 0.08 and ws >= edge - 0.02
        ]
        if not tail or tail[0][0] > edge + 0.2:
            continue
        end = min(no + 0.04, tail[0][0] + 1.6, max(we for _ws, we in tail))
        if end > edge + 0.08:
            spans.append((tail[0][0], end))
    if not spans:
        return 0
    restored = 0
    for ws, we in sorted(spans, key=lambda span: span[0], reverse=True):
        if _restore_word_span(plan, ws, we + 0.04):
            restored += 1
    if restored:
        plan["manual_override"] = True
    return restored


def finish_words_on_screen(plan: dict) -> int:
    """Keep the picture up until a word the cut landed in has been said.

    The voice is already playing that word. The next screen was starting in
    the middle of it. Later screens stay where they are. Lyric cards on the
    song clock are left alone; spoken lesson cards still finish the word.
    """
    words = _heard_spans(plan)
    mapped = _piece_map(plan)
    clips = _lesson_clips(plan)
    if not words or not mapped or len(clips) < 2:
        return 0
    clips.sort(key=lambda c: float(c.get("start") or 0))
    moved = 0
    for clip, nxt in zip(clips, clips[1:]):
        boundary = float(clip.get("end") or 0)
        ft = _file_at(mapped, boundary)
        if ft is None:
            continue
        hit = next(((ws, we) for ws, we in words if ws < ft < we and we - ft > 0.05), None)
        if hit is None:
            continue
        _ws, we = hit
        nxt_word = next((w for w in words if w[0] > we + 0.01), None)
        file_cut = we + 0.04
        if nxt_word is not None:
            file_cut = min(file_cut, nxt_word[0] - 0.04)
        if file_cut <= ft + 0.04:
            continue
        new_boundary = _pic_at(mapped, file_cut)
        nxt_end = float(nxt.get("end") or 0)
        if new_boundary is None or new_boundary <= boundary + 0.04 or new_boundary >= nxt_end - 0.08:
            continue
        _set_span(clip, float(clip.get("start") or 0), new_boundary)
        _set_span(nxt, new_boundary, nxt_end)
        _bump(clip, "narration_out", file_cut - ft)
        _bump(nxt, "narration_in", file_cut - ft)
        _move_matching_rows(plan, str(clip.get("screen") or ""), str(nxt.get("screen") or ""), boundary, new_boundary, file_cut - ft)
        moved += 1
    if moved:
        plan["manual_override"] = True
    return moved


def _piece_map(plan: dict) -> list[tuple[float, float, float, float]]:
    mapped = []
    for piece in plan.get("vo_pieces") or []:
        if not isinstance(piece, dict):
            continue
        offset = _slot_offset(plan, int(piece.get("slot") or 1))
        mapped.append((
            offset + float(piece.get("source_in") or 0),
            offset + float(piece.get("source_out") or 0),
            float(piece.get("start") or 0),
            float(piece.get("end") or 0),
        ))
    return mapped


def _file_at(mapped: list[tuple[float, float, float, float]], pic: float) -> float | None:
    for fa, fb, ps, pe in mapped:
        if ps - 0.02 <= pic <= pe + 0.02:
            return fa + (pic - ps)
    return None


def _pic_at(mapped: list[tuple[float, float, float, float]], file_t: float) -> float | None:
    for fa, fb, ps, pe in mapped:
        if fa - 0.02 <= file_t <= fb + 0.02:
            return ps + (file_t - fa)
    return None


def _set_span(row: dict, start: float, end: float) -> None:
    row["start"] = _r3(start)
    row["end"] = _r3(end)
    if "duration" in row or row.get("screen"):
        row["duration"] = _r3(end - start)
    if row.get("kind") not in (None, "video") and "source_out" in row:
        row["source_out"] = row["duration"]


def _bump(row: dict, key: str, delta: float) -> None:
    if row.get(key) is None:
        return
    try:
        row[key] = _r3(float(row[key]) + delta)
    except (TypeError, ValueError):
        return


def _move_matching_rows(plan: dict, screen: str, nxt_screen: str, old: float, new: float, delta: float) -> None:
    for key in ("narration_segments", "srt_cues"):
        for row in plan.get(key) or []:
            if not isinstance(row, dict):
                continue
            name = str(row.get("screen") or "")
            end = float(row.get("end") or 0)
            start = float(row.get("start") or 0)
            if name == screen and abs(end - old) <= 0.03:
                row["end"] = _r3(new)
                _bump(row, "narration_out", delta)
            elif name == nxt_screen and abs(start - old) <= 0.03:
                row["start"] = _r3(new)
                _bump(row, "narration_in", delta)


def _heard_spans(plan: dict) -> list[tuple[float, float]]:
    spans: list[tuple[float, float]] = []
    for word in plan.get("heard_vo_words") or []:
        if not isinstance(word, dict):
            continue
        try:
            ws = float(word.get("start"))
            we = float(word.get("end"))
        except (TypeError, ValueError):
            continue
        if we > ws + 0.04:
            spans.append((ws, we))
    spans.sort()
    return spans


def _on_screen(windows: list[tuple], ws: float, we: float) -> bool:
    return any(ws < no + 0.06 and we > ni + 0.02 for ni, no, _pic, _end in windows)


def _restore_word_span(plan: dict, file_start: float, file_end: float) -> bool:
    """Play file_start..file_end on the piece that stopped just before it."""
    pieces = [p for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    host = None
    host_end = None
    for piece in pieces:
        offset = _slot_offset(plan, int(piece.get("slot") or 1))
        fb = offset + float(piece.get("source_out") or 0)
        if fb <= file_start + 0.08 and (host_end is None or fb > host_end):
            host = piece
            host_end = fb
    if host is None or host_end is None or file_start - host_end > 0.35:
        return False
    delta = file_end - host_end
    if delta <= 0.04:
        return False
    offset = _slot_offset(plan, int(host.get("slot") or 1))
    host["source_out"] = _r3(file_end - offset)
    old_end = float(host.get("end") or 0)
    host["end"] = _r3(old_end + delta)
    for piece in pieces:
        if piece is host:
            continue
        if float(piece.get("start") or 0) >= old_end - 0.03:
            piece["start"] = _r3(float(piece.get("start") or 0) + delta)
            piece["end"] = _r3(float(piece.get("end") or 0) + delta)
    for clip in plan.get("clips") or []:
        if not isinstance(clip, dict):
            continue
        start = float(clip.get("start") or 0)
        end = float(clip.get("end") or 0)
        if start >= old_end - 0.03:
            clip["start"] = _r3(start + delta)
            clip["end"] = _r3(end + delta)
        elif end >= old_end - 0.05:
            clip["end"] = _r3(end + delta)
        clip["duration"] = _r3(float(clip["end"]) - float(clip["start"]))
        if clip.get("kind") != "video":
            clip["source_out"] = clip["duration"]
    for key in ("narration_segments", "srt_cues"):
        for row in plan.get(key) or []:
            if not isinstance(row, dict) or row.get("start") is None:
                continue
            start = float(row.get("start") or 0)
            end = float(row.get("end") or 0)
            if start >= old_end - 0.03:
                row["start"] = _r3(start + delta)
                row["end"] = _r3(end + delta)
            elif end >= old_end - 0.05:
                row["end"] = _r3(end + delta)
    total = float(plan.get("total_duration") or 0)
    if total > 0:
        plan["total_duration"] = _r3(total + delta)
    return True


def _same_voice_pieces(old: list[dict], new: list[dict]) -> bool:
    if len(old) != len(new):
        return False
    old_s = sorted(old, key=lambda p: (int(p.get("slot") or 1), float(p.get("start") or 0)))
    new_s = sorted(new, key=lambda p: (int(p.get("slot") or 1), float(p.get("start") or 0)))
    for a, b in zip(old_s, new_s):
        if int(a.get("slot") or 1) != int(b.get("slot") or 1):
            return False
        for key in ("start", "end", "source_in", "source_out"):
            if abs(float(a.get(key) or 0) - float(b.get(key) or 0)) > 0.08:
                return False
    return True
