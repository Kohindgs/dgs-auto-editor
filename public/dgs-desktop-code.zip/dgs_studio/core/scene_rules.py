"""Picture rules that apply to every chapter.

An instrumental does not insert its own picture. The screen already showing
keeps going, and the next screen takes the music only when nothing is before it.

A question and the answer after it share one pause of 4 seconds. Several
silences between those two lines are one pause, and that pause is 4 seconds.
"""

from __future__ import annotations

import re

from .repeat_vo import _r3, _slot_offset

QA_GAP = 4.0
_PAUSE_TAG = re.compile(r"\[\s*\d+(?:\.\d+)?\s*-\s*second\s+pause\s*\]\s*$", re.I)
_QUESTION = re.compile(r"\bquestion\b", re.I)
_ANSWER = re.compile(r"\banswer\b", re.I)


def _instrumental_clip(clip: dict) -> bool:
    blob = " ".join(
        str(clip.get(key) or "")
        for key in ("vo_text", "script_text", "caption_text", "section")
    ).lower()
    return "instrumental" in blob


def _tail(section: str) -> str:
    return str(section or "").split("·")[-1].strip()


def _is_question(scene: dict) -> bool:
    sec = str(scene.get("section") or "")
    tail = _tail(sec)
    if tail == "प्रश्न":
        return True
    return bool(_QUESTION.search(sec) and not _ANSWER.search(sec))


def _is_answer(scene: dict) -> bool:
    sec = str(scene.get("section") or "")
    if _tail(sec) == "उत्तर":
        return True
    return bool(_ANSWER.search(sec))


def _is_qa_pair(scene: dict, nxt: dict) -> bool:
    if _is_question(scene) and _is_answer(nxt):
        return True
    raw = str(scene.get("voiceover_raw") or "")
    return bool(_PAUSE_TAG.search(raw) and _is_answer(nxt))


def _poem_span(plan: dict | None) -> tuple[float, float, float]:
    if not isinstance(plan, dict):
        return 0.0, 0.0, 0.0
    poem_start = float(plan.get("poem_start_time") or 0)
    poem_end = float(plan.get("poem_end_time") or 0)
    if plan.get("has_poem") and poem_end > poem_start + 0.2:
        return poem_start, poem_end, poem_end - poem_start
    return 0.0, 0.0, 0.0


def _listen_sing_heading(clip: dict) -> bool:
    """Section flashcard before the song — must not eat the instrumental."""
    text = str(clip.get("vo_text") or clip.get("caption_text") or clip.get("script_text") or "").lower()
    return "listen and sing" in text


def fold_listen_sing_heading(plan: dict) -> int:
    """Drop the \"Listen and sing.\" flashcard from Video 1 entirely.

    Swapping its media to the song still left a short clip that could flash
    (still hold, scrub, or a one-frame cut). The previous picture now covers
    through to the first song card; the heading's VO/script lane stays so the
    line is still heard. Poem text still waits for poem_lyric_start.
    """
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict)]
    if len(clips) < 2:
        return 0
    poem_s, _poem_e, span = _poem_span(plan)
    if span <= 0:
        return 0
    out: list[dict] = []
    removed: set[str] = set()
    i = 0
    while i < len(clips):
        clip = clips[i]
        nxt = clips[i + 1] if i + 1 < len(clips) else None
        drop = (
            nxt is not None
            and _listen_sing_heading(clip)
            and float(clip.get("end") or 0) <= poem_s + 0.35
            and float(nxt.get("start") or 0) <= poem_s + 0.35
        )
        if not drop:
            out.append(clip)
            i += 1
            continue
        song = dict(nxt)
        if out:
            prev = out[-1]
            old_end = float(prev.get("end") or 0)
            new_end = float(song.get("start") or clip.get("end") or old_end)
            if new_end > old_end + 0.02:
                prev["end"] = _r3(new_end)
                _resize_clip(prev, old_end, plan)
                _extend_screen(plan, str(prev.get("screen") or ""), old_end, float(prev["end"]))
        else:
            # Nothing before the heading — pull the first song card back over it.
            old_start = float(song.get("start") or 0)
            song["start"] = _r3(float(clip.get("start") or old_start))
            if song.get("narration_in") is not None and abs(float(song.get("narration_in") or 0) - old_start) < 0.08:
                song["narration_in"] = song["start"]
            _resize_clip(song, old_start, plan)
            _extend_screen(plan, str(song.get("screen") or ""), old_start, float(song["start"]), at="start")
        removed.add(str(clip.get("screen") or ""))
        out.append(song)
        i += 2  # skip heading + consume song (already appended)
    # Always strip heading words from preview/export cues, even if the clip was
    # already gone from an older fold that only swapped media.
    cues = []
    cue_dropped = 0
    for cue in plan.get("srt_cues") or []:
        if not isinstance(cue, dict):
            continue
        if "listen and sing" in str(cue.get("text") or "").lower():
            cue_dropped += 1
            continue
        cues.append(cue)
    if not removed and not cue_dropped:
        return 0
    plan["srt_cues"] = cues
    if removed:
        plan["clips"] = out
        # Keep narration_segments for the heading so VO still plays; only the
        # picture row is gone. Drop stale srt/qa rows keyed to that screen.
        for key in ("srt_cues", "qa_issues"):
            plan[key] = _drop_screens(plan.get(key), removed)
    plan["manual_override"] = True
    return len(removed) or cue_dropped


def fold_instrumental_pictures(plan: dict) -> int:
    """Give each instrumental's time to the screen beside it.

    The previous picture keeps going. The next picture takes the music when
    the instrumental is the first screen. The instrumental's own image is
    not placed between them. A \"Listen and sing.\" heading never absorbs
    the intro — that kept the heading card on screen into the song.
    """
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict)]
    if not clips:
        return 0
    removed: set[str] = set()
    out: list[dict] = []
    lead: dict | None = None
    for clip in clips:
        if _instrumental_clip(clip):
            if out and lead is None and not _listen_sing_heading(out[-1]):
                prev = out[-1]
                old_end = float(prev.get("end") or 0)
                prev["end"] = _r3(float(clip.get("end") or old_end))
                _resize_clip(prev, old_end, plan)
                _extend_screen(plan, str(prev.get("screen") or ""), old_end, float(prev["end"]))
            else:
                if lead is None:
                    lead = dict(clip)
                else:
                    lead["end"] = clip.get("end")
            removed.add(str(clip.get("screen") or ""))
            continue
        nxt = dict(clip)
        if lead is not None:
            old_start = float(nxt.get("start") or 0)
            nxt["start"] = _r3(float(lead.get("start") or old_start))
            if nxt.get("narration_in") is not None and abs(float(nxt.get("narration_in") or 0) - old_start) < 0.08:
                nxt["narration_in"] = nxt["start"]
            _resize_clip(nxt, old_start, plan)
            _extend_screen(plan, str(nxt.get("screen") or ""), old_start, float(nxt["start"]), at="start")
            lead = None
        out.append(nxt)
    if lead is not None and out:
        prev = out[-1]
        old_end = float(prev.get("end") or 0)
        prev["end"] = _r3(float(lead.get("end") or old_end))
        _resize_clip(prev, old_end, plan)
        _extend_screen(plan, str(prev.get("screen") or ""), old_end, float(prev["end"]))
        removed.add(str(lead.get("screen") or ""))
    elif lead is not None:
        out.append(lead)
        removed.discard(str(lead.get("screen") or ""))
    if not removed:
        return 0
    plan["clips"] = out
    for key in ("narration_segments", "srt_cues", "qa_issues"):
        plan[key] = _drop_screens(plan.get(key), removed)
    plan["manual_override"] = True
    return len(removed)


def _resize_clip(clip: dict, old_edge: float, plan: dict | None = None) -> None:
    start = float(clip.get("start") or 0)
    end = float(clip.get("end") or start)
    if end < start + 0.12:
        end = start + 0.12
        clip["end"] = _r3(end)
    clip["duration"] = _r3(end - start)
    if clip.get("kind") != "video":
        clip["source_in"] = 0
        clip["source_out"] = clip["duration"]
    poem_s, _poem_e, span = _poem_span(plan)
    # Spoken card before the song that absorbs the instrumental intro: keep the
    # picture through the music, but leave narration_* on the VO file clock.
    head_into_poem = span > 0 and start < poem_s - 0.02 and end > poem_s + 0.05
    if head_into_poem:
        if clip.get("narration_out") is not None and float(clip.get("narration_out") or 0) > poem_s + 0.02:
            clip["narration_out"] = _r3(min(float(clip.get("narration_out") or poem_s), poem_s))
        return
    # Poem cards store the picture window on narration_in/out. Keep that
    # window on the screen that absorbed the instrumental.
    if clip.get("narration_out") is not None and abs(float(clip.get("narration_out") or 0) - old_edge) < 0.15:
        clip["narration_out"] = _r3(end)
    if clip.get("narration_in") is not None and abs(float(clip.get("narration_in") or 0) - old_edge) < 0.15:
        clip["narration_in"] = _r3(start)


def _extend_screen(plan: dict, screen: str, old: float, new: float, at: str = "end") -> None:
    if not screen or abs(new - old) < 0.02:
        return
    poem_s, _poem_e, span = _poem_span(plan)
    for key in ("narration_segments", "srt_cues"):
        for row in plan.get(key) or []:
            if not isinstance(row, dict) or str(row.get("screen") or "") != screen:
                continue
            if at == "end" and abs(float(row.get("end") or 0) - old) < 0.2:
                row["end"] = _r3(new)
                if row.get("narration_out") is not None and abs(float(row.get("narration_out") or 0) - old) < 0.2:
                    # Do not drag a pre-song narration window into the poem file clock.
                    if span > 0 and float(row.get("start") or 0) < poem_s - 0.02:
                        row["narration_out"] = _r3(min(float(row.get("narration_out") or poem_s), poem_s))
                    else:
                        row["narration_out"] = _r3(new)
            if at == "start" and abs(float(row.get("start") or 0) - old) < 0.2:
                row["start"] = _r3(new)
                if row.get("narration_in") is not None and abs(float(row.get("narration_in") or 0) - old) < 0.2:
                    row["narration_in"] = _r3(new)


def _drop_screens(rows, screens: set[str]) -> list:
    return [row for row in (rows or []) if not (isinstance(row, dict) and str(row.get("screen") or "") in screens)]


def _base_picture(plan: dict, file_t: float) -> float:
    poem_s = float(plan.get("poem_start_time") or 0)
    poem_e = float(plan.get("poem_end_time") or 0)
    span = poem_e - poem_s if plan.get("has_poem") and poem_e > poem_s + 0.2 else 0.0
    if span > 0 and file_t >= poem_s - 0.02:
        return file_t + span
    return file_t


def _speech_edges(words: list, qclip: dict, aclip: dict) -> tuple[float, float] | None:
    """File times of the last question word and the first answer word."""
    try:
        q0 = float(qclip.get("narration_in"))
        boundary = float(qclip.get("narration_out"))
        a1 = float(aclip.get("narration_out"))
    except (TypeError, ValueError):
        return None
    if a1 <= q0 + 0.2:
        return None
    q_end = None
    for word in words:
        if not isinstance(word, dict):
            continue
        start = float(word.get("start") or 0)
        end = float(word.get("end") or start)
        if q0 - 0.35 <= start and end <= boundary + 0.55:
            q_end = end if q_end is None else max(q_end, end)
    a_start = None
    for word in words:
        if not isinstance(word, dict):
            continue
        start = float(word.get("start") or 0)
        end = float(word.get("end") or start)
        if boundary - 0.55 <= start and end <= a1 + 0.35:
            if q_end is not None and start + 0.02 < q_end:
                continue
            a_start = start if a_start is None else min(a_start, start)
    if q_end is None or a_start is None or a_start <= q_end + 0.08:
        return None
    if not (q_end - 0.4 <= boundary <= a_start + 0.4):
        return None
    # The pause starts after the last question word has finished.
    q_cut = min(q_end + 0.18, a_start - 0.05)
    return q_cut, a_start


def _map_time(t: float, edits: list[dict]) -> float:
    """Original picture time after each question-answer pause is set to 4 seconds."""
    shift = 0.0
    for edit in edits:
        q = float(edit["q_pic"])
        a = float(edit["a_pic"])
        if t <= q + 0.02:
            return _r3(t + shift)
        if t < a - 0.02:
            return _r3(q + shift + QA_GAP)
        shift += float(edit["extra"])
    return _r3(t + shift)


def _snap_file(value, edits: list[dict], edge: str):
    try:
        f = float(value)
    except (TypeError, ValueError):
        return value
    for edit in edits:
        q = float(edit["q_file"])
        a = float(edit["a_file"])
        if q - 0.02 < f < a + 0.02:
            return _r3(q if edge == "out" else a)
    return value


def fit_question_answer_gaps(plan: dict, scenes: list, words: list | None, gap: float = QA_GAP) -> int:
    """The silences between a question and its answer become one 4-second pause."""
    ordered = [w for w in (words or []) if isinstance(w, dict)]
    if len(ordered) < 4 or not scenes:
        return 0
    by = {str(c.get("screen") or ""): c for c in (plan.get("clips") or []) if isinstance(c, dict)}
    edits = []
    for i, scene in enumerate(scenes[:-1]):
        if not isinstance(scene, dict):
            continue
        nxt = scenes[i + 1]
        if not isinstance(nxt, dict) or not _is_qa_pair(scene, nxt):
            continue
        qclip = by.get(str(scene.get("screen") or ""))
        aclip = by.get(str(nxt.get("screen") or ""))
        if not qclip or not aclip:
            continue
        edges = _speech_edges(ordered, qclip, aclip)
        if not edges:
            continue
        q_file, a_file = edges
        current = a_file - q_file
        if current < 0.15 or current > 20:
            continue
        extra = gap - current
        if abs(extra) < 0.08:
            continue
        edits.append({
            "q_file": q_file,
            "a_file": a_file,
            "q_pic": _base_picture(plan, q_file),
            "a_pic": _base_picture(plan, a_file),
            "extra": extra,
            "question": str(scene.get("screen") or ""),
            "answer": str(nxt.get("screen") or ""),
        })
    if not edits:
        return 0
    edits.sort(key=lambda e: e["q_file"])
    _apply_picture_edits(plan, edits)
    plan["qa_holds"] = [
        {"file": _r3(e["q_file"]), "extra": _r3(e["extra"]), "gap": gap}
        for e in edits
    ]
    plan["manual_override"] = True
    return len(edits)


def _apply_picture_edits(plan: dict, edits: list[dict]) -> None:
    for clip in plan.get("clips") or []:
        if not isinstance(clip, dict):
            continue
        start = float(clip.get("start") or 0)
        end = float(clip.get("end") or start)
        clip["start"] = _map_time(start, edits)
        clip["end"] = _map_time(end, edits)
        if float(clip["end"]) < float(clip["start"]) + 0.12:
            clip["end"] = _r3(float(clip["start"]) + 0.12)
        clip["duration"] = _r3(float(clip["end"]) - float(clip["start"]))
        if clip.get("kind") != "video":
            clip["source_out"] = clip["duration"]
        if clip.get("narration_out") is not None:
            clip["narration_out"] = _snap_file(clip.get("narration_out"), edits, "out")
        if clip.get("narration_in") is not None:
            clip["narration_in"] = _snap_file(clip.get("narration_in"), edits, "in")
    for key in ("narration_segments", "srt_cues"):
        kept = []
        for row in plan.get(key) or []:
            if not isinstance(row, dict):
                continue
            if row.get("start") is not None:
                row["start"] = _map_time(float(row.get("start") or 0), edits)
            if row.get("end") is not None:
                row["end"] = _map_time(float(row.get("end") or 0), edits)
            if float(row.get("end") or 0) <= float(row.get("start") or 0) + 0.04:
                continue
            if row.get("narration_out") is not None:
                row["narration_out"] = _snap_file(row.get("narration_out"), edits, "out")
            if row.get("narration_in") is not None:
                row["narration_in"] = _snap_file(row.get("narration_in"), edits, "in")
            kept.append(row)
        plan[key] = kept
    plan["vo_pieces"] = _remap_pieces(plan, edits)
    for key in ("poem_start_time", "poem_end_time", "total_duration"):
        if plan.get(key) is not None:
            plan[key] = _map_time(float(plan.get(key) or 0), edits)
    ends = [float(c.get("end") or 0) for c in (plan.get("clips") or []) if isinstance(c, dict)]
    if ends:
        plan["total_duration"] = _r3(max(ends))


def _remap_pieces(plan: dict, edits: list[dict]) -> list[dict]:
    pieces = [p for p in (plan.get("vo_pieces") or []) if isinstance(p, dict)]
    if not pieces:
        return pieces
    out = []
    for piece in pieces:
        offset = _slot_offset(plan, int(piece.get("slot") or 1))
        fa = offset + float(piece.get("source_in") or 0)
        fb = offset + float(piece.get("source_out") or 0)
        if fb <= fa + 0.05:
            continue
        marks = [fa, fb]
        for edit in edits:
            for edge in (float(edit["q_file"]), float(edit["a_file"])):
                if fa + 0.03 < edge < fb - 0.03:
                    marks.append(edge)
        marks = sorted(set(_r3(m) for m in marks))
        origin = float(piece.get("start") or 0)
        for i in range(len(marks) - 1):
            a, b = marks[i], marks[i + 1]
            if b <= a + 0.04:
                continue
            if any(float(e["q_file"]) - 0.03 <= a and b <= float(e["a_file"]) + 0.03 for e in edits):
                continue
            start = origin + (a - fa)
            end = origin + (b - fa)
            out.append({
                **piece,
                "id": f"{piece.get('id')}-q{len(out)}",
                "start": _map_time(start, edits),
                "end": _map_time(end, edits),
                "source_in": _r3(a - offset),
                "source_out": _r3(b - offset),
            })
    out.sort(key=lambda p: (int(p.get("slot") or 1), float(p.get("start") or 0)))
    return out
