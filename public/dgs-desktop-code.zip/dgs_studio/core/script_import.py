"""Read a chapter script into scenes.

Line-for-line port of ``hostinger_deploy/server.js`` (``parseProductionXlsx``,
``cleanVoText``, ``extractOnscreenText``, ``parseSunoRange``,
``loadRevisedDurationsFromWb``, ``loadPoemTimingFromWb``, ``parsePlainScript``,
``assertMasterScriptWorkbook``). JavaScript regexes treat ``\\b`` and ``\\w``
as ASCII, so those patterns use ``re.A`` here.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from pathlib import Path

A, I = re.A, re.I

MASTER_SHEETS = ["Sheet1", "Sheet2", "Narration VO", "Poem VO", "Audio Manifest"]
MASTER_SHEET1_HEADERS = ["Scene No.", "Section", "Duration", "English On-Screen Text", "English Voice Over"]
MASTER_MESSAGE = "Use DGS_Cloud_Chapter_Script_Example.xlsx as the layout."


class ScriptFormatError(ValueError):
    pass


# JavaScript value helpers ----------------------------------------------------


def _js_str(v) -> str:
    """``String(v)`` for a sheet cell (openpyxl gives None for blanks)."""
    if v is None:
        return ""
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        if math.isnan(v):
            return "NaN"
        if v.is_integer():
            return str(int(v))
        return repr(v)
    return str(v)


def _js_or(v) -> str:
    """``String(v || '')``: 0, '' and None all become ''."""
    if v is None or v == "" or v is False or (isinstance(v, (int, float)) and v == 0):
        return ""
    return _js_str(v)


def _js_float(s: str) -> float | None:
    m = re.match(r"^\s*[+-]?(\d+\.?\d*|\.\d+)(e[+-]?\d+)?", s, I)
    return float(m.group(0)) if m else None


def devanagari_to_ascii_digits(s: str) -> str:
    return re.sub("[०-९]", lambda m: str(ord(m.group(0)) - 0x0966), s or "")


# Text cleaning ---------------------------------------------------------------

_TAG_RE = re.compile(
    r"\[\s*(?:VO|Voiceover|Narration|Audio)\s*(?:\([^)]*\))?\s*\]\s*:?\s*([\s\S]*?)"
    r"(?=\[\s*(?:VO|Voiceover|Narration|Audio|On[- ]?screen[^[\]]*|Visual[^[\]]*|SFX[^[\]]*|Music[^[\]]*|Pause[^[\]]*|Note[^[\]]*)\s*\]|$)",
    I,
)


def clean_vo_text(raw, onscreen_text: str = "") -> str:
    if not raw:
        return ""
    text = str(raw).replace("\r\n", "\n")
    blocks = [m.group(1).strip() for m in _TAG_RE.finditer(text) if m.group(1) and m.group(1).strip()]
    if blocks:
        text = " ".join(blocks)
    text = re.sub(r"(\w)\s*\[\s*\d+\s*[- ]?(?:second|sec)[^\]]*pause[^\]]*\]\s*(\w)", r"\1 ... \2", text, flags=A | I)
    text = re.sub(r"\[[^\]]*\]", " ", text)
    text = re.sub(r"^(?:\s*)(?:narrator|teacher|child|kid|speaker|voice|audio)\s*(?:\([^)]*\))?\s*:\s*", "", text, flags=I | re.M)
    text = re.sub(r"\([^)]*(?:pause|beat|sfx|music|laughter|excited|warm|soft|tone|voice|whisper|sound|chuckle|sigh|gasp)[^)]*\)", " ", text, flags=I)
    text = re.sub(r"^[\"“”'\s]+|[\"“”'\s]+$", "", text)
    text = re.sub(r"[\"“”]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    low = text.lower()
    if low.startswith("read exact") or low in ("read on-screen text", "read onscreen text"):
        ost = re.sub(r"\s+", " ", re.sub(r"[•●▪▸]", " ", str(onscreen_text or "").replace("\r\n", "\n"))).strip()
        if ost:
            return ost
    return text


def extract_onscreen_text(raw) -> str:
    if not raw:
        return ""
    m = re.search(r"\[\s*On[- ]?screen[^\]]*\]\s*:?\s*([\s\S]*?)(?=\[|$)", str(raw), I)
    if m and m.group(1):
        return re.sub(r"\s+", " ", m.group(1)).strip()
    return ""


def parse_clock_value(val) -> float | None:
    if val is None or val == "":
        return None
    if isinstance(val, (int, float)) and not isinstance(val, bool) and math.isfinite(val):
        return float(val)
    s = _js_str(val).strip()
    colon = re.match(r"^(\d+):(\d{2}(?:\.\d+)?)(?::(\d{2}(?:\.\d+)?))?$", s)
    if colon:
        if colon.group(3) is not None:
            return int(colon.group(1)) * 3600 + float(colon.group(2)) * 60 + float(colon.group(3))
        return int(colon.group(1)) * 60 + float(colon.group(2))
    return _js_float(s)


def parse_suno_range(raw) -> tuple[float | None, float | None, bool]:
    if not raw:
        return None, None, False
    s = _js_str(raw)
    m = re.search(r"(?:suno\s*)?(\d{1,2}):(\d{2}(?:\.\d+)?)\s*[-–—→]\s*(\d{1,2}):(\d{2}(?:\.\d+)?)", s, I)
    if not m:
        return None, None, False
    start = int(m.group(1)) * 60 + float(m.group(2))
    end = int(m.group(3)) * 60 + float(m.group(4))
    return start, end, bool(re.search("suno", s, I))


def parse_duration_cell(val) -> float | None:
    if val is None or val == "":
        return None
    if isinstance(val, (int, float)) and not isinstance(val, bool) and 0 < val < 600:
        return float(val)
    s = _js_str(val).strip()
    a, b, _ = parse_suno_range(s)
    if a is not None and b is not None and b > a:
        return round((b - a) * 1000) / 1000
    sec = re.search(r"(\d+(?:\.\d+)?)\s*(?:s|sec|secs|seconds)\b", s, A | I)
    if sec:
        return float(sec.group(1))
    colon = re.match(r"^(\d+):(\d{2}(?:\.\d+)?)(?::(\d{2}(?:\.\d+)?))?$", s)
    if colon:
        if colon.group(3) is not None:
            return int(colon.group(1)) * 3600 + float(colon.group(2)) * 60 + float(colon.group(3))
        return int(colon.group(1)) * 60 + float(colon.group(2))
    n = _js_float(s)
    return n if n is not None and 0 < n < 600 else None


def is_spoken_heading_or_activity_scene(section, visual_type, voiceover_raw, audio_start) -> bool:
    if audio_start is not None:
        return False
    sec = str(section or "").strip().lower()
    vtype = str(visual_type or "").strip().lower()
    raw = str(voiceover_raw or "").strip().lower()
    if re.search(r"suno|original\s+song|poem\s*/\s*original\s+song|attached\s+poem\s+track|instrumental", f"{sec} {vtype} {raw}", I):
        return False
    if re.search(
        r"\b(heading|lead[- ]?in|attribution|author|poet|question|answer|vocabulary|exercise|activity|glossary|comprehension|summary|instruction|title|prompt|recap|task|guidance|challenge|discussion|statement|draw|label|write|true\s*/\s*false|talk\s+on)\b",
        f"{sec} {vtype}",
        A | I,
    ):
        return True
    return False


# Workbook --------------------------------------------------------------------


def _serial(v):
    """SheetJS reports date/time cells as Excel serial numbers."""
    import datetime as dt

    if v is None:
        return ""
    if isinstance(v, dt.datetime):
        return (v - dt.datetime(1899, 12, 30)).total_seconds() / 86400
    if isinstance(v, dt.date):
        return float((v - dt.date(1899, 12, 30)).days)
    if isinstance(v, dt.time):
        return (v.hour * 3600 + v.minute * 60 + v.second + v.microsecond / 1e6) / 86400
    if isinstance(v, dt.timedelta):
        return v.total_seconds() / 86400
    return v


def _sheet_rows(ws) -> list[list]:
    rows = []
    for r in ws.iter_rows(values_only=True):
        rows.append([_serial(v) for v in r])
    while rows and all(v == "" for v in rows[-1]):
        rows.pop()
    return rows


def _load_workbook(path: Path):
    import openpyxl

    return openpyxl.load_workbook(str(path), read_only=True, data_only=True)


def _revised_durations(sheets: list[tuple[str, list[list]]]) -> dict[int, float]:
    out: dict[int, float] = {}
    if len(sheets) < 2:
        return out
    for name, rows in sheets[1:]:
        low_name = str(name or "").lower()
        if any(k in low_name for k in ("poem", "prompt", "guide", "cue")):
            continue
        if not rows:
            continue
        hdr = " | ".join(_js_or(c).strip().lower() for c in rows[0])
        if "revised" not in hdr and low_name != "sheet2":
            continue
        if "poem line" in hdr or "script scene" in hdr:
            continue
        for row in rows[1:]:
            if not row or len(row) < 2:
                continue
            m = re.match(r"^(\d+)$", _js_str(row[0]).strip())
            if not m:
                continue
            dur = parse_duration_cell(row[1])
            if dur is not None and dur > 0:
                out[int(m.group(1))] = dur
    return out


def _poem_timings(sheets: list[tuple[str, list[list]]]) -> dict[int, dict]:
    out: dict[int, dict] = {}
    for _name, rows in sheets:
        hdr_idx = c_scene = c_in = c_out = c_dur = -1
        for r in range(min(len(rows), 15)):
            row = [_js_or(c).strip().lower() for c in rows[r]]
            s_idx = next((i for i, c in enumerate(row) if "script scene" in c or c in ("scene #", "scene no", "scene")), -1)
            in_idx = next((i for i, c in enumerate(row) if "audio in" in c or c == "in" or "start time" in c), -1)
            out_idx = next((i for i, c in enumerate(row) if "audio out" in c or c == "out" or "end time" in c), -1)
            if s_idx >= 0 and in_idx >= 0 and out_idx >= 0:
                hdr_idx, c_scene, c_in, c_out = r, s_idx, in_idx, out_idx
                c_dur = next((i for i, c in enumerate(row) if "scene duration" in c), -1)
                break
        if hdr_idx < 0:
            continue
        for row in rows[hdr_idx + 1:]:
            if not row:
                continue
            cell = lambda i: row[i] if 0 <= i < len(row) else ""  # noqa: E731
            m = re.search(r"(\d+)", _js_str(cell(c_scene)).strip())
            if not m:
                continue
            sc = int(m.group(1))
            a_in = parse_clock_value(cell(c_in))
            a_out = parse_clock_value(cell(c_out))
            s_dur = parse_duration_cell(cell(c_dur)) if c_dur >= 0 else None
            if sc > 0 and a_in is not None and a_out is not None and a_out > a_in:
                prev = out.get(sc)
                start = min(prev["audio_start"], a_in) if prev else a_in
                end = max(prev["audio_end"], a_out) if prev else a_out
                span = round((end - start) * 1000) / 1000
                out[sc] = {
                    "audio_start": round(start * 1000) / 1000,
                    "audio_end": round(end * 1000) / 1000,
                    "duration": s_dur if s_dur and s_dur > 0 else span,
                }
    return out


def _header_map(row: list[str]) -> dict[str, int]:
    col: dict[str, int] = {}

    def put(key: str, idx: int) -> None:
        col.setdefault(key, idx)

    for idx, c in enumerate(row):
        if "scene" in c or "screen" in c or c == "no" or "sr" in c:
            put("scene", idx)
        if "section" in c or "timestamp" in c:
            put("section", idx)
        if "section" not in c and ("duration" in c or re.search(r"\bsec(?:s|onds)?\b", c, A) or c == "time"):
            put("duration", idx)
        if "on-screen" in c or "onscreen" in c or "text on screen" in c or "ost" in c:
            put("onscreen", idx)
        if "visual" not in c and "description" not in c and (
            "voice" in c or "audio" in c or "narration" in c or c == "vo" or re.search(r"\bscript\b", c, A) or "dialogue" in c or "dialog" in c
        ):
            put("vo", idx)
        if "visual" in c and "type" in c:
            put("vtype", idx)
        elif "visual" in c or "animation" in c or "image" in c or "action" in c:
            put("visual", idx)
        if "type" in c or "asset" in c or "media" in c:
            put("vtype", idx)
    return col


def parse_production_rows(sheets: list[tuple[str, list[list]]]) -> list[dict]:
    revised = _revised_durations(sheets)
    poem_t = _poem_timings(sheets)
    scenes: list[dict] = []
    for _name, rows in sheets:
        header_idx = -1
        col: dict[str, int] = {}
        for r in range(min(len(rows), 25)):
            row = [re.sub(r"\s+", " ", _js_or(c)).strip().lower() for c in rows[r]]
            short = len([c for c in row if 0 < len(c) < 60])
            has_scene = any(len(c) < 40 and ("scene" in c or "screen" in c or c in ("sr. no", "s.no")) for c in row)
            has_text = any(
                len(c) < 55 and ("audio" in c or "voice" in c or "narration" in c or "script" in c or c == "vo" or "on-screen" in c or "onscreen" in c)
                for c in row
            )
            if short >= 3 and has_scene and has_text:
                header_idx = r
                col = _header_map(row)
                break
        if header_idx < 0:
            continue

        def cell(row, key):
            i = col.get(key)
            if i is None or i >= len(row):
                return ""
            return row[i]

        current_section = ""
        for row in rows[header_idx + 1:]:
            if not row:
                continue
            scene_i = col.get("scene", 0)
            raw_scene = devanagari_to_ascii_digits(_js_or(row[scene_i] if scene_i < len(row) else "")).strip()
            raw_sec = _js_or(cell(row, "section")).strip() if "section" in col else ""
            if raw_sec:
                current_section = raw_sec
            raw_vo = _js_or(cell(row, "vo")).strip() if "vo" in col else ""
            raw_ost = _js_or(cell(row, "onscreen")).strip() if "onscreen" in col else ""
            raw_vis = _js_or(cell(row, "visual")).strip() if "visual" in col else ""
            raw_type = _js_or(cell(row, "vtype")).strip() if "vtype" in col else ""
            raw_dur = cell(row, "duration") if "duration" in col else None

            num_m = re.search(r"(\d{1,3})", raw_scene)
            if not num_m:
                if scenes:
                    last = scenes[-1]
                    extra = raw_ost or extract_onscreen_text(raw_vo)
                    if extra and extra not in last["onscreen_text"]:
                        last["onscreen_text"] = f"{last['onscreen_text']}\n{extra}" if last["onscreen_text"] else extra
                        refreshed = clean_vo_text(last["voiceover_raw"], last["onscreen_text"])
                        if refreshed:
                            last["voiceover_text"] = refreshed
                        last["text"] = "\n".join(x for x in (last["voiceover_text"], last["onscreen_text"], last["section"]) if x)
                    c_start, c_end, _ = parse_suno_range(f"{raw_vo} {_js_or(raw_dur)}")
                    if c_start is not None and last["audio_start"] is None:
                        last["audio_start"] = c_start
                        last["audio_end"] = c_end
                        last["is_poem"] = True
                continue

            scene_no = int(num_m.group(1))
            if scene_no < 1 or scene_no > 500:
                continue
            a_start, a_end, is_suno = parse_suno_range(raw_vo)
            if a_start is None and raw_dur is not None:
                d_start, d_end, d_suno = parse_suno_range(_js_str(raw_dur))
                a_start, a_end = d_start, d_end
                is_suno = is_suno or d_suno
            cue = poem_t.get(scene_no)
            if cue:
                a_start, a_end, is_suno = cue["audio_start"], cue["audio_end"], True
            sheet1_dur = parse_duration_cell(raw_dur) if raw_dur is not None else None
            dur = cue["duration"] if cue else revised.get(scene_no, sheet1_dur)

            ost = raw_ost or extract_onscreen_text(raw_vo)
            vo = clean_vo_text(raw_vo, ost)
            combined = f"{raw_scene} {current_section} {raw_vo} {raw_vis} {raw_type}".lower()
            spoken_heading = is_spoken_heading_or_activity_scene(current_section, raw_type or raw_vis, raw_vo, a_start)
            poem_candidate = bool(
                re.search(r"\bpoem\b", current_section, A | I)
                or re.search(r"\bpoem\s+visual\b", f"{raw_type} {raw_vis}", A | I)
                or re.search(r"\b(stanza|couplet|lines?\s*\d+[-–—]\d+)\b", current_section, A | I)
                or re.search(r"\b(song\s+intro|full\s+poem\s+song|poem\s*/\s*original\s+song|attached\s+poem\s+track|poem\s+recitation|suno)\b", combined, A | I)
            )
            if poem_t:
                is_poem = bool(cue or is_suno or a_start is not None)
            else:
                is_poem = (not spoken_heading) and (is_suno or a_start is not None or poem_candidate)
            # Visual Type column only — not the free-form direction (which may say
            # "documentary shot" on a still card).
            v_type = (
                "Video"
                if re.search(
                    r"video|mp4|\banim\b|animation|documentary|cinematic|footage|motion\s*clip|व्हिडिओ|चलचित्र",
                    raw_type,
                    I,
                )
                else "Image"
            )
            scenes.append({
                "screen": f"screen_{scene_no}",
                "index": len(scenes),
                "scene_no": scene_no,
                "section": current_section or ("poem" if is_poem else "story"),
                "duration": dur,
                "audio_start": a_start,
                "audio_end": a_end,
                "onscreen_text": ost,
                "voiceover_text": vo,
                "voiceover_raw": raw_vo,
                "visual_type": v_type,
                "visual_handling": raw_type,
                "visual_direction": raw_vis,
                "text": "\n".join(x for x in (vo, ost, current_section) if x) or f"Scene {scene_no}",
                "is_poem": is_poem,
                "source": "production_xlsx",
            })
        if scenes:
            break
    return scenes


def parse_plain_script(raw: str) -> list[dict]:
    scenes = []
    for line in re.split(r"\r?\n", str(raw or "")):
        t = line.strip()
        if not t:
            continue
        m = re.match(r"^(?:screen|scene)[\s_-]*(\d{1,3})\s*[:\-–]\s*(.*)$", t, I)
        if not m:
            continue
        no = int(m.group(1))
        vo = clean_vo_text(m.group(2))
        scenes.append({
            "screen": f"screen_{no}",
            "index": len(scenes),
            "scene_no": no,
            "section": "story",
            "duration": None,
            "onscreen_text": m.group(2),
            "voiceover_text": vo,
            "voiceover_raw": m.group(2),
            "visual_type": "Image",
            "visual_direction": "",
            "text": vo or m.group(2),
            "is_poem": bool(re.search(r"\b(poem|suno|stanza|couplet)\b", m.group(2), A | I)),
            "source": "text",
        })
    return scenes


# Master format ---------------------------------------------------------------


@dataclass
class FormatReport:
    ok: bool
    problems: list[str] = field(default_factory=list)
    sheets: list[str] = field(default_factory=list)

    def message(self) -> str:
        if self.ok:
            return "Master script format OK (Sheet1, Sheet2, Narration VO, Poem VO, Audio Manifest)."
        return "Master script required: " + " ".join(self.problems)


def check_master_format(path: Path, sheets: list[tuple[str, list[list]]] | None = None) -> FormatReport:
    """Same rules and wording as ``assertMasterScriptWorkbook`` (the desktop EXE turns it on)."""
    ext = path.suffix.lower()
    if ext not in (".xlsx", ".xlsm"):
        return FormatReport(False, [f"only the DGS Cloud chapter workbook (.xlsx) is accepted. {MASTER_MESSAGE}"])
    if sheets is None:
        wb = _load_workbook(path)
        sheets = [(ws.title, _sheet_rows(ws)) for ws in wb.worksheets]
    names = [n for n, _ in sheets]
    rep = FormatReport(True, [], names)
    missing = [n for n in MASTER_SHEETS if n not in names]
    if missing:
        rep.ok = False
        rep.problems.append(
            f"missing sheet(s) {', '.join(missing)}. The workbook must match DGS_Cloud_Chapter_Script_Example.xlsx "
            "(Sheet1, Sheet2, Narration VO, Poem VO, Audio Manifest)."
        )
        return rep
    by = dict(sheets)

    def header(name: str) -> list[str]:
        rows = by.get(name) or []
        return [_js_or(c).strip() for c in (rows[0] if rows else [])]

    absent = [h for h in MASTER_SHEET1_HEADERS if h not in header("Sheet1")]
    if absent:
        rep.ok = False
        rep.problems.append(f"Sheet1 row 1 must keep the DGS headers (missing {', '.join(absent)}). Do not rename or reorder those columns.")
        return rep
    narr = header("Narration VO")
    poem = header("Poem VO")
    narr_ok = "EXACT WORDS TO SPEAK" in narr or any("VOICE OVER SCRIPT" in h.upper() for h in narr)
    poem_ok = "EXACT SUNG WORDS (blank for music)" in poem
    if not narr_ok or not poem_ok:
        rep.ok = False
        rep.problems.append('Narration VO must have "EXACT WORDS TO SPEAK" and Poem VO must have "EXACT SUNG WORDS (blank for music)".')
    return rep


@dataclass
class ScriptResult:
    scenes: list[dict]
    meta: dict
    report: FormatReport | None


def audio_name_key(name: str) -> str:
    """Match ``Marathi VO 1.mp3`` to ``Marathi VO 1(4).mp3`` (version tag in the name)."""
    stem = Path(str(name or "")).stem.lower().strip()
    stem = re.sub(r"\s*\(\d+\)\s*$", "", stem)
    stem = re.sub(r"\s+", " ", stem).strip()
    return stem


def parse_narration_vo_files(sheets: list[tuple[str, list[list]]]) -> list[dict]:
    """Expected narration files from Audio Manifest, else unique Narration VO filenames."""
    by = {n: rows for n, rows in sheets}
    out: list[dict] = []
    seen: set[int] = set()

    def add(slot: int, filename: str) -> None:
        slot = int(slot or 0)
        filename = str(filename or "").strip()
        if slot < 1 or not filename or slot in seen:
            return
        if Path(filename).suffix.lower() not in {".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"}:
            return
        seen.add(slot)
        out.append({"slot": slot, "filename": filename})

    man = by.get("Audio Manifest") or []
    if len(man) >= 2:
        head = [_js_or(c).strip().lower() for c in man[0]]
        file_i = next((i for i, h in enumerate(head) if "audio file" in h or h == "audio file exact name"), -1)
        role_i = next((i for i, h in enumerate(head) if "role" in h), -1)
        id_i = next((i for i, h in enumerate(head) if "track id" in h or h == "track id"), -1)
        narr_n = 0
        for row in man[1:]:
            cells = [_js_or(c).strip() for c in row]
            if not any(cells):
                continue
            role = cells[role_i] if 0 <= role_i < len(cells) else ""
            if role and not re.search(r"narration", role, I):
                continue
            fname = cells[file_i] if 0 <= file_i < len(cells) else ""
            tid = cells[id_i] if 0 <= id_i < len(cells) else ""
            m = re.search(r"(\d+)", tid)
            if m:
                add(int(m.group(1)), fname)
            else:
                narr_n += 1
                add(narr_n, fname)

    if not out:
        narr = by.get("Narration VO") or []
        if len(narr) >= 2:
            head = [_js_or(c).strip().lower() for c in narr[0]]
            file_i = next((i for i, h in enumerate(head) if "audio filename" in h or h == "audio filename"), -1)
            slot_i = next((i for i, h in enumerate(head) if h == "vo slot" or "vo slot" in h), -1)
            for row in narr[1:]:
                cells = [_js_or(c).strip() for c in row]
                if not any(cells):
                    continue
                try:
                    slot = int(float(cells[slot_i])) if 0 <= slot_i < len(cells) and cells[slot_i] else 1
                except ValueError:
                    slot = 1
                fname = cells[file_i] if 0 <= file_i < len(cells) else ""
                add(slot, fname)

    return sorted(out, key=lambda s: int(s["slot"]))


def poem_summary(scenes: list[dict]) -> dict:
    poem = [s for s in scenes if s.get("is_poem")]
    if not poem:
        return {"has_poem": False}
    suno = [s for s in poem if s.get("audio_start") is not None and s.get("audio_end") is not None]
    dur = round((max(float(s["audio_end"]) for s in suno) - min(float(s["audio_start"]) for s in suno)) * 1000) / 1000 if suno else None
    return {
        "has_poem": True,
        "scene_count": len(poem),
        "first_screen": poem[0]["screen"],
        "last_screen": poem[-1]["screen"],
        "suno_duration": dur,
    }


def read_script(path: Path, require_master: bool = True) -> ScriptResult:
    """Parse a script file. With ``require_master`` the master workbook check must pass."""
    ext = path.suffix.lower()
    report = None
    if ext in (".xlsx", ".xlsm", ".xls"):
        wb = _load_workbook(path)
        sheets = [(ws.title, _sheet_rows(ws)) for ws in wb.worksheets]
        report = check_master_format(path, sheets)
        if require_master and not report.ok:
            raise ScriptFormatError(report.message())
        scenes = parse_production_rows(sheets)
        vo_files = parse_narration_vo_files(sheets)
    else:
        if require_master:
            raise ScriptFormatError(check_master_format(path).message())
        scenes = parse_plain_script(path.read_text(encoding="utf-8", errors="replace"))
        vo_files = []
    meta = {
        "format": "production_xlsx" if "xls" in ext else "text",
        "filename": path.name,
        "scene_count": len(scenes),
        "poem": poem_summary(scenes),
        "vo_files": vo_files,
    }
    return ScriptResult(scenes, meta, report)
