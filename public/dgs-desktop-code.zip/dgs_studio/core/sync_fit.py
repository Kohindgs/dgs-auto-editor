"""Desktop-only sync polish after Auto-align.

Three repairs, for English and Marathi:

1. A spoken line that was not recognised is left on the neighbouring card.
   The two time windows are exchanged when the heard words prove it: either
   each window is the other's line, or one window is the neighbour's line and
   that neighbour is not already on its own line. A card that still matches
   its own line is never moved, so a lyric that merely runs long stays put.
   The pictures stay on their own scene numbers. English words are never
   matched against a Devanagari line.

2. Consecutive script cards stay in scene order on the VO. If Scene 69 was
   timed before Scene 68, the engine merges that stretch and cuts it back as
   68 then 69 (e.g. \"In urban areas, men…\" then \"while women…\").

3. A video that is a little shorter than its lyric or narration is slowed
   down so the whole take is still moving when the line ends. A video that is
   a little longer is sped up slightly so it finishes on the cut. The last
   frame is never held as a still.
"""

from __future__ import annotations

import re

from . import card_match
from .plan import fmt_short, scene_label

# A "little" long: speed up to 1.28x, then drop the extra frames at the cut.
FAST_LIMIT = 1.28
# A take shorter than this, compared with the line, is left alone. Slowing
# a near-empty file across a long line is not a real take.
SLOW_FLOOR = 0.20

# Glue words that sit in almost every line. They must not count as proof
# that a card is already on its own sentence.
_GLUE = {
    "is", "am", "be", "to", "of", "in", "on", "it", "at", "or", "an", "if",
    "we", "my", "so", "do", "up", "go", "by", "he", "me", "as", "no", "a",
}


def _r3(n: float) -> float:
    return round(float(n) * 1000) / 1000


def _content(text: str) -> list[str]:
    """Distinctive words from a full line (or a joined hearing).

    Glue/function words are dropped when the line still has two real words.
    Short headings like \"We have studied this.\" / \"आम्ही हे अभ्यासले.\" keep
    every substantial word so the engine can still prove the match.
    """
    raw = card_match.eng_words(text or "") + card_match.dev_words(text or "")
    skip = card_match.EN_FUNCTION_WORDS | card_match.MR_FUNCTION_WORDS | _GLUE
    out = [w for w in raw if w not in skip]
    if len(out) >= 2:
        return out
    kept = [w for w in raw if len(w) >= 3 and w not in _GLUE]
    return kept or out or [w for w in raw if len(w) >= 2]


def _cons_skel(word: str) -> str:
    key = re.sub(r"[^a-z]", "", (word or "").lower()).replace("ck", "k")
    if not key:
        return ""
    sk = re.sub(r"[aeiouh]", "", key)
    sk = re.sub(r"(.)\1+", r"\1", sk)
    if sk:
        return sk
    if key[0] in "vw":
        return "v"
    return key[0]


def _eng_same(a: str, b: str) -> bool:
    """True when two English tokens are the same hearing (stare↔stair, colour↔color).

    Short substring traps like air⊂stair are rejected — those stole the S18/S19 cut.
    """
    a = re.sub(r"[^a-z]", "", (a or "").lower())
    b = re.sub(r"[^a-z]", "", (b or "").lower())
    if not a or not b:
        return False
    if a == b:
        return True
    la, lb = len(a), len(b)
    if min(la, lb) >= 2 and abs(la - lb) <= 1 and (a.startswith(b) or b.startswith(a)):
        return True
    if la >= 3 and lb >= 3 and abs(la - lb) <= 2:
        sa, sb = _cons_skel(a), _cons_skel(b)
        # Full skeleton only — a shared "wn" prefix must not equate wind↔wings.
        if len(sa) >= 2 and sa == sb:
            return True
    # Substring only for longer stems (avoid air⊂stair / the⊂there).
    if min(la, lb) >= 4 and abs(la - lb) <= 2 and (a in b or b in a):
        return True
    return False


def _heard_tokens(words: list[dict], a: float, b: float) -> list[str]:
    # Join the window first, then score the line — per-word filtering would
    # turn a short heading into a single token and always fail the match.
    parts: list[str] = []
    for w in words or []:
        try:
            ws, we = float(w.get("start")), float(w.get("end") or w.get("start"))
        except (TypeError, ValueError):
            continue
        if we > a + 0.05 and ws < b - 0.05:
            tok = str(w.get("text") or w.get("word") or "").strip()
            if tok:
                parts.append(tok)
    return _content(" ".join(parts))


def _cover(heard: list[str], expected: list[str]) -> float:
    """Share of the line's distinctive words that were heard."""
    if not expected or not heard:
        return 0.0
    used: set[int] = set()
    hit = 0
    for w in expected:
        for i, h in enumerate(heard):
            if i in used:
                continue
            if _eng_same(w, h) or w == h:
                used.add(i)
                hit += 1
                break
    # One-word cards (after filtering) still count when that word was heard.
    if len(expected) == 1:
        return 1.0 if hit == 1 else 0.0
    if hit < 2:
        return 0.0
    return hit / len(expected)


def _poem_span(plan: dict) -> tuple[float, float, float]:
    """Timeline poem window (start, end, duration). Duration 0 when there is no separate song."""
    poem_start = float(plan.get("poem_start_time") or 0)
    poem_end = float(plan.get("poem_end_time") or 0)
    if plan.get("has_poem") and poem_end > poem_start + 0.2:
        return poem_start, poem_end, poem_end - poem_start
    return 0.0, 0.0, 0.0


def _poem_screens(scenes: list[dict] | None) -> set[str]:
    """Lyric / song screens from the script. Empty for chapters with no poem."""
    out: set[str] = set()
    for scene in scenes or []:
        if not isinstance(scene, dict):
            continue
        # Same rule as the align engine: poem flag or a Suno/sheet audio clock.
        if scene.get("is_poem") or scene.get("audio_start") is not None:
            screen = str(scene.get("screen") or "")
            if screen:
                out.add(screen)
    return out


def _is_poem_clip(plan: dict, clip: dict, poem_screens: set[str] | None = None) -> bool:
    """True only for real lyric/song screens — never for a lesson card parked on the song."""
    screen = str(clip.get("screen") or "")
    # Script list is authoritative. A misplaced lesson card can sit inside the
    # poem window; treating it as a lyric would skip the snap that pulls it out.
    if poem_screens is not None:
        return screen in poem_screens
    poem_start, poem_end, span = _poem_span(plan)
    if span <= 0 or not screen.startswith("screen_"):
        return False
    start = float(clip.get("start") or 0)
    if not (poem_start - 0.05 <= start < poem_end - 0.02):
        return False
    try:
        ni = float(clip.get("narration_in"))
    except (TypeError, ValueError):
        return True
    # Lyric cards keep narration_* on the timeline poem clock (ni ≈ picture start).
    # Lesson cards keep narration_* on the VO file clock (ni can match poem_start
    # while the picture was wrongly left under the song).
    return abs(ni - start) <= 0.55


def _narr_to_picture(plan: dict, ni: float, no: float, *, poem_screen: bool = False) -> tuple[float, float]:
    """Map a narration-file window onto the picture clock.

    Chapters without a poem: identity (picture == VO file clock).
    Chapters with a poem: spoken lines after the song keep narration_* on the
    continuous VO file clock, so pictures sit at file time + poem span.
    """
    poem_start, _poem_end, span = _poem_span(plan)
    if span <= 0 or poem_screen:
        return ni, no
    if ni >= poem_start - 0.02:
        return _r3(ni + span), _r3(no + span)
    return ni, no


def _cap_head_narration(plan: dict, clip: dict) -> bool:
    """Keep pre-song narration_* on the VO file clock (never into the song)."""
    poem_start, _poem_end, span = _poem_span(plan)
    if span <= 0:
        return False
    try:
        ni = float(clip.get("narration_in"))
        no = float(clip.get("narration_out"))
    except (TypeError, ValueError):
        return False
    if ni >= poem_start - 0.02 or no <= poem_start + 0.05:
        return False
    if float(clip.get("start") or 0) >= poem_start - 0.02:
        return False
    clip["narration_out"] = _r3(poem_start)
    return True


def set_poem_lyric_start(
    plan: dict,
    scenes: list[dict] | None = None,
    poem_words: list | None = None,
) -> float:
    """Timeline time when Poem text may first appear (first sung lyric).

    Instrumental intro and the \"Listen and sing.\" heading stay without Poem text.
    """
    poem_start, poem_end, span = _poem_span(plan)
    if span <= 0:
        plan["poem_lyric_start"] = 0.0
        return 0.0
    sheet: list[float] = []
    heard: list[float] = []
    words = poem_words if isinstance(poem_words, list) else plan.get("heard_poem_words")
    if isinstance(words, list) and words:
        for w in words:
            if not isinstance(w, dict):
                continue
            try:
                st = float(w.get("start"))
            except (TypeError, ValueError):
                continue
            tok = str(w.get("text") or w.get("word") or "").strip()
            if tok and st >= 0.0:
                heard.append(poem_start + st)
    for scene in scenes or []:
        if not isinstance(scene, dict):
            continue
        if not (scene.get("is_poem") or scene.get("audio_start") is not None):
            continue
        text = str(scene.get("voiceover_text") or "")
        raw = str(scene.get("voiceover_raw") or "")
        blob = f"{text} {raw}".lower()
        if "instrumental" in blob or "listen and sing" in blob:
            continue
        try:
            audio_start = float(scene.get("audio_start"))
        except (TypeError, ValueError):
            continue
        if audio_start >= 0.0:
            sheet.append(poem_start + audio_start)
    # Workbook Suno clock wins when present — early Whisper must not put Poem
    # text up during the instrumental (that looked like a Listen-and-sing flash).
    if sheet:
        lyric_start = min(sheet)
    elif heard:
        lyric_start = min(heard)
    else:
        lyric_start = poem_start
        for clip in plan.get("clips") or []:
            if not isinstance(clip, dict):
                continue
            start = float(clip.get("start") or 0)
            if start < poem_start - 0.05 or start >= poem_end - 0.05:
                continue
            text = str(clip.get("vo_text") or clip.get("caption_text") or "").strip()
            low = text.lower()
            if not text or "instrumental" in low or "listen and sing" in low:
                continue
            lyric_start = start
            break
    lyric_start = max(poem_start, min(lyric_start, poem_end - 0.2))
    plan["poem_lyric_start"] = _r3(lyric_start)
    return lyric_start


def ensure_poem_clock(plan: dict, scenes: list[dict] | None = None) -> int:
    """Final safety net after Auto-align — poem and non-poem chapters.

    - No poem: no-op (returns 0).
    - With poem: snap post-song pictures off the lyric window, rebuild the VO
      lane with a hole for the song, and stretch total_duration past the song.
    """
    poem_start, poem_end, span = _poem_span(plan)
    if span <= 0:
        plan["poem_lyric_start"] = 0.0
        return 0
    set_poem_lyric_start(plan, scenes, plan.get("heard_poem_words"))
    poem_screens = _poem_screens(scenes)
    fixed = 0
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict)]
    for clip in clips:
        if _is_poem_clip(plan, clip, poem_screens):
            continue
        if _cap_head_narration(plan, clip):
            fixed += 1
        try:
            ni = float(clip.get("narration_in"))
            no = float(clip.get("narration_out"))
        except (TypeError, ValueError):
            continue
        if no - ni < 0.2:
            continue
        target_s, target_e = _narr_to_picture(plan, ni, no, poem_screen=False)
        start = float(clip.get("start") or 0)
        end = float(clip.get("end") or start)
        # Keep an instrumental fold on the heading card; only reseat the start.
        if start < poem_start - 0.02 and end > poem_start + 0.05 and end <= poem_end + 0.05:
            if abs(start - target_s) > 0.35:
                clip["start"] = _r3(target_s)
                clip["duration"] = _r3(end - target_s)
                if clip.get("kind") != "video":
                    clip["source_out"] = clip["duration"]
                fixed += 1
            continue
        if abs(start - target_s) > 0.35 or abs(end - target_e) > 0.35:
            _set_pic_span(clip, target_s, target_e)
            fixed += 1
    clips.sort(key=lambda c: (float(c.get("start") or 0), str(c.get("screen") or "")))
    for i in range(len(clips) - 1):
        a, b = clips[i], clips[i + 1]
        ae = float(a.get("end") or 0)
        bs = float(b.get("start") or 0)
        if ae > bs + 0.02:
            _set_pic_span(a, float(a.get("start") or 0), bs)
            fixed += 1
    plan["clips"] = clips

    from .repeat_vo import ensure_voice_pieces

    plan["vo_pieces"] = []
    if ensure_voice_pieces(plan):
        fixed += 1

    ends = [float(c.get("end") or 0) for c in clips]
    for p in plan.get("vo_pieces") or []:
        if isinstance(p, dict):
            ends.append(float(p.get("end") or 0))
    ends.append(poem_end)
    if ends:
        plan["total_duration"] = _r3(max(float(plan.get("total_duration") or 0), max(ends)))
    if fixed:
        plan["manual_override"] = True
        sync_narration_segments_from_clips(plan)
    return fixed


def _window(clip: dict, poem_start: float, poem_end: float) -> tuple[float, float, list[dict], float]:
    """Return (start, end, which word list key is chosen by the caller). Times compared later."""
    a = float(clip.get("narration_in") if clip.get("narration_in") is not None else clip.get("start") or 0)
    b = float(clip.get("narration_out") if clip.get("narration_out") is not None else clip.get("end") or 0)
    start = float(clip.get("start") or 0)
    in_poem = poem_end > poem_start + 0.3 and poem_start - 0.05 <= start < poem_end - 0.02
    return a, b, in_poem


def repair_misplaced_lines(plan: dict, scenes: list[dict], vo_words: list | None, poem_words: list | None) -> tuple[int, list[str]]:
    """Exchange two adjacent cards' time windows when each is playing the other's line.

    Returns how many cards were moved, and those scene ids. A line that was not
    heard is not guessed onto its neighbour.
    """
    clips = list(plan.get("clips") or [])
    if len(clips) < 2:
        return 0
    by_screen = {str(s.get("screen")): s for s in scenes or []}
    poem_start = float(plan.get("poem_start_time") or 0)
    poem_end = float(plan.get("poem_end_time") or 0)
    moved = 0
    moved_screens: list[str] = []
    used: set[int] = set()
    for i in range(len(clips) - 1):
        if i in used:
            continue
        a, b = clips[i], clips[i + 1]
        sa, sb = by_screen.get(str(a.get("screen"))), by_screen.get(str(b.get("screen")))
        if not sa or not sb:
            continue
        exp_a = _content(str(sa.get("voiceover_text") or sa.get("onscreen_text") or ""))
        exp_b = _content(str(sb.get("voiceover_text") or sb.get("onscreen_text") or ""))
        if len(exp_a) < 2 or len(exp_b) < 2:
            continue
        aa, ab, a_poem = _window(a, poem_start, poem_end)
        ba, bb, b_poem = _window(b, poem_start, poem_end)
        if ab - aa < 0.2 or bb - ba < 0.2:
            continue
        words_a = poem_words if a_poem else vo_words
        words_b = poem_words if b_poem else vo_words
        if a_poem:
            aa, ab = aa - poem_start, ab - poem_start
        if b_poem:
            ba, bb = ba - poem_start, bb - poem_start
        heard_a = _heard_tokens(words_a or [], aa, ab)
        heard_b = _heard_tokens(words_b or [], ba, bb)
        own_a = _cover(heard_a, exp_a)
        own_b = _cover(heard_b, exp_b)
        onto_b = _cover(heard_a, exp_b)
        onto_a = _cover(heard_b, exp_a)
        # Both windows are each other's line. Shared glue words do not count.
        mutual = onto_b >= 0.55 and onto_a >= 0.55 and onto_b >= own_a + 0.25 and onto_a >= own_b + 0.25
        # One card is holding the neighbour's line, and that neighbour is not
        # already on its own line. A card that still matches itself is left
        # alone, so a lyric that merely runs long is not treated as a swap.
        one_way = (
            (onto_b >= 0.70 and own_a <= 0.40 and own_b <= 0.40 and onto_a < 0.55)
            or (onto_a >= 0.70 and own_b <= 0.40 and own_a <= 0.40 and onto_b < 0.55)
        )
        if not mutual and not one_way:
            continue
        _exchange_window(a, b)
        moved_screens.extend([str(a.get("screen") or ""), str(b.get("screen") or "")])
        used.add(i)
        used.add(i + 1)
        moved += 2
    if moved:
        plan["clips"] = sorted(clips, key=lambda c: (float(c.get("start") or 0), str(c.get("screen") or "")))
        note = plan.get("qa_summary") or ""
        extra = f"{moved} cards put back on their own spoken line"
        plan["qa_summary"] = f"{note} · {extra}".strip(" ·")
    return moved, [s for s in moved_screens if s]


def _scene_no(screen: str) -> int | None:
    m = re.search(r"(\d+)$", str(screen or ""))
    return int(m.group(1)) if m else None


def _word_rows(words: list | None) -> list[tuple[float, float, str]]:
    rows: list[tuple[float, float, str]] = []
    for w in words or []:
        if not isinstance(w, dict):
            continue
        try:
            ws = float(w.get("start"))
            we = float(w.get("end") or w.get("start"))
        except (TypeError, ValueError):
            continue
        tok = str(w.get("text") or w.get("word") or "").strip()
        if we > ws and tok:
            rows.append((ws, we, tok))
    rows.sort()
    return rows


def _best_ordered_split(
    rows: list[tuple[float, float, str]],
    t0: float,
    t1: float,
    exp_a: list[str],
    exp_b: list[str],
) -> float | None:
    """File time that best separates exp_a then exp_b inside [t0, t1]."""
    inside = [(ws, we, tok) for ws, we, tok in rows if we > t0 + 0.02 and ws < t1 - 0.02]
    if len(inside) < 4:
        return None
    best_t = None
    best_score = -1.0
    for i in range(2, len(inside) - 1):
        split = inside[i][0]
        if split <= t0 + 0.15 or split >= t1 - 0.15:
            continue
        left = _content(" ".join(tok for ws, we, tok in inside if ws < split))
        right = _content(" ".join(tok for ws, we, tok in inside if ws >= split))
        score = _cover(left, exp_a) + _cover(right, exp_b)
        # Prefer a clean hand-off: left looks like A, right looks like B.
        if _cover(left, exp_b) > _cover(left, exp_a):
            score -= 0.35
        spill_a = _cover(right, exp_a)
        if spill_a > _cover(right, exp_b):
            score -= 0.35
        elif spill_a >= 0.18:
            # Vocab tails (Stare/Air heard as stair/air) must stay on A even when
            # a larger pause sits before them — that pause is not the next line.
            score -= 0.45 * spill_a
        gap = inside[i][0] - inside[i - 1][1]
        score += min(0.15, max(0.0, gap) * 0.2)
        if score > best_score:
            best_score = score
            best_t = split
    if best_t is None or best_score < 0.7:
        return None
    return best_t


def repair_script_order(
    plan: dict,
    scenes: list[dict],
    vo_words: list | None,
    poem_words: list | None = None,
) -> tuple[int, list[str]]:
    """Put consecutive script cards back in scene order on the VO.

    Example: Scene 69 timed before Scene 68 → merge that stretch and cut it as
    68 then 69 (\"In urban areas, men…shorts,\" then \"while women…sarees.\").
    """
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict)]
    if len(clips) < 2:
        return 0, []
    by_screen = {str(s.get("screen")): s for s in scenes or []}
    clip_by = {str(c.get("screen") or ""): c for c in clips if c.get("screen")}
    numbered: list[tuple[int, str, dict, dict]] = []
    for screen, scene in by_screen.items():
        no = _scene_no(screen)
        clip = clip_by.get(screen)
        if no is None or not clip:
            continue
        numbered.append((no, screen, scene, clip))
    numbered.sort(key=lambda row: row[0])
    rows = _word_rows(vo_words)
    poem_screens = _poem_screens(scenes)
    moved = 0
    moved_screens: list[str] = []
    for i in range(len(numbered) - 1):
        na, sa, scena, ca = numbered[i]
        nb, sb, scenb, cb = numbered[i + 1]
        if nb != na + 1:
            continue
        # Poem lyric cards live on the song clock, not the narration VO.
        if sa in poem_screens or sb in poem_screens:
            continue
        exp_a = _content(str(scena.get("voiceover_text") or scena.get("onscreen_text") or ""))
        exp_b = _content(str(scenb.get("voiceover_text") or scenb.get("onscreen_text") or ""))
        if len(exp_a) < 2 or len(exp_b) < 2:
            continue
        try:
            ai = float(ca.get("narration_in"))
            ao = float(ca.get("narration_out"))
            bi = float(cb.get("narration_in"))
            bo = float(cb.get("narration_out"))
        except (TypeError, ValueError):
            continue
        out_of_order = bi < ai - 0.05
        heard_a = _heard_tokens(vo_words or [], ai, ao)
        heard_b = _heard_tokens(vo_words or [], bi, bo)
        a_on_b = _cover(heard_a, exp_b)
        b_on_a = _cover(heard_b, exp_a)
        a_own = _cover(heard_a, exp_a)
        b_own = _cover(heard_b, exp_b)
        crossed = (a_on_b >= 0.45 and a_on_b >= a_own + 0.15) or (b_on_a >= 0.45 and b_own < 0.45)
        if not out_of_order and not crossed:
            continue
        t0 = min(ai, bi)
        t1 = max(ao, bo)
        # Pull in trailing words of B that still sit before the next card.
        if i + 2 < len(numbered):
            try:
                nxt_i = float(numbered[i + 2][3].get("narration_in"))
                t1 = max(t1, min(nxt_i - 0.05, t1 + 8.0))
            except (TypeError, ValueError):
                pass
        else:
            t1 = max(t1, t0 + 0.5)
        # Grow t1 while distinctive B words continue.
        for ws, we, tok in rows:
            if ws < t1 - 0.01 or ws > t1 + 6.0:
                continue
            if tok.lower().strip(".,;") in {w.lower() for w in exp_b}:
                t1 = max(t1, we)
            elif ws > t1 + 0.35:
                break
        split = _best_ordered_split(rows, t0, t1, exp_a, exp_b)
        if split is None:
            if out_of_order:
                _exchange_window(ca, cb)
                moved += 2
                moved_screens.extend([sa, sb])
            continue
        left = _heard_tokens(vo_words or [], t0, split)
        right = _heard_tokens(vo_words or [], split, t1)
        if _cover(left, exp_a) < 0.35 or _cover(right, exp_b) < 0.35:
            if out_of_order:
                _exchange_window(ca, cb)
                moved += 2
                moved_screens.extend([sa, sb])
            continue
        # Picture stays up for the full spoken line (1:1 with narration).
        # Later cards move forward — never cut the line short for the next video.
        dur_a = max(0.35, split - t0)
        dur_b = max(0.35, t1 - split)
        pic0 = min(float(ca.get("start") or 0), float(cb.get("start") or 0))
        mid = pic0 + dur_a
        pic1 = mid + dur_b
        old_end = max(float(ca.get("end") or 0), float(cb.get("end") or 0))
        ca["narration_in"] = _r3(t0)
        ca["narration_out"] = _r3(split)
        cb["narration_in"] = _r3(split)
        cb["narration_out"] = _r3(t1)
        _set_pic_span(ca, pic0, mid)
        _set_pic_span(cb, mid, pic1)
        growth = pic1 - old_end
        if growth > 0.05:
            _shift_clips_from(clips, old_end - 0.02, growth)
            _shift_point_rows(plan.get("narration_segments"), old_end - 0.02, growth)
            _shift_point_rows(plan.get("srt_cues"), old_end - 0.02, growth)
            total = float(plan.get("total_duration") or 0)
            if total > 0:
                plan["total_duration"] = _r3(total + growth)
        moved += 2
        moved_screens.extend([sa, sb])
    if moved:
        plan["clips"] = sorted(clips, key=lambda c: (float(c.get("start") or 0), str(c.get("screen") or "")))
        plan["manual_override"] = True
        note = plan.get("qa_summary") or ""
        extra = f"{moved} cards put back in script order on the VO"
        if extra not in note:
            plan["qa_summary"] = f"{note} · {extra}".strip(" ·")
    return moved, [s for s in moved_screens if s]


def extend_pictures_to_spoken_lines(plan: dict, scenes: list[dict] | None = None) -> int:
    """Keep each picture up until its narration line finishes.

    If the next video started while this line was still being said, grow this
    card and push later cards forward.
    """
    clips = sorted(
        [c for c in (plan.get("clips") or []) if isinstance(c, dict)],
        key=lambda c: float(c.get("start") or 0),
    )
    if len(clips) < 2:
        return 0
    poem_screens = _poem_screens(scenes)
    grown = 0
    for i, clip in enumerate(clips):
        screen = str(clip.get("screen") or "")
        # Poem cards are already locked to the song / sheet clock.
        if screen in poem_screens:
            continue
        try:
            ni = float(clip.get("narration_in"))
            no = float(clip.get("narration_out"))
        except (TypeError, ValueError):
            continue
        target_s, target_e = _narr_to_picture(plan, ni, no, poem_screen=False)
        need = max(0.0, target_e - target_s)
        if need < 0.35:
            continue
        start = float(clip.get("start") or target_s)
        end = float(clip.get("end") or start)
        have = end - start
        if have >= need - 0.12:
            continue
        extra = need - have
        new_end = start + need
        _set_pic_span(clip, start, new_end)
        _shift_clips_from(clips[i + 1 :], end - 0.02, extra)
        _shift_point_rows(plan.get("narration_segments"), end - 0.02, extra)
        _shift_point_rows(plan.get("srt_cues"), end - 0.02, extra)
        total = float(plan.get("total_duration") or 0)
        if total > 0:
            plan["total_duration"] = _r3(total + extra)
        grown += 1
    if grown:
        plan["clips"] = sorted(clips, key=lambda c: (float(c.get("start") or 0), str(c.get("screen") or "")))
        plan["manual_override"] = True
    return grown


def retighten_adjacent_cuts(
    plan: dict,
    scenes: list[dict],
    vo_words: list | None,
) -> tuple[int, list[str]]:
    """Move shared cuts so the next spoken line does not start under the previous card.

    Example: Scene 68 was still on screen when \"while women…\" (Scene 69) began,
    and Scene 67 still held the first \"In\" of Scene 68. Each consecutive pair is
    re-cut at the best ordered hand-off on the VO.
    """
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict)]
    if len(clips) < 2 or not vo_words:
        return 0, []
    by_screen = {str(s.get("screen")): s for s in scenes or []}
    clip_by = {str(c.get("screen") or ""): c for c in clips if c.get("screen")}
    numbered: list[tuple[int, str, dict, dict]] = []
    for screen, scene in by_screen.items():
        no = _scene_no(screen)
        clip = clip_by.get(screen)
        if no is None or not clip:
            continue
        numbered.append((no, screen, scene, clip))
    numbered.sort(key=lambda row: row[0])
    rows = _word_rows(vo_words)
    poem_screens = _poem_screens(scenes)
    moved = 0
    moved_screens: list[str] = []
    for i in range(len(numbered) - 1):
        na, sa, scena, ca = numbered[i]
        nb, sb, scenb, cb = numbered[i + 1]
        if nb != na + 1:
            continue
        if sa in poem_screens or sb in poem_screens:
            continue
        exp_a = _content(str(scena.get("voiceover_text") or scena.get("onscreen_text") or ""))
        exp_b = _content(str(scenb.get("voiceover_text") or scenb.get("onscreen_text") or ""))
        if len(exp_a) < 1 or len(exp_b) < 1:
            continue
        try:
            ai = float(ca.get("narration_in"))
            ao = float(ca.get("narration_out"))
            bi = float(cb.get("narration_in"))
            bo = float(cb.get("narration_out"))
        except (TypeError, ValueError):
            continue
        if ao - ai < 0.25 or bo - bi < 0.25:
            continue
        # File-clock window only. Picture start/end after a poem insert are
        # offset by the song span and must never widen the VO search.
        t0 = max(0.0, min(ai, bi) - 0.35)
        t1 = max(ao, bo) + 0.55
        split = _best_ordered_split(rows, t0, t1, exp_a, exp_b)
        if split is None:
            continue
        cur_cut = min(ao, bi) if bi >= ao - 0.05 else (ao + bi) / 2.0
        left_now = _heard_tokens(vo_words, t0, cur_cut)
        right_now = _heard_tokens(vo_words, cur_cut, t1)
        left_new = _heard_tokens(vo_words, t0, split)
        right_new = _heard_tokens(vo_words, split, t1)
        score_now = _cover(left_now, exp_a) + _cover(right_now, exp_b)
        score_new = _cover(left_new, exp_a) + _cover(right_new, exp_b)
        if score_new < 0.7:
            continue
        if score_new < score_now + 0.12 and abs(split - cur_cut) < 0.15:
            continue
        # Never take a worse hand-off just because a later pause looked bigger
        # inside a too-wide search window.
        if score_new + 0.02 < score_now and abs(split - cur_cut) > 0.12:
            continue
        # Spill proof: next line's distinctive words already sit under this card,
        # or this line's words still sit under the next card.
        spill = _cover(_heard_tokens(vo_words, max(t0, cur_cut - 1.8), cur_cut), exp_b)
        early = _cover(_heard_tokens(vo_words, cur_cut, min(t1, cur_cut + 1.2)), exp_a)
        if spill < 0.35 and early < 0.35 and abs(split - cur_cut) < 0.2 and score_new < score_now + 0.25:
            continue
        # Only move the shared cut; keep each line's outer edge unless the
        # first word of A was sitting under the previous card.
        new_ai = ai
        first_hit = None
        for ws, _we, tok in rows:
            if ws < t0 - 0.02 or ws >= split - 0.05:
                continue
            clean = tok.lower().strip(".,;")
            if any(_eng_same(clean, w) or clean == w for w in exp_a):
                first_hit = ws
                new_ai = min(new_ai, ws)
                break
        if first_hit is None and new_ai >= split - 0.08:
            # Empty card: leave a short lead before the next line.
            new_ai = max(t0, split - 0.25)
        new_ao = split
        new_bi = split
        new_bo = max(bo, split + 0.35)
        ca["narration_in"] = _r3(new_ai)
        ca["narration_out"] = _r3(new_ao)
        cb["narration_in"] = _r3(new_bi)
        cb["narration_out"] = _r3(new_bo)
        _apply_narr_pic(plan, ca, new_ai, new_ao, poem_screens)
        _apply_narr_pic(plan, cb, new_bi, new_bo, poem_screens)
        moved += 2
        moved_screens.extend([sa, sb])
    # Second pass: pull the cut back to the next line's first spoken word
    # (including short headings like \"We have studied this.\").
    # MCQ answers that repeat an option word (\"Rainy.\" after \"(c) rainy\")
    # must use the *later* hearing — never steal the option from the question.
    for i in range(len(numbered) - 1):
        na, sa, scena, ca = numbered[i]
        nb, sb, scenb, cb = numbered[i + 1]
        if nb != na + 1:
            continue
        if sa in poem_screens or sb in poem_screens:
            continue
        try:
            ao = float(ca.get("narration_out"))
            bi = float(cb.get("narration_in"))
            ai = float(ca.get("narration_in"))
            bo = float(cb.get("narration_out"))
        except (TypeError, ValueError):
            continue
        cur_cut = min(ao, bi) if bi >= ao - 0.05 else (ao + bi) / 2.0
        text_a = str(scena.get("voiceover_text") or scena.get("onscreen_text") or "")
        text_b = str(scenb.get("voiceover_text") or scenb.get("onscreen_text") or "")
        exp_a = set(_content(text_a))
        exp_b = set(_content(text_b))
        answer_echo = bool(exp_b) and exp_b <= exp_a
        if answer_echo:
            # Later hearing of the answer after the options finish.
            later = _first_spoken_time(rows, cur_cut + 0.15, cur_cut + 12.0, text_b)
            if later is None:
                later = _nth_spoken_time(rows, ai, bo + 8.0, text_b, index=1)
            if later is None or later <= cur_cut + 0.1:
                continue
            # Grow the question/options card through every option word.
            opt_end = _last_spoken_time(rows, ai, later - 0.05, text_a)
            new_ao = min(later - 0.05, (opt_end + 0.18) if opt_end else later - 0.05)
            if new_ao <= ai + 0.3:
                continue
            new_bo = max(bo, ((_last_spoken_time(rows, later, later + 6.0, text_b) or later) + 0.12))
            _apply_narr_pic(plan, ca, float(ca.get("narration_in") or ai), new_ao, poem_screens)
            _apply_narr_pic(plan, cb, later, new_bo, poem_screens)
            if sa not in moved_screens:
                moved += 2
                moved_screens.extend([sa, sb])
            elif sb not in moved_screens:
                moved_screens.append(sb)
            continue
        first_b = _first_spoken_time(rows, cur_cut - 1.2, cur_cut + 0.8, text_b)
        if first_b is None or first_b >= cur_cut - 0.04:
            continue
        if first_b <= ai + 0.25:
            continue
        _apply_narr_pic(plan, ca, float(ca.get("narration_in") or ai), first_b, poem_screens)
        _apply_narr_pic(plan, cb, first_b, float(cb.get("narration_out") or bo), poem_screens)
        if sa not in moved_screens:
            moved += 2
            moved_screens.extend([sa, sb])
        elif sb not in moved_screens:
            moved_screens.append(sb)
    if moved:
        plan["clips"] = sorted(clips, key=lambda c: (float(c.get("start") or 0), str(c.get("screen") or "")))
        plan["manual_override"] = True
        sync_narration_segments_from_clips(plan)
        note = plan.get("qa_summary") or ""
        extra = f"{moved} adjacent cuts tightened to the spoken hand-off"
        if extra not in note:
            plan["qa_summary"] = f"{note} · {extra}".strip(" ·")
    return moved, [s for s in moved_screens if s]


def _spoken_hits(
    rows: list[tuple[float, float, str]],
    t0: float,
    t1: float,
    text: str,
) -> list[tuple[float, float]]:
    """(start, end) for each hearing of this line inside [t0, t1]."""
    want = card_match.eng_words(text or "") + card_match.dev_words(text or "")
    if not want:
        return []
    want_l = [w.lower() for w in want]
    inside = [(ws, we, tok.lower().strip(".,;:!?\"'")) for ws, we, tok in rows if we > t0 and ws < t1]
    hits: list[tuple[float, float]] = []
    for i, (ws, we, tok) in enumerate(inside):
        if tok != want_l[0]:
            continue
        ok = True
        end = we
        for j, need in enumerate(want_l[1:4], start=1):
            if i + j >= len(inside):
                break
            if inside[i + j][2] != need:
                if len(want_l) <= 4 and j == 1:
                    continue
                ok = False
                break
            end = inside[i + j][1]
        if ok:
            hits.append((ws, end))
    return hits


def _first_spoken_time(
    rows: list[tuple[float, float, str]],
    t0: float,
    t1: float,
    text: str,
) -> float | None:
    """Timeline time of the first word of this line inside [t0, t1]."""
    hits = _spoken_hits(rows, t0, t1, text)
    return hits[0][0] if hits else None


def _nth_spoken_time(
    rows: list[tuple[float, float, str]],
    t0: float,
    t1: float,
    text: str,
    index: int = 1,
) -> float | None:
    hits = _spoken_hits(rows, t0, t1, text)
    if len(hits) <= index:
        return None
    return hits[index][0]


def _last_spoken_time(
    rows: list[tuple[float, float, str]],
    t0: float,
    t1: float,
    text: str,
) -> float | None:
    """End time of the last matched content word of this line in [t0, t1]."""
    want = set(_content(text))
    if not want:
        return None
    last = None
    for ws, we, tok in rows:
        if we <= t0 or ws >= t1:
            continue
        clean = tok.lower().strip(".,;:!?\"'")
        if clean in want or any(_eng_same(clean, w) for w in want):
            last = we
    return last


def sync_narration_segments_from_clips(plan: dict) -> int:
    """Keep narration_segments on the same windows as Video 1 clips.

    Playback maps picture time → VO through narration_segments. If those rows
    lag behind the clips, Scene 70 can still show while Scene 71's line plays.
    """
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict) and c.get("screen")]
    segs = plan.get("narration_segments")
    if not clips:
        return 0
    by_screen = {str(c.get("screen")): c for c in clips}
    if not isinstance(segs, list) or not segs:
        # Build a fresh lane from the clips so VO follows the pictures.
        plan["narration_segments"] = [
            {
                "screen": str(c.get("screen")),
                "start": c.get("start"),
                "end": c.get("end"),
                "narration_in": c.get("narration_in", c.get("start")),
                "narration_out": c.get("narration_out", c.get("end")),
                "vo_text": c.get("vo_text") or c.get("script_text") or "",
            }
            for c in sorted(clips, key=lambda x: float(x.get("start") or 0))
            if c.get("narration_in") is not None and c.get("narration_out") is not None
        ]
        return len(plan["narration_segments"])
    n = 0
    for seg in segs:
        if not isinstance(seg, dict):
            continue
        clip = by_screen.get(str(seg.get("screen") or ""))
        if not clip:
            continue
        before = (seg.get("start"), seg.get("end"), seg.get("narration_in"), seg.get("narration_out"))
        seg["start"] = clip.get("start")
        seg["end"] = clip.get("end")
        if clip.get("narration_in") is not None:
            seg["narration_in"] = clip.get("narration_in")
        if clip.get("narration_out") is not None:
            seg["narration_out"] = clip.get("narration_out")
        after = (seg.get("start"), seg.get("end"), seg.get("narration_in"), seg.get("narration_out"))
        if before != after:
            n += 1
    return n


def close_overlapping_narration(plan: dict, scenes: list[dict] | None = None) -> int:
    """Ensure consecutive scene narration windows do not overlap.

    After hand locks / answer-echo repairs, an earlier card can keep a late
    ``narration_out`` while the next card already owns that VO (e.g. Scene 91
    still covering \"Which season…\" that belongs on 92). Pictures then chain
    from the wrong end and look like VO/script/image sync is broken.
    """
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict)]
    poem_screens = _poem_screens(scenes)
    numbered: list[tuple[int, dict]] = []
    for clip in clips:
        no = _scene_no(str(clip.get("screen") or ""))
        if no is None:
            continue
        numbered.append((no, clip))
    numbered.sort(key=lambda row: row[0])
    fixed = 0
    for i in range(len(numbered) - 1):
        na, ca = numbered[i]
        nb, cb = numbered[i + 1]
        if nb != na + 1:
            continue
        sa = str(ca.get("screen") or "")
        sb = str(cb.get("screen") or "")
        # Do not mix the song clock with the narration file clock.
        if sa in poem_screens or sb in poem_screens:
            continue
        try:
            ao = float(ca.get("narration_out"))
            bi = float(cb.get("narration_in"))
            ai = float(ca.get("narration_in"))
            bo = float(cb.get("narration_out"))
        except (TypeError, ValueError):
            continue
        if bi + 0.02 >= ao:
            continue
        # Next line already started — cut previous card there.
        if bi <= ai + 0.25:
            continue
        ca["narration_out"] = _r3(bi)
        pic_ai, pic_bi = _narr_to_picture(plan, ai, bi, poem_screen=False)
        pic_bi2, pic_bo = _narr_to_picture(plan, bi, max(bo, bi + 0.35), poem_screen=False)
        if float(ca.get("end") or 0) > pic_bi + 0.02 or float(ca.get("start") or 0) < pic_ai - 0.02:
            _set_pic_span(ca, pic_ai, pic_bi)
        else:
            _set_pic_span(ca, float(ca.get("start") or pic_ai), pic_bi)
        _set_pic_span(cb, pic_bi2, pic_bo)
        fixed += 1
    if not fixed:
        return 0
    plan["clips"] = sorted(clips, key=lambda c: (float(c.get("start") or 0), str(c.get("screen") or "")))
    plan["manual_override"] = True
    sync_narration_segments_from_clips(plan)
    return fixed


def align_pictures_to_narration(plan: dict, scenes: list[dict] | None = None) -> int:
    """Put each picture on its spoken window when it has drifted off the VO.

    VO 2 cards such as \"We have studied this.\" must show while that line is
    heard — not several seconds early on the previous line.

    Poem lyric cards stay on the song clock. Spoken lines after the poem keep
    ``narration_in`` / ``narration_out`` on the VO file clock, so their pictures
    must sit after the song (file time + poem span) — never snapped back on top
    of the lyrics.
    """
    clips = [c for c in (plan.get("clips") or []) if isinstance(c, dict)]
    if not clips:
        return 0
    poem_screens = _poem_screens(scenes)
    poem_start, poem_end, span = _poem_span(plan)
    fixed = 0
    for clip in clips:
        screen = str(clip.get("screen") or "")
        poem_screen = _is_poem_clip(plan, clip, poem_screens)
        if _cap_head_narration(plan, clip):
            fixed += 1
        try:
            ni = float(clip.get("narration_in"))
            no = float(clip.get("narration_out"))
        except (TypeError, ValueError):
            continue
        if no - ni < 0.25:
            continue
        target_s, target_e = _narr_to_picture(plan, ni, no, poem_screen=poem_screen)
        start = float(clip.get("start") or 0)
        end = float(clip.get("end") or start)
        # Heading card that absorbed the song intro: keep the picture through
        # the instrumental; only re-seat the start onto the VO head.
        if (
            span > 0
            and not poem_screen
            and start < poem_start - 0.02
            and end > poem_start + 0.05
            and end <= poem_end + 0.05
        ):
            if abs(start - target_s) > 0.35:
                clip["start"] = _r3(target_s)
                clip["duration"] = _r3(end - target_s)
                if clip.get("kind") != "video":
                    clip["source_out"] = clip["duration"]
                fixed += 1
            continue
        if abs(start - target_s) <= 0.35 and abs(end - target_e) <= 0.35:
            continue
        _set_pic_span(clip, target_s, target_e)
        fixed += 1
    if not fixed:
        return 0
    clips.sort(key=lambda c: (float(c.get("start") or 0), str(c.get("screen") or "")))
    # Close tiny overlaps from rounding; picture windows are the authority.
    for i in range(len(clips) - 1):
        a, b = clips[i], clips[i + 1]
        ae = float(a.get("end") or 0)
        bs = float(b.get("start") or 0)
        if ae > bs + 0.02:
            _set_pic_span(a, float(a.get("start") or 0), bs)
    plan["clips"] = clips
    ends = [float(c.get("end") or 0) for c in clips]
    if ends:
        plan["total_duration"] = _r3(max(float(plan.get("total_duration") or 0), max(ends)))
    plan["manual_override"] = True
    return fixed

def _apply_narr_pic(
    plan: dict,
    clip: dict,
    ni: float,
    no: float,
    poem_screens: set[str] | None = None,
) -> None:
    """Write narration_* and map the picture onto the right clock (song or VO)."""
    poem = _is_poem_clip(plan, clip, poem_screens)
    pic_s, pic_e = _narr_to_picture(plan, float(ni), float(no), poem_screen=poem)
    clip["narration_in"] = _r3(ni)
    clip["narration_out"] = _r3(no)
    _set_pic_span(clip, pic_s, pic_e)


def _set_pic_span(clip: dict, start: float, end: float) -> None:
    clip["start"] = _r3(start)
    clip["end"] = _r3(end)
    clip["duration"] = _r3(end - start)
    if clip.get("kind") != "video":
        clip["source_out"] = clip["duration"]
        return
    # A short take still covers the spoken line: play what exists, hold the rest.
    try:
        src_in = float(clip.get("source_in") or 0)
        src_out = float(clip.get("source_out") or 0)
    except (TypeError, ValueError):
        src_in, src_out = 0.0, 0.0
    file_span = max(0.0, src_out - src_in)
    need = float(clip["duration"])
    # Tiny source windows (e.g. 0.2s) on a multi-second card freeze/stutter —
    # treat as missing take length and play through the spoken window instead.
    if file_span <= 0.05 or (file_span < 0.5 and need > 1.5):
        clip["source_in"] = 0
        clip["source_out"] = clip["duration"]
        clip["fit"] = "trim"
    elif file_span + 0.08 < need:
        clip["fit"] = "hold"
    else:
        clip["source_out"] = _r3(src_in + need)
        if clip.get("fit") not in ("trim", "stretch", "hold"):
            clip["fit"] = "trim"


def _shift_clips_from(clips: list, at: float, delta: float) -> None:
    if delta <= 0.02:
        return
    for clip in clips:
        if not isinstance(clip, dict):
            continue
        start = float(clip.get("start") or 0)
        end = float(clip.get("end") or 0)
        if end <= at:
            continue
        if start >= at:
            clip["start"] = _r3(start + delta)
            clip["end"] = _r3(end + delta)
        else:
            clip["end"] = _r3(end + delta)
        clip["duration"] = _r3(float(clip["end"]) - float(clip["start"]))
        if clip.get("kind") != "video" and clip.get("source_out") is not None:
            clip["source_out"] = clip["duration"]


def _shift_point_rows(rows, at: float, delta: float) -> None:
    if not rows or delta <= 0.02:
        return
    for row in rows:
        if not isinstance(row, dict) or row.get("start") is None:
            continue
        start = float(row.get("start") or 0)
        end = float(row.get("end") or 0)
        if end <= at:
            continue
        if start >= at:
            row["start"] = _r3(start + delta)
            row["end"] = _r3(end + delta)
        else:
            row["end"] = _r3(end + delta)


def _exchange_window(a: dict, b: dict) -> None:
    keys = ("start", "end", "duration", "narration_in", "narration_out")
    saved = {k: a.get(k) for k in keys}
    for k in keys:
        if k in b or k in saved:
            a[k] = b.get(k)
    for k in keys:
        b[k] = saved.get(k)


def _dev(words: list[str]) -> bool:
    return any(w and "\u0900" <= w[0] <= "\u097F" for w in words)


def _lang_ok(expected: list[str], heard: list[str]) -> bool:
    """English hearing is not proof about a Devanagari line, or the reverse."""
    return bool(heard) and _dev(expected) == _dev(heard)


def _same_line(a: list[str], b: list[str]) -> bool:
    return a == b or (len(a) >= 2 and set(a) == set(b))


def _rows(plan: dict, scenes: list[dict], vo_words: list | None, poem_words: list | None) -> list[dict]:
    poem_start = float(plan.get("poem_start_time") or 0)
    poem_end = float(plan.get("poem_end_time") or 0)
    by_screen = {str(s.get("screen")): s for s in scenes or []}
    rows = []
    for clip in plan.get("clips") or []:
        screen = str(clip.get("screen") or "")
        scene = by_screen.get(screen)
        if not scene:
            continue
        expected = _content(str(scene.get("voiceover_text") or scene.get("onscreen_text") or ""))
        if len(expected) < 2:
            continue
        a, b, in_poem = _window(clip, poem_start, poem_end)
        if b - a < 0.2:
            continue
        if in_poem:
            a, b = a - poem_start, b - poem_start
        heard = _heard_tokens((poem_words if in_poem else vo_words) or [], a, b)
        if heard and not _lang_ok(expected, heard):
            continue
        rows.append({
            "clip": clip,
            "screen": screen,
            "expected": expected,
            "heard": heard,
            "own": _cover(heard, expected),
            "text": str(scene.get("voiceover_text") or scene.get("onscreen_text") or ""),
        })
    return rows


def _bubble(row: dict, message: str, found: str) -> dict:
    clip = row["clip"]
    start = float(clip.get("start") or 0)
    return {
        "kind": "line_mismatch",
        "severity": "warning",
        "screen": row["screen"],
        "time": start,
        "end": float(clip.get("end") or start),
        "timecode": f"{fmt_short(start)}–{fmt_short(clip.get('end'))}",
        "message": f"{scene_label(row['screen'])} ({fmt_short(start)}): {message}",
        "expected": row["text"][:180],
        "found": found[:180],
        "source": "sync_native",
    }


def line_warnings(
    plan: dict,
    scenes: list[dict],
    vo_words: list | None,
    poem_words: list | None,
    moved_screens: list[str] | None = None,
) -> list[dict]:
    """Yellow bubbles for a line that is proven wrong and was not repaired.

    A card that matches its own line is silent. A line that was not heard is
    silent, except a card this pass moved onto a window that still is not its line.
    """
    rows = _rows(plan, scenes, vo_words, poem_words)
    moved = set(moved_screens or [])
    issues = []
    used: set[str] = set()
    for row in rows:
        if not row["heard"] or row["own"] >= 0.55:
            continue
        best = None
        best_score = 0.0
        for other in rows:
            if other["screen"] == row["screen"] or _same_line(row["expected"], other["expected"]):
                continue
            score = _cover(row["heard"], other["expected"])
            if score > best_score:
                best, best_score = other, score
        # Own line barely heard, and another card's line clearly fills this window.
        if best is None or best_score < 0.60 or best_score < row["own"] + 0.25:
            continue
        heard = " ".join(row["heard"][:8])
        issues.append(_bubble(
            row,
            f'narration here is {scene_label(best["screen"])}\'s line ("{heard}"), not this card.',
            heard,
        ))
        used.add(row["screen"])
    for row in rows:
        if row["screen"] in used or row["screen"] not in moved or row["own"] >= 0.40:
            continue
        issues.append(_bubble(row, "this card was moved, and its own line was not heard here.", ""))
    return issues


def _file_duration(clip: dict, dur_by_id: dict[str, float]) -> float | None:
    found = dur_by_id.get(str(clip.get("media_id") or ""))
    if found:
        return found
    try:
        src_out = float(clip.get("source_out"))
        src_in = float(clip.get("source_in") or 0)
    except (TypeError, ValueError):
        return None
    if src_out > src_in + 0.2 and clip.get("fit") != "trim":
        return src_out - src_in
    return None


def fit_videos_to_spoken_window(plan: dict, media: list) -> int:
    """Play each video across its lyric or narration window. No frozen last frame.

    A take a little shorter than the line is slowed down. A take a little longer
    is sped up. Anything longer than that is sped up slightly and the extra
    frames are dropped at the cut, still moving.
    """
    dur_by_id: dict[str, float] = {}
    for m in media or []:
        if isinstance(m, dict) and m.get("id") and m.get("duration"):
            try:
                d = float(m["duration"])
            except (TypeError, ValueError):
                continue
            if d > 0.2:
                dur_by_id[str(m["id"])] = d
    n = 0
    for c in plan.get("clips") or []:
        if c.get("kind") != "video":
            continue
        slot = float(c.get("end") or 0) - float(c.get("start") or 0)
        try:
            ni = float(c.get("narration_in"))
            no = float(c.get("narration_out"))
        except (TypeError, ValueError):
            ni = no = 0.0
        # A pause after the line is not part of the take. Time the video to the words.
        if no > ni + 0.05 and (no - ni) + 0.20 < slot:
            slot = no - ni
        file_dur = _file_duration(c, dur_by_id)
        if not file_dur or slot < 0.25:
            continue
        ratio = file_dur / slot
        if ratio > FAST_LIMIT:
            c["fit"] = "stretch"
            c["source_in"] = 0.0
            c["source_out"] = _r3(slot * FAST_LIMIT)
        elif ratio >= SLOW_FLOOR:
            c["fit"] = "stretch"
            c["source_in"] = 0.0
            c["source_out"] = _r3(file_dur)
        else:
            continue
        n += 1
    if n:
        note = plan.get("qa_summary") or ""
        extra = f"{n} video{'s' if n != 1 else ''} timed to the spoken line"
        plan["qa_summary"] = f"{note} · {extra}".strip(" ·")
    return n
