"""Check the published updates feed and sync code updates across Windows & Mac PCs.

Normal editing does not need the network. The check runs once after open (and
optionally on launcher startup via ``python -m dgs_studio.core.update_check --auto-sync``),
fails quietly offline, and can apply code updates in-place from GitHub.
"""

from __future__ import annotations

import argparse
import io
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

from .. import __version__, paths

DEFAULT_CODE_ZIP_URL = (
    "https://raw.githubusercontent.com/Kohindgs/dgs-auto-editor/main/public/dgs-desktop-code.zip"
)

_FEED_URLS = [
    os.environ.get("DGS_UPDATE_URL") or "",
    "https://raw.githubusercontent.com/Kohindgs/dgs-auto-editor/main/public/updates.json",
    "https://raw.githubusercontent.com/Kohindgs/dgs-auto-editor/main/frontend/public/updates.json",
    "https://editor.dgeniussolutions.com/updates.json",
    "https://editor.dgeniussolutions.com/api/app/version",
]

_VERSION_RE = re.compile(
    r"(\d+)\.(\d+)\.(\d+)(?:-(?:beta|native)\.(\d+))?",
    re.I,
)


def version_parts(value: str) -> tuple[int, int, int, int, int]:
    """Sort key: major, minor, patch, channel (beta=0, native=1, final=2), build."""
    match = _VERSION_RE.search(str(value or ""))
    if not match:
        return (0, 0, 0, 0, 0)
    major, minor, patch = (int(match.group(1)), int(match.group(2)), int(match.group(3)))
    raw = str(value or "").lower()
    build = int(match.group(4) or 0)
    if "-beta." in raw:
        channel = 0
        build = int(match.group(4) or 0)
    elif "-native." in raw:
        channel = 1
        build = int(match.group(4) or 0)
    else:
        channel = 2
        build = 1000
    return (major, minor, patch, channel, build)


def version_compare(a: str, b: str) -> int:
    left, right = version_parts(a), version_parts(b)
    if left < right:
        return -1
    if left > right:
        return 1
    return 0


def local_feed() -> dict:
    path = paths.updates_feed()
    if path and path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("version"):
                return data
        except (OSError, ValueError):
            pass
    return {
        "version": __version__,
        "released": "",
        "notes": [],
        "downloads": {},
        "history": [],
    }


def _with_cache_bust(url: str) -> str:
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}t={int(time.time())}"


def _fetch_json(url: str, timeout: float = 8.0) -> dict:
    req = urllib.request.Request(
        _with_cache_bust(url),
        headers={
            "User-Agent": "DGS-Auto-Editor",
            "Accept": "application/json",
            "Cache-Control": "no-cache",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 — fixed HTTPS feed URLs
        body = resp.read().decode("utf-8", errors="replace")
    text = body.lstrip()
    if not text.startswith("{"):
        raise ValueError("update feed returned HTML or empty data (file not published yet)")
    data = json.loads(body)
    if not isinstance(data, dict):
        raise ValueError("update feed is not an object")
    return data


def _report_from_payload(payload: dict, *, current_ver: str, local: dict, feed_error: str = "") -> dict:
    """Accept either raw ``updates.json`` or ``/api/app/version`` shape."""
    platform = "darwin" if sys.platform == "darwin" else "win"
    downloads = payload.get("downloads") if isinstance(payload.get("downloads"), dict) else {}
    if not downloads and isinstance(local.get("downloads"), dict):
        downloads = local["downloads"]
    latest_ver = str(payload.get("latest") or payload.get("version") or current_ver)
    if "updateAvailable" in payload and payload.get("latest"):
        available = bool(payload.get("updateAvailable"))
        if version_compare(latest_ver, current_ver) > 0:
            available = True
        elif version_compare(latest_ver, current_ver) <= 0:
            available = False
    else:
        available = bool(latest_ver and version_compare(latest_ver, current_ver) > 0)
    code_zip = str(
        payload.get("code_zip")
        or downloads.get("code_zip")
        or DEFAULT_CODE_ZIP_URL
    )
    return {
        "current": current_ver,
        "latest": latest_ver,
        "released": str(payload.get("latestReleased") or payload.get("released") or ""),
        "updateAvailable": available,
        "notes": list(payload.get("notes") or []),
        "history": list(payload.get("history") or local.get("history") or []),
        "downloads": downloads,
        "codeZipUrl": code_zip,
        "downloadUrl": str(
            downloads.get("mac" if platform == "darwin" else "win")
            or downloads.get("win")
            or ""
        ),
        "platform": platform,
        "feedError": feed_error,
        "localPath": str(paths.updates_feed() or ""),
    }


def check_remote(*, current: str | None = None, timeout: float = 8.0) -> dict:
    """Compare this program to the published feeds and pick the newest version."""
    local = local_feed()
    current_ver = str(current or __version__ or local.get("version") or "")
    best_remote: dict | None = None
    best_ver = ""
    feed_error = ""
    for url in _FEED_URLS:
        if not url:
            continue
        try:
            body = _fetch_json(url, timeout=timeout)
            cand_ver = str(body.get("latest") or body.get("version") or "")
            if cand_ver:
                if best_remote is None or version_compare(cand_ver, best_ver) > 0:
                    best_remote = body
                    best_ver = cand_ver
                # If the primary GitHub feed succeeded and is newer or equal, no need to wait on slow fallbacks
                if "raw.githubusercontent.com" in url and best_remote is not None:
                    break
        except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, ValueError, OSError) as exc:
            feed_error = str(exc) or feed_error
    if best_remote is None:
        return _report_from_payload(local, current_ver=current_ver, local=local, feed_error=feed_error)
    return _report_from_payload(best_remote, current_ver=current_ver, local=local, feed_error="")


def download_url_for(report: dict) -> str:
    return str((report or {}).get("downloadUrl") or "")


def apply_code_update(
    report: dict | None = None,
    *,
    root_dir: Path | None = None,
    timeout: float = 45.0,
) -> dict:
    """Download ``dgs-desktop-code.zip`` and extract updated code files into ``root_dir``."""
    target_root = Path(root_dir or paths.ROOT).resolve()
    rep = report or check_remote(timeout=10.0)
    zip_url = str(rep.get("codeZipUrl") or DEFAULT_CODE_ZIP_URL)
    req = urllib.request.Request(
        _with_cache_bust(zip_url),
        headers={
            "User-Agent": "DGS-Auto-Editor",
            "Cache-Control": "no-cache",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
        raw_bytes = resp.read()
    buf = io.BytesIO(raw_bytes)
    if not zipfile.is_zipfile(buf):
        raise ValueError("Downloaded update package is not a valid ZIP archive")
    buf.seek(0)
    updated_count = 0
    with zipfile.ZipFile(buf, "r") as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            rel = info.filename.replace("\\", "/").lstrip("/")
            if not rel or ".." in rel.split("/"):
                continue
            dest = (target_root / rel).resolve()
            if not str(dest).startswith(str(target_root)):
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            data = zf.read(info.filename)
            dest.write_bytes(data)
            if sys.platform == "darwin" and dest.suffix in (".command", ".sh"):
                try:
                    dest.chmod(0o755)
                except OSError:
                    pass
            updated_count += 1
    return {
        "ok": True,
        "version": str(rep.get("latest") or ""),
        "files_updated": updated_count,
        "root": str(target_root),
    }


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="dgs_studio.core.update_check")
    ap.add_argument("--auto-sync", action="store_true", help="Check and apply update if a newer version is published")
    ap.add_argument("--force-sync", action="store_true", help="Download and apply the latest code zip regardless of version")
    ap.add_argument("--timeout", type=float, default=6.0)
    args = ap.parse_args(argv)

    try:
        rep = check_remote(timeout=args.timeout)
        if args.force_sync or rep.get("updateAvailable"):
            latest = rep.get("latest") or "latest"
            current = rep.get("current") or __version__
            print(f"[DGS Sync] Updating DGS Auto Editor ({current} -> {latest})...", flush=True)
            res = apply_code_update(rep, timeout=max(30.0, args.timeout * 5))
            print(f"[DGS Sync] Updated {res.get('files_updated', 0)} files to {res.get('version') or latest}.", flush=True)
    except Exception as exc:  # noqa: BLE001
        # Never block editor launch if offline
        print(f"[DGS Sync] Offline or skipped ({exc}).", file=sys.stderr, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
