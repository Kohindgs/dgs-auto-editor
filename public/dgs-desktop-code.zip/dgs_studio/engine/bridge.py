"""Talk to the chapter engine (the website's own ``server.js`` and timeline logic).

The engine is a hidden Node process started from ``native_editor/engine/engine_host.js``.
It has no network port and no address: ``server.js`` is bound to a private named
pipe inside that process, and this module speaks to the host over stdin/stdout,
one JSON line per message. Auto-align, export, Filmora files and the server QA
therefore follow exactly the same rules as the live editor.
"""

from __future__ import annotations

import json
import os
import subprocess
import threading
import time
from concurrent.futures import Future
from pathlib import Path

from PySide6.QtCore import QObject, Signal

from .. import paths

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


class EngineError(RuntimeError):
    pass


class Engine:
    """One engine process per data folder (``<data>/projects/<id>``)."""

    _instances: dict[str, "Engine"] = {}
    _lock = threading.Lock()

    def __init__(self, data_dir: Path) -> None:
        self.data_dir = data_dir
        self.proc: subprocess.Popen | None = None
        self._pending: dict[int, Future] = {}
        self._next = 1
        self._wlock = threading.Lock()
        self._ready = threading.Event()
        self._fatal = ""

    @classmethod
    def for_project(cls, project_root: Path) -> "Engine":
        return cls.for_data(project_root.parent.parent)

    @classmethod
    def for_data(cls, data_dir: Path) -> "Engine":
        key = str(data_dir.resolve()).lower()
        with cls._lock:
            eng = cls._instances.get(key)
            if eng is None or not eng.alive:
                eng = cls(data_dir)
                cls._instances[key] = eng
        return eng

    @classmethod
    def shutdown_all(cls) -> None:
        with cls._lock:
            engines = list(cls._instances.values())
            cls._instances.clear()
        for e in engines:
            e.stop()

    @property
    def alive(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def start(self, timeout: float = 60.0) -> None:
        if self.alive and self._ready.is_set():
            return
        node, host = paths.node_exe(), paths.engine_host()
        if not node or not host:
            raise EngineError("The chapter engine is not bundled with this build (node / engine_host.js missing)")
        env = dict(os.environ)
        env.update({
            "DGS_DATA_DIR": str(self.data_dir),
            "DGS_REQUIRE_MASTER_SCRIPT": "1",
            "DGS_DESKTOP": "1",
            "UV_THREADPOOL_SIZE": "4",
            "DGS_PYTHON": str(paths.python_exe()),
            **({"FFMPEG_BIN": str(paths.ffmpeg_exe())} if paths.ffmpeg_exe() else {}),
            **({"FFPROBE_BIN": str(paths.ffprobe_exe())} if paths.ffprobe_exe() else {}),
        })
        srv = paths.server_js()
        if srv:
            env["DGS_SERVER_JS"] = str(srv)
        logic = paths.engine_logic_dir()
        if logic:
            env["DGS_LOGIC_DIR"] = str(logic)
        log_dir = paths.data_dir() / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        self._log = open(log_dir / "engine.log", "a", encoding="utf-8", errors="replace")
        self._log.write(f"\n--- engine start {time.strftime('%Y-%m-%d %H:%M:%S')} data={self.data_dir}\n")
        self._log.flush()
        self._ready.clear()
        self.proc = subprocess.Popen(
            [str(node), str(host)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=self._log,
            env=env,
            cwd=str(Path(srv).parent if srv else host.parent),
            creationflags=_NO_WINDOW,
        )
        threading.Thread(target=self._reader, daemon=True).start()
        if not self._ready.wait(timeout):
            raise EngineError(self._fatal or "The chapter engine did not start (see dgs_data/logs/engine.log)")
        if self._fatal:
            raise EngineError(self._fatal)

    def _reader(self) -> None:
        assert self.proc and self.proc.stdout
        for raw in self.proc.stdout:
            try:
                msg = json.loads(raw.decode("utf-8", errors="replace"))
            except ValueError:
                continue
            if msg.get("event") == "ready":
                self._ready.set()
                continue
            if msg.get("event") == "fatal":
                self._fatal = str(msg.get("error") or "engine failed to start")
                self._ready.set()
                continue
            fut = self._pending.pop(int(msg.get("id") or 0), None)
            if fut and not fut.done():
                fut.set_result(msg)
        err = EngineError("The chapter engine stopped (see dgs_data/logs/engine.log)")
        for fut in list(self._pending.values()):
            if not fut.done():
                fut.set_exception(err)
        self._pending.clear()
        self._ready.set()

    def _send(self, msg: dict) -> Future:
        self.start()
        fut: Future = Future()
        with self._wlock:
            mid = self._next
            self._next += 1
            self._pending[mid] = fut
            data = (json.dumps({**msg, "id": mid}, ensure_ascii=False) + "\n").encode("utf-8")
            assert self.proc and self.proc.stdin
            self.proc.stdin.write(data)
            self.proc.stdin.flush()
        return fut

    def http(self, method: str, path: str, body=None, timeout: float = 1800.0, save_to: str | None = None) -> dict:
        msg = {"op": "http", "method": method, "path": path, "timeout": int(timeout * 1000)}
        if body is not None:
            msg["body"] = body
        if save_to:
            msg["save_to"] = save_to
        r = self._send(msg).result(timeout + 30)
        if not r.get("ok"):
            raise EngineError(str(r.get("error") or "engine request failed"))
        status = int(r.get("status") or 0)
        if status >= 400:
            j = r.get("json") if isinstance(r.get("json"), dict) else {}
            raise EngineError(str(j.get("detail") or j.get("error") or r.get("text") or f"HTTP {status}"))
        return r

    def json(self, method: str, path: str, body=None, timeout: float = 1800.0):
        return self.http(method, path, body, timeout).get("json")

    def fn(self, module: str, name: str, *args, timeout: float = 600.0):
        r = self._send({"op": "fn", "module": module, "name": name, "args": list(args)}).result(timeout)
        if not r.get("ok"):
            raise EngineError(str(r.get("error") or f"{module}.{name} failed"))
        return r.get("result")

    def stop(self) -> None:
        p = self.proc
        if not p:
            return
        try:
            if p.poll() is None and p.stdin:
                p.stdin.write(b'{"id":0,"op":"quit"}\n')
                p.stdin.flush()
                p.wait(3)
        except (OSError, subprocess.TimeoutExpired, ValueError):
            pass
        if p.poll() is None:
            p.kill()
        self.proc = None


class EngineJob(QObject):
    """Run one engine call on a worker thread and report back on the UI thread."""

    done = Signal(object)
    failed = Signal(str)
    progress = Signal(str)

    def __init__(self, fn, parent=None) -> None:
        super().__init__(parent)
        self._fn = fn
        self._thread: threading.Thread | None = None

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def start(self) -> None:
        def run() -> None:
            try:
                self.done.emit(self._fn(self.progress.emit))
            except Exception as e:  # noqa: BLE001
                self.failed.emit(str(e))

        self._thread = threading.Thread(target=run, daemon=True)
        self._thread.start()
