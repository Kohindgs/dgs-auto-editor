"""Chapter jobs that run through the engine: new project, VO links, Filmora files, Auto-align.

Every step mirrors the web editor (``App.tsx``) so the timeline comes out the same.
The desktop window saves first, the engine works on the chapter folder, and the
window reloads the folder afterwards.
"""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Callable

import numpy as np

from .. import paths
from ..core.project_store import IMAGE_EXT, VIDEO_EXT, Project, _read
from .bridge import Engine, EngineError

Progress = Callable[[str], None]

_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
_POEM_SECTION = re.compile(r"\bpoem\b", re.I)
_NOT_POEM = re.compile(r"\b(instruction|question|answer|heading|activity|summary|title|prompt)\b", re.I)


class AlignStopped(RuntimeError):
    """Auto-align refused to cut on estimates; the message says what to link."""


def fmt(t: float) -> str:
    t = max(0.0, float(t or 0))
    m, s = divmod(t, 60)
    return f"{int(m)}:{s:05.2f}"


# Audio --------------------------------------------------------------------------


def analyze_audio(path: Path) -> tuple[float, list[list[float]]]:
    """Duration and silences, the same recipe as ``analyzeAudioBrowser``.

    First channel, 20 ms RMS windows, below -34 dB for at least 0.18 s.
    """
    ff = paths.ffmpeg_exe()
    if not ff:
        raise EngineError("ffmpeg is not bundled with this build")
    sr = 16000
    proc = subprocess.run(
        [str(ff), "-v", "error", "-i", str(path), "-af", "pan=mono|c0=c0", "-ar", str(sr), "-f", "f32le", "-"],
        capture_output=True,
        creationflags=_NO_WINDOW,
        timeout=600,
    )
    if proc.returncode != 0 or not proc.stdout:
        raise EngineError(f"Could not decode {path.name}: {proc.stderr.decode('utf-8', 'replace')[-300:]}")
    chan = np.frombuffer(proc.stdout, dtype=np.float32)
    duration = round(len(chan) / sr, 3)
    win = int(sr * 0.02)
    n = len(chan) // win
    rms = np.sqrt(np.mean(chan[: n * win].reshape(n, win).astype(np.float64) ** 2, axis=1)) if n else np.zeros(0)
    if len(chan) > n * win:
        tail = chan[n * win :].astype(np.float64)
        rms = np.append(rms, np.sqrt(np.mean(tail**2)))
    thresh = 10 ** (-34 / 20)
    silences: list[list[float]] = []
    sil_start: float | None = None
    for i, v in enumerate(rms):
        t = i * win / sr
        if v < thresh:
            if sil_start is None:
                sil_start = t
        elif sil_start is not None:
            if t - sil_start >= 0.18:
                silences.append([round(sil_start, 3), round(t, 3)])
            sil_start = None
    if sil_start is not None and duration - sil_start >= 0.18:
        silences.append([round(sil_start, 3), duration])
    return duration, silences


# Registering local files with the engine --------------------------------------


def register_vo(eng: Engine, pid: str, slot: int, path: Path) -> dict:
    duration, silences = analyze_audio(path)
    return eng.json(
        "POST",
        f"/api/projects/{pid}/voiceover-meta?slot={int(slot)}",
        {"slot": int(slot), "filename": path.name, "duration": duration, "silences": silences, "local_path": str(path)},
    )


def register_poem(eng: Engine, pid: str, path: Path, slot: int = 1) -> dict:
    duration, _ = analyze_audio(path)
    return eng.json(
        "POST",
        f"/api/projects/{pid}/poem-voiceover-meta",
        {"slot": int(slot), "filename": path.name, "duration": duration, "local_path": str(path)},
    )


def remove_poem(eng: Engine, pid: str, slot: int) -> dict:
    return eng.json("DELETE", f"/api/projects/{pid}/poem-voiceover/{int(slot)}")


def remove_vo(eng: Engine, pid: str, slot: int) -> dict:
    return eng.json("DELETE", f"/api/projects/{pid}/voiceover/{int(slot)}")


def _video_duration(path: str) -> float | None:
    probe = paths.ffprobe_exe()
    if not probe:
        return None
    try:
        out = subprocess.run(
            [str(probe), "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", path],
            capture_output=True,
            text=True,
            creationflags=_NO_WINDOW,
            timeout=60,
        ).stdout.strip()
        return round(float(out), 3)
    except (OSError, ValueError, subprocess.SubprocessError):
        return None


def sync_links(eng: Engine, proj: Project, progress: Progress | None = None) -> list[str]:
    """Tell the engine where the files linked on this PC are.

    ``native_links.json`` is desktop-only; the engine reads ``media.json`` and
    ``voiceover.json``. Items are matched by file name, so media ids stay the same.
    """
    pid = proj.pid
    notes: list[str] = []
    media = proj.media_by_id
    known = {str(m.get("filename") or "").lower(): m for m in proj.media if isinstance(m, dict)}
    items: dict[str, dict[str, dict]] = {"images": {}, "videos": {}}

    def add(path: str) -> None:
        p = Path(path)
        ext = p.suffix.lower()
        kind = "images" if ext in IMAGE_EXT else "videos" if ext in VIDEO_EXT else ""
        if not kind:
            return
        cur = known.get(p.name.lower())
        if cur and Path(str(cur.get("path") or "")) == p:
            return
        item = {"filename": p.name, "local_path": str(p), "folder": kind, "size": p.stat().st_size if p.exists() else 0}
        if kind == "videos":
            item["duration"] = _video_duration(str(p))
        items[kind][p.name.lower()] = item

    for mid, path in (proj.links.get("media") or {}).items():
        if mid in media and Path(str(path)).is_file():
            add(str(path))
    for key in ("images", "videos"):
        for path in (proj.links.get(key) or {}).values():
            if Path(str(path)).is_file():
                add(str(path))
    for kind, found in items.items():
        if found:
            if progress:
                progress(f"Registering {len(found)} linked {kind} with the engine…")
            eng.json(
                "POST",
                f"/api/projects/{pid}/media-meta",
                {"kind": kind, "items": list(found.values()), "replace_kind": False},
            )
            notes.append(f"{len(found)} {kind}")

    slots = {int(s.get("slot") or 0): s for s in proj.slots}
    for key, path in (proj.links.get("vo_slots") or {}).items():
        n = int(key)
        cur = slots.get(n) or {}
        if Path(str(path)).is_file() and Path(str(cur.get("path") or "")) != Path(path):
            if progress:
                progress(f"Reading VO {n} ({Path(path).name})…")
            register_vo(eng, pid, n, Path(path))
            notes.append(f"VO {n}")
    one = proj.links.get("voiceover")
    if one and not proj.links.get("vo_slots") and Path(str(one)).is_file():
        cur = slots.get(1) or proj.voiceover
        if Path(str(cur.get("path") or "")) != Path(one):
            register_vo(eng, pid, 1, Path(one))
            notes.append("VO 1")
    poem = proj.links.get("poem")
    if poem and Path(str(poem)).is_file() and Path(str(proj.poem_vo.get("path") or "")) != Path(poem):
        if progress:
            progress(f"Reading Poem VO ({Path(poem).name})…")
        register_poem(eng, pid, Path(poem))
        notes.append("Poem VO")
    logo = proj.links.get("logo")
    if logo and Path(str(logo)).is_file() and Path(str(proj.logo.get("path") or "")) != Path(logo):
        eng.json(
            "POST",
            f"/api/projects/{pid}/logo-meta",
            {"filename": Path(logo).name, "local_path": str(logo), "transform": proj.logo_transform},
        )
        notes.append("logo")
    return notes


# Projects -----------------------------------------------------------------------


def new_project(eng: Engine) -> str:
    return str(eng.json("POST", "/api/projects")["project_id"])


def open_project_file(eng: Engine, path: Path) -> str:
    """Open a Filmora ``.wfp`` / ``.wfpbundle`` (or a DGS project file) from disk."""
    r = eng.json("POST", "/api/projects/open-path", {"path": str(path)}, timeout=1800)
    pid = str((r or {}).get("project_id") or "")
    if not pid:
        raise EngineError(f"{path.name} did not open as a project")
    return pid


# Auto-align -------------------------------------------------------------------


def _is_poem_scene(s: dict) -> bool:
    sec = str(s.get("section") or "")
    return bool(s.get("is_poem")) or bool(_POEM_SECTION.search(sec) and not _NOT_POEM.search(sec))


def _poem_lyric_lines(scenes: list[dict]) -> list[str]:
    lines = []
    for scene in scenes:
        if not _is_poem_scene(scene):
            continue
        raw = str(scene.get("voiceover_raw") or "").lower()
        sec = str(scene.get("section") or "").lower()
        text = str(scene.get("voiceover_text") or "").strip()
        if not text or "instrumental" in raw or "instrumental" in sec or "song intro" in sec:
            continue
        lines.append(text)
    return lines


def _poem_align_audio(proj: Project) -> str:
    """One poem file, or poem 1…10 joined in order with a 0.5 s gap so the lyric can lock."""
    slots = [s for s in proj.poem_slots() if proj.poem_slot_path(int(s.get("slot") or 1))]
    if len(slots) <= 1:
        return proj.poem_path()
    ffmpeg = paths.ffmpeg_exe()
    if not ffmpeg:
        return proj.poem_slot_path(int(slots[0].get("slot") or 1))
    out = proj.root / "meta" / "_poem_merged.wav"
    cmd = [str(ffmpeg), "-y"]
    for sl in slots:
        cmd += ["-i", proj.poem_slot_path(int(sl.get("slot") or 1))]
    filters = []
    for i in range(len(slots)):
        if i < len(slots) - 1:
            filters.append(f"[{i}:a]apad=pad_dur=0.5[a{i}]")
        else:
            filters.append(f"[{i}:a]anull[a{i}]")
    labels = "".join(f"[a{i}]" for i in range(len(slots)))
    filters.append(f"{labels}concat=n={len(slots)}:v=0:a=1[out]")
    cmd += ["-filter_complex", ";".join(filters), "-map", "[out]", str(out)]
    try:
        subprocess.run(cmd, capture_output=True, timeout=600, creationflags=_NO_WINDOW)
    except (OSError, subprocess.TimeoutExpired):
        return proj.poem_slot_path(int(slots[0].get("slot") or 1))
    return str(out) if out.is_file() else proj.poem_path()


def _force_align_poem(proj: Project, progress: Progress) -> list[dict] | None:
    """Place the known Marathi lyric on the poem vocal. None means use the speech model."""
    audio = _poem_align_audio(proj)
    lines = _poem_lyric_lines(proj.scenes)
    if not audio or len(lines) < 4:
        return None
    worker = Path(__file__).resolve().parents[2] / "hostinger_deploy" / "poem_force_align.py"
    if not worker.is_file():
        return None
    work = proj.root / "meta"
    text_path = work / "_poem_lyric.txt"
    out_path = work / "_poem_aligned.json"
    text_path.write_text("\n".join(lines), encoding="utf-8")
    cmd = [sys.executable, str(worker), "--audio", audio, "--text", str(text_path), "--out", str(out_path)]
    progress("Lifting the poem vocal and placing the known lyric…")
    try:
        run = subprocess.run(
            cmd,
            capture_output=True,
            timeout=3600,
            creationflags=_NO_WINDOW,
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
    except subprocess.TimeoutExpired:
        progress("Poem lyric placement took too long. The song stays on the speech-model cut.")
        return None
    log = ((run.stdout or b"") + b"\n" + (run.stderr or b"")).decode("utf-8", errors="replace")
    for line in log.splitlines():
        if line.startswith("PROGRESS "):
            progress(line[9:].strip())
    if run.returncode != 0 or not out_path.is_file():
        err = next((ln[6:].strip() for ln in log.splitlines() if ln.startswith("ERROR ")), "")
        progress(err or "Poem lyric placement did not finish. The song stays on the speech-model cut.")
        return None
    try:
        payload = json.loads(out_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None
    words = _words(payload.get("words"))
    return words if len(words) >= 6 else None


def missing_audio(proj: Project) -> list[str]:
    missing = []
    # Prefer slots already registered, else the master-script Audio Manifest list.
    slot_rows = list(proj.slots)
    if not slot_rows:
        files = proj.script_meta.get("vo_files") if isinstance(proj.script_meta, dict) else None
        if isinstance(files, list):
            slot_rows = [f for f in files if isinstance(f, dict)]
    slots = [int(s.get("slot") or 1) for s in slot_rows] or [1]
    by_slot = {int(s.get("slot") or 1): s for s in slot_rows if isinstance(s, dict)}
    for n in slots:
        if not proj.slot_path(n):
            name = str((by_slot.get(n) or {}).get("filename") or "").strip()
            missing.append(f"VO {n}" + (f" ({name})" if name else ""))
    if any(_is_poem_scene(s) for s in proj.scenes):
        poem_slots = proj.poem_slots() or [{"slot": 1}]
        for sl in poem_slots:
            n = int(sl.get("slot") or 1)
            if not proj.poem_slot_path(n):
                missing.append(f"Poem {n}")
    return missing


def _words(raw) -> list[dict]:
    out = []
    for w in raw if isinstance(raw, list) else []:
        text = str(w.get("text") or w.get("word") or "").strip()
        try:
            start, end = float(w.get("start")), float(w.get("end"))
        except (TypeError, ValueError):
            continue
        if text:
            out.append({"text": text, "start": start, "end": end})
    return out


def _cover(words: list[dict], dur: float, frac: float, min_dur: float) -> tuple[float, bool]:
    max_t = max((float(w.get("end") or w.get("start") or 0) for w in words), default=0.0)
    return max_t, len(words) >= 6 and (dur <= min_dur or max_t >= dur * frac)


def _marathi_language(language: str) -> bool:
    return str(language or "").strip().lower() in ("mr", "hi", "marathi", "hindi")


def auto_align(eng: Engine, proj: Project, language: str, progress: Progress) -> dict:
    """Cut the chapter with the module selected for its language.

    English chapters are heard with the English module only. Marathi and Hindi
    chapters use the Marathi engine only. One module never hears the other language.

    Returns ``{"message": str}``; raises ``AlignStopped`` when it refuses to cut on estimates.
    """
    pid = proj.pid
    root = proj.root
    gap = missing_audio(proj)
    if gap:
        needs_poem = any(_is_poem_scene(s) for s in proj.scenes)
        raise AlignStopped(
            f"Waiting — link {', '.join(gap)} first, then Auto-align. Hearing starts only when all narration VOs"
            + (" and the Poem VO" if needs_poem else "")
            + " are linked so cuts lock together."
        )
    sync_links(eng, proj, progress)
    vo = _read(root / "meta" / "voiceover.json", {}) or {}
    poem_vo = _read(root / "meta" / "poem_voiceover.json", {}) or {}
    scenes = _read(root / "meta" / "script.json", []) or proj.scenes
    meta = _read(root / "meta" / "script_meta.json", {}) or {}
    # Filmora import with no real spoken lines: keep the imported clock immediately.
    # Do not spend minutes on Whisper — build would discard those words as filmora_keep.
    filmora_keep = bool(meta.get("imported_bundle")) and bool(scenes) and all(
        (not str(s.get("voiceover_text") or "").strip())
        or bool(re.match(r"^(scene\s*)?\d+$", str(s.get("voiceover_text") or "").strip(), re.I))
        for s in scenes
        if isinstance(s, dict)
    )
    if filmora_keep:
        progress("Filmora import — keeping picture times (no script lines to hear)…")
        plan = eng.json(
            "POST",
            f"/api/projects/{pid}/build",
            {"language": language, "force_realign": True, "require_heard_words": False},
            timeout=120,
        ) or {}
        plan.pop("scenes", None)
        if plan.get("align_engine") == "filmora_keep" or meta.get("imported_bundle"):
            if not plan.get("align_engine"):
                plan["align_engine"] = "filmora_keep"
            saved = eng.json("PUT", f"/api/projects/{pid}/timeline", plan) or {}
            for key in ("qa_issues", "qa_summary", "sync_report", "narration_segments", "srt_cues"):
                if saved.get(key) is not None:
                    plan[key] = saved[key]
            n = len(plan.get("clips") or [])
            return {
                "message": (
                    f"Filmora import kept · picture times and VO left on the imported clock "
                    f"· {n} scenes · no estimate cuts (add a master script to word-lock)"
                ),
                "plan": plan,
            }
    expect_vo = float(vo.get("duration") or 0)
    expect_poem = float(poem_vo.get("duration") or 0)
    poem_scenes = any(_is_poem_scene(s) for s in scenes)
    has_poem = bool(proj.poem_path() or poem_vo)
    marathi = _marathi_language(language)
    status = eng.json("GET", "/api/engine/status") or {}
    can_hear = bool(status.get("hear"))
    can_hear_mr = bool(status.get("hear_marathi"))

    def hear(kind: str, hear_lang: str) -> list[dict] | None:
        try:
            r = eng.json(
                "POST",
                f"/api/projects/{pid}/engine/hear",
                {"kind": kind, "language": hear_lang},
                timeout=3600,
            )
        except EngineError:
            return None
        words = _words((r or {}).get("words"))
        return words if len(words) >= 6 else None

    words = None
    poem_words = None
    poem_words_source = None
    must_hear_vo = False
    must_hear_poem = False
    if marathi:
        progress("Marathi chapter. The English hearer stays off.")
        if expect_poem > 1 and has_poem and poem_scenes:
            placed = _force_align_poem(proj, progress)
            if placed:
                poem_words = placed
                poem_words_source = "mms_fa"
                must_hear_poem = True
                progress(
                    f"Known lyric placed: {len(placed)} words, sung from {fmt(float(placed[0]['start']))} to {fmt(float(placed[-1]['end']))}."
                )
        if can_hear_mr:
            if expect_vo > 1:
                progress(f"Hearing narration with the Marathi engine ({fmt(expect_vo)})…")
                heard = hear("narration", "mr")
                if heard:
                    max_t, ok = _cover(heard, expect_vo, 0.82, 30)
                    if ok:
                        words = heard
                        must_hear_vo = True
                        progress(f"Marathi engine heard {len(heard)} narration words through {fmt(max_t)}.")
                    else:
                        raise AlignStopped(
                            f"STOPPED — the Marathi engine heard only part of the VO ({len(heard)} words through {fmt(max_t)} of {fmt(expect_vo)}). "
                            "Link both VO files, then Auto-align again. English hearing was not used."
                        )
                else:
                    raise AlignStopped(
                        "STOPPED — the Marathi engine returned no narration words. English hearing was not used."
                    )
            if expect_poem > 1 and has_poem and poem_scenes and not poem_words:
                progress("Hearing the Poem VO with the Marathi engine…")
                heard = hear("poem", "mr")
                if heard:
                    max_t, ok = _cover(heard, expect_poem, 0.55, 20)
                    if ok:
                        poem_words = heard
                        must_hear_poem = True
                        progress(f"Marathi engine heard {len(heard)} poem words through {fmt(max_t)}.")
                    else:
                        progress(
                            f"Marathi engine heard only {len(heard)} poem words through {fmt(max_t)}. "
                            "The song stays on the sheet. Narration still locks to the spoken words."
                        )
                else:
                    progress("Marathi engine did not hear the song. The song stays on the sheet. Narration still locks to the spoken words.")
        elif not poem_words:
            progress("Marathi speech model is not on this PC. Cuts follow Devanagari line length and the silence after each line.")
    else:
        must_hear_vo = expect_vo > 1
        must_hear_poem = can_hear and expect_poem > 1 and has_poem and poem_scenes
        if expect_vo > 1:
            progress(f"Hearing narration with the English module ({fmt(expect_vo)} of VO)…")
            heard = hear("narration", "en") if can_hear else None
            if heard:
                max_t, ok = _cover(heard, expect_vo, 0.82, 30)
                if ok:
                    words = heard
                    progress(f"English module heard {len(heard)} VO words through {fmt(max_t)}.")
                elif must_hear_vo:
                    raise AlignStopped(
                        f"STOPPED — the English module heard only part of the VO ({len(heard)} words through {fmt(max_t)} of {fmt(expect_vo)}). "
                        "Link both VO files, then Auto-align again."
                    )
        if must_hear_vo and not words:
            why = "the English hearer is not available in this build" if not can_hear else "the English module returned no words"
            raise AlignStopped(f"STOPPED — did not hear the VO ({why}). No estimate cuts will be applied.")
        if expect_poem > 1 and has_poem and poem_scenes:
            progress("Hearing Poem VO with the English module…")
            heard = hear("poem", "en") if can_hear else None
            if heard:
                max_t, ok = _cover(heard, expect_poem, 0.55, 20)
                if ok:
                    poem_words = heard
                    progress(f"English module heard {len(heard)} poem words through {fmt(max_t)}.")
                elif must_hear_poem:
                    raise AlignStopped(
                        f"STOPPED — the English module did not hear the Poem VO (heard {len(heard)} words through {fmt(max_t)} of {fmt(expect_poem)}). "
                        "Re-link Poem VO, then Auto-align again."
                    )
        if must_hear_poem and not poem_words:
            raise AlignStopped("STOPPED — did not hear Poem VO words. Re-link Poem VO, then Auto-align again. No estimate poem cuts will be applied.")

    progress("Align + Cut + Stretch…" if marathi and not words else "Align + Cut + Stretch to heard VO…")
    body = {
        "language": language,
        "use_ollama": True,
        "force_realign": True,
        "require_heard_words": must_hear_vo,
        "require_heard_poem": must_hear_poem,
    }
    if words is not None:
        body["words"] = words
    if poem_words is not None:
        body["poem_words"] = poem_words
    if poem_words_source:
        body["poem_words_source"] = poem_words_source
    plan = eng.json("POST", f"/api/projects/{pid}/build", body, timeout=3600) or {}
    if isinstance(plan.get("scenes"), list) and plan["scenes"]:
        scenes = plan["scenes"]
    plan.pop("scenes", None)

    # Filmora import with no spoken script: build already kept picture/VO clocks.
    # Do not run estimate stretch / repeat cuts — that was desyncing the chapter.
    if plan.get("align_engine") == "filmora_keep":
        saved = eng.json("PUT", f"/api/projects/{pid}/timeline", plan) or {}
        for key in ("qa_issues", "qa_summary", "sync_report", "narration_segments", "srt_cues"):
            if saved.get(key) is not None:
                plan[key] = saved[key]
        n = len(plan.get("clips") or [])
        return {
            "message": (
                f"Filmora import kept · picture times and VO left on the imported clock "
                f"· {n} scenes · no estimate cuts (add a master script to word-lock)"
            ),
            "plan": plan,
        }

    # Auto-align only retimes cuts; each scene keeps the picture it had.
    prev_by_screen = {str(c.get("screen")): c for c in proj.clips}
    clips = []
    for c in plan.get("clips") or []:
        prev = prev_by_screen.get(str(c.get("screen")))
        if prev and prev.get("media_id") and not str(c.get("screen") or "").startswith("missing_vo_"):
            c = {
                **c,
                "media_id": prev["media_id"],
                "media_path": prev.get("media_path") or c.get("media_path"),
                "filename": prev.get("filename") or c.get("filename"),
                "kind": prev.get("kind") or c.get("kind"),
                "fit": ("stretch" if prev.get("kind") == "video" else "hold") if c.get("fit") == "missing" else c.get("fit"),
            }
        clips.append(c)
    plan["clips"] = clips

    progress("Cutting & stretching images/videos to VO…")
    media = _read(root / "meta" / "media.json", []) or []
    stretched = eng.fn("stretchClipsToVo", "applyStretchAlignToPlan", plan, media)
    poem_args = eng.fn("syncVerify", "poemSyncArgs", stretched, scenes) or {}
    sync = eng.fn(
        "syncVerify",
        "verifySync",
        stretched.get("clips") or [],
        {"repair": False, "voDuration": float(vo.get("duration") or (plan.get("sync_report") or {}).get("vo_duration") or 0), **poem_args},
    )
    with_sync = {
        **stretched,
        "sync_report": sync,
        "qa_summary": sync.get("summary") or stretched.get("qa_summary") or plan.get("qa_summary") or "",
        "qa_issues": [q for q in (plan.get("qa_issues") or []) if q.get("kind") != "vo_sync"] + list(sync.get("issues") or []),
    }
    for keep in ("ignored_qa_keys",):
        if keep in proj.plan and keep not in with_sync:
            with_sync[keep] = proj.plan[keep]
    from ..core.scene_rules import fold_instrumental_pictures, fold_listen_sing_heading
    from ..core.sync_fit import (
        align_pictures_to_narration,
        close_overlapping_narration,
        ensure_poem_clock,
        extend_pictures_to_spoken_lines,
        fit_videos_to_spoken_window,
        line_warnings,
        repair_misplaced_lines,
        repair_script_order,
        retighten_adjacent_cuts,
        sync_narration_segments_from_clips,
    )

    scenes_for_fit = scenes if isinstance(scenes, list) else []
    moved, moved_screens = repair_misplaced_lines(with_sync, scenes_for_fit, words, poem_words)
    ordered_n, ordered_screens = repair_script_order(with_sync, scenes_for_fit, words, poem_words)
    if ordered_n:
        moved += ordered_n
        moved_screens = list(moved_screens) + list(ordered_screens)
    tight_n, tight_screens = retighten_adjacent_cuts(with_sync, scenes_for_fit, words)
    if tight_n:
        moved += tight_n
        moved_screens = list(moved_screens) + list(tight_screens)
    overlap_n = close_overlapping_narration(with_sync, scenes_for_fit)
    if overlap_n:
        moved += overlap_n
    snapped = align_pictures_to_narration(with_sync, scenes_for_fit)
    grown = extend_pictures_to_spoken_lines(with_sync, scenes_for_fit)
    timed = fit_videos_to_spoken_window(with_sync, media)
    sync_narration_segments_from_clips(with_sync)
    warnings = line_warnings(with_sync, scenes_for_fit, words, poem_words, moved_screens)
    # The engine turns a slowed video back into a frozen last frame on save.
    # Keeping this flag stops that. Auto-align still rebuilds the timeline.
    if moved or timed or grown or snapped:
        with_sync["manual_override"] = True
    repeat_note = ""
    if words:
        try:
            report = eng.fn("repeatVo", "narrationRepeatReport", words, scenes_for_fit, poem_words or []) or {}
        except EngineError as e:
            report = {}
            progress(f"Repeated-word check skipped ({e}).")
        from ..core.repeat_vo import (
            align_voice_pieces,
            apply_repeat_cuts,
            complete_words_at_cuts,
            drop_false_take_retakes,
            finish_cut_sentences,
            finish_words_on_screen,
            keep_opening_words,
            keep_words_whole,
            place_scene_words,
            cap_voice_pauses,
            close_break_gaps,
            ensure_voice_pieces,
            repair_vo_piece_sync,
            silence_unscripted,
            snap_vo_piece_heads,
        )
        from ..core.scene_rules import fit_question_answer_gaps

        groups = list(report.get("narration") or [])
        leaks = report.get("tags") or []
        if leaks:
            groups.append({"kind": "tag", "card": None, "keep": {"start": 0, "end": 0}, "drop": leaks})
        with_sync["heard_vo_words"] = words
        cut_n = apply_repeat_cuts(with_sync, groups, report.get("poem") or [])
        dropped = silence_unscripted(with_sync)
        ensure_voice_pieces(with_sync)
        retake_n = drop_false_take_retakes(with_sync)
        cut_n += retake_n
        qa_gaps = fit_question_answer_gaps(with_sync, scenes_for_fit, words)
        capped = cap_voice_pauses(with_sync, words)
        joined = close_break_gaps(with_sync)
        align_voice_pieces(with_sync)
        keep_words_whole(with_sync)
        finish_words_on_screen(with_sync)
        place_scene_words(with_sync)
        finished = complete_words_at_cuts(with_sync)
        sentences = finish_cut_sentences(with_sync)
        openings = keep_opening_words(with_sync)
        # Last: lock the voice lane to the picture/word clock after every cut.
        vo_sync_n = repair_vo_piece_sync(with_sync)
        snap_vo_piece_heads(with_sync)
        if cut_n or dropped or capped or qa_gaps or joined:
            progress("A line that is not in the script is removed. A cut does not leave a gap. A pause stays at 4 seconds. The poem is left as it is.")
            repeat_note = ""
            if cut_n:
                repeat_note += f" · {cut_n} repeated hearing{'s' if cut_n != 1 else ''} removed from the VO"
            if dropped:
                repeat_note += f" · {dropped} line{'s' if dropped != 1 else ''} not in the script removed from the VO"
            if joined:
                repeat_note += " · cut words leave no extra gap"
            if capped:
                repeat_note += " · pauses longer than 4 seconds closed"
            if qa_gaps:
                repeat_note += f" · {qa_gaps} question-and-answer pause{'s' if qa_gaps != 1 else ''} set to 4 seconds"
        if finished:
            repeat_note += f" · {finished} voice cut{'s' if finished != 1 else ''} kept until the word finished"
        if sentences:
            repeat_note += f" · {sentences} sentence{'s' if sentences != 1 else ''} played through to the end"
        if openings:
            repeat_note += f" · {openings} line{'s' if openings != 1 else ''} kept their first word"
        if vo_sync_n:
            repeat_note += " · voice lane put back on the picture clock"
    fold_listen_sing_heading(with_sync)
    fold_instrumental_pictures(with_sync)
    if words is not None:
        with_sync["heard_vo_words"] = words
    if poem_words is not None:
        with_sync["heard_poem_words"] = poem_words
    # Global last pass: poem chapters keep the song gap; non-poem chapters are untouched.
    # Also sets poem_lyric_start so Poem text waits for the first sung word.
    ensure_poem_clock(with_sync, scenes_for_fit)
    from ..core.sync_fit import set_poem_lyric_start

    set_poem_lyric_start(with_sync, scenes_for_fit, poem_words)
    sync_narration_segments_from_clips(with_sync)
    # Re-check after cut repairs — an early verifySync left a stale SYNC FAIL
    # (e.g. Scene 61) even when pictures already matched the VO.
    try:
        poem_args = eng.fn("syncVerify", "poemSyncArgs", with_sync, scenes_for_fit) or {}
        sync = eng.fn(
            "syncVerify",
            "verifySync",
            with_sync.get("clips") or [],
            {
                "repair": False,
                "voDuration": float(vo.get("duration") or (with_sync.get("sync_report") or {}).get("vo_duration") or 0),
                **poem_args,
            },
        )
        with_sync["sync_report"] = sync
        keep_qa = [
            q
            for q in (with_sync.get("qa_issues") or [])
            if isinstance(q, dict) and q.get("kind") != "vo_sync"
        ]
        with_sync["qa_issues"] = keep_qa + list(sync.get("issues") or [])
        note = sync.get("summary") or ""
        prev = str(with_sync.get("qa_summary") or "")
        # Prefer the fresh sync summary; keep trailing repair notes if present.
        extras = [
            bit.strip()
            for bit in prev.split("·")
            if bit.strip()
            and not bit.strip().startswith("SYNC ")
            and "spoken scenes locked" not in bit
        ]
        with_sync["qa_summary"] = " · ".join([note] + extras[:6]) if note else prev
    except EngineError as e:
        progress(f"Sync re-check skipped ({e}).")
    if words is not None:
        with_sync["heard_vo_words"] = words
    if poem_words is not None:
        with_sync["heard_poem_words"] = poem_words
    from ..core.deep_qa import save_heard_words

    save_heard_words(root, words, poem_words)
    with_sync["language"] = "mr" if marathi else "en"
    with_sync["language_choice"] = with_sync["language"]
    if not marathi and with_sync.get("align_engine") == "audio_word":
        with_sync["align_engine"] = "english_word"
    saved = eng.json("PUT", f"/api/projects/{pid}/timeline", with_sync) or {}
    for key in ("qa_issues", "qa_summary", "sync_report", "narration_segments", "srt_cues"):
        if saved.get(key) is not None:
            with_sync[key] = saved[key]
    _store_line_warnings(root, with_sync, warnings)

    if must_hear_vo and marathi and with_sync.get("align_engine") != "audio_word":
        raise AlignStopped("STOPPED — the Marathi engine heard the narration but the lines did not lock to those words. English hearing was not used.")
    # filmora_keep = imported Filmora bundle with no spoken script lines; picture
    # times stay on the imported clock (word-lock has nothing to match).
    if must_hear_vo and not marathi and with_sync.get("align_engine") not in ("english_word", "audio_word", "filmora_keep"):
        raise AlignStopped("STOPPED — the engine did not lock to heard VO words (refused estimate path). Re-link VO and retry Auto-align.")
    poem_engine = with_sync.get("poem_align_engine")
    if must_hear_poem and poem_engine not in ("poem_word", "poem_sheet"):
        raise AlignStopped(
            "STOPPED — the engine did not lock poem lyric cards to heard Poem VO words (refused estimate path). Re-link Poem VO and retry Auto-align."
        )
    clips = with_sync.get("clips") or []
    stretch_n = sum(1 for c in clips if c.get("fit") == "stretch")
    image_n = sum(1 for c in clips if c.get("kind") != "video" and c.get("narration_in") is not None)
    cue_n = len(with_sync.get("srt_cues") or [])
    msg = (
        "Align + Cut + Stretch done · "
        + ("Marathi engine" if marathi else "English module")
        + (" · heard narration" if words else "")
        + (
            " · poem follows the workbook clock"
            if poem_engine == "poem_sheet"
            else (" · poem lyric placed" if poem_words_source == "mms_fa" else (" · heard poem" if poem_words else ""))
        )
        + (" only (no estimates)" if must_hear_vo else "")
        + f" · {image_n} images aligned/held to VO · {stretch_n} videos stretched to VO · {cue_n} SRT cues aligned"
        + repeat_note
        + (f" · {len(warnings)} line{'s' if len(warnings) != 1 else ''} need a look" if warnings else "")
        + f" · {fmt(float(with_sync.get('total_duration') or 0))} · {sync.get('summary') or ''}"
    )
    return {"message": msg, "plan": with_sync}


def _store_line_warnings(root: Path, plan: dict, warnings: list[dict]) -> None:
    """The timeline save replaces QA with the engine list. Put these bubbles back on disk."""
    import json

    tl = root / "meta" / "timeline.json"
    if tl.is_file():
        data = json.loads(tl.read_text(encoding="utf-8"))
    else:
        data = plan
    issues = [q for q in (data.get("qa_issues") or []) if isinstance(q, dict) and q.get("kind") != "line_mismatch"]
    data["qa_issues"] = issues + list(warnings)
    if warnings:
        note = str(data.get("qa_summary") or "")
        extra = f"{len(warnings)} line{'s' if len(warnings) != 1 else ''} need a look"
        if extra not in note:
            data["qa_summary"] = f"{note} · {extra}".strip(" ·")
    if tl.is_file():
        tl.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    plan["qa_issues"] = data["qa_issues"]
    if data.get("qa_summary"):
        plan["qa_summary"] = data["qa_summary"]


def match_poem_videos_to_lyrics(plan: dict, media: list) -> dict:
    """Older name. Poem and narration videos now share ``fit_videos_to_spoken_window``."""
    from ..core.sync_fit import fit_videos_to_spoken_window

    fit_videos_to_spoken_window(plan, media)
    return plan


def _poll(eng: Engine, path: str, progress: Progress, timeout: float = 3600) -> dict:
    import time

    t0 = time.time()
    last = {}
    while time.time() - t0 < timeout:
        last = eng.json("GET", path) or {}
        progress(str(last.get("message") or last.get("status") or "Working…"))
        if not last.get("running"):
            return last
        time.sleep(1.2)
    raise EngineError("Timed out waiting for the engine")


def _free_path(dest: Path) -> Path:
    """Keep an existing download. The new file is the next numbered copy."""
    dest = Path(dest)
    if not dest.exists():
        return dest
    stem = re.sub(r" \(\d+\)$", "", dest.stem)
    for n in range(2, 1000):
        cand = dest.with_name(f"{stem} ({n}){dest.suffix}")
        if not cand.exists():
            return cand
    return dest


def export_media(eng: Engine, pid: str, title: str, fmt: str, dest: Path, progress: Progress, include_logo: bool = False, settings: dict | None = None) -> Path:
    fmt = fmt.lower().lstrip(".")
    if fmt in ("mp4", "mov", "mkv", "avi"):
        dest = _free_path(Path(dest))
    # Captions are a separate SRT. burn_subtitles stays false so words are never drawn onto the picture.
    # The logo is composited only when the chapter has it switched on.
    chosen = dict(settings or {})
    chosen["format"] = fmt
    chosen["include_logo"] = bool(include_logo) and bool(chosen.get("include_logo", include_logo))
    chosen["burn_subtitles"] = False
    chosen["export_srt_sidecar"] = False
    chosen.setdefault("resolution", "1920x1080")
    chosen.setdefault("fps", 30)
    settings = chosen
    eng.json("POST", f"/api/projects/{pid}/export", {"title": title, "settings": settings, "dest": str(dest)}, timeout=60)
    st = _poll_export(eng, f"/api/projects/{pid}/export/status", progress)
    if st.get("cancelled"):
        raise EngineError("Export cancelled")
    if st.get("error"):
        raise EngineError(str(st["error"]))
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    src = Path(str(st.get("path") or st.get("out_path") or ""))
    if src.is_file() and src.resolve() != dest.resolve():
        shutil.copy2(src, dest)
    if not dest.is_file():
        raise EngineError(st.get("message") or f"Export finished but the {fmt} file was not found")
    return dest


def cancel_export(eng: Engine, pid: str) -> None:
    eng.json("POST", f"/api/projects/{pid}/export/cancel", {}, timeout=30)


def _poll_export(eng: Engine, path: str, progress: Progress, timeout: float = 3600) -> dict:
    import time

    t0 = time.time()
    last = {}
    while time.time() - t0 < timeout:
        last = eng.json("GET", path) or {}
        pct = last.get("percent")
        msg = str(last.get("message") or last.get("status") or "Working…")
        progress(f"{pct if pct is not None else ''}|{msg}")
        if not last.get("running"):
            return last
        time.sleep(1.2)
    raise EngineError("Timed out waiting for the engine")


def export_srt(eng: Engine, pid: str, title: str, dest: Path) -> Path:
    r = eng.http("GET", f"/api/projects/{pid}/srt/download?title={title}")
    text = str(r.get("text") or "")
    cues = [ln for ln in text.splitlines() if ln.strip() and not ln.strip().isdigit() and "-->" not in ln]
    spoken = [ln for ln in cues if not re.match(r"^\d+\.(png|jpe?g|mp4|mov)$", ln.strip(), re.I)]
    if len(spoken) < 2:
        raise EngineError("No spoken lines to put in an SRT (the script is file names only, or the timeline has no VO text).")
    dest = Path(dest)
    dest.write_text(text, encoding="utf-8")
    return dest


def collect_filmora(eng: Engine, pid: str, title: str, mode: str, dest: Path, progress: Progress) -> Path:
    mode = "wfpbundle" if mode != "wfp" else "wfp"
    dest = _free_path(Path(dest))
    if mode == "wfp":
        progress("Building Filmora .wfp…")
        r = eng.json("POST", f"/api/projects/{pid}/save-wfp-to", {"title": title, "dest": str(dest)}, timeout=1800) or {}
        src = Path(str(r.get("saved_to") or r.get("path") or ""))
    else:
        eng.json("POST", f"/api/projects/{pid}/collect", {"title": title, "mode": "wfpbundle", "dest": str(dest)}, timeout=60)
        st = _poll_export(eng, f"/api/projects/{pid}/collect/status", progress, timeout=1800)
        if st.get("error"):
            raise EngineError(str(st["error"]))
        src = Path(str(st.get("bundle_path") or st.get("path") or ""))
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if src.is_file() and src.resolve() != dest.resolve():
        shutil.copy2(src, dest)
    if not dest.is_file():
        raise EngineError("The Filmora file was not written")
    return dest
