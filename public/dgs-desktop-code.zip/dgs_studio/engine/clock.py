"""The one playhead.

It is a wall clock, so a file that is slow to load cannot drag the picture
backward. Widgets that move with time listen to ``tick``. Tracks are not
rebuilt when it moves.
"""

from __future__ import annotations

import time

from PySide6.QtCore import QObject, QTimer, Signal


class PlayheadClock(QObject):
    tick = Signal(float)
    running_changed = Signal(bool)

    def __init__(self, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.duration = 0.0
        self.running = False
        self._held = 0.0
        self._origin_t = 0.0
        self._origin_wall = 0.0
        self._tail_until = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._on_timer)

    def position(self) -> float:
        if not self.running:
            return self._held
        t = self._origin_t + (time.perf_counter() - self._origin_wall)
        return min(t, self.duration) if self.duration > 0 else t

    def set_duration(self, d: float) -> None:
        self.duration = max(0.0, float(d or 0))

    def play(self) -> None:
        if self.running:
            return
        t = self._held
        if self.duration > 0 and t >= self.duration - 0.05:
            t = 0.0
        self._origin_t = t
        self._origin_wall = time.perf_counter()
        self.running = True
        self._tail_until = 0.0
        self._timer.start()
        self.running_changed.emit(True)
        self.tick.emit(t)

    def at_end(self) -> bool:
        return self.running and self.duration > 0 and self.position() >= self.duration - 0.001

    def finish(self) -> None:
        """Stop on the last frame once the voice has said the closing words."""
        if not self.running:
            return
        self._held = self.duration if self.duration > 0 else self.position()
        self.running = False
        self._tail_until = 0.0
        self._timer.stop()
        self.running_changed.emit(False)
        self.tick.emit(self._held)

    def pause(self) -> None:
        if not self.running:
            return
        self._held = self.position()
        self.running = False
        self._tail_until = 0.0
        self._timer.stop()
        self.running_changed.emit(False)
        self.tick.emit(self._held)

    def toggle(self) -> None:
        if self.running:
            self.pause()
        else:
            self.play()

    def seek(self, t: float) -> None:
        t = max(0.0, float(t))
        if self.duration > 0:
            t = min(t, self.duration)
        self._held = t
        if self.running:
            self._origin_t = t
            self._origin_wall = time.perf_counter()
        self.tick.emit(t)

    def _on_timer(self) -> None:
        t = self.position()
        if self.duration > 0 and t >= self.duration - 0.001:
            # Stay on the last frame for a short while. Stopping here used to
            # cut the voice off, so the closing line never played.
            self._held = self.duration
            self._origin_t = self.duration
            self._origin_wall = time.perf_counter()
            if self._tail_until <= 0:
                self._tail_until = time.perf_counter() + 1.5
            self.tick.emit(self.duration)
            if time.perf_counter() >= self._tail_until:
                self.finish()
            return
        self._tail_until = 0.0
        self.tick.emit(t)
