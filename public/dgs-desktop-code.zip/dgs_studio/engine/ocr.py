"""Read the text printed on every project picture with the bundled Tesseract.

Each picture is read twice (sparse text ``--psm 11`` and full page ``--psm 3``)
and the two readings are joined: psm 11 finds table cells and scattered labels,
psm 3 keeps Devanagari lines whole. Marathi chapters use ``mar+eng``.

Results are cached in ``meta/native_ocr.json`` (same file and layout as
``hostinger_deploy/nativeEngine.js``), keyed by media id and file time.
"""

from __future__ import annotations

import json
import os
import subprocess
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6.QtCore import QObject, Signal

from .. import paths

CACHE_VERSION = 2
_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def ocr_language(indic: bool) -> str:
    d = paths.tessdata_dir()
    if indic and d and (d / "mar.traineddata").exists():
        return "mar+eng"
    return "eng"


def read_image(path: str, lang: str) -> str:
    exe = paths.tesseract_exe()
    if not exe:
        raise FileNotFoundError("Tesseract is not bundled with this build")
    d = paths.tessdata_dir()
    env = dict(os.environ, OMP_THREAD_LIMIT="1")
    parts = []
    for psm in ("11", "3"):
        args = [str(exe), path, "stdout", "-l", lang, "--psm", psm]
        if d:
            args[1:1] = ["--tessdata-dir", str(d)]
        try:
            out = subprocess.run(args, capture_output=True, timeout=90, env=env, creationflags=_NO_WINDOW)
            parts.append(out.stdout.decode("utf-8", errors="replace").strip())
        except (OSError, subprocess.SubprocessError):
            parts.append("")
    return "\n".join(p for p in parts if p)


def _mtime_ms(path: str) -> float:
    return os.stat(path).st_mtime_ns / 1e6


class CardReader(QObject):
    """Runs OCR in background threads and reports progress to the window."""

    progress = Signal(int, int)  # done, total
    finished = Signal(dict)  # media id -> text
    failed = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._cancel = threading.Event()
        self._thread: threading.Thread | None = None

    @property
    def running(self) -> bool:
        return bool(self._thread and self._thread.is_alive())

    def cancel(self) -> None:
        self._cancel.set()

    def start(self, meta_dir: Path, items: dict[str, str], indic: bool) -> None:
        """``items`` maps media id to picture path."""
        if self.running:
            return
        self._cancel.clear()
        self._thread = threading.Thread(target=self._run, args=(meta_dir, dict(items), indic), daemon=True)
        self._thread.start()

    def _run(self, meta_dir: Path, items: dict[str, str], indic: bool) -> None:
        try:
            lang = ocr_language(indic)
            if not paths.tesseract_exe():
                self.failed.emit("Tesseract is not bundled with this build")
                return
            cache_path = meta_dir / "native_ocr.json"
            try:
                cache = json.loads(cache_path.read_text(encoding="utf-8")).get("files") or {}
            except (OSError, ValueError, AttributeError):
                cache = {}
            texts: dict[str, str] = {}
            todo = []
            for mid, path in items.items():
                try:
                    mt = _mtime_ms(path)
                except OSError:
                    continue
                prev = cache.get(mid)
                if (isinstance(prev, dict) and prev.get("v") == CACHE_VERSION and prev.get("lang") == lang
                        and prev.get("mtime") == mt and isinstance(prev.get("text"), str)):
                    texts[mid] = prev["text"]
                else:
                    todo.append((mid, path, mt))
            total = len(items)
            done = len(texts)
            self.progress.emit(done, total)
            lock = threading.Lock()

            def work(job):
                mid, path, mt = job
                if self._cancel.is_set():
                    return
                text = read_image(path, lang)
                nonlocal done
                with lock:
                    texts[mid] = text
                    cache[mid] = {"mtime": mt, "text": text, "lang": lang, "v": CACHE_VERSION}
                    done += 1
                    self.progress.emit(done, total)

            workers = max(1, min(4, (os.cpu_count() or 2) // 2))
            with ThreadPoolExecutor(max_workers=workers) as pool:
                list(pool.map(work, todo))
            if todo:
                try:
                    tmp = cache_path.with_suffix(".tmp")
                    tmp.write_text(json.dumps({"files": cache}, ensure_ascii=False), encoding="utf-8")
                    os.replace(tmp, cache_path)
                except OSError:
                    pass
            if self._cancel.is_set():
                return
            self.finished.emit(texts)
        except Exception as e:  # noqa: BLE001
            self.failed.emit(str(e))
