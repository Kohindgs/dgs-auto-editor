"""Picture and sound through libmpv.

The picture is drawn by libmpv into a Qt OpenGL surface (render API), so the
logo, the poem lyric and captions are painted on top by Qt in the same
frame. Narration and poem each keep their own audio-only libmpv instance, so
crossing into or out of the song does not reload a file.
"""

from __future__ import annotations

import math
import os
import threading
import time
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QImage, QOpenGLContext, QPainter, QPainterPath, QPen, QPixmap, QRadialGradient
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtOpenGL import QOpenGLFramebufferObject

from .. import paths
from ..core.plan import Heard, logo_box
from ..core.project_store import DEFAULT_LOGO_TRANSFORM

paths.prepare_dlls()
import mpv  # noqa: E402  (needs the DLL path above)


def _file_stamp(path: str) -> int:
    """Changes when the file on disk is replaced, even if the path stays the same."""
    try:
        return os.stat(path).st_mtime_ns
    except OSError:
        return 0


# No built-in Lua scripts (OSC, ytdl, console…): the editor draws its own
# controls, and LuaJIT's error unwinding crashed the process under Qt.
# Local files. Never pause the picture to fill a buffer: that is what made
# the poem look stuck, one short video after another.
PLAY = {
    "cache": "yes",
    "cache_pause": "no",
    "demuxer_cache_wait": "no",
    "demuxer_readahead_secs": "8",
}

QUIET = {
    "config": "no",
    "load_scripts": "no",
    "osc": "no",
    "ytdl": "no",
    "load_stats_overlay": "no",
    "load_console": "no",
    "load_osd_console": "no",
    "load_auto_profiles": "no",
    "load_select": "no",
    "load_positioning": "no",
    "load_commands": "no",
    "load_context_menu": "no",
    "input_default_bindings": "no",
    "input_vo_keyboard": "no",
    "terminal": "no",
}


def _font_weight(value) -> QFont.Weight:
    """Poem text weight. 100 is thin, 400 is regular, 700 is bold."""
    try:
        n = int(value)
    except (TypeError, ValueError):
        n = 400
    steps = (
        (150, QFont.Weight.Thin),
        (250, QFont.Weight.ExtraLight),
        (350, QFont.Weight.Light),
        (450, QFont.Weight.Normal),
        (550, QFont.Weight.Medium),
        (650, QFont.Weight.DemiBold),
        (750, QFont.Weight.Bold),
        (850, QFont.Weight.ExtraBold),
    )
    for limit, weight in steps:
        if n < limit:
            return weight
    return QFont.Weight.Black


def _proc_address(_ctx, name):
    glctx = QOpenGLContext.currentContext()
    if glctx is None:
        return 0
    addr = glctx.getProcAddress(name)
    return int(addr) if addr else 0


class PreviewSurface(QOpenGLWidget):
    frame_ready = Signal()
    logo_moved = Signal(dict)
    logo_reset = Signal()
    replace_placeholder = Signal()
    lyric_moved = Signal(dict)
    _still_ready = Signal(str, int, QImage)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setMinimumSize(320, 180)
        self.setMouseTracking(True)
        self.player = self._open_player()
        self._next = self._open_player()
        self._armed = ""
        self._hold_for = ""
        self._hold_since = 0.0
        self._tiny = None
        self._ready_at = 0.0
        self._ctx = None
        self._next_ctx = None
        self._proc_fn = mpv.MpvGlGetProcAddressFn(_proc_address)
        self.frame_ready.connect(self.update, Qt.ConnectionType.QueuedConnection)
        self.path = ""
        self.kind = "missing"
        self._still: QPixmap | None = None
        self._shown_stamp = 0
        self._stills: dict[str, QPixmap] = {}
        self._still_stamp: dict[str, int] = {}
        self._loading: set[str] = set()
        self._still_ready.connect(self._store_still, Qt.ConnectionType.QueuedConnection)
        self._last_src = -1.0
        self.fill = False
        self.logo_on = False
        self.logo_locked = False
        self.logo_pix: QPixmap | None = None
        self.logo_transform = dict(DEFAULT_LOGO_TRANSFORM)
        self._frame_wh = (0, 0)
        self._logo_cache_key = None
        self._logo_cache: QPixmap | None = None
        self.lyric = ""
        self.lyric_style: dict = {}
        self._lyric_rect = QRectF()
        self._lyric_drag = None
        self._lyric_resize = None
        self._lyric_local = 0.0
        self._lyric_dur = 1.0
        self.caption = ""
        self.note = "Import media or open a project to preview"
        self._drag = None
        self._logo_rect = QRectF()

    def _open_player(self):
        return mpv.MPV(
            vo="libmpv",
            # d3d11va-copy showed scrambled frames after a paused seek on the studio PC.
            hwdec=os.environ.get("DGS_HWDEC", "no"),
            keep_open="yes",
            idle="yes",
            pause=True,
            aid="no",
            sid="no",
            ao="null",
            hr_seek="no",
            image_display_duration="inf",
            **PLAY,
            **QUIET,
        )

    # GL --------------------------------------------------------------------

    def initializeGL(self) -> None:
        self._ctx = mpv.MpvRenderContext(
            self.player,
            "opengl",
            opengl_init_params={"get_proc_address": self._proc_fn},
        )
        self._ctx.update_cb = self.frame_ready.emit
        self._next_ctx = mpv.MpvRenderContext(
            self._next,
            "opengl",
            opengl_init_params={"get_proc_address": self._proc_fn},
        )
        self._next_ctx.update_cb = self.frame_ready.emit

    def paintGL(self) -> None:
        still = self._still is not None and not self._still.isNull()
        drew = False
        if not still and self.kind == "video" and self.path:
            dpr = self.devicePixelRatioF()
            w = int(self.width() * dpr)
            h = int(self.height() * dpr)
            # The next clip is decoded off to the side, so the cut does not
            # open a new file on the picture the viewer is watching.
            if self._next_ctx is not None and self._armed:
                if self._tiny is None or self._tiny.width() != 64:
                    self._tiny = QOpenGLFramebufferObject(64, 64)
                self._next_ctx.render(
                    flip_y=True,
                    opengl_fbo={"w": 64, "h": 64, "fbo": int(self._tiny.handle())},
                )
            if self._ctx is not None:
                self._ctx.render(
                    flip_y=True,
                    opengl_fbo={"w": w, "h": h, "fbo": self.defaultFramebufferObject()},
                )
                drew = True
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        if still:
            self._draw_still(p)
        elif not drew:
            p.fillRect(self.rect(), QColor("#050407"))
        if not self.path and self.note:
            self._paint_note(p)
        self._paint_lyric(p)
        self._paint_caption(p)
        self._paint_logo(p)
        p.end()

    def shutdown(self) -> None:
        self.makeCurrent()
        if self._ctx is not None:
            self._ctx.free()
            self._ctx = None
        if self._next_ctx is not None:
            self._next_ctx.free()
            self._next_ctx = None
        self.doneCurrent()
        for player in (self.player, getattr(self, "_next", None)):
            if player is None:
                continue
            try:
                player.terminate()
            except Exception:
                pass

    # Picture ---------------------------------------------------------------

    def show_picture(self, path: str, kind: str, src_t: float, speed: float, playing: bool, force: bool) -> None:
        if not path:
            if self.kind == "video" and self.path:
                self.player.command("stop")
            self.path = ""
            self.kind = kind
            self._still = None
            self.update()
            return
        if kind != "video":
            # Stills are drawn by Qt. Reloading each card in mpv is what stopped
            # the picture on the line between two cards.
            stamp = _file_stamp(path)
            if (
                path == self.path
                and self.kind == "image"
                and self._still is not None
                and not self._still.isNull()
                and stamp == self._shown_stamp
            ):
                return
            if self.kind == "video" and self.path:
                try:
                    self.player.command("stop")
                except Exception:
                    pass
            self.path = path
            self.kind = "image"
            self._still = self._still_for(path)
            self._shown_stamp = _file_stamp(path)
            self.update()
            return
        # Leaving a still (e.g. "Listen and sing.") for a poem video: never keep
        # the still path/kind, or the next tick reloads that heading as a flash.
        leaving_still = self.kind == "image" and bool(self.path) and path != self.path
        self._still = None
        if leaving_still:
            self.kind = "video"
            self.path = ""
        if path != self.path:
            swapped = False
            if not force and path == self._armed and self._next is not None:
                ready = False
                try:
                    ready = self._next.time_pos is not None
                except Exception:
                    ready = False
                if ready:
                    self.player, self._next = self._next, self.player
                    self._ctx, self._next_ctx = self._next_ctx, self._ctx
                    self._armed = ""
                    self._hold_for = ""
                    swapped = True
                else:
                    now = time.perf_counter()
                    if self._hold_for != path:
                        self._hold_for = path
                        self._hold_since = now
                    if now - self._hold_since < 0.45 and not leaving_still:
                        # Video→video can wait on the armed player. Image→video
                        # must not freeze the previous still into the song.
                        return
            if not swapped:
                self.player.loadfile(path, "replace", start=f"{max(0.0, src_t):.3f}")
                self._armed = ""
            self.path = path
            self.kind = kind
            self._last_src = src_t
            force = False
            self._ready_at = time.perf_counter() + 0.35
        if speed <= 0.01:
            # The words are finished and the card is holding for a pause.
            try:
                pos = self.player.time_pos
                if force or pos is None or abs(float(pos) - src_t) > 0.08:
                    self._seek(src_t, exact=True)
                if not self.player.pause:
                    self.player.pause = True
            except Exception:
                pass
            self._last_src = src_t
            return
        try:
            if abs(float(self.player.speed or 1.0) - speed) > 0.01:
                self.player.speed = speed
        except Exception:
            pass
        if playing:
            if self._pull_back_from_end(src_t):
                self._last_src = src_t
                return
            if self._hold_last_frame(src_t):
                self._last_src = src_t
                return
            pos = self.player.time_pos
            now = time.perf_counter()
            if force:
                self._seek(src_t, exact=True)
                self._ready_at = now + 0.35
            elif pos is not None and abs(pos - src_t) > 0.75 and now >= self._ready_at:
                self._seek(src_t, exact=False)
                self._ready_at = now + 0.35
            if self.player.pause:
                self.player.pause = False
        else:
            if not self.player.pause:
                self.player.pause = True
            if force or abs(src_t - self._last_src) > 1 / 60:
                self._seek(src_t, exact=True)
        self._last_src = src_t

    def arm_next_video(self, path: str, src_t: float, speed: float) -> None:
        """Open the next clip on the hidden player so the cut does not restart the picture."""
        if not path or self._next is None or path == self.path or path == self._armed:
            return
        try:
            self._next.pause = True
            self._next.speed = speed if speed > 0 else 1.0
            self._next.loadfile(path, "replace", start=f"{max(0.0, src_t):.3f}")
            self._armed = path
            self._hold_for = ""
        except Exception:
            self._armed = ""

    def drop_stills(self) -> None:
        """Forget loaded pictures so the next frame reads the files on disk."""
        self._stills.clear()
        self._still_stamp.clear()
        self._loading.clear()
        self._still = None
        self._shown_stamp = 0
        self.path = ""

    def preload_stills(self, paths: list[str]) -> None:
        for path in paths:
            stamp = _file_stamp(path)
            if not path or path in self._loading:
                continue
            if path in self._stills and self._still_stamp.get(path) == stamp:
                continue
            if len(self._loading) >= 2:
                break
            self._loading.add(path)
            threading.Thread(target=self._load_still_bg, args=(path, stamp), daemon=True).start()

    def _load_still_bg(self, path: str, stamp: int) -> None:
        img = QImage(path)
        self._still_ready.emit(path, stamp, img)

    def _store_still(self, path: str, stamp: int, img: QImage) -> None:
        self._loading.discard(path)
        if img.isNull():
            return
        if _file_stamp(path) != stamp:
            return
        self._stills[path] = QPixmap.fromImage(img)
        self._still_stamp[path] = stamp
        if len(self._stills) > 240:
            for old in list(self._stills)[:40]:
                if old != path:
                    self._stills.pop(old, None)
                    self._still_stamp.pop(old, None)
        if self.path == path and self.kind == "image":
            self._still = self._stills[path]
            self._shown_stamp = stamp
            self.update()

    def _still_for(self, path: str) -> QPixmap:
        stamp = _file_stamp(path)
        pix = self._stills.get(path)
        if pix is not None and self._still_stamp.get(path) == stamp:
            return pix
        pix = QPixmap(path)
        self._stills[path] = pix
        self._still_stamp[path] = stamp
        return pix

    def _draw_still(self, p: QPainter) -> None:
        pix = self._still
        if pix is None or pix.isNull():
            p.fillRect(self.rect(), QColor("#050407"))
            return
        dpr = max(1.0, float(self.devicePixelRatioF()))
        mode = Qt.AspectRatioMode.KeepAspectRatioByExpanding if self.fill else Qt.AspectRatioMode.KeepAspectRatio
        target_px = self.size() * dpr
        scaled = pix.scaled(target_px, mode, Qt.TransformationMode.SmoothTransformation)
        scaled.setDevicePixelRatio(dpr)
        sw = scaled.width() / dpr
        sh = scaled.height() / dpr
        p.fillRect(self.rect(), QColor("#050407"))
        p.drawPixmap(QPointF((self.width() - sw) * 0.5, (self.height() - sh) * 0.5), scaled)

    def _pull_back_from_end(self, src_t: float) -> bool:
        """The file reached its end while this line still has picture left.

        Leaving it there skipped the last text. Land back on the frame that
        belongs with the voice and keep playing.
        """
        try:
            dur = float(self.player.duration or 0)
            pos = self.player.time_pos
        except Exception:
            return False
        if dur < 0.2 or pos is None or float(pos) < dur - 0.05:
            return False
        if src_t >= dur - 0.12:
            return False
        self._seek(src_t, exact=True)
        self._ready_at = time.perf_counter() + 0.35
        try:
            if self.player.pause:
                self.player.pause = False
        except Exception:
            pass
        return True

    def _hold_last_frame(self, src_t: float) -> bool:
        """Keep the last frame up. Playing into the end of the file clears it,
        so the closing words lose the text that belongs with them.
        """
        try:
            dur = self.player.duration
        except Exception:
            return False
        if not dur or float(dur) < 0.2:
            return False
        end = max(0.0, float(dur) - 0.04)
        if src_t < end - 0.03:
            return False
        try:
            pos = self.player.time_pos
        except Exception:
            pos = None
        if pos is None or abs(float(pos) - end) > 0.08:
            self._seek(end, exact=True)
        try:
            if not self.player.pause:
                self.player.pause = True
        except Exception:
            pass
        return True

    def _seek(self, t: float, exact: bool = True) -> None:
        try:
            self.player.hr_seek = "yes" if exact else "no"
            self.player.seek(max(0.0, t), reference="absolute", precision="exact" if exact else "keyframes")
        except Exception:
            pass

    def pause_video(self) -> None:
        for player in (self.player, self._next):
            try:
                player.pause = True
            except Exception:
                pass

    def set_fill(self, fill: bool) -> None:
        self.fill = fill
        self.player.panscan = 1.0 if fill else 0.0
        if self._next is not None:
            self._next.panscan = 1.0 if fill else 0.0
        self.update()

    # Overlays --------------------------------------------------------------

    def set_logo(self, on: bool, file: str, transform: dict) -> None:
        self.logo_on = on
        self.logo_transform = dict(transform)
        if file and (self.logo_pix is None or getattr(self, "_logo_file", "") != file):
            pix = QPixmap(file)
            self.logo_pix = pix if not pix.isNull() else None
            self._logo_file = file
            self._logo_cache_key = None
            self._logo_cache = None
        elif not file:
            self.logo_pix = None
            self._logo_file = ""
            self._logo_cache_key = None
            self._logo_cache = None
        self.update()

    def set_lyric(self, text: str, style: dict, local: float = 0.0, dur: float = 1.0) -> None:
        self.lyric = text
        if not self._lyric_drag and not self._lyric_resize:
            self.lyric_style = style or {}
        self._lyric_local = max(0.0, float(local or 0))
        self._lyric_dur = max(0.2, float(dur or 1))
        self.update()

    def set_video_frame(self, width: int, height: int) -> None:
        """The uploaded picture’s real size. The logo is locked to that frame, not the window."""
        self._frame_wh = (max(0, int(width)), max(0, int(height)))
        self._logo_cache_key = None
        self.update()

    def _video_rect(self) -> tuple[float, float, float, float]:
        fw, fh = self._frame_wh
        if fw < 2 or fh < 2:
            return 0.0, 0.0, float(self.width()), float(self.height())
        from ..core.caption_video import fitted_frame

        return fitted_frame(float(self.width()), float(self.height()), fw, fh)

    def set_caption(self, text: str) -> None:
        if text != self.caption:
            self.caption = text
            self.update()

    def set_note(self, text: str) -> None:
        if text != self.note:
            self.note = text
            self.update()

    def _paint_note(self, p: QPainter) -> None:
        w, h = self.width(), self.height()
        if self.note.startswith("Missing image"):
            box = QRectF(w * 0.18, h * 0.30, w * 0.64, h * 0.40)
            path = QPainterPath()
            path.addRoundedRect(box, 16, 16)
            p.fillPath(path, QColor("#1c1218"))
            p.setPen(QPen(QColor("#fbbf24"), 2, Qt.PenStyle.DashLine))
            p.drawPath(path)
            p.setPen(QColor("#fde68a"))
            title = QFont("Segoe UI", 10)
            title.setPixelSize(max(18, int(h * 0.055)))
            title.setWeight(QFont.Weight.DemiBold)
            p.setFont(title)
            p.drawText(box.adjusted(16, 12, -16, -box.height() * 0.42), Qt.AlignmentFlag.AlignCenter, "Missing image")
            p.setPen(QColor("#d4c2d0"))
            sub = QFont("Segoe UI", 10)
            sub.setPixelSize(max(12, int(h * 0.032)))
            p.setFont(sub)
            p.drawText(box.adjusted(16, box.height() * 0.42, -16, -12), Qt.AlignmentFlag.AlignHCenter | Qt.TextFlag.TextWordWrap, self.note.split("\n", 1)[-1])
            return
        p.setPen(QColor("#d4c2d0"))
        p.setFont(QFont("Segoe UI", 13))
        p.drawText(self.rect().adjusted(24, 24, -24, -24), Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, self.note)

    def _paint_logo(self, p: QPainter) -> None:
        self._logo_rect = QRectF()
        if not self.logo_on or self.logo_pix is None:
            return
        ox, oy, cw, ch = self._video_rect()
        left, top, w, h = logo_box(self.logo_transform, cw, ch, self.logo_pix.width(), self.logo_pix.height())
        left += ox
        top += oy
        rect = QRectF(left, top, w, h)
        # Scale once from the source PNG, then blit without smoothing so the logo stays sharp.
        # Always use the (target, pixmap, source) draw — Qt has no (QRectF, QPixmap) overload that fills the box.
        dpr = max(1.0, float(self.devicePixelRatioF()))
        tw, th = max(1, int(round(w * dpr))), max(1, int(round(h * dpr)))
        key = (int(self.logo_pix.cacheKey()), tw, th)
        if self._logo_cache_key != key or self._logo_cache is None:
            self._logo_cache = self.logo_pix.scaled(
                tw, th,
                Qt.AspectRatioMode.IgnoreAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            self._logo_cache_key = key
        rot = float(self.logo_transform.get("rotate") or 0)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, False)
        if abs(rot) > 0.01:
            p.save()
            p.translate(rect.center())
            p.rotate(rot)
            p.drawPixmap(QRectF(-w / 2, -h / 2, w, h), self._logo_cache, QRectF(self._logo_cache.rect()))
            p.restore()
        else:
            p.drawPixmap(rect, self._logo_cache, QRectF(self._logo_cache.rect()))
        self._logo_rect = rect

    def _paint_lyric(self, p: QPainter) -> None:
        st = self.lyric_style or {}
        if not self.lyric or st.get("enabled") is False:
            self._lyric_rect = QRectF()
            return
        w, h = self.width(), self.height()
        box = QRectF(
            w * float(st.get("x_pct", 10)) / 100,
            h * float(st.get("y_pct", 72)) / 100,
            w * float(st.get("w_pct", 80)) / 100,
            h * float(st.get("h_pct", 20)) / 100,
        )
        local, dur = self._lyric_local, self._lyric_dur
        change = str(st.get("changeover") or "none")
        intro = min(0.45, dur * 0.35)
        t = min(1.0, local / intro) if intro > 0.05 and change != "none" else 1.0
        p.save()
        if change == "fade":
            p.setOpacity(0.15 + 0.85 * t)
        elif change == "slide":
            p.translate((t - 1.0) * box.width() * 0.35, 0)
        elif change == "pop":
            scale = 0.82 + 0.18 * t
            c = box.center()
            p.translate(c)
            p.scale(scale, scale)
            p.translate(-c)
        scale_h = h / 1080
        size = max(9.0, float(st.get("font_size_px", 28)) * 1.6 * scale_h)
        family = str(st.get("font_family") or "Nirmala UI")
        font = QFont()
        font.setFamilies([family])
        font.setPixelSize(int(size))
        font.setWeight(_font_weight(st.get("font_weight")))
        bg = QColor(str(st.get("bg_color") or "#0f172a"))
        bg.setAlphaF(max(0.0, min(1.0, float(st.get("bg_opacity", 0.88)))))
        radius = float(st.get("border_radius", 24)) * scale_h
        path = QPainterPath()
        path.addRoundedRect(box, radius, radius)
        if st.get("box_shadow"):
            shadow = QColor(str(st.get("shadow_color") or "#000000"))
            soft = max(1, int(st.get("shadow_soft") or 6))
            steps = max(1, min(5, soft // 2))
            for i in range(steps, 0, -1):
                shade = QColor(shadow)
                shade.setAlpha(int(70 / i))
                p.fillPath(path.translated(2 * scale_h, (1 + i) * scale_h), shade)
        if not st.get("bg_none") and bg.alphaF() > 0.02:
            p.fillPath(path, bg)
        bw = float(st.get("border_width", 2))
        if not st.get("border_none") and bw > 0:
            p.setPen(QPen(QColor(str(st.get("border_color") or "#38bdf8")), max(1.0, bw * scale_h * 1.5)))
            p.drawPath(path)
        p.setFont(font)
        words = [wrd for wrd in self.lyric.replace("\n", " ").split(" ") if wrd]
        inner = box.adjusted(12, 6, -12, -6)
        fill = QColor(str(st.get("text_color") or "#ffffff"))
        flags = self._lyric_align(st) | Qt.AlignmentFlag.AlignVCenter | Qt.TextFlag.TextWordWrap
        if st.get("word_balls") and len(words) >= 2:
            self._paint_lyric_words(p, st, font, words, inner, local, dur)
        else:
            self._draw_poem_text(p, inner, self.lyric, flags, fill, st, font)
        p.restore()
        self._lyric_rect = box
        if box.width() > 24 and box.height() > 24:
            p.setPen(QPen(QColor(255, 255, 255, 180), 2))
            c = box.bottomRight()
            p.drawLine(QPointF(c.x() - 14, c.y()), QPointF(c.x() - 3, c.y()))
            p.drawLine(QPointF(c.x(), c.y() - 14), QPointF(c.x(), c.y() - 3))

    def _sharp_font(self, font: QFont, px: int) -> QFont:
        """Hint the letters to the real pixels so the lyric stays crisp on the preview."""
        sharp = QFont(font)
        sharp.setPixelSize(max(8, int(px)))
        sharp.setHintingPreference(QFont.HintingPreference.PreferFullHinting)
        return sharp

    def _draw_poem_text(self, p: QPainter, target, text: str, flags, fill: QColor, st: dict, font: QFont) -> None:
        """Sharp letters. The edge is a few real pixels, then the words are drawn on top."""
        raw = str(text or "")
        if not raw:
            return
        style = str(st.get("text_style") or "shadow")
        if style not in ("plain", "shadow", "outline", "sticker", "lift", "glow"):
            style = "shadow"
        dpr = max(1.0, float(self.devicePixelRatioF() or 1))
        logical = max(10.0, float(font.pixelSize() or 28))
        sharp = self._sharp_font(font, int(round(logical * dpr)))
        logical_font = self._sharp_font(font, int(round(logical)))
        logical_fm = QFontMetricsF(logical_font)
        pad = int(max(4, logical_font.pixelSize() * 0.35))
        if flags is None:
            tw = logical_fm.horizontalAdvance(raw)
            th = logical_fm.height()
            origin = QPointF(float(target.x()), float(target.y()) - logical_fm.ascent())
            box = QRectF(0, 0, tw, th)
            baseline = logical_fm.ascent()
        else:
            origin = QPointF(float(target.left()), float(target.top()))
            box = QRectF(0, 0, float(target.width()), float(target.height()))
            baseline = None
        iw = max(2, int(round((box.width() + pad * 2) * dpr)))
        ih = max(2, int(round((box.height() + pad * 2) * dpr)))
        img = QImage(iw, ih, QImage.Format.Format_ARGB32_Premultiplied)
        img.fill(0)
        tp = QPainter(img)
        tp.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        tp.setFont(sharp)
        rect = QRectF(pad * dpr, pad * dpr, box.width() * dpr, box.height() * dpr)
        point = QPointF(pad * dpr, pad * dpr + (baseline or 0) * dpr)

        def paint(dx: float, dy: float, color: QColor) -> None:
            tp.setPen(color)
            if flags is None:
                tp.drawText(QPointF(point.x() + dx, point.y() + dy), raw)
            else:
                tp.drawText(rect.translated(dx, dy), flags, raw)

        px = 1.0
        shadow = QColor(str(st.get("shadow_color") or "#000000"))
        if "text_shadow" in st:
            shadow_on = bool(st.get("text_shadow"))
        else:
            shadow_on = style in ("shadow", "sticker", "lift", "glow")
        if style == "glow":
            for reach, alpha in ((4 * px, 50), (2 * px, 90)):
                shade = QColor(shadow)
                shade.setAlpha(alpha)
                for ox, oy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    paint(ox * reach, oy * reach, shade)
        elif shadow_on:
            dist = 2 * px if style == "lift" else px
            shade = QColor(shadow)
            shade.setAlpha(220)
            paint(dist, dist, shade)
        if style in ("outline", "sticker"):
            reach = 2 * px if style == "sticker" else px
            ink = QColor(str(st.get("stroke_color") or "#111111"))
            for ox, oy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
                paint(ox * reach, oy * reach, ink)
        paint(0, 0, fill)
        tp.end()
        img.setDevicePixelRatio(dpr)
        p.save()
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, False)
        p.drawImage(QPointF(origin.x() - pad, origin.y() - pad), img)
        p.restore()

    def _lyric_align(self, st: dict):
        return {"left": Qt.AlignmentFlag.AlignLeft, "right": Qt.AlignmentFlag.AlignRight}.get(
            str(st.get("text_align") or "center"), Qt.AlignmentFlag.AlignHCenter
        )

    def _paint_lyric_words(self, p: QPainter, st: dict, font: QFont, words: list[str], inner: QRectF, local: float, dur: float) -> None:
        fm = QFontMetricsF(font)
        gap = fm.horizontalAdvance(" ")
        widths = [fm.horizontalAdvance(w) for w in words]
        total = sum(widths) + gap * (len(words) - 1)
        x = inner.left() + max(0.0, (inner.width() - total) / 2)
        y = inner.center().y()
        centers = []
        slot = dur / len(words)
        idx = min(len(words) - 1, int(local / slot)) if slot else 0
        frac = (local - idx * slot) / slot if slot else 0.0
        ball = QColor(str(st.get("ball_color") or "#facc15"))
        spoken = QColor(ball)
        rest = QColor(str(st.get("text_color") or "#ffffff"))
        for i, word in enumerate(words):
            ink = spoken if i == idx else rest
            self._draw_poem_text(p, QPointF(x, y + fm.ascent() / 2), word, None, ink, st, font)
            centers.append(QPointF(x + widths[i] / 2, y))
            x += widths[i] + gap
        radius = max(7.0, inner.height() * 0.16)
        if idx > 0 and frac < 0.55:
            a, b = centers[idx - 1], centers[idx]
            hop = abs(math.sin(frac / 0.55 * math.pi))
            bx = a.x() + (b.x() - a.x()) * (frac / 0.55)
            by = a.y() - radius * 1.6 - hop * max(10.0, inner.height() * 0.34)
        else:
            here = centers[idx]
            bx, by = here.x(), here.y() - radius * 1.7
        self._paint_ball(p, QPointF(bx, by), radius, ball)

    def _paint_ball(self, p: QPainter, center: QPointF, radius: float, color: QColor) -> None:
        p.setPen(Qt.PenStyle.NoPen)
        floor = QRadialGradient(center.x(), center.y() + radius * 0.85, radius * 1.15)
        floor.setColorAt(0.0, QColor(0, 0, 0, 110))
        floor.setColorAt(1.0, QColor(0, 0, 0, 0))
        p.setBrush(floor)
        p.drawEllipse(QPointF(center.x(), center.y() + radius * 0.95), radius * 0.85, radius * 0.28)
        body = QRadialGradient(center.x() - radius * 0.38, center.y() - radius * 0.46, radius * 1.55)
        body.setColorAt(0.0, color.lighter(185))
        body.setColorAt(0.42, color)
        body.setColorAt(1.0, color.darker(190))
        p.setBrush(body)
        p.drawEllipse(center, radius, radius)
        rim = QColor(color.darker(220))
        rim.setAlpha(90)
        p.setPen(QPen(rim, max(1.0, radius * 0.08)))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(center, radius, radius)
        p.setPen(Qt.PenStyle.NoPen)
        shine = QRadialGradient(center.x() - radius * 0.32, center.y() - radius * 0.38, radius * 0.55)
        shine.setColorAt(0.0, QColor(255, 255, 255, 230))
        shine.setColorAt(1.0, QColor(255, 255, 255, 0))
        p.setBrush(shine)
        p.drawEllipse(QPointF(center.x() - radius * 0.28, center.y() - radius * 0.34), radius * 0.38, radius * 0.26)

    def _paint_caption(self, p: QPainter) -> None:
        if not self.caption:
            return
        w, h = self.width(), self.height()
        font = QFont("Nirmala UI")
        font.setWeight(QFont.Weight.Thin)
        font.setPixelSize(max(10, int(h * 0.026)))
        p.setFont(font)
        fm = QFontMetricsF(font)
        box_w = w * 0.72
        flags = Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignBottom | Qt.TextFlag.TextWordWrap
        rect = fm.boundingRect(QRectF(0, 0, box_w, h), Qt.AlignmentFlag.AlignHCenter | Qt.TextFlag.TextWordWrap, self.caption)
        # Devanagari line spacing is taller than the measured box, and the
        # last line was clipped just as the voice reached it.
        rect.setHeight(rect.height() + fm.descent() + fm.leading() + 4)
        bottom = h - 8
        top = max(8.0, bottom - rect.height())
        rect = QRectF((w - box_w) / 2, top, box_w, bottom - top)
        bg = rect.adjusted(-8, -3, 8, 3)
        p.fillRect(bg, QColor(0, 0, 0, 210))
        p.setPen(QColor("#ffffff"))
        p.drawText(rect, flags, self.caption)

    # Logo drag (same mapping as the current preview: 1920x1080 units) -----

    def _lyric_corner(self, pos) -> bool:
        box = self._lyric_rect
        if box.isNull():
            return False
        return abs(pos.x() - box.right()) <= 16 and abs(pos.y() - box.bottom()) <= 16

    def mousePressEvent(self, e) -> None:  # noqa: N802
        if e.button() == Qt.MouseButton.LeftButton and not self.path and self.note.startswith("Missing image"):
            self.replace_placeholder.emit()
            e.accept()
            return
        if (
            e.button() == Qt.MouseButton.LeftButton
            and self._lyric_corner(e.position())
            and not (self.lyric_style or {}).get("locked")
        ):
            self._lyric_resize = (e.position(), dict(self.lyric_style or {}))
            e.accept()
            return
        if (
            e.button() == Qt.MouseButton.LeftButton
            and self._lyric_rect.contains(e.position())
            and not (self.lyric_style or {}).get("locked")
        ):
            self._lyric_drag = (e.position(), dict(self.lyric_style or {}))
            e.accept()
            return
        if e.button() == Qt.MouseButton.LeftButton and self._logo_rect.contains(e.position()) and not self.logo_locked:
            self._drag = (e.position(), dict(self.logo_transform))
            e.accept()
            return
        super().mousePressEvent(e)

    def mouseMoveEvent(self, e) -> None:  # noqa: N802
        if self._lyric_corner(e.position()) or self._lyric_resize:
            self.setCursor(Qt.CursorShape.SizeFDiagCursor)
        elif self._lyric_rect.contains(e.position()) or self._lyric_drag or self._logo_rect.contains(e.position()) or self._drag:
            self.setCursor(Qt.CursorShape.SizeAllCursor)
        else:
            self.unsetCursor()
        if self._lyric_resize:
            start, style = self._lyric_resize
            dw = (e.position().x() - start.x()) / max(1, self.width()) * 100
            dh = (e.position().y() - start.y()) / max(1, self.height()) * 100
            nxt = dict(style)
            nxt["w_pct"] = max(20.0, min(100.0, float(style.get("w_pct") or 80) + dw))
            nxt["h_pct"] = max(8.0, min(60.0, float(style.get("h_pct") or 20) + dh))
            nxt["border_none"] = bool(style.get("border_none"))
            self.lyric_style = nxt
            self.update()
            return
        if self._lyric_drag:
            start, style = self._lyric_drag
            dx = (e.position().x() - start.x()) / max(1, self.width()) * 100
            dy = (e.position().y() - start.y()) / max(1, self.height()) * 100
            nxt = dict(style)
            nxt["x_pct"] = max(0.0, min(90.0, float(style.get("x_pct") or 10) + dx))
            nxt["y_pct"] = max(0.0, min(90.0, float(style.get("y_pct") or 72) + dy))
            self.lyric_style = nxt
            self.update()
            return
        if not self._drag:
            return
        start, t0 = self._drag
        dx = (e.position().x() - start.x()) / max(1, self.width()) * 1920
        dy = -(e.position().y() - start.y()) / max(1, self.height()) * 1080
        t = dict(t0)
        t["pos_x"] = round(t0["pos_x"] + dx, 2)
        t["pos_y"] = round(t0["pos_y"] + dy, 2)
        self.logo_transform = t
        self.update()

    def mouseReleaseEvent(self, e) -> None:  # noqa: N802
        if self._lyric_resize:
            self._lyric_resize = None
            self.lyric_moved.emit(dict(self.lyric_style or {}))
            e.accept()
            return
        if self._lyric_drag:
            self._lyric_drag = None
            self.lyric_moved.emit(dict(self.lyric_style or {}))
            e.accept()
            return
        if self._drag:
            self._drag = None
            self.logo_moved.emit(dict(self.logo_transform))
            e.accept()
            return
        super().mouseReleaseEvent(e)

    def mouseDoubleClickEvent(self, e) -> None:  # noqa: N802
        if self._logo_rect.contains(e.position()):
            self.logo_reset.emit()
            e.accept()
            return
        super().mouseDoubleClickEvent(e)


class AudioDeck:
    """Narration and poem, each in its own audio-only libmpv."""

    def __init__(self) -> None:
        self._players = {
            "narration": mpv.MPV(video=False, keep_open="yes", idle="yes", pause=True, **PLAY, **QUIET),
            "poem": mpv.MPV(video=False, keep_open="yes", idle="yes", pause=True, **PLAY, **QUIET),
        }
        self._paths = {"narration": "", "poem": ""}
        self._seeked: dict[str, float] = {}
        self.volume = 1.0
        self.muted = False
        self.vo_muted = False
        self.poem_muted = False

    def follow(self, heard: Heard | None, playing: bool, force: bool) -> None:
        if not playing or heard is None:
            self.pause()
            return
        other = "poem" if heard.kind == "narration" else "narration"
        self._pause_one(other)
        pl = self._players[heard.kind]
        muted = self.muted or (self.vo_muted if heard.kind == "narration" else self.poem_muted)
        vol = 0 if muted else round(self.volume * 100)
        try:
            if pl.volume != vol:
                pl.volume = vol
        except Exception:
            pass
        now = time.perf_counter()
        if heard.path != self._paths[heard.kind]:
            self._paths[heard.kind] = heard.path
            self._seeked[heard.kind] = now
            pl.loadfile(heard.path, "replace", start=f"{heard.offset:.3f}")
            pl.pause = False
            return
        pos = pl.time_pos
        # While the song is running, let it play. An exact seek on every
        # small drift is what stalled the poem.
        late = (
            pos is not None
            and abs(float(pos) - heard.offset) > 0.75
            and now - self._seeked.get(heard.kind, 0) > 1.25
        )
        if force or late:
            self._seeked[heard.kind] = now
            try:
                pl.hr_seek = "yes" if force else "no"
                pl.seek(heard.offset, reference="absolute", precision="exact" if force else "keyframes")
            except Exception:
                pass
        if pl.pause:
            pl.pause = False

    def _pause_one(self, key: str) -> None:
        pl = self._players[key]
        try:
            if not pl.pause:
                pl.pause = True
        except Exception:
            pass

    def release(self, heard: Heard) -> None:
        """Keep the voice playing. Do not jump it forward to the playhead."""
        other = "poem" if heard.kind == "narration" else "narration"
        self._pause_one(other)
        pl = self._players[heard.kind]
        try:
            if pl.pause:
                pl.pause = False
        except Exception:
            pass

    def behind(self, heard: Heard, slack: float = 0.1) -> bool:
        """True when the file has not yet reached the words the playhead is on."""
        pl = self._players.get(heard.kind)
        if pl is None:
            return False
        try:
            pos = pl.time_pos
        except Exception:
            return False
        if pos is None:
            return False
        return float(heard.offset) - float(pos) > slack

    def pause(self) -> None:
        for key in self._players:
            self._pause_one(key)

    def shutdown(self) -> None:
        for pl in self._players.values():
            try:
                pl.terminate()
            except Exception:
                pass


def file_ok(path: str) -> bool:
    return bool(path) and Path(path).is_file()
