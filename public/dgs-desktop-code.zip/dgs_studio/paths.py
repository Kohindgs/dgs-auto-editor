"""Where the program finds its own files and the chapter data.

A packaged build carries everything under its own folder (``sys._MEIPASS``).
A source run falls back to the files already in the project tree.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FROZEN = bool(getattr(sys, "frozen", False))
BASE = Path(getattr(sys, "_MEIPASS", ROOT))


def _first(*candidates: Path) -> Path | None:
    for c in candidates:
        if c and c.exists():
            return c
    return None


def mpv_dir() -> Path | None:
    if sys.platform == "darwin":
        return _first(
            BASE / "vendor" / "mpv",
            ROOT / "native_editor" / "vendor" / "mpv-mac",
            Path("/opt/homebrew/lib"),
            Path("/usr/local/lib"),
            Path("/opt/local/lib"),
            ROOT / "native_editor" / "vendor" / "mpv",
        )
    return _first(
        BASE / "vendor" / "mpv",
        ROOT / "native_editor" / "vendor" / "mpv",
    )


def python_exe() -> Path:
    """Best Python interpreter for background worker scripts (hearing, bundle unpack, poem align)."""
    import shutil

    env_py = os.environ.get("DGS_PYTHON")
    if env_py and Path(env_py).is_file():
        return Path(env_py)
    if sys.platform == "darwin":
        cand = _first(
            ROOT / ".venv_mac" / "bin" / "python",
            ROOT / ".venv_mac" / "bin" / "python3",
            ROOT / "backend" / ".venv" / "bin" / "python",
            ROOT / "backend" / ".venv" / "bin" / "python3",
            ROOT / ".venv" / "bin" / "python",
            ROOT / ".venv" / "bin" / "python3",
            Path(sys.executable) if sys.executable else None,
            Path("/opt/homebrew/bin/python3"),
            Path("/usr/local/bin/python3"),
        )
        if cand:
            return cand
        which = shutil.which("python3") or shutil.which("python")
        return Path(which) if which else Path(sys.executable)
    cand = _first(
        ROOT / "python311" / "python.exe",
        ROOT / "backend" / ".venv" / "Scripts" / "python.exe",
        Path(sys.executable).with_name("python.exe") if sys.executable else None,
        Path(sys.executable) if sys.executable else None,
    )
    if cand:
        return cand
    which = shutil.which("python")
    return Path(which) if which else Path(sys.executable)


def ffmpeg_exe() -> Path | None:
    import shutil

    which = shutil.which("ffmpeg")
    if sys.platform == "darwin":
        return _first(
            BASE / "vendor" / "ffmpeg" / "ffmpeg",
            ROOT / "native_editor" / "vendor" / "ffmpeg" / "ffmpeg",
            Path("/opt/homebrew/bin/ffmpeg"),
            Path("/usr/local/bin/ffmpeg"),
            Path(which) if which else None,
        )
    return _first(
        BASE / "vendor" / "ffmpeg" / "ffmpeg.exe",
        ROOT / "native_editor" / "vendor" / "ffmpeg" / "ffmpeg.exe",
        ROOT / "hostinger_deploy" / "node_modules" / "ffmpeg-static" / "ffmpeg.exe",
        Path(which) if which else None,
    )


def ffprobe_exe() -> Path | None:
    import shutil

    which = shutil.which("ffprobe")
    if sys.platform == "darwin":
        return _first(
            BASE / "vendor" / "ffmpeg" / "ffprobe",
            ROOT / "native_editor" / "vendor" / "ffmpeg" / "ffprobe",
            Path("/opt/homebrew/bin/ffprobe"),
            Path("/usr/local/bin/ffprobe"),
            Path(which) if which else None,
        )
    return _first(
        BASE / "vendor" / "ffmpeg" / "ffprobe.exe",
        ROOT / "native_editor" / "vendor" / "ffmpeg" / "ffprobe.exe",
        ROOT / "hostinger_deploy" / "node_modules" / "@ffprobe-installer" / "win32-x64" / "ffprobe.exe",
        Path(which) if which else None,
    )


def default_logo() -> Path | None:
    return _first(
        BASE / "assets" / "eclass-logo.png",
        ROOT / "hostinger_deploy" / "public" / "eclass-logo.png",
    )


def app_logo() -> Path:
    """Neon D'AA emblem for D'Auto Aline window/taskbar icon (separate from video watermark logo)."""
    out = ROOT / "dgs_studio" / "assets" / "daa_neon_logo.png"
    out.parent.mkdir(parents=True, exist_ok=True)
    return out


def updates_feed() -> Path | None:
    return _first(
        BASE / "assets" / "updates.json",
        ROOT / "frontend" / "public" / "updates.json",
        ROOT / "hostinger_deploy" / "public" / "updates.json",
    )


def node_exe() -> Path | None:
    import shutil

    which = shutil.which("node")
    if sys.platform == "darwin":
        return _first(
            BASE / "vendor" / "node" / "node",
            ROOT / "native_editor" / "vendor" / "node" / "node",
            Path("/opt/homebrew/bin/node"),
            Path("/usr/local/bin/node"),
            Path(which) if which else None,
        )
    return _first(
        BASE / "vendor" / "node" / "node.exe",
        ROOT / "native_editor" / "vendor" / "node" / "node.exe",
        Path(r"C:\Program Files\nodejs\node.exe"),
        Path(which) if which else None,
    )


def engine_host() -> Path | None:
    return _first(
        BASE / "engine" / "engine_host.js",
        ROOT / "native_editor" / "engine" / "engine_host.js",
    )


def server_js() -> Path | None:
    return _first(
        BASE / "server" / "server.js",
        ROOT / "hostinger_deploy" / "server.js",
    )


def engine_logic_dir() -> Path | None:
    """Copy of the frontend logic ``.ts`` files (packaged builds); a source run reads ``frontend/src``."""
    return _first(BASE / "engine" / "logic") if FROZEN else None


def tesseract_exe() -> Path | None:
    import shutil

    which = shutil.which("tesseract")
    if sys.platform == "darwin":
        return _first(
            BASE / "vendor" / "tesseract" / "tesseract",
            ROOT / "native_editor" / "vendor" / "tesseract" / "tesseract",
            Path("/opt/homebrew/bin/tesseract"),
            Path("/usr/local/bin/tesseract"),
            Path(which) if which else None,
        )
    return _first(
        BASE / "vendor" / "tesseract" / "tesseract.exe",
        ROOT / "native_editor" / "vendor" / "tesseract" / "tesseract.exe",
        Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe"),
        Path(which) if which else None,
    )


def tessdata_dir() -> Path | None:
    """Folder with eng + mar ``.traineddata`` (Devanagari Marathi needs ``mar``)."""
    if sys.platform == "darwin":
        return _first(
            BASE / "vendor" / "tessdata",
            ROOT / "native_editor" / "vendor" / "tessdata",
            Path("/opt/homebrew/share/tessdata"),
            Path("/usr/local/share/tessdata"),
        )
    return _first(
        BASE / "vendor" / "tessdata",
        ROOT / "native_editor" / "vendor" / "tessdata",
        Path(r"C:\Program Files\Tesseract-OCR\tessdata"),
    )


def script_template() -> Path | None:
    """Blank universal master workbook every chapter must follow."""
    return _first(
        BASE / "assets" / "DGS_Master_Script_Template.xlsx",
        ROOT / "native_editor" / "assets" / "DGS_Master_Script_Template.xlsx",
        ROOT / "DGS_Master_Script_Template.xlsx",
        BASE / "assets" / "DGS_Cloud_Chapter_Script_Example.xlsx",
        ROOT / "native_editor" / "assets" / "DGS_Cloud_Chapter_Script_Example.xlsx",
    )


def data_dir() -> Path:
    # C: is often nearly full on the studio PC, so chapters live on D: when it exists.
    env = os.environ.get("DGS_DATA_DIR")
    if env:
        return Path(env)
    studio = Path(r"D:\AI Editor\dgs_data")
    if studio.exists():
        return studio
    local_data = ROOT / "dgs_data"
    if local_data.exists() or not FROZEN:
        local_data.mkdir(parents=True, exist_ok=True)
        return local_data
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "DGS Auto Editor" / "dgs_data"
    appdata = Path(os.environ.get("APPDATA", str(Path.home())))
    return appdata / "DGS Auto Editor" / "dgs_data"


def projects_dirs() -> list[Path]:
    dirs = [data_dir() / "projects"]
    if sys.platform == "darwin":
        mac_support = Path.home() / "Library" / "Application Support" / "DGS Auto Editor" / "dgs_data" / "projects"
        if mac_support not in dirs:
            dirs.append(mac_support)
    else:
        roaming = Path(os.environ.get("APPDATA", str(Path.home()))) / "dgs-auto-editor-desktop" / "dgs_data" / "projects"
        if roaming not in dirs:
            dirs.append(roaming)
    if not FROZEN:
        dirs.append(ROOT / "data" / "projects")
    return dirs


_DLLS_READY = False


def prepare_dlls() -> None:
    """libmpv must be on the DLL / dylib search path before ``import mpv``."""
    global _DLLS_READY
    if _DLLS_READY:
        return
    d = mpv_dir()
    if sys.platform == "darwin":
        import ctypes.util

        search_dirs = [
            BASE / "vendor" / "mpv",
            ROOT / "native_editor" / "vendor" / "mpv-mac",
            Path("/opt/homebrew/lib"),
            Path("/usr/local/lib"),
            Path("/opt/local/lib"),
        ]
        existing_dirs = [str(p) for p in search_dirs if p.exists()]
        if existing_dirs:
            joined = os.pathsep.join(existing_dirs)
            os.environ["DYLD_FALLBACK_LIBRARY_PATH"] = joined + os.pathsep + os.environ.get("DYLD_FALLBACK_LIBRARY_PATH", "")
            os.environ["DYLD_LIBRARY_PATH"] = joined + os.pathsep + os.environ.get("DYLD_LIBRARY_PATH", "")
            os.environ["PATH"] = joined + os.pathsep + os.environ.get("PATH", "")

        _orig_find = ctypes.util.find_library

        def _mac_find_library(name: str):
            found = _orig_find(name)
            if found:
                return found
            if name in ("mpv", "libmpv", "mpv.2", "libmpv.2"):
                for folder in search_dirs:
                    for fname in ("libmpv.2.dylib", "libmpv.dylib", "libmpv.1.dylib"):
                        cand = folder / fname
                        if cand.is_file():
                            return str(cand)
            return None

        ctypes.util.find_library = _mac_find_library
        _DLLS_READY = True
        return

    if d is None:
        raise FileNotFoundError("libmpv-2.dll is not bundled with this build")
    os.environ["PATH"] = str(d) + os.pathsep + os.environ.get("PATH", "")
    if hasattr(os, "add_dll_directory"):
        os.add_dll_directory(str(d))
    _DLLS_READY = True
