"""Colours, neon brand renderer, and widget styles — D'Auto Aline Cosmic Neon Studio theme."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, QSize, Qt
from PySide6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QIcon,
    QImage,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QRadialGradient,
)
from PySide6.QtWidgets import QGraphicsDropShadowEffect, QSizePolicy, QWidget

INK = "#f8f2fc"
INK_SOFT = "#dcd0e8"
MUTED = "#a695b8"
ACCENT = "#ec4899"
ACCENT_DEEP = "#db2777"
ACCENT_2 = "#c084fc"
POEM = "#e879f9"
IMAGE = "#fb7185"
VIDEO = "#f97316"
MISSING = "#ef4444"
PLAYHEAD = "#ff4d79"
CYAN = "#22d3ee"


def add_neon_glow(widget: QWidget, color_hex: str = "#ec4899", blur: int = 18, alpha: int = 115) -> None:
    """Attach a real Qt outer neon bloom shadow to a primary studio CTA or card."""
    eff = QGraphicsDropShadowEffect(widget)
    c = QColor(color_hex)
    c.setAlpha(alpha)
    eff.setColor(c)
    eff.setOffset(0, 0)
    eff.setBlurRadius(blur)
    widget.setGraphicsEffect(eff)


def render_daa_neon_image(size: int = 256) -> QImage:
    """Render a clean, minimalist geometric Neon Line 'D'AA' emblem at high DPI."""
    img = QImage(size, size, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

    s = float(size)
    pad = s * 0.055
    rect = QRectF(pad, pad, s - 2 * pad, s - 2 * pad)
    radius = s * 0.22

    # 1. Deep obsidian squircle base
    bg = QLinearGradient(rect.topLeft(), rect.bottomRight())
    bg.setColorAt(0.0, QColor("#110722"))
    bg.setColorAt(0.5, QColor("#080312"))
    bg.setColorAt(1.0, QColor("#160829"))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(bg)
    p.drawRoundedRect(rect, radius, radius)

    # 2. Crisp dual-tone neon line border (cyan -> violet -> hot pink)
    border_grad = QLinearGradient(rect.topLeft(), rect.bottomRight())
    border_grad.setColorAt(0.0, QColor("#00f0ff"))
    border_grad.setColorAt(0.5, QColor("#a855f7"))
    border_grad.setColorAt(1.0, QColor("#ff2a85"))

    glow_pen = QPen(QBrush(border_grad), max(2.0, s * 0.036))
    p.setPen(glow_pen)
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.save()
    p.setOpacity(0.28)
    p.drawRoundedRect(rect, radius, radius)
    p.restore()

    rim_pen = QPen(QBrush(border_grad), max(1.4, s * 0.018))
    p.setPen(rim_pen)
    p.drawRoundedRect(rect, radius, radius)

    # 3. Sleek geometric Neon Line Play-Wave Prism above D'AA
    prism = QPainterPath()
    prism.moveTo(s * 0.36, s * 0.20)
    prism.lineTo(s * 0.66, s * 0.34)
    prism.lineTo(s * 0.36, s * 0.48)
    prism.closeSubpath()

    wave = QPainterPath()
    wave.moveTo(s * 0.22, s * 0.34)
    wave.lineTo(s * 0.31, s * 0.34)
    wave.lineTo(s * 0.36, s * 0.25)
    wave.lineTo(s * 0.43, s * 0.43)
    wave.lineTo(s * 0.49, s * 0.30)
    wave.lineTo(s * 0.54, s * 0.34)
    wave.lineTo(s * 0.78, s * 0.34)

    p.setPen(QPen(QColor(0, 240, 255, 70), max(2.2, s * 0.042), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    p.drawPath(prism)
    p.setPen(QPen(QColor("#00f0ff"), max(1.5, s * 0.020), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    p.drawPath(prism)

    p.setPen(QPen(QColor(255, 42, 133, 80), max(2.2, s * 0.038), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    p.drawPath(wave)
    p.setPen(QPen(QColor("#ff2a85"), max(1.5, s * 0.018), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
    p.drawPath(wave)

    # 4. Crisp architectural "D'AA" typography (no muddy stroke outlines)
    font = QFont("Segoe UI", 10)
    font.setPixelSize(max(11, round(s * 0.27)))
    font.setWeight(QFont.Weight.Black)
    p.setFont(font)
    text_rect = QRectF(0, s * 0.50, s, s * 0.38)
    p.setPen(QColor(255, 42, 133, 90))
    p.drawText(text_rect.translated(0, s * 0.01), Qt.AlignmentFlag.AlignCenter, "D'AA")
    p.setPen(QColor("#ffffff"))
    p.drawText(text_rect, Qt.AlignmentFlag.AlignCenter, "D'AA")

    p.end()
    return img


def render_daa_neon_icon(size: int = 256) -> QPixmap:
    return QPixmap.fromImage(render_daa_neon_image(size))


def ensure_daa_logo_file(path: Path) -> Path:
    """Write the neon D'AA icon PNG to disk so taskbar/window icons can load it."""
    try:
        img = render_daa_neon_image(256)
        path.parent.mkdir(parents=True, exist_ok=True)
        img.save(str(path), "PNG")
    except Exception:  # noqa: BLE001
        pass
    return path


class DaaNeonBrandWidget(QWidget):
    """Sleek, razor-sharp geometric Neon Line [▷⚡ D'AA] capsule badge for the top bar."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedSize(86, 32)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.setToolTip("D'Auto Aline (D'AA) — AI Timeline Studio")

    def paintEvent(self, _event) -> None:  # noqa: N802
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)

        r = QRectF(1.0, 1.0, self.width() - 2.0, self.height() - 2.0)

        # Dark obsidian capsule fill
        bg = QLinearGradient(r.topLeft(), r.bottomRight())
        bg.setColorAt(0.0, QColor("#140828"))
        bg.setColorAt(0.5, QColor("#0a0416"))
        bg.setColorAt(1.0, QColor("#190930"))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(bg)
        p.drawRoundedRect(r, 9.0, 9.0)

        # Crisp 1.4px dual-tone neon line border (cyan -> magenta)
        b_grad = QLinearGradient(r.topLeft(), r.bottomRight())
        b_grad.setColorAt(0.0, QColor("#00f0ff"))
        b_grad.setColorAt(0.5, QColor("#a855f7"))
        b_grad.setColorAt(1.0, QColor("#ff2a85"))
        p.setPen(QPen(QBrush(b_grad), 1.4))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(r, 9.0, 9.0)

        # Left geometric neon line icon: Play-Prism + Pulse Wave
        prism = QPainterPath()
        prism.moveTo(11.5, 8.5)
        prism.lineTo(24.5, 16.0)
        prism.lineTo(11.5, 23.5)
        prism.closeSubpath()
        p.setPen(QPen(QColor(0, 240, 255, 55), 3.0, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        p.drawPath(prism)
        p.setPen(QPen(QColor("#00f0ff"), 1.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        p.drawPath(prism)

        wave = QPainterPath()
        wave.moveTo(7.5, 16.0)
        wave.lineTo(12.0, 16.0)
        wave.lineTo(14.5, 11.5)
        wave.lineTo(17.5, 20.5)
        wave.lineTo(20.0, 14.0)
        wave.lineTo(22.0, 16.0)
        wave.lineTo(27.5, 16.0)
        p.setPen(QPen(QColor("#ff2a85"), 1.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        p.drawPath(wave)

        # Right: Native ClearType crisp "D'AA" typography
        f = QFont("Segoe UI", 10)
        f.setPixelSize(14)
        f.setWeight(QFont.Weight.Black)
        p.setFont(f)
        txt_r = QRectF(31.0, 0.0, 50.0, self.height())
        p.setPen(QColor("#ffffff"))
        p.drawText(txt_r, Qt.AlignmentFlag.AlignCenter, "D'AA")
        p.end()


# High-DPI Neon Line-Based Vector Icon Engine ----------------------------------

_NEON_ICON_CACHE: dict[tuple[str, str, int], QIcon] = {}


def _build_neon_vector_path(name: str) -> tuple[QPainterPath, list[tuple[float, float, float]]]:
    """Return (stroke_path, extra_circles[(cx, cy, r)]) in a 24x24 coordinate grid."""
    path = QPainterPath()
    dots: list[tuple[float, float, float]] = []

    if name == "plus":
        path.moveTo(12, 5.0)
        path.lineTo(12, 19.0)
        path.moveTo(5.0, 12)
        path.lineTo(19.0, 12)
    elif name == "folder":
        path.moveTo(3.5, 7.5)
        path.lineTo(9.2, 7.5)
        path.lineTo(11.4, 9.8)
        path.lineTo(20.5, 9.8)
        path.lineTo(20.5, 18.5)
        path.lineTo(3.5, 18.5)
        path.closeSubpath()
    elif name == "folder_open":
        path.moveTo(3.2, 18.5)
        path.lineTo(3.2, 7.2)
        path.lineTo(9.0, 7.2)
        path.lineTo(11.0, 9.4)
        path.lineTo(19.2, 9.4)
        path.moveTo(3.2, 18.5)
        path.lineTo(6.0, 12.2)
        path.lineTo(21.2, 12.2)
        path.lineTo(18.6, 18.5)
        path.closeSubpath()
    elif name == "clock":
        path.addEllipse(QRectF(4.0, 4.0, 16.0, 16.0))
        path.moveTo(12.0, 7.6)
        path.lineTo(12.0, 12.2)
        path.lineTo(15.4, 14.2)
    elif name == "save":
        path.addRoundedRect(QRectF(4.2, 4.2, 15.6, 15.6), 2.5, 2.5)
        path.addRect(QRectF(7.8, 4.2, 8.0, 5.2))
        path.addRect(QRectF(7.2, 13.0, 9.6, 6.8))
    elif name == "script":
        path.addRoundedRect(QRectF(5.2, 3.6, 13.6, 16.8), 2.4, 2.4)
        path.moveTo(8.4, 8.5)
        path.lineTo(15.6, 8.5)
        path.moveTo(8.4, 12.2)
        path.lineTo(15.6, 12.2)
        path.moveTo(8.4, 15.9)
        path.lineTo(13.2, 15.9)
    elif name == "film":
        path.addRoundedRect(QRectF(3.8, 4.6, 16.4, 14.8), 2.4, 2.4)
        path.moveTo(7.6, 4.6)
        path.lineTo(7.6, 19.4)
        path.moveTo(16.4, 4.6)
        path.lineTo(16.4, 19.4)
        path.moveTo(3.8, 12.0)
        path.lineTo(20.2, 12.0)
        for y in (8.3, 15.7):
            path.moveTo(4.6, y)
            path.lineTo(6.8, y)
            path.moveTo(17.2, y)
            path.lineTo(19.4, y)
    elif name == "clapper":
        path.addRoundedRect(QRectF(3.6, 4.6, 16.8, 11.8), 2.4, 2.4)
        path.moveTo(10.2, 8.0)
        path.lineTo(15.0, 10.5)
        path.lineTo(10.2, 13.0)
        path.closeSubpath()
        path.moveTo(6.2, 19.4)
        path.lineTo(17.8, 19.4)
    elif name == "link":
        path.addRoundedRect(QRectF(3.6, 8.8, 9.6, 6.4), 3.2, 3.2)
        path.addRoundedRect(QRectF(10.8, 8.8, 9.6, 6.4), 3.2, 3.2)
    elif name == "refresh":
        path.arcMoveTo(QRectF(4.6, 4.6, 14.8, 14.8), 35)
        path.arcTo(QRectF(4.6, 4.6, 14.8, 14.8), 35, 285)
        path.moveTo(15.2, 4.5)
        path.lineTo(19.2, 6.2)
        path.lineTo(17.2, 10.0)
    elif name == "bolt":
        path.moveTo(13.4, 3.4)
        path.lineTo(6.2, 13.0)
        path.lineTo(11.8, 13.0)
        path.lineTo(10.4, 20.6)
        path.lineTo(17.8, 10.8)
        path.lineTo(12.2, 10.8)
        path.closeSubpath()
    elif name in ("export", "rocket"):
        path.moveTo(12.0, 16.2)
        path.lineTo(12.0, 4.4)
        path.moveTo(7.6, 8.8)
        path.lineTo(12.0, 4.4)
        path.lineTo(16.4, 8.8)
        path.moveTo(4.6, 15.2)
        path.lineTo(4.6, 19.4)
        path.lineTo(19.4, 19.4)
        path.lineTo(19.4, 15.2)
    elif name == "bell":
        path.moveTo(6.0, 16.2)
        path.lineTo(18.0, 16.2)
        path.moveTo(7.4, 16.2)
        path.lineTo(7.4, 10.6)
        path.arcTo(QRectF(7.4, 5.4, 9.2, 9.2), 180, -180)
        path.lineTo(16.6, 16.2)
        path.moveTo(10.2, 18.6)
        path.arcTo(QRectF(10.2, 17.2, 3.6, 2.8), 180, 180)
    elif name == "image":
        path.addRoundedRect(QRectF(3.8, 4.8, 16.4, 14.4), 2.4, 2.4)
        dots.append((8.6, 9.2, 1.5))
        path.moveTo(4.6, 17.6)
        path.lineTo(10.2, 12.2)
        path.lineTo(13.8, 15.4)
        path.lineTo(16.4, 13.0)
        path.lineTo(19.6, 17.6)
    elif name == "video":
        path.addRoundedRect(QRectF(3.4, 6.4, 12.2, 11.2), 2.2, 2.2)
        path.moveTo(15.6, 10.2)
        path.lineTo(20.6, 7.4)
        path.lineTo(20.6, 16.6)
        path.lineTo(15.6, 13.8)
        path.closeSubpath()
    elif name == "box":
        path.moveTo(12.0, 3.6)
        path.lineTo(19.8, 7.8)
        path.lineTo(19.8, 16.2)
        path.lineTo(12.0, 20.4)
        path.lineTo(4.2, 16.2)
        path.lineTo(4.2, 7.8)
        path.closeSubpath()
        path.moveTo(4.2, 7.8)
        path.lineTo(12.0, 12.0)
        path.lineTo(19.8, 7.8)
        path.moveTo(12.0, 12.0)
        path.lineTo(12.0, 20.4)
    elif name == "mic":
        path.addRoundedRect(QRectF(9.2, 3.8, 5.6, 9.6), 2.8, 2.8)
        path.moveTo(6.4, 11.0)
        path.arcTo(QRectF(6.4, 6.8, 11.2, 9.6), 180, 180)
        path.moveTo(12.0, 16.6)
        path.lineTo(12.0, 20.0)
        path.moveTo(8.8, 20.0)
        path.lineTo(15.2, 20.0)
    elif name == "music":
        path.moveTo(9.4, 16.8)
        path.lineTo(9.4, 6.6)
        path.lineTo(18.6, 4.8)
        path.lineTo(18.6, 15.0)
        dots.append((7.4, 16.8, 2.1))
        dots.append((16.6, 15.0, 2.1))
    elif name == "download":
        path.moveTo(12.0, 4.4)
        path.lineTo(12.0, 15.2)
        path.moveTo(7.8, 11.2)
        path.lineTo(12.0, 15.4)
        path.lineTo(16.2, 11.2)
        path.moveTo(5.0, 19.2)
        path.lineTo(19.0, 19.2)
    elif name == "swap":
        path.moveTo(4.6, 8.8)
        path.lineTo(19.4, 8.8)
        path.moveTo(15.6, 5.4)
        path.lineTo(19.4, 8.8)
        path.lineTo(15.6, 12.2)
        path.moveTo(19.4, 15.4)
        path.lineTo(4.6, 15.4)
        path.moveTo(8.4, 12.0)
        path.lineTo(4.6, 15.4)
        path.lineTo(8.4, 18.8)
    elif name == "close":
        path.moveTo(6.4, 6.4)
        path.lineTo(17.6, 17.6)
        path.moveTo(17.6, 6.4)
        path.lineTo(6.4, 17.6)
    elif name == "check":
        path.moveTo(5.0, 12.6)
        path.lineTo(9.8, 17.4)
        path.lineTo(19.2, 6.8)
    elif name == "sliders":
        for y, cx in ((7.0, 9.5), (12.0, 15.0), (17.0, 10.5)):
            path.moveTo(4.2, y)
            path.lineTo(cx - 2.2, y)
            path.moveTo(cx + 2.2, y)
            path.lineTo(19.8, y)
            dots.append((cx, y, 2.1))
    elif name == "grid":
        for rx, ry in ((4.4, 4.4), (13.2, 4.4), (4.4, 13.2), (13.2, 13.2)):
            path.addRoundedRect(QRectF(rx, ry, 6.4, 6.4), 1.5, 1.5)
    elif name == "list":
        for y in (7.0, 12.0, 17.0):
            dots.append((5.4, y, 1.1))
            path.moveTo(9.0, y)
            path.lineTo(19.4, y)
    elif name == "scan":
        for sx, sy, dx, dy in ((4.2, 8.4, 4.2, 4.2), (15.6, 4.2, 19.8, 4.2), (4.2, 15.6, 4.2, 19.8), (15.6, 19.8, 19.8, 19.8)):
            pass
        path.moveTo(4.2, 8.6)
        path.lineTo(4.2, 4.2)
        path.lineTo(8.6, 4.2)
        path.moveTo(15.4, 4.2)
        path.lineTo(19.8, 4.2)
        path.lineTo(19.8, 8.6)
        path.moveTo(4.2, 15.4)
        path.lineTo(4.2, 19.8)
        path.lineTo(8.6, 19.8)
        path.moveTo(15.4, 19.8)
        path.lineTo(19.8, 19.8)
        path.lineTo(19.8, 15.4)
        path.moveTo(6.6, 12.0)
        path.lineTo(17.4, 12.0)
    elif name == "undo":
        path.moveTo(9.0, 7.0)
        path.lineTo(4.6, 11.2)
        path.lineTo(9.0, 15.4)
        path.moveTo(5.0, 11.2)
        path.lineTo(14.4, 11.2)
        path.arcTo(QRectF(10.8, 11.2, 8.4, 7.2), 90, -180)
    elif name == "redo":
        path.moveTo(15.0, 7.0)
        path.lineTo(19.4, 11.2)
        path.lineTo(15.0, 15.4)
        path.moveTo(19.0, 11.2)
        path.lineTo(9.6, 11.2)
        path.arcTo(QRectF(4.8, 11.2, 8.4, 7.2), 90, 180)
    elif name == "trash":
        path.moveTo(4.8, 7.2)
        path.lineTo(19.2, 7.2)
        path.moveTo(9.2, 7.2)
        path.lineTo(9.2, 4.8)
        path.lineTo(14.8, 4.8)
        path.lineTo(14.8, 7.2)
        path.moveTo(6.8, 7.2)
        path.lineTo(7.6, 19.4)
        path.lineTo(16.4, 19.4)
        path.lineTo(17.2, 7.2)
        path.moveTo(10.4, 10.6)
        path.lineTo(10.4, 16.4)
        path.moveTo(13.6, 10.6)
        path.lineTo(13.6, 16.4)
    elif name == "split":
        dots.append((7.2, 7.2, 2.2))
        dots.append((7.2, 16.8, 2.2))
        path.moveTo(9.0, 8.6)
        path.lineTo(19.0, 17.6)
        path.moveTo(9.0, 15.4)
        path.lineTo(19.0, 6.4)
    elif name == "arrow_left":
        path.moveTo(18.8, 12.0)
        path.lineTo(5.4, 12.0)
        path.moveTo(10.6, 7.0)
        path.lineTo(5.4, 12.0)
        path.lineTo(10.6, 17.0)
    elif name == "arrow_right":
        path.moveTo(5.2, 12.0)
        path.lineTo(18.6, 12.0)
        path.moveTo(13.4, 7.0)
        path.lineTo(18.6, 12.0)
        path.lineTo(13.4, 17.0)
    elif name == "fit":
        path.moveTo(4.2, 6.0)
        path.lineTo(4.2, 18.0)
        path.moveTo(19.8, 6.0)
        path.lineTo(19.8, 18.0)
        path.moveTo(7.2, 12.0)
        path.lineTo(16.8, 12.0)
        path.moveTo(9.8, 9.2)
        path.lineTo(7.0, 12.0)
        path.lineTo(9.8, 14.8)
        path.moveTo(14.2, 9.2)
        path.lineTo(17.0, 12.0)
        path.lineTo(14.2, 14.8)
    elif name == "bracket_in":
        path.moveTo(15.0, 5.0)
        path.lineTo(8.4, 5.0)
        path.lineTo(8.4, 19.0)
        path.lineTo(15.0, 19.0)
    elif name == "bracket_out":
        path.moveTo(9.0, 5.0)
        path.lineTo(15.6, 5.0)
        path.lineTo(15.6, 19.0)
        path.lineTo(9.0, 19.0)
    elif name == "skip_start":
        path.moveTo(6.2, 6.2)
        path.lineTo(6.2, 17.8)
        path.moveTo(17.6, 6.4)
        path.lineTo(9.4, 12.0)
        path.lineTo(17.6, 17.6)
        path.closeSubpath()
    elif name == "step_back":
        path.moveTo(16.6, 6.2)
        path.lineTo(8.0, 12.0)
        path.lineTo(16.6, 17.8)
        path.closeSubpath()
    elif name == "play":
        path.moveTo(7.4, 5.6)
        path.lineTo(18.2, 12.0)
        path.lineTo(7.4, 18.4)
        path.closeSubpath()
    elif name == "pause":
        path.moveTo(8.6, 5.8)
        path.lineTo(8.6, 18.2)
        path.moveTo(15.4, 5.8)
        path.lineTo(15.4, 18.2)
    elif name == "step_fwd":
        path.moveTo(6.4, 6.4)
        path.lineTo(14.6, 12.0)
        path.lineTo(6.4, 17.6)
        path.closeSubpath()
        path.moveTo(17.8, 6.2)
        path.lineTo(17.8, 17.8)
    elif name == "stop":
        path.addRoundedRect(QRectF(6.4, 6.4, 11.2, 11.2), 2.0, 2.0)
    elif name == "volume":
        path.moveTo(4.6, 9.6)
        path.lineTo(8.4, 9.6)
        path.lineTo(13.2, 5.8)
        path.lineTo(13.2, 18.2)
        path.lineTo(8.4, 14.4)
        path.lineTo(4.6, 14.4)
        path.closeSubpath()
        path.arcMoveTo(QRectF(11.6, 8.2, 5.6, 7.6), -45)
        path.arcTo(QRectF(11.6, 8.2, 5.6, 7.6), -45, 90)
        path.arcMoveTo(QRectF(13.2, 5.6, 7.6, 12.8), -45)
        path.arcTo(QRectF(13.2, 5.6, 7.6, 12.8), -45, 90)
    elif name == "mute":
        path.moveTo(4.6, 9.6)
        path.lineTo(8.4, 9.6)
        path.lineTo(13.2, 5.8)
        path.lineTo(13.2, 18.2)
        path.lineTo(8.4, 14.4)
        path.lineTo(4.6, 14.4)
        path.closeSubpath()
        path.moveTo(15.8, 9.4)
        path.lineTo(20.2, 14.6)
        path.moveTo(20.2, 9.4)
        path.lineTo(15.8, 14.6)
    elif name == "cc":
        path.addRoundedRect(QRectF(3.6, 5.6, 16.8, 12.8), 2.6, 2.6)
        path.moveTo(7.2, 11.2)
        path.lineTo(16.8, 11.2)
        path.moveTo(7.2, 14.6)
        path.lineTo(14.2, 14.6)
    elif name == "type":
        path.moveTo(5.6, 6.2)
        path.lineTo(18.4, 6.2)
        path.moveTo(12.0, 6.2)
        path.lineTo(12.0, 18.6)
        path.moveTo(9.0, 18.6)
        path.lineTo(15.0, 18.6)
    elif name == "fullscreen":
        path.moveTo(4.4, 9.2)
        path.lineTo(4.4, 4.4)
        path.lineTo(9.2, 4.4)
        path.moveTo(14.8, 4.4)
        path.lineTo(19.6, 4.4)
        path.lineTo(19.6, 9.2)
        path.moveTo(19.6, 14.8)
        path.lineTo(19.6, 19.6)
        path.lineTo(14.8, 19.6)
        path.moveTo(9.2, 19.6)
        path.lineTo(4.4, 19.6)
        path.lineTo(4.4, 14.8)
    elif name == "eye":
        path.moveTo(3.2, 12.0)
        path.quadTo(12.0, 4.6, 20.8, 12.0)
        path.quadTo(12.0, 19.4, 3.2, 12.0)
        dots.append((12.0, 12.0, 2.5))
    elif name == "eye_off":
        path.moveTo(3.2, 12.0)
        path.quadTo(12.0, 4.6, 20.8, 12.0)
        path.quadTo(12.0, 19.4, 3.2, 12.0)
        path.moveTo(4.8, 19.2)
        path.lineTo(19.2, 4.8)
    elif name == "lock":
        path.addRoundedRect(QRectF(5.6, 10.6, 12.8, 9.2), 2.2, 2.2)
        path.moveTo(8.4, 10.6)
        path.lineTo(8.4, 7.8)
        path.arcTo(QRectF(8.4, 4.2, 7.2, 7.2), 180, -180)
        path.lineTo(15.6, 10.6)
    elif name == "unlock":
        path.addRoundedRect(QRectF(5.6, 10.6, 12.8, 9.2), 2.2, 2.2)
        path.moveTo(8.4, 10.6)
        path.lineTo(8.4, 7.4)
        path.arcTo(QRectF(8.4, 4.0, 7.2, 7.0), 180, -135)
    else:
        dots.append((12.0, 12.0, 4.0))

    return path, dots


def _render_neon_icon_pixmap(name: str, color_hex: str, logical_size: int, dpr: float, *, disabled: bool = False) -> QPixmap:
    px = max(12, int(round(logical_size * dpr)))
    img = QImage(px, px, QImage.Format.Format_ARGB32_Premultiplied)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)

    scale = px / 24.0
    p.scale(scale, scale)

    path, dots = _build_neon_vector_path(name)
    base = QColor(color_hex)

    if disabled:
        dim = QColor(base.red(), base.green(), base.blue(), 95)
        pen = QPen(dim, 1.7, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)
        for cx, cy, r in dots:
            p.drawEllipse(QPointF(cx, cy), r, r)
    else:
        # Subtle tight neon halo (2.5 units instead of 4.2 so 16px icons stay razor-sharp)
        glow = QColor(base.red(), base.green(), base.blue(), 38)
        p.setPen(QPen(glow, 2.5, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawPath(path)
        for cx, cy, r in dots:
            p.drawEllipse(QPointF(cx, cy), r, r)

        # Crisp high-contrast neon vector core stroke
        core = QColor(
            min(255, int(base.red() * 0.78 + 255 * 0.22)),
            min(255, int(base.green() * 0.78 + 255 * 0.22)),
            min(255, int(base.blue() * 0.78 + 255 * 0.22)),
            255,
        )
        p.setPen(QPen(core, 1.7, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin))
        p.drawPath(path)
        for cx, cy, r in dots:
            p.drawEllipse(QPointF(cx, cy), r, r)

    p.end()
    pix = QPixmap.fromImage(img)
    pix.setDevicePixelRatio(dpr)
    return pix


def neon_icon(name: str, color: str = "#f472b6", size: int = 16) -> QIcon:
    """Return a cached multi-DPI (1x, 1.5x, 2x, 3x) razor-sharp neon line-art QIcon."""
    key = (name, color, size)
    cached = _NEON_ICON_CACHE.get(key)
    if cached is not None:
        return cached
    icon = QIcon()
    for dpr in (1.0, 1.5, 2.0, 3.0):
        norm = _render_neon_icon_pixmap(name, color, size, dpr, disabled=False)
        dis = _render_neon_icon_pixmap(name, color, size, dpr, disabled=True)
        icon.addPixmap(norm, QIcon.Mode.Normal, QIcon.State.Off)
        icon.addPixmap(norm, QIcon.Mode.Active, QIcon.State.Off)
        icon.addPixmap(norm, QIcon.Mode.Selected, QIcon.State.Off)
        icon.addPixmap(dis, QIcon.Mode.Disabled, QIcon.State.Off)
    _NEON_ICON_CACHE[key] = icon
    return icon


def set_btn_neon_icon(btn: QWidget, name: str, color: str = "#f472b6", size: int = 16) -> None:
    """Attach a crisp high-DPI neon line icon to a QPushButton or QToolButton."""
    if hasattr(btn, "setIcon"):
        btn.setIcon(neon_icon(name, color, size))  # type: ignore[attr-defined]
    if hasattr(btn, "setIconSize"):
        btn.setIconSize(QSize(size, size))  # type: ignore[attr-defined]


QSS = f"""
* {{
    font-family: "Segoe UI", -apple-system, "SF Pro Text", "Helvetica Neue", "Nirmala UI";
    font-size: 12px;
    color: {INK};
}}
QMainWindow, #Root {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 #080410, stop:0.45 #110820, stop:1 #190a2a);
}}
#Panel {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
        stop:0 rgba(28, 16, 48, 0.92), stop:1 rgba(13, 7, 25, 0.96));
    border: 1px solid rgba(192, 132, 252, 0.30);
    border-radius: 14px;
}}
#TopBar {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(30, 15, 52, 0.96), stop:0.5 rgba(20, 10, 38, 0.96), stop:1 rgba(34, 14, 50, 0.96));
    border: 1px solid rgba(236, 72, 153, 0.42);
    border-bottom: 2px solid rgba(236, 72, 153, 0.68);
    border-radius: 14px;
}}
#TopCapsule {{
    background: rgba(12, 6, 24, 0.62);
    border: 1px solid rgba(192, 132, 252, 0.24);
    border-radius: 11px;
}}
#CapsuleTag {{
    color: rgba(192, 132, 252, 0.85);
    font-size: 9px;
    font-weight: 800;
    letter-spacing: 1px;
    padding: 0 3px;
}}
#BrandTitle {{
    font-size: 15px;
    font-weight: 800;
    color: #ffffff;
}}
#BrandSub {{
    color: #c084fc;
    font-size: 10px;
    font-weight: 600;
}}
#PanelTitle {{
    font-size: 12px;
    font-weight: 700;
    color: #f3e8ff;
    text-transform: uppercase;
}}
#Muted {{ color: {MUTED}; }}
#SpecKey {{
    color: {MUTED};
    font-size: 11px;
    font-weight: 600;
}}
#SpecVal {{
    font-weight: 700;
    color: {INK};
    font-size: 12px;
}}
#SpecCardPink {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 rgba(236, 72, 153, 0.22), stop:1 rgba(22, 11, 38, 0.90));
    border: 1px solid rgba(236, 72, 153, 0.52);
    border-radius: 10px;
}}
#SpecCardAmber {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 rgba(245, 158, 11, 0.22), stop:1 rgba(22, 11, 38, 0.90));
    border: 1px solid rgba(245, 158, 11, 0.52);
    border-radius: 10px;
}}
#SpecCardCyan {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 rgba(34, 211, 238, 0.22), stop:1 rgba(22, 11, 38, 0.90));
    border: 1px solid rgba(34, 211, 238, 0.52);
    border-radius: 10px;
}}
#SpecCardPurple {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 rgba(168, 85, 247, 0.24), stop:1 rgba(22, 11, 38, 0.90));
    border: 1px solid rgba(192, 132, 252, 0.52);
    border-radius: 10px;
}}
#StatusLine {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(22, 12, 38, 0.92), stop:1 rgba(16, 9, 30, 0.92));
    border: 1px solid rgba(192, 132, 252, 0.26);
    border-radius: 10px;
    padding: 5px 12px;
    color: {INK_SOFT};
}}
#NeonToast {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 rgba(34, 16, 60, 0.97), stop:0.6 rgba(22, 11, 42, 0.97), stop:1 rgba(40, 14, 54, 0.97));
    border: 1.5px solid rgba(34, 211, 238, 0.78);
    border-radius: 13px;
}}
#NeonToastTitle {{
    font-size: 13px;
    font-weight: 800;
    color: #ffffff;
}}
#NeonToastBody {{
    font-size: 12px;
    font-weight: 600;
    color: #e2d4f0;
}}
QPushButton, QToolButton {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
        stop:0 rgba(48, 30, 78, 0.88), stop:1 rgba(26, 15, 46, 0.94));
    border: 1px solid rgba(192, 132, 252, 0.28);
    border-radius: 8px;
    padding: 4px 10px;
    font-weight: 600;
    color: {INK};
}}
QPushButton:hover, QToolButton:hover {{
    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
        stop:0 rgba(74, 44, 118, 0.95), stop:1 rgba(44, 26, 74, 0.98));
    border: 1px solid rgba(236, 72, 153, 0.65);
    color: #ffffff;
}}
QPushButton:pressed, QToolButton:pressed {{
    background: rgba(236, 72, 153, 0.32);
    border: 1px solid rgba(236, 72, 153, 0.85);
}}
QPushButton:checked, QToolButton:checked {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(34, 211, 238, 0.25), stop:1 rgba(168, 85, 247, 0.26));
    border: 1px solid rgba(34, 211, 238, 0.72);
    color: #a5f3fc;
}}
QPushButton:disabled, QToolButton:disabled {{
    background: rgba(25, 18, 38, 0.45);
    border-color: rgba(255, 255, 255, 0.07);
    color: rgba(248, 242, 252, 0.32);
}}
QPushButton#Primary {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #ec4899, stop:0.5 #d946ef, stop:1 #f43f5e);
    border: 1px solid rgba(255, 210, 240, 0.78);
    color: #ffffff;
    font-weight: 800;
    letter-spacing: 0.2px;
}}
QPushButton#Primary:hover {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 #f472b6, stop:0.5 #e879f9, stop:1 #fb7185);
    border: 1px solid #ffffff;
}}
QPushButton#NeonCyan {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(6, 182, 212, 0.36), stop:0.5 rgba(59, 130, 246, 0.34), stop:1 rgba(168, 85, 247, 0.36));
    border: 1px solid rgba(34, 211, 238, 0.78);
    color: #ecfeff;
    font-weight: 800;
    letter-spacing: 0.2px;
}}
QPushButton#NeonCyan:hover {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(34, 211, 238, 0.52), stop:1 rgba(168, 85, 247, 0.48));
    border: 1px solid #a5f3fc;
    color: #ffffff;
}}
QPushButton#Accent {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(236, 72, 153, 0.24), stop:1 rgba(168, 85, 247, 0.26));
    border: 1px solid rgba(236, 72, 153, 0.62);
    color: #fbcfe8;
    font-weight: 700;
}}
QPushButton#Accent:hover {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(236, 72, 153, 0.38), stop:1 rgba(168, 85, 247, 0.40));
    border: 1px solid rgba(244, 114, 182, 0.90);
    color: #ffffff;
}}
QPushButton#VoLinkBtn {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(34, 211, 238, 0.16), stop:1 rgba(59, 130, 246, 0.14));
    border: 1px solid rgba(34, 211, 238, 0.50);
    border-radius: 8px;
    padding: 3px 8px;
    text-align: left;
    color: #e0f2fe;
    font-weight: 600;
}}
QPushButton#VoLinkBtn:hover {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(34, 211, 238, 0.28), stop:1 rgba(168, 85, 247, 0.24));
    border: 1px solid rgba(103, 232, 249, 0.85);
    color: #ffffff;
}}
QPushButton#VoLinkMissing {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(245, 158, 11, 0.18), stop:1 rgba(236, 72, 153, 0.16));
    border: 1px dashed rgba(251, 191, 36, 0.65);
    border-radius: 8px;
    padding: 3px 8px;
    text-align: left;
    color: #fde68a;
    font-weight: 700;
}}
QPushButton#VoLinkMissing:hover {{
    background: rgba(245, 158, 11, 0.28);
    border: 1px solid #fbbf24;
    color: #ffffff;
}}
QPushButton#Pill {{
    border-radius: 10px;
    padding: 3px 10px;
    font-size: 11px;
    font-weight: 600;
}}
QPushButton#Pill:checked {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(236, 72, 153, 0.34), stop:1 rgba(168, 85, 247, 0.34));
    border: 1px solid rgba(244, 114, 182, 0.80);
    color: #ffe4f3;
}}
QPushButton#IconSquare {{
    padding: 0px;
    font-size: 12px;
    font-weight: 700;
    border-radius: 7px;
}}
QToolButton#Accordion {{
    background: rgba(168, 85, 247, 0.14);
    border: 1px solid rgba(192, 132, 252, 0.30);
    border-radius: 8px;
    padding: 4px 8px;
    font-weight: 700;
    color: #f3e8ff;
}}
QToolButton#Accordion:hover {{
    background: rgba(236, 72, 153, 0.22);
    border-color: rgba(236, 72, 153, 0.58);
}}
QToolButton#Track {{
    padding: 0;
    border-radius: 6px;
    min-width: 22px; max-width: 22px;
    min-height: 20px; max-height: 20px;
    font-size: 11px;
}}
QToolButton#Track:checked {{
    background: rgba(236, 72, 153, 0.28);
    border-color: rgba(236, 72, 153, 0.68);
    color: #ffd0e8;
}}
QTabWidget::pane {{ border: 0; }}
QTabBar::tab {{
    background: rgba(255, 255, 255, 0.04);
    border: 1px solid rgba(192, 132, 252, 0.18);
    color: {INK_SOFT};
    padding: 6px 12px;
    margin-right: 5px;
    border-radius: 8px;
    font-weight: 600;
}}
QTabBar::tab:hover {{
    background: rgba(236, 72, 153, 0.16);
    border-color: rgba(236, 72, 153, 0.44);
}}
QTabBar::tab:selected {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(236, 72, 153, 0.34), stop:1 rgba(168, 85, 247, 0.34));
    border: 1px solid rgba(244, 114, 182, 0.72);
    color: #ffffff;
}}
QListWidget, QTextEdit, QPlainTextEdit {{
    background: rgba(8, 4, 16, 0.58);
    border: 1px solid rgba(192, 132, 252, 0.20);
    border-radius: 10px;
    padding: 4px;
}}
QListWidget::item {{
    padding: 4px 5px;
    border-radius: 8px;
    border: 1px solid transparent;
}}
QListWidget::item:selected {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
        stop:0 rgba(236, 72, 153, 0.30), stop:1 rgba(168, 85, 247, 0.26));
    border: 1px solid rgba(244, 114, 182, 0.75);
    color: #ffffff;
}}
QListWidget::item:hover {{
    background: rgba(192, 132, 252, 0.14);
    border: 1px solid rgba(192, 132, 252, 0.32);
}}
QSlider::groove:horizontal {{
    height: 5px;
    background: rgba(255, 255, 255, 0.14);
    border-radius: 2px;
}}
QSlider::sub-page:horizontal {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ec4899, stop:1 #22d3ee);
    border-radius: 2px;
}}
QSlider::handle:horizontal {{
    background: #ffffff;
    border: 2px solid #ec4899;
    width: 12px;
    margin: -5px 0;
    border-radius: 7px;
}}
QScrollBar:vertical {{ background: transparent; width: 8px; }}
QScrollBar:horizontal {{ background: transparent; height: 8px; }}
QScrollBar::handle {{
    background: rgba(192, 132, 252, 0.28);
    border-radius: 4px;
    min-height: 24px;
    min-width: 24px;
}}
QScrollBar::handle:hover {{ background: rgba(236, 72, 153, 0.55); }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
/* Timeline lane scroller — taller track + clearer grip so it is easy to drag. */
QScrollBar#TimelineHBar {{
    background: rgba(255, 255, 255, 0.07);
    border: 1px solid rgba(192, 132, 252, 0.20);
    border-radius: 8px;
    height: 16px;
    margin: 2px 0 0 0;
}}
QScrollBar#TimelineHBar::handle:horizontal {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(236, 72, 153, 0.60), stop:1 rgba(168, 85, 247, 0.60));
    border: 1px solid rgba(255, 255, 255, 0.35);
    border-radius: 7px;
    min-width: 48px;
}}
QScrollBar#TimelineHBar::handle:horizontal:hover {{
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 rgba(244, 114, 182, 0.85), stop:1 rgba(192, 132, 252, 0.85));
}}
QScrollBar#TimelineHBar::add-page:horizontal,
QScrollBar#TimelineHBar::sub-page:horizontal {{
    background: transparent;
}}
QMenu {{
    background: #140b24;
    border: 1px solid rgba(236, 72, 153, 0.42);
    border-radius: 8px;
    padding: 4px;
}}
QMenu::item {{ padding: 6px 18px; border-radius: 6px; }}
QMenu::item:selected {{ background: rgba(236, 72, 153, 0.30); }}
QSplitter::handle {{ background: transparent; }}
QDoubleSpinBox, QComboBox, QLineEdit {{
    background: rgba(12, 7, 24, 0.68);
    border: 1px solid rgba(192, 132, 252, 0.30);
    border-radius: 8px;
    padding: 4px 8px;
    font-weight: 600;
}}
QComboBox:hover {{ border-color: rgba(236, 72, 153, 0.58); }}
QToolTip {{
    background: #160c28;
    color: {INK};
    border: 1px solid rgba(236, 72, 153, 0.45);
    padding: 4px 6px;
}}
"""


def reveal_in_explorer(file_or_dir: str | Path) -> None:
    """Open Windows Explorer / Finder highlighting the file or opening the folder."""
    import subprocess
    import sys

    from PySide6.QtCore import QUrl
    from PySide6.QtGui import QDesktopServices

    p = Path(file_or_dir)
    try:
        if sys.platform == "win32":
            if p.is_file():
                subprocess.Popen(["explorer", f"/select,{p.resolve()}"])
                return
            if p.is_dir():
                subprocess.Popen(["explorer", str(p.resolve())])
                return
            if p.parent.is_dir():
                subprocess.Popen(["explorer", str(p.parent.resolve())])
                return
        target = p if p.is_dir() else p.parent
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(target)))
    except Exception:  # noqa: BLE001
        pass


class NeonToast(QWidget):
    """Floating Cosmic Neon toast notification banner anchored at the top-right of the studio."""

    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        from PySide6.QtCore import QTimer
        from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setVisible(False)
        self._file_path: str = ""
        self._border_col = "#22d3ee"

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        self.card = QFrame(self)
        self.card.setObjectName("NeonToast")
        lay = QHBoxLayout(self.card)
        lay.setContentsMargins(14, 10, 12, 10)
        lay.setSpacing(10)

        self.icon_lbl = QLabel()
        self.icon_lbl.setStyleSheet("background: transparent;")
        self.icon_lbl.setFixedSize(26, 26)
        self.icon_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self.icon_lbl)

        text_col = QVBoxLayout()
        text_col.setContentsMargins(0, 0, 0, 0)
        text_col.setSpacing(2)
        self.title_lbl = QLabel("")
        self.title_lbl.setObjectName("NeonToastTitle")
        self.title_lbl.setStyleSheet("background: transparent;")
        self.body_lbl = QLabel("")
        self.body_lbl.setObjectName("NeonToastBody")
        self.body_lbl.setWordWrap(True)
        self.body_lbl.setStyleSheet("background: transparent;")
        text_col.addWidget(self.title_lbl)
        text_col.addWidget(self.body_lbl)
        lay.addLayout(text_col, 1)

        self.open_btn = QPushButton("Show in Folder")
        set_btn_neon_icon(self.open_btn, "folder_open", "#22d3ee", 15)
        self.open_btn.setObjectName("NeonCyan")
        self.open_btn.setFixedHeight(28)
        self.open_btn.clicked.connect(self._on_open_folder)
        self.open_btn.setVisible(False)
        lay.addWidget(self.open_btn)

        self.close_btn = QPushButton("")
        set_btn_neon_icon(self.close_btn, "close", "#f472b6", 13)
        self.close_btn.setObjectName("IconSquare")
        self.close_btn.setFixedSize(24, 24)
        self.close_btn.setToolTip("Dismiss notification")
        self.close_btn.clicked.connect(self.hide_toast)
        lay.addWidget(self.close_btn)

        outer.addWidget(self.card)
        add_neon_glow(self.card, "#22d3ee", blur=24, alpha=140)

        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self.hide_toast)

    def show_toast(
        self,
        title: str,
        message: str,
        *,
        kind: str = "success",
        file_path: str | None = None,
        duration_ms: int = 6500,
        chime: bool = True,
    ) -> None:
        from PySide6.QtWidgets import QApplication

        palette = {
            "success": ("check", "#22d3ee", "rgba(34, 211, 238, 0.85)"),
            "export": ("export", "#ec4899", "rgba(236, 72, 153, 0.90)"),
            "info": ("bolt", "#c084fc", "rgba(192, 132, 252, 0.85)"),
            "warn": ("bell", "#f59e0b", "rgba(245, 158, 11, 0.85)"),
        }
        icon_name, glow_hex, border_rgba = palette.get(kind, palette["success"])
        self.icon_lbl.setPixmap(_render_neon_icon_pixmap(icon_name, glow_hex, 22, 2.0))
        self.title_lbl.setText(title)
        self.body_lbl.setText(message)
        self._file_path = str(file_path or "").strip()
        self.open_btn.setVisible(bool(self._file_path))
        self.card.setStyleSheet(
            f"#NeonToast {{"
            f" background: qlineargradient(x1:0, y1:0, x2:1, y2:1,"
            f" stop:0 rgba(36, 16, 64, 0.98), stop:0.55 rgba(20, 10, 40, 0.98), stop:1 rgba(44, 15, 58, 0.98));"
            f" border: 1.5px solid {border_rgba};"
            f" border-radius: 13px;"
            f"}}"
        )
        add_neon_glow(self.card, glow_hex, blur=24, alpha=145)
        self.reposition()
        self.setVisible(True)
        self.raise_()
        if chime:
            try:
                QApplication.beep()
            except Exception:  # noqa: BLE001
                pass
        self._timer.start(max(2500, duration_ms))

    def reposition(self) -> None:
        p = self.parentWidget()
        if p is None:
            return
        w = min(500, max(360, int(p.width() * 0.34)))
        self.setFixedWidth(w)
        self.adjustSize()
        h = max(68, self.sizeHint().height())
        self.resize(w, h)
        x = max(16, p.width() - w - 20)
        y = 66
        self.move(x, y)

    def _on_open_folder(self) -> None:
        if self._file_path:
            reveal_in_explorer(self._file_path)

    def hide_toast(self) -> None:
        self._timer.stop()
        self.setVisible(False)


class NeonCompletionDialog(QWidget):
    """Show a sleek Cosmic Neon modal completion dialog when an Export or major milestone finishes."""

    @staticmethod
    def show_modal(
        parent: QWidget,
        title: str,
        message: str,
        *,
        file_path: str | None = None,
    ) -> None:
        from PySide6.QtCore import QUrl
        from PySide6.QtGui import QDesktopServices
        from PySide6.QtWidgets import QDialog, QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout

        dlg = QDialog(parent)
        dlg.setWindowTitle(f"D'Auto Aline — {title}")
        dlg.setModal(True)
        dlg.setMinimumWidth(460)
        dlg.setStyleSheet(
            """
            QDialog {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                    stop:0 #120722, stop:0.5 #1b0b30, stop:1 #240c3a);
                color: #f8f2fc;
            }
            QFrame#Card {
                background: rgba(28, 14, 48, 0.92);
                border: 1.5px solid rgba(236, 72, 153, 0.58);
                border-radius: 14px;
            }
            """
        )
        root = QVBoxLayout(dlg)
        root.setContentsMargins(16, 16, 16, 16)
        card = QFrame()
        card.setObjectName("Card")
        cl = QVBoxLayout(card)
        cl.setContentsMargins(18, 16, 18, 16)
        cl.setSpacing(12)

        top = QHBoxLayout()
        top.setSpacing(12)
        badge = QLabel()
        badge.setPixmap(render_daa_neon_icon(52))
        badge.setFixedSize(52, 52)
        top.addWidget(badge)

        tcol = QVBoxLayout()
        tcol.setSpacing(3)
        hl = QLabel(title)
        hl.setStyleSheet("font-size: 16px; font-weight: 800; color: #ffffff;")
        sub = QLabel("D'Auto Aline · Render & Export Engine")
        sub.setStyleSheet("font-size: 11px; font-weight: 600; color: #67e8f9;")
        tcol.addWidget(hl)
        tcol.addWidget(sub)
        top.addLayout(tcol, 1)
        cl.addLayout(top)

        body = QLabel(message)
        body.setWordWrap(True)
        body.setStyleSheet(
            "font-size: 12.5px; color: #f3e8ff; background: rgba(8, 4, 16, 0.55); "
            "border: 1px solid rgba(192, 132, 252, 0.25); border-radius: 9px; padding: 10px;"
        )
        cl.addWidget(body)

        btns = QHBoxLayout()
        btns.setSpacing(8)
        btns.addStretch(1)
        fp = str(file_path or "").strip()
        if fp:
            folder_btn = QPushButton("Show in Folder")
            set_btn_neon_icon(folder_btn, "folder_open", "#22d3ee", 15)
            folder_btn.setObjectName("NeonCyan")
            folder_btn.setFixedHeight(32)
            folder_btn.clicked.connect(lambda: reveal_in_explorer(fp))
            btns.addWidget(folder_btn)
            if Path(fp).is_file():
                open_file_btn = QPushButton("Open File")
                set_btn_neon_icon(open_file_btn, "play", "#f472b6", 15)
                open_file_btn.setFixedHeight(32)
                open_file_btn.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path(fp).resolve()))))
                btns.addWidget(open_file_btn)
        ok_btn = QPushButton("Done")
        set_btn_neon_icon(ok_btn, "check", "#ffffff", 15)
        ok_btn.setObjectName("Primary")
        ok_btn.setFixedHeight(32)
        ok_btn.setMinimumWidth(96)
        ok_btn.clicked.connect(dlg.accept)
        btns.addWidget(ok_btn)
        cl.addLayout(btns)
        root.addWidget(card)
        dlg.exec()


