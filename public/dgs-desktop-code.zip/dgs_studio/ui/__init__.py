"""Windows and panels."""
