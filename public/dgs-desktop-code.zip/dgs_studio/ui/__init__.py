"""Windows and panels."""
