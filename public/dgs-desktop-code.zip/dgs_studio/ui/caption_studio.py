"""Video, logo and SRT.

Filmora's auto-caption tool imports a clip, lets you place a watermark, and
lists the speech as editable subtitle rows. This window does that with the
DGS logo and the English or Marathi speech module. The rows are written to
an SRT file. They are shown in this preview only, never on the exported picture.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QFontMetricsF, QPainter, QPixmap
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QFileDialog,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QMessageBox,
    QPushButton,
    QSlider,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import paths
from ..core.caption_video import (
    export_command,
    fitted_frame,
    format_srt,
    format_srt_time,
    hear,
    next_free_pair,
    parse_srt_time,
    probe_video,
    words_to_cues,
)
from ..core.plan import logo_box
from ..core.project_store import DEFAULT_LOGO_TRANSFORM, IMAGE_EXT, VIDEO_EXT

paths.prepare_dlls()
import mpv  # noqa: E402


def _filter(exts: set[str], label: str) -> str:
    return f"{label} (" + " ".join(f"*{e}" for e in sorted(exts)) + ")"


class _HearThread(QThread):
    ready = Signal(list)
    failed = Signal(str)

    def __init__(self, video: Path, language: str) -> None:
        super().__init__()
        self.video = video
        self.language = language

    def run(self) -> None:
        try:
            self.ready.emit(words_to_cues(hear(self.video, self.language)))
        except Exception as exc:
            self.failed.emit(str(exc) or "Speech detection failed")


class _ExportThread(QThread):
    progress = Signal(int)
    ready = Signal(str, str)
    failed = Signal(str)

    def __init__(self, command: list[str], duration: float, video_out: Path, srt_text: str, srt_out: Path) -> None:
        super().__init__()
        self.command = command
        self.duration = max(0.1, duration)
        self.video_out = video_out
        self.srt_text = srt_text
        self.srt_out = srt_out

    def run(self) -> None:
        try:
            self.srt_out.write_text(self.srt_text, encoding="utf-8")
            proc = subprocess.Popen(
                self.command,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
            )
            assert proc.stdout is not None
            tail = ""
            for line in proc.stdout:
                tail = line.strip() or tail
                if line.startswith("out_time_ms="):
                    try:
                        ms = int(line.split("=", 1)[1])
                    except ValueError:
                        continue
                    self.progress.emit(min(99, int((ms / 1_000_000) / self.duration * 100)))
            code = proc.wait()
            if code != 0 or not self.video_out.is_file():
                raise RuntimeError(tail or "The video could not be written")
            self.progress.emit(100)
            self.ready.emit(str(self.video_out), str(self.srt_out))
        except Exception as exc:
            self.failed.emit(str(exc) or "Export failed")


class VideoLogoView(QOpenGLWidget):
    """One imported video, with the logo and a preview caption painted by Qt."""

    frame_ready = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setMinimumSize(480, 270)
        self.setMouseTracking(True)
        self.frame_ready.connect(self.update, Qt.ConnectionType.QueuedConnection)
        self.player = mpv.MPV(
            vo="libmpv",
            hwdec=os.environ.get("DGS_HWDEC", "no"),
            keep_open="yes",
            keepaspect="yes",
            panscan="0",
            idle="yes",
            pause=True,
            sid="no",
            sub_auto="no",
            osc="no",
            ytdl="no",
            config="no",
            load_scripts="no",
            input_default_bindings="no",
            terminal="no",
        )
        self._ctx = None
        self._proc = mpv.MpvGlGetProcAddressFn(self._proc_address)
        self.path = ""
        self.note = "Import a video"
        self.logo_on = True
        self.logo_pix: QPixmap | None = None
        self.logo_transform = dict(DEFAULT_LOGO_TRANSFORM)
        self.frame_w = 0
        self.frame_h = 0
        self._logo_cache = None
        self._logo_key = None
        self.caption = ""
        self.show_caption = True
        self._logo_rect = QRectF()

    @staticmethod
    def _proc_address(_ctx, name):
        from PySide6.QtGui import QOpenGLContext

        glctx = QOpenGLContext.currentContext()
        if glctx is None:
            return 0
        return int(glctx.getProcAddress(name))

    def initializeGL(self) -> None:
        self._ctx = mpv.MpvRenderContext(
            self.player, "opengl", opengl_init_params={"get_proc_address": self._proc},
        )
        self._ctx.update_cb = self.frame_ready.emit

    def paintGL(self) -> None:
        drew = False
        if self._ctx is not None and self.path:
            dpr = self.devicePixelRatioF()
            self._ctx.render(
                flip_y=True,
                opengl_fbo={
                    "w": int(self.width() * dpr),
                    "h": int(self.height() * dpr),
                    "fbo": self.defaultFramebufferObject(),
                },
            )
            drew = True
        p = QPainter(self)
        if not drew:
            p.fillRect(self.rect(), QColor("#050407"))
            p.setPen(QColor("#d4c2d0"))
            p.setFont(QFont("Segoe UI", 13))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.note)
        self._paint_caption(p)
        self._paint_logo(p)
        p.end()

    def shutdown(self) -> None:
        try:
            self.makeCurrent()
        except Exception:
            try:
                self.player.terminate()
            except Exception:
                pass
            return
        if self._ctx is not None:
            self._ctx.free()
            self._ctx = None
        self.doneCurrent()
        try:
            self.player.terminate()
        except Exception:
            pass

    def load(self, path: str) -> None:
        self.path = path
        self.note = ""
        self.player.loadfile(path, "replace")
        self.player.pause = True
        self.update()

    def set_logo_file(self, file: str) -> None:
        pix = QPixmap(file) if file else QPixmap()
        self.logo_pix = pix if not pix.isNull() else None
        self._logo_cache = None
        self._logo_key = None
        self.update()

    def set_frame_size(self, width: int, height: int) -> None:
        """The uploaded video's real frame. The logo is placed inside this, not the window."""
        self.frame_w = int(width)
        self.frame_h = int(height)
        self.logo_transform = dict(DEFAULT_LOGO_TRANSFORM)
        stage = self.parent()
        if isinstance(stage, VideoStage):
            stage.place()
        self.update()

    def _frame_rect(self) -> QRectF:
        # This view is already the 16:9 frame. The logo is locked to that frame.
        return QRectF(0, 0, self.width(), self.height())

    def _sharp_logo(self, w: float, h: float):
        dpr = max(1.0, float(self.devicePixelRatioF() or 1))
        tw = max(1, int(round(w * dpr)))
        th = max(1, int(round(h * dpr)))
        key = (self.logo_pix.cacheKey(), tw, th)
        if self._logo_key == key and self._logo_cache is not None:
            return self._logo_cache
        scaled = self.logo_pix.scaled(
            tw, th,
            Qt.AspectRatioMode.IgnoreAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        image = scaled.toImage()
        image.setDevicePixelRatio(dpr)
        self._logo_key = key
        self._logo_cache = image
        return image

    def _paint_logo(self, p: QPainter) -> None:
        self._logo_rect = QRectF()
        if not self.logo_on or self.logo_pix is None:
            return
        frame = self._frame_rect()
        left, top, w, h = logo_box(
            DEFAULT_LOGO_TRANSFORM, frame.width(), frame.height(), self.logo_pix.width(), self.logo_pix.height(),
        )
        dpr = max(1.0, float(self.devicePixelRatioF() or 1))
        left = round((frame.left() + left) * dpr) / dpr
        top = round((frame.top() + top) * dpr) / dpr
        image = self._sharp_logo(w, h)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, False)
        p.drawImage(QPointF(left, top), image)
        self._logo_rect = QRectF(left, top, w, h)

    def _paint_caption(self, p: QPainter) -> None:
        if not self.show_caption or not self.caption:
            return
        frame = self._frame_rect()
        w, h = frame.width(), frame.height()
        font = QFont("Nirmala UI")
        font.setWeight(QFont.Weight.Thin)
        font.setPixelSize(max(10, int(h * 0.026)))
        p.setFont(font)
        fm = QFontMetricsF(font)
        box_w = w * 0.72
        flags = Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignBottom | Qt.TextFlag.TextWordWrap
        rect = fm.boundingRect(QRectF(0, 0, box_w, h), Qt.AlignmentFlag.AlignHCenter | Qt.TextFlag.TextWordWrap, self.caption)
        rect.setHeight(rect.height() + fm.descent() + fm.leading() + 4)
        bottom = frame.bottom() - 8
        top = max(frame.top() + 8, bottom - rect.height())
        rect = QRectF(frame.left() + (w - box_w) / 2, top, box_w, bottom - top)
        p.fillRect(rect.adjusted(-8, -3, 8, 3), QColor(0, 0, 0, 210))
        p.setPen(QColor("#ffffff"))
        p.drawText(rect, flags, self.caption)


class VideoStage(QWidget):
    """The preview canvas is the video's own shape, the way Filmora's player is the frame."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setMinimumHeight(240)
        self.setStyleSheet("background: #050407;")
        self.view = VideoLogoView(self)

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self.place()

    def place(self) -> None:
        # Filmora's open project frame is 16:9. The video is fitted inside it.
        x, y, w, h = fitted_frame(self.width(), self.height(), 16, 9)
        self.view.setGeometry(int(round(x)), int(round(y)), max(2, int(round(w))), max(2, int(round(h))))


class CaptionStudio(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Root")
        self.setWindowFlag(Qt.WindowType.Window, True)
        self.setAttribute(Qt.WidgetAttribute.WA_DeleteOnClose, True)
        self.setWindowTitle("Video, Logo & SRT")
        self.resize(1080, 760)
        self.video: Path | None = None
        self.size_info: dict = {}
        self.logo = paths.default_logo()
        self._hear: _HearThread | None = None
        self._export: _ExportThread | None = None
        self._export_after = False
        self._sliding = False

        root = QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(8)
        title = QLabel("Video, Logo & SRT")
        title.setObjectName("BrandTitle")
        root.addWidget(title)
        note = QLabel(
            "The frame is 16:9, the same as Filmora. The video keeps its shape inside that frame. "
            "The logo stays locked in the Filmora corner. Export writes a 1920×1080 video with the logo, and a separate SRT."
        )
        note.setObjectName("Muted")
        note.setWordWrap(True)
        root.addWidget(note)

        tools = QHBoxLayout()
        self.btn_import = QPushButton("Import Video…")
        self.btn_import.setObjectName("Primary")
        self.btn_import.clicked.connect(self.import_video)
        tools.addWidget(self.btn_import)
        self.logo_box = QCheckBox("Logo")
        self.logo_box.setChecked(True)
        self.logo_box.toggled.connect(self._on_logo)
        tools.addWidget(self.logo_box)
        self.btn_logo = QPushButton("Change Logo…")
        self.btn_logo.clicked.connect(self.change_logo)
        tools.addWidget(self.btn_logo)
        self.btn_reset = QPushButton("Reset Logo")
        self.btn_reset.clicked.connect(self.reset_logo)
        tools.addWidget(self.btn_reset)
        tools.addStretch(1)
        tools.addWidget(QLabel("Speech"))
        self.lang = QComboBox()
        self.lang.addItem("English", "en")
        self.lang.addItem("Marathi", "mr")
        self.lang.setToolTip("English uses the English speech module. Marathi uses the Marathi speech module.")
        tools.addWidget(self.lang)
        self.btn_hear = QPushButton("Detect Speech")
        self.btn_hear.setObjectName("Accent")
        self.btn_hear.clicked.connect(self.detect)
        tools.addWidget(self.btn_hear)
        root.addLayout(tools)

        self.stage = VideoStage()
        self.view = self.stage.view
        if self.logo:
            self.view.set_logo_file(str(self.logo))
        root.addWidget(self.stage, 1)

        play = QHBoxLayout()
        self.btn_play = QPushButton("Play")
        self.btn_play.clicked.connect(self.toggle_play)
        play.addWidget(self.btn_play)
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(0, 0)
        self.slider.sliderPressed.connect(self._slider_down)
        self.slider.sliderReleased.connect(self._slider_up)
        play.addWidget(self.slider, 1)
        self.time_label = QLabel("0:00 / 0:00")
        self.time_label.setObjectName("Muted")
        play.addWidget(self.time_label)
        self.preview_captions = QCheckBox("Show captions in the preview")
        self.preview_captions.setChecked(True)
        self.preview_captions.toggled.connect(self._on_preview_captions)
        play.addWidget(self.preview_captions)
        root.addLayout(play)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Start", "End", "Text"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.itemChanged.connect(self._on_item)
        self.table.itemSelectionChanged.connect(self._on_row)
        self.table.setStyleSheet(
            "QTableWidget { background: rgba(0,0,0,0.28); gridline-color: rgba(255,255,255,0.08); }"
            "QHeaderView::section { background: #1c1420; color: #f6eef4; padding: 4px; border: 0; }"
        )
        root.addWidget(self.table, 1)

        bottom = QHBoxLayout()
        self.btn_remove = QPushButton("Remove Line")
        self.btn_remove.clicked.connect(self.remove_line)
        bottom.addWidget(self.btn_remove)
        bottom.addStretch(1)
        self.btn_export = QPushButton("Export logo video and SRT")
        self.btn_export.setObjectName("Primary")
        self.btn_export.clicked.connect(self.export)
        bottom.addWidget(self.btn_export)
        root.addLayout(bottom)
        self.status = QLabel("Import a video to begin.")
        self.status.setObjectName("StatusLine")
        root.addWidget(self.status)

        self._timer = QTimer(self)
        self._timer.setInterval(80)
        self._timer.timeout.connect(self._tick)
        self._timer.start()

    def closeEvent(self, event) -> None:  # noqa: N802
        self._timer.stop()
        self.view.shutdown()
        super().closeEvent(event)

    def import_video(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Import a video", "", _filter(VIDEO_EXT, "Video"))
        if not path:
            return
        try:
            info = probe_video(Path(path))
        except Exception as exc:
            QMessageBox.warning(self, "Video", str(exc))
            return
        self.video = Path(path)
        self.size_info = info
        self.view.set_frame_size(int(info["width"]), int(info["height"]))
        self.view.load(path)
        self.slider.setRange(0, max(1, int(info["duration"] * 1000)))
        self._fill([])
        frames = int(info.get("frames") or 0)
        fps = float(info.get("fps") or 0)
        fps_txt = f"{fps:.3f}".rstrip("0").rstrip(".") if fps else "?"
        self.status.setText(
            f"Understood {info['width']}×{info['height']} · {fps_txt} fps · {frames} frames · {info['duration']:.2f}s. "
            "It sits inside a 16:9 frame. The logo is locked to the Filmora corner. Export gives the logo video and a separate SRT."
        )
        self._tick()

    def change_logo(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Choose a logo", "", _filter(IMAGE_EXT, "Image"))
        if not path:
            return
        self.logo = Path(path)
        self.view.set_logo_file(path)
        self.logo_box.setChecked(True)

    def reset_logo(self) -> None:
        self.view.logo_transform = dict(DEFAULT_LOGO_TRANSFORM)
        brand = paths.default_logo()
        if brand:
            self.logo = brand
            self.view.set_logo_file(str(brand))
        self.logo_box.setChecked(True)
        self.view.update()

    def _on_logo(self, on: bool) -> None:
        self.view.logo_on = bool(on)
        self.view.update()

    def _on_preview_captions(self, on: bool) -> None:
        self.view.show_caption = bool(on)
        self.view.update()

    def toggle_play(self) -> None:
        if not self.view.path:
            return
        paused = bool(self.view.player.pause)
        self.view.player.pause = not paused
        self.btn_play.setText("Pause" if paused else "Play")

    def detect(self) -> None:
        if self.video is None:
            QMessageBox.information(self, "Detect Speech", "Import a video first.")
            return
        if self._hear is not None and self._hear.isRunning():
            return
        lang = self.lang.currentData()
        name = "Marathi" if lang == "mr" else "English"
        self.status.setText(f"Listening with the {name} speech module…")
        self.btn_hear.setEnabled(False)
        job = _HearThread(self.video, lang)
        job.ready.connect(self._heard)
        job.failed.connect(self._hear_failed)
        job.finished.connect(lambda: self.btn_hear.setEnabled(True))
        self._hear = job
        job.start()

    def _heard(self, cues: list) -> None:
        self._fill(cues)
        if not cues:
            self._export_after = False
            self.status.setText("No speech was heard in this video, so no SRT was written.")
            return
        if self._export_after:
            self._export_after = False
            self._write_pair()
            return
        self.status.setText(f"{len(cues)} caption lines. Edit any line, then export the logo video and the SRT as two files.")

    def _hear_failed(self, message: str) -> None:
        self._export_after = False
        self.status.setText(message)
        QMessageBox.warning(self, "Detect Speech", message)

    def _fill(self, cues: list[dict]) -> None:
        self.table.blockSignals(True)
        self.table.setRowCount(len(cues))
        for row, cue in enumerate(cues):
            self._set_row(row, cue)
        self.table.blockSignals(False)
        self.table.resizeRowsToContents()
        self._show_caption_at(self._position())

    def _set_row(self, row: int, cue: dict) -> None:
        start = self._time_item(float(cue["start"]))
        end = self._time_item(float(cue["end"]))
        text = QTableWidgetItem(str(cue.get("text") or ""))
        text.setFlags(text.flags() | Qt.ItemFlag.ItemIsEditable)
        self.table.setItem(row, 0, start)
        self.table.setItem(row, 1, end)
        self.table.setItem(row, 2, text)

    def _time_item(self, sec: float) -> QTableWidgetItem:
        item = QTableWidgetItem(format_srt_time(sec))
        item.setData(Qt.ItemDataRole.UserRole, float(sec))
        item.setFlags(item.flags() | Qt.ItemFlag.ItemIsEditable)
        return item

    def _on_item(self, item: QTableWidgetItem) -> None:
        if item.column() in (0, 1):
            parsed = parse_srt_time(item.text())
            if parsed is None:
                old = item.data(Qt.ItemDataRole.UserRole)
                item.setText(format_srt_time(float(old or 0)))
                return
            item.setData(Qt.ItemDataRole.UserRole, parsed)
            item.setText(format_srt_time(parsed))
        self._show_caption_at(self._position())

    def _on_row(self) -> None:
        row = self.table.currentRow()
        item = self.table.item(row, 0) if row >= 0 else None
        if item is None:
            return
        sec = float(item.data(Qt.ItemDataRole.UserRole) or 0)
        try:
            self.view.player.seek(sec, reference="absolute", precision="exact")
        except Exception:
            pass
        self.slider.setValue(int(sec * 1000))
        self._show_caption_at(sec)

    def remove_line(self) -> None:
        row = self.table.currentRow()
        if row >= 0:
            self.table.removeRow(row)

    def cues(self) -> list[dict]:
        out = []
        for row in range(self.table.rowCount()):
            start_item = self.table.item(row, 0)
            end_item = self.table.item(row, 1)
            text_item = self.table.item(row, 2)
            if start_item is None or end_item is None or text_item is None:
                continue
            text = text_item.text().strip()
            if not text:
                continue
            start = float(start_item.data(Qt.ItemDataRole.UserRole) or 0)
            end = float(end_item.data(Qt.ItemDataRole.UserRole) or 0)
            out.append({"start": start, "end": end, "text": text})
        return out

    def export(self) -> None:
        if self.video is None:
            QMessageBox.information(self, "Export", "Upload a video first.")
            return
        if not self.logo_box.isChecked():
            QMessageBox.information(self, "Export", "Turn Logo on. The logo is placed on every frame of the new video. The SRT is a separate file.")
            return
        if self.logo is None or not self.logo.is_file():
            QMessageBox.warning(self, "Export", "Choose a logo image first.")
            return
        if self._export is not None and self._export.isRunning():
            return
        if not self.cues():
            self._export_after = True
            self.detect()
            return
        self._write_pair()

    def _write_pair(self) -> None:
        if self.video is None:
            return
        srt_body = format_srt(self.cues())
        if not srt_body.strip():
            QMessageBox.information(self, "Export", "No speech was heard, so there is no SRT to save.")
            return
        suggested = self.video.with_name(self.video.stem + " logo.mp4")
        dest, _ = QFileDialog.getSaveFileName(self, "Save the video with the logo", str(suggested), "Video (*.mp4)")
        if not dest:
            return
        video_out, srt_out = next_free_pair(Path(dest if dest.lower().endswith(".mp4") else dest + ".mp4"))
        try:
            command = export_command(self.video, self.logo, DEFAULT_LOGO_TRANSFORM, video_out, self.size_info)
        except Exception as exc:
            QMessageBox.warning(self, "Export", str(exc))
            return
        frames = int(self.size_info.get("frames") or 0)
        self.btn_export.setEnabled(False)
        self.status.setText(f"Placing the logo on {frames or 'each'} frame, and writing the SRT as its own file…")
        job = _ExportThread(command, float(self.size_info.get("duration") or 1), video_out, srt_body, srt_out)
        job.progress.connect(lambda n: self.status.setText(f"Placing the logo on each frame… {n}%"))
        job.ready.connect(self._exported)
        job.failed.connect(self._export_failed)
        job.finished.connect(lambda: self.btn_export.setEnabled(True))
        self._export = job
        job.start()

    def _exported(self, video: str, srt: str) -> None:
        self.status.setText(f"Logo video: {Path(video).name}. SRT file: {Path(srt).name}. The words are only in the SRT.")

    def _export_failed(self, message: str) -> None:
        self.status.setText(message)
        QMessageBox.warning(self, "Export", message)

    def _slider_down(self) -> None:
        self._sliding = True

    def _slider_up(self) -> None:
        self._sliding = False
        if not self.view.path:
            return
        sec = self.slider.value() / 1000
        try:
            self.view.player.seek(sec, reference="absolute", precision="exact")
        except Exception:
            pass
        self._show_caption_at(sec)

    def _position(self) -> float:
        try:
            pos = self.view.player.time_pos
        except Exception:
            pos = None
        if pos is None:
            return self.slider.value() / 1000
        return float(pos)

    def _tick(self) -> None:
        if not self.view.path or self._sliding:
            return
        pos = self._position()
        self.slider.setValue(int(pos * 1000))
        dur = float(self.size_info.get("duration") or 0)
        self.time_label.setText(f"{self._clock(pos)} / {self._clock(dur)}")
        self._show_caption_at(pos)
        try:
            paused = bool(self.view.player.pause)
        except Exception:
            paused = True
        self.btn_play.setText("Play" if paused else "Pause")

    def _show_caption_at(self, t: float) -> None:
        text = ""
        if self.preview_captions.isChecked():
            for cue in self.cues():
                if cue["start"] - 0.02 <= t < cue["end"]:
                    text = cue["text"]
                    break
        if text != self.view.caption:
            self.view.caption = text
            self.view.update()

    @staticmethod
    def _clock(sec: float) -> str:
        sec = max(0, int(sec))
        return f"{sec // 60}:{sec % 60:02d}"
