"""Small windows: Updates and the Filmora-style logo Transform panel."""

from __future__ import annotations

import json

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtGui import QColor, QDesktopServices, QFont, QFontDatabase, QStandardItem, QStandardItemModel
from PySide6.QtWidgets import (
    QCheckBox,
    QColorDialog,
    QComboBox,
    QDialog,
    QDoubleSpinBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QTextBrowser,
    QVBoxLayout,
    QWidget,
)

from .. import __version__, paths
from ..core.plan import DEFAULT_POEM_OVERLAY, POEM_PRESETS, normalize_poem_overlay, scene_label
from ..core.project_store import DEFAULT_LOGO_TRANSFORM, normalize_logo_transform


class UpdatesDialog(QDialog):
    def __init__(self, parent=None, report: dict | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Updates · Windows & Mac Auto-Sync")
        self.resize(540, 480)
        self._report = dict(report or {})
        self._parent_win = parent
        lay = QVBoxLayout(self)
        current = str(self._report.get("current") or __version__)
        latest = str(self._report.get("latest") or "")
        available = bool(self._report.get("updateAvailable"))
        head = QLabel(
            f"<b>DGS Auto Editor</b> · this program {current}"
            + (f" · latest {latest}" if latest and latest != current else "")
        )
        head.setWordWrap(True)
        lay.addWidget(head)
        self.ping = QLabel()
        self.ping.setWordWrap(True)
        self.ping.setObjectName("Muted")
        if available:
            self.ping.setText(
                f"A newer build is available ({latest}). "
                "Click 'Update & Restart Now' to sync the latest changes directly onto this PC/Mac."
            )
            self.ping.setStyleSheet("color: #ffb4a2;")
        elif self._report.get("feedError"):
            self.ping.setText(
                "Could not reach the published update feed right now. "
                "You can keep editing offline; try Updates again later."
            )
        else:
            self.ping.setText("This copy is up to date. You can also click 'Sync Latest Code Now' to pull any fresh changes.")
        lay.addWidget(self.ping)
        body = QTextBrowser()
        body.setOpenLinks(False)
        parts = []
        notes = self._report.get("notes") or []
        if available and notes:
            parts.append("<h4>What’s new</h4><ul>" + "".join(f"<li>{n}</li>" for n in notes) + "</ul>")
        history = self._report.get("history")
        if not isinstance(history, list) or not history:
            feed = {}
            f = paths.updates_feed()
            if f:
                try:
                    feed = json.loads(f.read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    feed = {}
            history = feed.get("history") or []
        for h in history or []:
            if not isinstance(h, dict):
                continue
            parts.append(
                f"<h4>{h.get('version')} · {h.get('date')}</h4><ul>"
                + "".join(f"<li>{n}</li>" for n in h.get("notes") or [])
                + "</ul>"
            )
        body.setHtml("".join(parts) or "No change log is bundled with this build.")
        lay.addWidget(body, 1)
        row = QHBoxLayout()
        self.sync_btn = QPushButton("Update & Restart Now" if available else "Sync Latest Code Now")
        self.sync_btn.setObjectName("Primary")
        self.sync_btn.setToolTip("Downloads the latest published desktop code from GitHub and restarts the editor.")
        self.sync_btn.clicked.connect(self._sync_now)
        row.addWidget(self.sync_btn)
        url = str(self._report.get("downloadUrl") or "")
        if not url:
            downloads = self._report.get("downloads") if isinstance(self._report.get("downloads"), dict) else {}
            url = str((downloads or {}).get("win") or "")
        if url:
            dl = QPushButton("Open download page")
            dl.setToolTip("Opens the GitHub releases page in your browser.")
            dl.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(url)))
            row.addWidget(dl)
        row.addStretch(1)
        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        row.addWidget(close)
        lay.addLayout(row)

    def _sync_now(self) -> None:
        from PySide6.QtWidgets import QApplication, QMessageBox
        from ..core.update_check import apply_code_update, check_remote

        self.sync_btn.setEnabled(False)
        self.ping.setText("Checking and downloading latest code update from GitHub…")
        QApplication.processEvents()
        try:
            rep = check_remote(timeout=10.0)
            res = apply_code_update(rep, timeout=45.0)
            ver = res.get("version") or rep.get("latest") or __version__
            count = res.get("files_updated", 0)
            self.ping.setText(f"Synced {count} files (version {ver}). Restarting editor…")
            QApplication.processEvents()
            if self._parent_win is not None and hasattr(self._parent_win, "restart_after_update"):
                self.accept()
                self._parent_win.restart_after_update()
                return
            QMessageBox.information(self, "Update Installed", f"Updated {count} files to {ver}. Please reopen the editor.")
            self.accept()
        except Exception as exc:  # noqa: BLE001
            self.sync_btn.setEnabled(True)
            self.ping.setText(f"Update sync failed: {exc}")
            QMessageBox.warning(self, "Update Sync Failed", f"Could not download update:\n{exc}")


class LogoTransformDialog(QDialog):
    """Live edit: every change is sent through ``changed`` straight to the preview."""

    changed = Signal(dict)

    def __init__(self, transform: dict, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Logo · Transform")
        self.setModal(False)
        self._orig = normalize_logo_transform(transform)
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self._spins: dict[str, QDoubleSpinBox] = {}
        spec = [
            ("scale_w", "Scale W %", 0.5, 200, 0.5),
            ("scale_h", "Scale H %", 0.5, 200, 0.5),
            ("pos_x", "Position X", -4000, 4000, 1),
            ("pos_y", "Position Y", -4000, 4000, 1),
            ("anchor_x", "Anchor X", -4000, 4000, 1),
            ("anchor_y", "Anchor Y", -4000, 4000, 1),
            ("rotate", "Rotate °", -360, 360, 1),
        ]
        for key, label, lo, hi, step in spec:
            s = QDoubleSpinBox()
            s.setRange(lo, hi)
            s.setDecimals(2)
            s.setSingleStep(step)
            s.setValue(float(self._orig[key]))
            s.valueChanged.connect(lambda _v, k=key: self._on_change(k))
            form.addRow(label, s)
            self._spins[key] = s
        self.lock = QCheckBox("Lock aspect ratio")
        self.lock.setChecked(bool(self._orig.get("lock_aspect", True)))
        self.lock.toggled.connect(lambda _v: self._emit())
        form.addRow("", self.lock)
        lay.addLayout(form)
        note = QLabel("Same numbers as Filmora 16's Transform panel. You can also drag the logo on the preview; double-click it to reset.")
        note.setWordWrap(True)
        note.setObjectName("Muted")
        lay.addWidget(note)
        row = QHBoxLayout()
        reset = QPushButton("Default")
        reset.clicked.connect(self._reset)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self._cancel)
        ok = QPushButton("Done")
        ok.setObjectName("Primary")
        ok.clicked.connect(self.accept)
        row.addWidget(reset)
        row.addStretch(1)
        row.addWidget(cancel)
        row.addWidget(ok)
        lay.addLayout(row)
        self._busy = False

    def value(self) -> dict:
        out = {k: round(s.value(), 2) for k, s in self._spins.items()}
        out["lock_aspect"] = self.lock.isChecked()
        return out

    def _on_change(self, key: str) -> None:
        if self._busy:
            return
        if self.lock.isChecked() and key in ("scale_w", "scale_h"):
            other = "scale_h" if key == "scale_w" else "scale_w"
            self._busy = True
            self._spins[other].setValue(self._spins[key].value())
            self._busy = False
        self._emit()

    def _emit(self) -> None:
        self.changed.emit(self.value())

    def _set(self, t: dict) -> None:
        self._busy = True
        for k, s in self._spins.items():
            s.setValue(float(t[k]))
        self.lock.setChecked(bool(t.get("lock_aspect", True)))
        self._busy = False
        self._emit()

    def _reset(self) -> None:
        self._set(dict(DEFAULT_LOGO_TRANSFORM))

    def _cancel(self) -> None:
        self._set(self._orig)
        self.reject()

    def keyPressEvent(self, e) -> None:  # noqa: N802
        if e.key() == Qt.Key.Key_Escape:
            self._cancel()
            return
        super().keyPressEvent(e)


_WEIGHTS = (
    ("Thin", 100),
    ("Extra light", 200),
    ("Light", 300),
    ("Regular", 400),
    ("Medium", 500),
    ("Semibold", 600),
    ("Bold", 700),
    ("Extra bold", 800),
    ("Black", 900),
)
_DEVANAGARI_FIRST = (
    "Nirmala UI", "Mangal", "Kokila", "Aparajita", "Sanskrit Text", "Utsaah",
    "Noto Sans Devanagari", "Noto Serif Devanagari",
)
_ENGLISH_FONTS = (
    "Segoe UI", "Arial", "Verdana", "Georgia", "Trebuchet MS", "Calibri", "Cambria",
    "Times New Roman", "Candara", "Constantia", "Corbel", "Tahoma", "Comic Sans MS",
    "Impact", "Palatino Linotype", "Garamond", "Courier New",
)


def _installed_fonts() -> tuple[list[str], list[str]]:
    """Devanagari faces and Latin faces, only the ones this PC can actually draw."""
    have = set(QFontDatabase.families())
    try:
        dev = list(QFontDatabase.families(QFontDatabase.WritingSystem.Devanagari))
    except TypeError:
        dev = []
    for name in _DEVANAGARI_FIRST:
        if name in have and name not in dev:
            dev.append(name)
    devanagari = [n for n in _DEVANAGARI_FIRST if n in dev]
    devanagari += [n for n in dev if n not in devanagari and n in have and "Collection" not in n]
    english = [n for n in _ENGLISH_FONTS if n in have]
    return devanagari, english
_PALETTE = [
    "#ffffff", "#f8fafc", "#facc15", "#fde68a", "#fb923c",
    "#f43f5e", "#ec4899", "#c084fc", "#38bdf8", "#1cd6b0",
    "#4ade80", "#0f172a", "#1e1b4b", "#000000", "#fef08a",
]
_TEXT_TYPES = (
    ("plain", "Plain"),
    ("shadow", "Shadow"),
    ("outline", "Outline"),
    ("sticker", "Sticker"),
    ("lift", "Lift"),
    ("glow", "Glow"),
)
_TYPE_LOOKS = {
    "plain": {"text_shadow": False},
    "shadow": {"text_shadow": True, "text_shadow_soft": 8},
    "outline": {"text_shadow": False},
    "sticker": {"text_shadow": True, "text_shadow_soft": 5},
    "lift": {"text_shadow": True, "text_shadow_soft": 0},
    "glow": {"text_shadow": True, "text_shadow_soft": 14},
}
_PRESET_NAMES = {
    "badge_pill": "Badge pill",
    "neon_glow": "Neon glow",
    "karaoke_box": "Karaoke",
    "pastel_banner": "Pastel banner",
    "comic_pop": "Comic pop",
    "clean_subtitle": "Clean subtitle",
}


class PoemTextDialog(QDialog):
    """Placement, type, and motion for the poem lyric. One look is used on every poem screen."""

    changed = Signal(dict)

    def __init__(self, style: dict, parent=None, indic: bool = False) -> None:
        super().__init__(parent)
        self.setWindowTitle("Poem text")
        self.setModal(False)
        self.resize(480, 720)
        self._indic = bool(indic)
        self._orig = normalize_poem_overlay(style)
        self._style = dict(self._orig)
        lay = QVBoxLayout(self)
        note = QLabel(
            "Drag the lyric on the preview to place it. Type sets the letters: Shadow, Sticker, Outline, Lift, or Glow. "
            "Text shadow is on the letters. Devanagari fonts draw Marathi. English fonts draw English."
        )
        note.setWordWrap(True)
        lay.addWidget(note)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        body = QWidget()
        form = QFormLayout(body)
        self.preset = QComboBox()
        for key, name in _PRESET_NAMES.items():
            self.preset.addItem(name, key)
        self.preset.currentIndexChanged.connect(self._on_preset)
        form.addRow("Presentation", self.preset)
        self.font = QComboBox()
        self.font.setMaxVisibleItems(22)
        self.font.currentIndexChanged.connect(self._on_font)
        self._fill_fonts(self._style.get("font_family") or "")
        form.addRow("Font", self.font)
        self.weight = QComboBox()
        for name, value in _WEIGHTS:
            self.weight.addItem(name, value)
        self.weight.currentIndexChanged.connect(self._on_weight)
        form.addRow("Font weight", self.weight)
        self.kind = QComboBox()
        for key, name in _TEXT_TYPES:
            self.kind.addItem(name, key)
        self.kind.currentIndexChanged.connect(self._on_text_style)
        form.addRow("Type", self.kind)
        self.show_text = QCheckBox("Show poem text on every screen")
        self.show_text.setToolTip("Turns the lyric on or off for every poem screen.")
        self.show_text.toggled.connect(self._on_show)
        form.addRow("", self.show_text)
        self.effect_title = QLabel("Shadow colour")
        self.effect_title.setWordWrap(True)
        self.stroke_wrap = QWidget()
        stroke_lay = QVBoxLayout(self.stroke_wrap)
        stroke_lay.setContentsMargins(0, 0, 0, 0)
        stroke_lay.addWidget(QLabel("Outline"))
        self.shadow_wrap = QWidget()
        shadow_lay = QVBoxLayout(self.shadow_wrap)
        shadow_lay.setContentsMargins(0, 0, 0, 0)
        shadow_lay.addWidget(QLabel("Shadow / glow"))
        self.size = QSpinBox()
        self.size.setRange(14, 72)
        self.size.valueChanged.connect(lambda v: self._set("font_size_px", int(v)))
        form.addRow("Size", self.size)
        self.align = QComboBox()
        self.align.addItems(["center", "left", "right"])
        self.align.currentTextChanged.connect(lambda v: self._set("text_align", v))
        form.addRow("Align", self.align)
        self.text_color = self._swatches("text_color")
        self.bg_color = self._swatches("bg_color", allow_none=True)
        self.border_color = self._swatches("border_color")
        self.shadow_color = self._swatches("shadow_color")
        self.stroke_color = self._swatches("stroke_color")
        self.ball_color = self._swatches("ball_color")
        stroke_lay.addWidget(self.stroke_color)
        shadow_lay.addWidget(self.shadow_color)
        self.effect_host = QWidget()
        effect_lay = QVBoxLayout(self.effect_host)
        effect_lay.setContentsMargins(0, 0, 0, 0)
        effect_lay.setSpacing(4)
        effect_lay.addWidget(self.effect_title)
        effect_lay.addWidget(self.stroke_wrap)
        effect_lay.addWidget(self.shadow_wrap)
        form.addRow("Effect", self.effect_host)
        form.addRow("Text", self.text_color)
        form.addRow("Background", self.bg_color)
        form.addRow("Border", self.border_color)
        self.no_border = QCheckBox("No border")
        self.no_border.toggled.connect(self._on_border)
        form.addRow("", self.no_border)
        self.box_w = QSpinBox()
        self.box_w.setRange(20, 100)
        self.box_w.setSuffix(" %")
        self.box_w.valueChanged.connect(lambda v: self._set("w_pct", float(v)))
        form.addRow("Box width", self.box_w)
        self.box_h = QSpinBox()
        self.box_h.setRange(8, 60)
        self.box_h.setSuffix(" %")
        self.box_h.valueChanged.connect(lambda v: self._set("h_pct", float(v)))
        form.addRow("Box height", self.box_h)
        form.addRow("Ball", self.ball_color)
        self.text_shadow = QCheckBox("Text shadow")
        self.text_shadow.setToolTip("A shadow on the letters. The box shadow is separate.")
        self.text_shadow.toggled.connect(lambda v: self._set("text_shadow", bool(v)))
        form.addRow("", self.text_shadow)
        self.shadow = QCheckBox("Box shadow")
        self.shadow.toggled.connect(lambda v: self._set("box_shadow", bool(v)))
        form.addRow("", self.shadow)
        self.soft = QSpinBox()
        self.soft.setRange(0, 24)
        self.soft.setToolTip("How soft the letter shadow and the box shadow are. 0 is a hard edge.")
        self.soft.valueChanged.connect(self._on_soft)
        form.addRow("Shadow softness", self.soft)
        self.balls = QCheckBox("Bouncing ball on the spoken word")
        self.balls.toggled.connect(lambda v: self._set("word_balls", bool(v)))
        form.addRow("", self.balls)
        self.change = QComboBox()
        self.change.addItem("None", "none")
        self.change.addItem("Fade", "fade")
        self.change.addItem("Slide", "slide")
        self.change.addItem("Pop", "pop")
        self.change.currentIndexChanged.connect(self._on_changeover)
        form.addRow("Screen change", self.change)
        self.all_screens = QCheckBox("Use this look on every poem screen")
        self.all_screens.toggled.connect(lambda v: self._set("apply_all", bool(v)))
        form.addRow("", self.all_screens)
        scroll.setWidget(body)
        lay.addWidget(scroll, 1)
        row = QHBoxLayout()
        reset = QPushButton("Default")
        reset.clicked.connect(self._reset)
        self.remove = QPushButton("Remove this screen's text")
        self.remove.setToolTip("Take the lyric off the poem screen you are on. The other poem screens keep theirs.")
        self.remove.clicked.connect(self._remove)
        self._screen = ""
        done = QPushButton("Done")
        done.setObjectName("Primary")
        done.clicked.connect(self.accept)
        row.addWidget(reset)
        row.addWidget(self.remove)
        row.addStretch(1)
        row.addWidget(done)
        lay.addLayout(row)
        self._busy = False
        self._load(self._style)

    def _swatches(self, key: str, allow_none: bool = False) -> QWidget:
        host = QWidget()
        col_lay = QVBoxLayout(host)
        col_lay.setContentsMargins(0, 0, 0, 0)
        col_lay.setSpacing(4)
        chip = QLabel()
        chip.setFixedSize(22, 22)
        chip.setObjectName(f"chip-{key}")
        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.addWidget(chip)
        top.addStretch(1)
        col_lay.addLayout(top)
        for start in (0, 8):
            row = QHBoxLayout()
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(4)
            for col in _PALETTE[start:start + 8]:
                b = QPushButton()
                b.setFixedSize(20, 20)
                b.setToolTip(col)
                b.setStyleSheet(
                    f"background: {col}; border-radius: 10px; border: 1px solid rgba(255,255,255,0.35); padding: 0;"
                )
                b.clicked.connect(lambda _=False, c=col, k=key: self._pick_color(k, c))
                row.addWidget(b)
            row.addStretch(1)
            col_lay.addLayout(row)
        extra = QHBoxLayout()
        extra.setContentsMargins(0, 0, 0, 0)
        if allow_none:
            none = QPushButton("No background")
            none.setToolTip("Text and the ball only. No box behind the lyric.")
            none.clicked.connect(lambda _=False, k=key: self._pick_color(k, "none"))
            extra.addWidget(none)
        custom = QPushButton("Custom")
        custom.clicked.connect(lambda _=False, k=key: self._custom_color(k))
        extra.addWidget(custom)
        extra.addStretch(1)
        col_lay.addLayout(extra)
        return host

    def set_script(self, indic: bool) -> None:
        indic = bool(indic)
        if indic == self._indic:
            return
        self._indic = indic
        self._fill_fonts(str(self._style.get("font_family") or ""))

    def _fill_fonts(self, current: str) -> None:
        devanagari, english = _installed_fonts()
        self._devanagari = set(devanagari)
        self._english = set(english)
        model = QStandardItemModel(self.font)
        self._font_header(model, "Devanagari")
        for name in devanagari:
            self._font_item(model, name)
        self._font_header(model, "English")
        for name in english:
            self._font_item(model, name)
        known = self._devanagari | self._english
        if current and current not in known:
            self._font_item(model, current)
        self._busy = True
        self.font.blockSignals(True)
        self.font.setModel(model)
        self._select_font(current)
        self.font.blockSignals(False)
        self._busy = False

    def _font_header(self, model: QStandardItemModel, title: str) -> None:
        item = QStandardItem(title)
        item.setFlags(Qt.ItemFlag.NoItemFlags)
        item.setData("", Qt.ItemDataRole.UserRole)
        face = QFont()
        face.setBold(True)
        item.setFont(face)
        model.appendRow(item)

    def _font_item(self, model: QStandardItemModel, name: str) -> None:
        item = QStandardItem(name)
        item.setData(name, Qt.ItemDataRole.UserRole)
        face = QFont(name)
        face.setPointSize(12)
        item.setFont(face)
        model.appendRow(item)

    def _select_font(self, name: str) -> None:
        pick = 0
        for i in range(self.font.count()):
            if self.font.itemData(i) == name:
                pick = i
                break
            if pick == 0 and self.font.itemData(i):
                pick = i
        self.font.setCurrentIndex(pick)
        chosen = str(self.font.currentData() or name or "")
        if chosen:
            face = QFont(chosen)
            face.setPointSize(11)
            self.font.setFont(face)

    def _on_font(self, _index: int) -> None:
        if self._busy:
            return
        name = self.font.currentData()
        if not name:
            return
        face = QFont(str(name))
        face.setPointSize(11)
        self.font.setFont(face)
        self._set("font_family", str(name))

    def _on_soft(self, value: int) -> None:
        if self._busy:
            return
        self._live_box()
        self._style["shadow_soft"] = int(value)
        self._style["text_shadow_soft"] = int(value)
        self.changed.emit(normalize_poem_overlay(self._style))

    def _on_text_style(self, _index: int) -> None:
        if self._busy:
            return
        key = str(self.kind.currentData() or "shadow")
        self._live_box()
        self._style["text_style"] = key
        self._style.update(_TYPE_LOOKS.get(key) or {})
        self._busy = True
        self.text_shadow.setChecked(bool(self._style.get("text_shadow")))
        self._paint_chips()
        self._sync_effect_colors()
        self._busy = False
        self.changed.emit(normalize_poem_overlay(self._style))

    def _on_weight(self, _index: int) -> None:
        if self._busy:
            return
        value = self.weight.currentData()
        if value is None:
            return
        self._set("font_weight", int(value))

    def adopt_placement(self, style: dict) -> None:
        """Keep a drag on the preview. A later colour click must not put the box back."""
        if not isinstance(style, dict):
            return
        self._busy = True
        for key in ("x_pct", "y_pct", "w_pct", "h_pct"):
            if style.get(key) is not None:
                self._style[key] = style[key]
        self.box_w.setValue(int(round(float(self._style.get("w_pct") or 80))))
        self.box_h.setValue(int(round(float(self._style.get("h_pct") or 20))))
        self._busy = False

    def _live_box(self) -> None:
        win = self.parent()
        surf = getattr(getattr(win, "preview", None), "surface", None)
        st = getattr(surf, "lyric_style", None) if surf is not None else None
        if not isinstance(st, dict) or not st:
            return
        for key in ("x_pct", "y_pct", "w_pct", "h_pct"):
            if st.get(key) is not None:
                self._style[key] = st[key]

    def _pick_color(self, key: str, value: str) -> None:
        if self._busy:
            return
        self._live_box()
        if value == "none":
            self._style["bg_none"] = True
            self._style["bg_opacity"] = 0.0
        else:
            self._style[key] = value
            if key == "bg_color":
                self._style["bg_none"] = False
                if float(self._style.get("bg_opacity") or 0) < 0.05:
                    self._style["bg_opacity"] = 0.88
        self._paint_chips()
        self.changed.emit(normalize_poem_overlay(self._style))

    def _custom_color(self, key: str) -> None:
        start = QColor(str(self._style.get(key) or "#ffffff"))
        picked = QColorDialog.getColor(start, self, "Colour")
        if not picked.isValid():
            return
        self._pick_color(key, picked.name())

    def _paint_chips(self) -> None:
        for key in ("text_color", "bg_color", "border_color", "shadow_color", "stroke_color", "ball_color"):
            chip = self.findChild(QLabel, f"chip-{key}")
            if chip is None:
                continue
            if key == "bg_color" and self._style.get("bg_none"):
                chip.setStyleSheet("background: transparent; border: 1px dashed rgba(255,255,255,0.5); border-radius: 4px;")
                chip.setToolTip("No background")
            else:
                col = str(self._style.get(key) or "#ffffff")
                chip.setStyleSheet(f"background: {col}; border-radius: 4px; border: 1px solid rgba(255,255,255,0.35);")
                chip.setToolTip(col)

    def _load(self, style: dict) -> None:
        self._busy = True
        style = normalize_poem_overlay(style)
        self._style = style
        idx = self.preset.findData(style["preset_style"])
        if idx >= 0:
            self.preset.setCurrentIndex(idx)
        self._select_font(str(style.get("font_family") or ""))
        weight = int(style.get("font_weight") or 400)
        widx = min(range(self.weight.count()), key=lambda i: abs(int(self.weight.itemData(i) or 400) - weight))
        self.weight.setCurrentIndex(widx)
        self.size.setValue(int(style["font_size_px"]))
        self.align.setCurrentText(style["text_align"])
        self.no_border.setChecked(bool(style.get("border_none")) or float(style.get("border_width") or 0) <= 0)
        self.box_w.setValue(int(round(float(style.get("w_pct") or 80))))
        self.box_h.setValue(int(round(float(style.get("h_pct") or 20))))
        self._paint_chips()
        kidx = self.kind.findData(style.get("text_style") or "shadow")
        if kidx >= 0:
            self.kind.setCurrentIndex(kidx)
        self.text_shadow.setChecked(bool(style.get("text_shadow")))
        self.shadow.setChecked(bool(style["box_shadow"]))
        self.soft.setValue(int(style.get("text_shadow_soft") if style.get("text_shadow_soft") is not None else style.get("shadow_soft") or 0))
        self.balls.setChecked(bool(style["word_balls"]))
        self.show_text.setChecked(style.get("enabled") is not False)
        self._sync_effect_colors()
        cidx = self.change.findData(style["changeover"])
        if cidx >= 0:
            self.change.setCurrentIndex(cidx)
        self.all_screens.setChecked(bool(style["apply_all"]))
        self._busy = False

    def _set(self, key: str, value) -> None:
        if self._busy:
            return
        self._live_box()
        self._style[key] = value
        self.changed.emit(normalize_poem_overlay(self._style))

    def _on_show(self, on: bool) -> None:
        if self._busy:
            return
        self._set("enabled", bool(on))

    def _sync_effect_colors(self) -> None:
        kind = str(self._style.get("text_style") or "shadow")
        if kind == "glow":
            self.effect_title.setText("Glow colour. Pick a swatch or Custom.")
            self.stroke_wrap.setVisible(False)
            self.shadow_wrap.setVisible(True)
        elif kind == "sticker":
            self.effect_title.setText("Sticker colours. Outline around the letters, then the shadow.")
            self.stroke_wrap.setVisible(True)
            self.shadow_wrap.setVisible(True)
        elif kind == "outline":
            self.effect_title.setText("Outline colour. Pick a swatch or Custom.")
            self.stroke_wrap.setVisible(True)
            self.shadow_wrap.setVisible(False)
        elif kind in ("shadow", "lift"):
            self.effect_title.setText("Shadow colour. Pick a swatch or Custom.")
            self.stroke_wrap.setVisible(False)
            self.shadow_wrap.setVisible(True)
        else:
            self.effect_title.setText("Plain letters use the text colour only.")
            self.stroke_wrap.setVisible(False)
            self.shadow_wrap.setVisible(False)
        self.effect_host.setVisible(True)

    def note_screen(self, clip: dict | None, on_poem: bool) -> None:
        """The remove button follows the poem screen under the playhead."""
        screen = str((clip or {}).get("screen") or "") if on_poem else ""
        self._screen = screen
        label = scene_label(screen) if screen else ""
        hidden = {str(s) for s in (self._style.get("hidden_screens") or [])}
        if not screen:
            self.remove.setText("Remove this screen's text")
            self.remove.setEnabled(False)
            self.remove.setToolTip("Move the playhead onto a poem screen first.")
            return
        self.remove.setEnabled(True)
        if screen in hidden:
            self.remove.setText(f"Show text on {label}")
            self.remove.setToolTip("Put the lyric back on this screen only. The video, WFP, and bundle follow it.")
        else:
            self.remove.setText(f"Remove text on {label}")
            self.remove.setToolTip("Take the lyric off this screen only. The other poem screens keep theirs.")

    def _remove(self) -> None:
        screen = str(getattr(self, "_screen", "") or "")
        if not screen:
            return
        self._live_box()
        hidden = [str(s) for s in (self._style.get("hidden_screens") or []) if str(s) != screen]
        if screen not in {str(s) for s in (self._style.get("hidden_screens") or [])}:
            hidden.append(screen)
        self._style["hidden_screens"] = hidden
        self._style["enabled"] = True
        self._busy = True
        self.show_text.setChecked(True)
        self._busy = False
        self.changed.emit(normalize_poem_overlay(self._style))
        self.note_screen({"screen": screen}, True)

    def _on_border(self, on: bool) -> None:
        if self._busy:
            return
        self._live_box()
        self._style["border_none"] = bool(on)
        self._style["border_width"] = 0 if on else max(2.0, float(self._style.get("border_width") or 0))
        self.changed.emit(normalize_poem_overlay(self._style))

    def _on_preset(self) -> None:
        if self._busy:
            return
        self._live_box()
        key = self.preset.currentData()
        nxt = dict(self._style)
        nxt["preset_style"] = key
        nxt["bg_none"] = False
        nxt["border_none"] = False
        look = dict(POEM_PRESETS.get(key) or {})
        # A presentation changes colours. It must not swap a Marathi face for an English one.
        if self._indic:
            look.pop("font_family", None)
        nxt.update(look)
        self._load(nxt)
        self.changed.emit(normalize_poem_overlay(self._style))

    def _on_changeover(self) -> None:
        if self._busy:
            return
        self._set("changeover", self.change.currentData())

    def _reset(self) -> None:
        self._load(dict(DEFAULT_POEM_OVERLAY))
        self.changed.emit(normalize_poem_overlay(self._style))

