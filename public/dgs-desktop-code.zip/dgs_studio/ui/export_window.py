"""Export window laid out like Filmora 16: Local, Device, Social, and DVD.

The picture settings (format, resolution, encoder, quality, bitrate, compression)
are the same models the chapter renderer already understands. Captions are
always a separate SRT and are never drawn onto the picture. The logo is
included only while the logo switch is on.
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QDesktopServices, QPixmap
from PySide6.QtCore import QUrl
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSpinBox,
    QVBoxLayout,
    QWidget,
)

from .. import paths

_MATCH = {
    "format": "mp4",
    "resolution": "1920x1080",
    "fps": 30,
    "encoder": "h264",
    "quality_preset": "high",
    "bitrate_mode": "vbr",
    "video_bitrate_kbps": 20000,
    "compression_mode": "by_quality",
    "compression_quality": 70,
    "audio_encoder": "aac",
    "audio_bitrate_kbps": 320,
    "audio_sample_rate": 44100,
    "audio_channels": "stereo",
    "color_space": "bt709",
    "advanced_compression": True,
    "export_video_only": False,
    "preset_name": "Match Project",
}

_BUILTINS = {
    "Match Project": dict(_MATCH),
    "Sundharam BR": {**_MATCH, "preset_name": "Sundharam BR"},
    "YouTube HD (1080p)": {**_MATCH, "video_bitrate_kbps": 15000, "quality_preset": "custom", "preset_name": "YouTube HD (1080p)"},
    "Classroom 720p": {**_MATCH, "resolution": "1280x720", "video_bitrate_kbps": 5000, "quality_preset": "custom", "preset_name": "Classroom 720p"},
    "4K UHD": {**_MATCH, "resolution": "3840x2160", "video_bitrate_kbps": 40000, "quality_preset": "custom", "preset_name": "4K UHD"},
}

# Taken from Filmora 16's encoder profiles (EncParamsApplyProfile.xml):
# PC containers, Device targets, and the web targets it encodes as H.264 + AAC.
_DEVICES = {
    "iPhone": ("1920x1080", 12000),
    "iPad": ("1920x1080", 12000),
    "Apple TV": ("1920x1080", 15000),
    "iPod": ("1280x720", 5000),
    "Galaxy": ("1920x1080", 12000),
    "Android": ("1920x1080", 12000),
    "Sony TV": ("1920x1080", 15000),
    "PS4": ("1920x1080", 12000),
}
_SOCIAL = {
    "YouTube": ("1920x1080", 15000),
    "Facebook": ("1920x1080", 12000),
    "Vimeo": ("1920x1080", 15000),
    "TikTok": ("1080x1920", 12000),
    "Instagram": ("1080x1920", 12000),
}
_DVD = {
    "DVD / USB (720p)": ("1280x720", 5000),
    "Full HD USB (1080p)": ("1920x1080", 20000),
}

_RESOLUTIONS = ["1920x1080", "1280x720", "3840x2160", "1080x1920"]


def _preset_file() -> Path:
    return paths.data_dir() / "export_presets.json"


def _load_custom() -> dict:
    f = _preset_file()
    if not f.is_file():
        return {}
    try:
        raw = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return raw if isinstance(raw, dict) else {}


def _save_custom(data: dict) -> None:
    f = _preset_file()
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def bitrate_for(resolution: str, quality: str, encoder: str, fallback: int) -> int:
    if quality == "custom":
        return max(500, int(fallback or 20000))
    base = {"high": 20000, "medium": 10000}.get(quality, 5000)
    res = {"3840x2160": 2.0, "1280x720": 0.5, "1080x1920": 1.0}.get(resolution, 1.0)
    enc = {"h265": 0.7, "mpeg4": 1.15}.get(encoder, 1.0)
    return max(500, int(round(base * res * enc / 100.0) * 100))


def signal_for(settings: dict, duration: float, still_share: float = 1.0) -> dict:
    """The numbers the encoder will actually use.

    ``video`` is the cap written into FFmpeg. ``stream`` is the average a
    chapter of still cards really produces, so the size line is not the cap.
    """
    base = max(500, int(settings.get("video_bitrate_kbps") or 20000))
    mode = str(settings.get("compression_mode") or "by_quality")
    comp = bool(settings.get("advanced_compression") and mode != "none")
    pct = max(10, min(95, int(settings.get("compression_quality") or 70)))
    keep = max(0.05, (100 - pct) / 100.0) if comp else 1.0
    video = max(400, int(round(base * keep))) if comp else base
    if comp and mode == "by_quality":
        crf = max(18, min(35, round(18 + (pct / 100.0) * 14)))
    elif comp:
        crf = 20 if video >= 10000 else 23 if video >= 5000 else 26 if video >= 2500 else 29
    else:
        quality = str(settings.get("quality_preset") or "high")
        crf = 26 if quality == "low" else 22 if quality == "medium" else 19
    share = min(1.0, max(0.0, float(still_share)))
    content = share * 0.09 + (1.0 - share) * 0.44
    quality_mode = mode != "by_bitrate" and str(settings.get("bitrate_mode") or "vbr") != "cbr"
    realistic = base * content if quality_mode else float(base)
    stream = max(250, int(round(realistic * keep))) if comp else int(round(realistic))
    if settings.get("export_video_only"):
        audio = 0
    elif settings.get("audio_encoder") == "pcm":
        audio = 1411
    else:
        audio = int(settings.get("audio_bitrate_kbps") or 320)
    if video >= 14000:
        bars, badge, color = 4, "STUDIO MASTER HD", "#10b981"
    elif video >= 5000:
        bars, badge, color = 3, "OPTIMAL HD", "#1cd6b0"
    elif video >= 2500:
        bars, badge, color = 2, "BALANCED", "#f59e0b"
    else:
        bars, badge, color = 1, "COMPACT", "#f43f5e"
    mb = duration * (stream + audio) / 8192.0 if duration > 0 else 0.0
    return {
        "base": base,
        "video": video,
        "stream": stream,
        "crf": crf,
        "audio": audio,
        "bars": bars,
        "badge": badge,
        "color": color,
        "mb": mb,
        "pct": pct,
        "comp": comp,
    }


class FilmoraExportWindow(QDialog):
    start_export = Signal(dict, str)
    export_srt = Signal(str)
    save_wfp = Signal(str)
    save_bundle = Signal(str)
    logo_toggled = Signal(bool)
    cancel_export = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Export")
        self.setModal(False)
        self.resize(860, 700)
        self.setStyleSheet(_QSS)
        self._settings = dict(_MATCH)
        self._custom = _load_custom()
        self._running = False
        self._duration = 0.0
        self._still_share = 1.0
        self._images: list[tuple[str, str]] = []
        self._thumb_i = 0
        self._build()
        self._fill_presets()
        self._apply_settings(dict(_MATCH))

    def set_chapter(self, title: str, logo_on: bool, duration: float, images: list[tuple[str, str]], still_share: float = 1.0) -> None:
        self.title_edit.setText(title or "Export")
        self._duration = max(0.0, float(duration or 0))
        self._still_share = min(1.0, max(0.0, float(still_share)))
        self._images = [(p, n) for p, n in images if p]
        self._thumb_i = 0
        self.logo.blockSignals(True)
        self.logo.setChecked(bool(logo_on))
        self.logo.blockSignals(False)
        self._show_thumb()
        self._refresh_readout()

    def set_progress(self, text: str) -> None:
        pct, msg = 0, text
        if "|" in text:
            head, msg = text.split("|", 1)
            try:
                pct = int(float(head))
            except ValueError:
                pct = 0
        self.progress.setVisible(True)
        self.progress.setValue(max(0, min(100, pct)))
        self.status.setText(msg or "Exporting…")
        self.export_btn.setText(f"Exporting {pct}%…" if pct else "Exporting…")

    def mark_running(self) -> None:
        self._running = True
        self.export_btn.setEnabled(False)
        self.cancel_btn.setVisible(True)
        self.progress.setVisible(True)
        self.progress.setValue(4)
        self.status.setText("Preparing the export…")

    def mark_done(self, text: str) -> None:
        self._running = False
        self.export_btn.setEnabled(True)
        self.export_btn.setText("Export")
        self.cancel_btn.setVisible(False)
        self.progress.setValue(100)
        self.status.setText(text)

    def mark_failed(self, text: str) -> None:
        self._running = False
        self.export_btn.setEnabled(True)
        self.export_btn.setText("Export")
        self.cancel_btn.setVisible(False)
        self.status.setText(text)

    # Layout ----------------------------------------------------------------

    def _build(self) -> None:
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        bar = QHBoxLayout()
        bar.setContentsMargins(14, 8, 14, 8)
        close = QPushButton("●")
        close.setObjectName("Dot")
        close.setFixedSize(16, 16)
        close.clicked.connect(self.close)
        title = QLabel("Export")
        title.setObjectName("WinTitle")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        bar.addWidget(close)
        bar.addWidget(title, 1)
        self.cancel_btn = QPushButton("Cancel render")
        self.cancel_btn.setObjectName("Danger")
        self.cancel_btn.setVisible(False)
        self.cancel_btn.clicked.connect(self.cancel_export.emit)
        bar.addWidget(self.cancel_btn)
        root.addLayout(bar)

        tabs = QHBoxLayout()
        tabs.setContentsMargins(12, 8, 12, 8)
        tabs.addStretch(1)
        self._tabs = {}
        for key, label in (("local", "Local"), ("device", "Device"), ("social", "Social Media"), ("dvd", "DVD")):
            b = QPushButton(label)
            b.setCheckable(True)
            b.setObjectName("Tab")
            b.clicked.connect(lambda _=False, k=key: self._set_tab(k))
            self._tabs[key] = b
            tabs.addWidget(b)
        tabs.addStretch(1)
        root.addLayout(tabs)
        self._tabs["local"].setChecked(True)

        body = QHBoxLayout()
        body.setContentsMargins(14, 4, 14, 8)
        body.setSpacing(12)
        left = QVBoxLayout()
        self.thumb = QLabel("Thumbnail")
        self.thumb.setObjectName("Thumb")
        self.thumb.setFixedSize(240, 136)
        self.thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        left.addWidget(self.thumb)
        self.thumb_btn = QPushButton("Edit cover")
        self.thumb_btn.clicked.connect(self._next_thumb)
        left.addWidget(self.thumb_btn)
        self.signal = QLabel()
        self.signal.setObjectName("Signal")
        self.signal.setWordWrap(True)
        self.signal.setTextFormat(Qt.TextFormat.RichText)
        left.addWidget(self.signal)
        left.addStretch(1)
        body.addLayout(left)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        host = QWidget()
        form = QVBoxLayout(host)
        form.setContentsMargins(0, 0, 4, 0)
        form.setSpacing(8)

        self.profile_label = QLabel("Target profile")
        self.profile = QComboBox()
        self.profile.currentTextChanged.connect(self._on_profile)
        form.addWidget(self.profile_label)
        form.addWidget(self.profile)
        self.dest_note = QLabel("")
        self.dest_note.setObjectName("Hint")
        self.dest_note.setWordWrap(True)
        form.addWidget(self.dest_note)

        form.addWidget(QLabel("Title"))
        self.title_edit = QLineEdit()
        form.addWidget(self.title_edit)
        form.addWidget(QLabel("Save to"))
        save = QHBoxLayout()
        self.folder = QLineEdit(str(Path.home() / "Videos"))
        folder_btn = QPushButton("Folder")
        folder_btn.clicked.connect(self._pick_folder)
        save.addWidget(self.folder, 1)
        save.addWidget(folder_btn)
        form.addLayout(save)

        form.addWidget(QLabel("Preset"))
        preset_row = QHBoxLayout()
        self.preset = QComboBox()
        self.preset.currentTextChanged.connect(self._on_preset)
        save_preset = QPushButton("Save preset")
        save_preset.clicked.connect(self._save_preset)
        preset_row.addWidget(self.preset, 1)
        preset_row.addWidget(save_preset)
        form.addLayout(preset_row)

        card = QFrame()
        card.setObjectName("Card")
        grid = QGridLayout(card)
        self.format = self._combo(grid, 0, 0, "Format", ["mp4", "mov", "mkv", "avi", "mp3", "wav"], self._on_format)
        self.resolution = self._combo(grid, 0, 1, "Resolution", [r.replace("x", "*") for r in _RESOLUTIONS], self._on_resolution)
        self.encoder = self._combo(grid, 1, 0, "Encoder", ["H.264", "H.265", "MPEG-4"], self._on_encoder)
        self.quality = self._combo(grid, 1, 1, "Quality", ["High", "Medium", "Low", "Custom"], self._on_quality)
        form.addWidget(card)

        summary = QHBoxLayout()
        self.summary = QLabel("30 fps  |  20000 kbps  |  SDR - Rec.709")
        adv = QPushButton("Advanced >")
        adv.setObjectName("Link")
        adv.clicked.connect(self._toggle_advanced)
        summary.addWidget(self.summary, 1)
        summary.addWidget(adv)
        form.addLayout(summary)

        self.advanced = QFrame()
        self.advanced.setObjectName("Card")
        self.advanced.setVisible(False)
        ag = QGridLayout(self.advanced)
        self.fps = QComboBox()
        self.fps.addItems(["24", "25", "30", "50", "60"])
        self.fps.setCurrentText("30")
        self.fps.currentTextChanged.connect(lambda _t: self._refresh_readout())
        ag.addWidget(QLabel("Frame rate"), 0, 0)
        ag.addWidget(self.fps, 1, 0)
        self.bitrate_mode = QComboBox()
        self.bitrate_mode.addItems(["VBR", "CBR"])
        self.bitrate_mode.currentTextChanged.connect(lambda _t: self._refresh_readout())
        ag.addWidget(QLabel("Bitrate mode"), 0, 1)
        ag.addWidget(self.bitrate_mode, 1, 1)
        self.video_kbps = QSpinBox()
        self.video_kbps.setRange(500, 80000)
        self.video_kbps.setSingleStep(500)
        self.video_kbps.setValue(20000)
        self.video_kbps.valueChanged.connect(self._on_custom_bitrate)
        ag.addWidget(QLabel("Video bitrate (kbps)"), 2, 0)
        ag.addWidget(self.video_kbps, 3, 0)
        self.audio_enc = QComboBox()
        self.audio_enc.addItems(["AAC", "MP3", "PCM"])
        self.audio_enc.currentTextChanged.connect(lambda _t: self._refresh_readout())
        ag.addWidget(QLabel("Audio"), 2, 1)
        ag.addWidget(self.audio_enc, 3, 1)
        self.audio_kbps = QComboBox()
        self.audio_kbps.addItems(["128", "192", "256", "320"])
        self.audio_kbps.setCurrentText("320")
        self.audio_kbps.currentTextChanged.connect(lambda _t: self._refresh_readout())
        ag.addWidget(QLabel("Audio bitrate (kbps)"), 2, 2)
        ag.addWidget(self.audio_kbps, 3, 2)
        self.sample_rate = QComboBox()
        self.sample_rate.addItems(["44100", "48000"])
        ag.addWidget(QLabel("Sample rate"), 4, 0)
        ag.addWidget(self.sample_rate, 5, 0)
        self.channels = QComboBox()
        self.channels.addItems(["Stereo", "Mono"])
        ag.addWidget(QLabel("Channels"), 4, 1)
        ag.addWidget(self.channels, 5, 1)
        self.color = QComboBox()
        self.color.addItems(["SDR - Rec.709", "SDR - Rec.601"])
        ag.addWidget(QLabel("Color space"), 6, 0)
        ag.addWidget(self.color, 7, 0)
        self.video_only = QCheckBox("Video only (no narration or poem audio)")
        self.video_only.toggled.connect(lambda _v: self._refresh_readout())
        ag.addWidget(self.video_only, 8, 0, 1, 2)
        form.addWidget(self.advanced)

        comp = QFrame()
        comp.setObjectName("Card")
        cl = QHBoxLayout(comp)
        cl.setContentsMargins(10, 8, 10, 8)
        self.compression = QCheckBox("Advanced Compression")
        self.compression.setChecked(True)
        self.compression.toggled.connect(lambda _v: self._refresh_readout())
        self.comp_mode = QComboBox()
        self.comp_mode.addItems(["By Quality", "By Bitrate"])
        self.comp_mode.setMinimumWidth(126)
        self.comp_mode.currentTextChanged.connect(lambda _t: self._refresh_readout())
        self.comp_pct = QComboBox()
        self.comp_pct.addItems([f"{n}%" for n in (30, 40, 50, 60, 70, 75, 80, 85, 90)])
        self.comp_pct.setCurrentText("70%")
        self.comp_pct.setMinimumWidth(78)
        self.comp_pct.currentTextChanged.connect(lambda _t: self._refresh_readout())
        cl.addWidget(self.compression)
        cl.addStretch(1)
        cl.addWidget(self.comp_mode)
        cl.addWidget(self.comp_pct)
        form.addWidget(comp)

        self.logo = QCheckBox("Brand logo on the video")
        self.logo.toggled.connect(self._on_logo)
        form.addWidget(self.logo)
        srt = QLabel("Subtitles are saved as a separate SRT beside the video. They are not burned into the picture.")
        srt.setObjectName("Hint")
        srt.setWordWrap(True)
        form.addWidget(srt)
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress.setRange(0, 100)
        form.addWidget(self.progress)
        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.status.setObjectName("Hint")
        form.addWidget(self.status)
        form.addStretch(1)
        scroll.setWidget(host)
        body.addWidget(scroll, 1)
        root.addLayout(body, 1)

        foot = QHBoxLayout()
        foot.setContentsMargins(14, 8, 14, 12)
        self.meta = QLabel()
        self.meta.setObjectName("Hint")
        foot.addWidget(self.meta, 1)
        srt_btn = QPushButton("Export SRT only")
        srt_btn.clicked.connect(self._srt_only)
        wfp = QPushButton("Save .wfp")
        wfp.clicked.connect(lambda: self._pack("wfp"))
        bundle = QPushButton("Collect .wfpbundle")
        bundle.clicked.connect(lambda: self._pack("wfpbundle"))
        self.export_btn = QPushButton("Export")
        self.export_btn.setObjectName("Go")
        self.export_btn.clicked.connect(self._export)
        show = QPushButton("Show in folder")
        show.clicked.connect(self._show_folder)
        for b in (srt_btn, wfp, bundle, show, self.export_btn):
            foot.addWidget(b)
        root.addLayout(foot)
        self._set_tab("local")

    def _combo(self, grid: QGridLayout, row: int, col: int, label: str, items: list[str], handler) -> QComboBox:
        box = QVBoxLayout()
        box.addWidget(QLabel(label))
        combo = QComboBox()
        combo.blockSignals(True)
        combo.addItems(items)
        combo.blockSignals(False)
        combo.currentTextChanged.connect(lambda _t: handler())
        box.addWidget(combo)
        wrap = QWidget()
        wrap.setLayout(box)
        grid.addWidget(wrap, row, col)
        return combo

    # Models ----------------------------------------------------------------

    def _fill_presets(self) -> None:
        name = self.preset.currentText()
        self.preset.blockSignals(True)
        self.preset.clear()
        for key in list(_BUILTINS) + sorted(self._custom):
            self.preset.addItem(key)
        if name:
            self.preset.setCurrentText(name)
        self.preset.blockSignals(False)

    def _set_tab(self, key: str) -> None:
        for k, b in self._tabs.items():
            b.setChecked(k == key)
        profiles = {"device": _DEVICES, "social": _SOCIAL, "dvd": _DVD}.get(key)
        show = profiles is not None
        self.profile_label.setVisible(show)
        self.profile.setVisible(show)
        self.dest_note.setText({
            "local": "Saves the file in the folder above. A video also writes an SRT beside it. Words are not burned into the picture.",
            "device": "Saves an H.264 file with AAC audio at that device's size. It does not copy itself onto the phone or TV.",
            "social": "Saves an H.264 file with AAC audio at that site's size. It does not log in or upload.",
            "dvd": "Saves the video for a USB stick. It does not burn a disc.",
        }[key])
        if profiles:
            labels = {
                "device": "Target device profile",
                "social": "Target platform profile",
                "dvd": "Disc / media profile",
            }[key]
            self.profile_label.setText(labels)
            self.profile.blockSignals(True)
            self.profile.clear()
            self.profile.addItems(list(profiles))
            self.profile.blockSignals(False)
            self._on_profile(self.profile.currentText())

    def _on_profile(self, name: str) -> None:
        table = None
        if self._tabs["device"].isChecked():
            table = _DEVICES
        elif self._tabs["social"].isChecked():
            table = _SOCIAL
        elif self._tabs["dvd"].isChecked():
            table = _DVD
        if not table or name not in table:
            return
        res, kbps = table[name]
        self._settings["resolution"] = res
        self._settings["video_bitrate_kbps"] = kbps
        self._settings["quality_preset"] = "custom"
        self._settings["preset_name"] = name
        self._push_widgets()

    def _on_preset(self, name: str) -> None:
        src = _BUILTINS.get(name) or self._custom.get(name)
        if src:
            self._apply_settings(dict(src))

    def _apply_settings(self, src: dict) -> None:
        self._settings = {**_MATCH, **src}
        self._push_widgets()

    def _push_widgets(self) -> None:
        s = self._settings
        self._set_combo(self.format, s.get("format") or "mp4")
        self._set_combo(self.resolution, str(s.get("resolution") or "1920x1080").replace("x", "*"))
        self._set_combo(self.encoder, {"h264": "H.264", "h265": "H.265", "mpeg4": "MPEG-4"}.get(s.get("encoder"), "H.264"))
        self._set_combo(self.quality, str(s.get("quality_preset") or "high").capitalize())
        self._set_combo(self.fps, str(int(s.get("fps") or 30)))
        self._set_combo(self.bitrate_mode, str(s.get("bitrate_mode") or "vbr").upper())
        self.video_kbps.blockSignals(True)
        self.video_kbps.setValue(int(s.get("video_bitrate_kbps") or 20000))
        self.video_kbps.blockSignals(False)
        self._set_combo(self.audio_enc, str(s.get("audio_encoder") or "aac").upper())
        self._set_combo(self.audio_kbps, str(int(s.get("audio_bitrate_kbps") or 320)))
        self._set_combo(self.sample_rate, str(int(s.get("audio_sample_rate") or 44100)))
        self._set_combo(self.channels, "Mono" if s.get("audio_channels") == "mono" else "Stereo")
        self._set_combo(self.color, "SDR - Rec.601" if s.get("color_space") == "bt601" else "SDR - Rec.709")
        self.compression.blockSignals(True)
        self.compression.setChecked(bool(s.get("advanced_compression", True)))
        self.compression.blockSignals(False)
        self._set_combo(self.comp_mode, "By Bitrate" if s.get("compression_mode") == "by_bitrate" else "By Quality")
        self._set_combo(self.comp_pct, f"{int(s.get('compression_quality') or 70)}%")
        self.video_only.blockSignals(True)
        self.video_only.setChecked(bool(s.get("export_video_only")))
        self.video_only.blockSignals(False)
        self._refresh_readout()

    def _set_combo(self, box: QComboBox, text: str) -> None:
        box.blockSignals(True)
        if box.findText(text) < 0 and text:
            box.addItem(text)
        box.setCurrentText(text)
        box.blockSignals(False)

    def _gather(self) -> dict:
        fmt = self.format.currentText()
        quality = self.quality.currentText().lower()
        audio_enc = {"AAC": "aac", "MP3": "mp3", "PCM": "pcm"}.get(self.audio_enc.currentText(), "aac")
        if fmt == "mp3":
            audio_enc = "mp3"
        elif fmt == "wav":
            audio_enc = "pcm"
        enc = {"H.264": "h264", "H.265": "h265", "MPEG-4": "mpeg4"}.get(self.encoder.currentText(), "h264")
        res = self.resolution.currentText().replace("*", "x")
        kbps = self.video_kbps.value()
        if quality != "custom":
            kbps = bitrate_for(res, quality, enc, kbps)
            self.video_kbps.blockSignals(True)
            self.video_kbps.setValue(kbps)
            self.video_kbps.blockSignals(False)
        video = fmt in ("mp4", "mov", "mkv", "avi")
        return {
            "format": fmt,
            "resolution": res,
            "fps": int(self.fps.currentText() or 30),
            "encoder": enc,
            "quality_preset": quality,
            "bitrate_mode": self.bitrate_mode.currentText().lower(),
            "video_bitrate_kbps": kbps,
            "compression_mode": "by_bitrate" if self.comp_mode.currentText() == "By Bitrate" else "by_quality",
            "compression_quality": int(str(self.comp_pct.currentText()).replace("%", "") or 70),
            "audio_encoder": audio_enc,
            "audio_bitrate_kbps": int(self.audio_kbps.currentText() or 320),
            "audio_sample_rate": int(self.sample_rate.currentText() or 44100),
            "audio_channels": "mono" if self.channels.currentText() == "Mono" else "stereo",
            "color_space": "bt601" if "601" in self.color.currentText() else "bt709",
            "advanced_compression": self.compression.isChecked(),
            "export_video_only": self.video_only.isChecked(),
            "export_srt_sidecar": False,
            "burn_subtitles": False,
            "include_logo": bool(self.logo.isChecked()) and video,
            "preset_name": self.preset.currentText() or "Match Project",
        }

    def _refresh_readout(self) -> None:
        s = self._gather()
        self._settings = s
        video = s["format"] in ("mp4", "mov", "mkv", "avi")
        on = bool(s["advanced_compression"]) and video
        self.compression.setEnabled(video)
        self.comp_mode.setEnabled(on)
        self.comp_pct.setEnabled(on)
        sig = signal_for(s, self._duration, self._still_share)
        color = "SDR - Rec.709" if s["color_space"] == "bt709" else "SDR - Rec.601"
        if video:
            self.summary.setText(f"{s['fps']} fps   |   {sig['video']:,} kbps   |   CRF {sig['crf']}   |   {color}")
            if sig["comp"]:
                detail = (
                    f"{sig['pct']}% compression of {sig['base']:,} kbps"
                    f" · cap {sig['video']:,} kbps · CRF {sig['crf']}"
                )
            else:
                detail = f"Compression off · {sig['video']:,} kbps · CRF {sig['crf']}"
            self.signal.setText(
                f"<span style='color:{sig['color']}'>{sig['badge']}</span><br>{detail}"
                f"<br>{sig['audio']} kbps audio · about {sig['stream']:,} kbps average"
            )
            logo = "Logo on" if s["include_logo"] else "Logo off"
            self.meta.setText(f"Duration {self._duration/60:.1f} min · about {sig['mb']:.0f} MB · {logo} · poem line on the poem screens · SRT is separate")
        else:
            self.summary.setText("Audio only")
            self.signal.setText("Audio file. No picture and no logo.")
            self.meta.setText(f"Duration {self._duration/60:.1f} min · audio only")

    def _on_format(self) -> None:
        video = self.format.currentText() in ("mp4", "mov", "mkv", "avi")
        for w in (self.resolution, self.encoder, self.quality, self.logo):
            w.setEnabled(video)
        self._refresh_readout()

    def _on_resolution(self) -> None:
        self._refresh_readout()

    def _on_encoder(self) -> None:
        self._refresh_readout()

    def _on_quality(self) -> None:
        self._refresh_readout()

    def _on_custom_bitrate(self) -> None:
        if self.quality.currentText() != "Custom":
            self.quality.setCurrentText("Custom")
        self._refresh_readout()

    def _on_logo(self, on: bool) -> None:
        self.logo_toggled.emit(bool(on))
        self._refresh_readout()

    def _toggle_advanced(self) -> None:
        self.advanced.setVisible(not self.advanced.isVisible())

    def _save_preset(self) -> None:
        name = self.preset.currentText().strip() or "Custom"
        if name in _BUILTINS:
            name = name + " copy"
        settings = self._gather()
        settings["preset_name"] = name
        self._custom[name] = settings
        _save_custom(self._custom)
        self._fill_presets()
        self.preset.setCurrentText(name)
        self.status.setText(f"Saved preset {name}.")

    def _pick_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Save to", self.folder.text().strip() or str(Path.home()))
        if folder:
            self.folder.setText(folder)

    def _dest(self, ext: str) -> str:
        folder = Path(self.folder.text().strip() or str(Path.home() / "Videos"))
        raw = self.title_edit.text().strip() or "Export"
        name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", raw).strip().rstrip(". ") or "Export"
        return str(folder / f"{name}.{ext}")

    def _export(self) -> None:
        if self._running:
            return
        settings = self._gather()
        self.start_export.emit(settings, self._dest(settings["format"]))

    def _srt_only(self) -> None:
        dest, _ = QFileDialog.getSaveFileName(self, "Export SRT", self._dest("srt"), "SubRip (*.srt)")
        if dest:
            self.export_srt.emit(dest)

    def _pack(self, kind: str) -> None:
        ext = "wfp" if kind == "wfp" else "wfpbundle"
        dest = self._dest(ext)
        self.status.setText(f"Saving {dest}")
        if kind == "wfp":
            self.save_wfp.emit(dest)
        else:
            self.save_bundle.emit(dest)

    def _show_folder(self) -> None:
        folder = self.folder.text().strip()
        if folder:
            QDesktopServices.openUrl(QUrl.fromLocalFile(folder))

    def _show_thumb(self) -> None:
        if not self._images:
            self.thumb.setText("No picture yet")
            self.thumb_btn.setText("Edit cover")
            return
        path, label = self._images[self._thumb_i % len(self._images)]
        pix = QPixmap(path)
        if pix.isNull():
            self.thumb.setText(label)
        else:
            self.thumb.setPixmap(pix.scaled(self.thumb.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        self.thumb_btn.setText(f"Edit cover ({self._thumb_i % len(self._images) + 1}/{len(self._images)})")

    def _next_thumb(self) -> None:
        if not self._images:
            return
        self._thumb_i = (self._thumb_i + 1) % len(self._images)
        self._show_thumb()

    def closeEvent(self, e) -> None:  # noqa: N802
        if self._running:
            self.cancel_export.emit()
        super().closeEvent(e)


_QSS = """
FilmoraExportWindow, QScrollArea, QWidget { background: #171b20; color: #e4e8ee; }
QLabel#WinTitle { font-weight: 600; color: #f0f3f7; }
QLabel#Hint { color: #8c96a4; }
QLabel#Thumb { background: #101418; border: 1px solid rgba(255,255,255,0.12); border-radius: 8px; }
QFrame#Card { background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; }
QLineEdit, QComboBox, QSpinBox {
    background: rgba(0,0,0,0.35); border: 1px solid rgba(255,255,255,0.12);
    border-radius: 6px; padding: 4px 8px; color: #e4e8ee; min-height: 22px;
}
QComboBox QAbstractItemView {
    background: #1c2228; color: #e4e8ee;
    selection-background-color: rgba(28,214,176,0.35); selection-color: #f0fdfa;
    border: 1px solid rgba(255,255,255,0.12); outline: 0;
}
QComboBox:disabled { color: #5c6772; }
QLabel#Signal {
    background: rgba(28,214,176,0.08); border: 1px solid rgba(28,214,176,0.35);
    border-radius: 8px; padding: 8px;
}
QPushButton { background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.12); border-radius: 6px; padding: 5px 10px; }
QPushButton#Tab { background: transparent; border: 0; color: #8c96a4; }
QPushButton#Tab:checked { background: rgba(28,214,176,0.16); color: #a7f3e2; }
QPushButton#Go { background: #1cd6b0; color: #06241c; font-weight: 700; border: 0; }
QPushButton#Link { background: transparent; border: 0; color: #5eead4; }
QPushButton#Danger { background: rgba(244,63,94,0.2); color: #fecdd3; }
QPushButton#Dot { background: #ff5f57; border: 0; border-radius: 8px; color: transparent; padding: 0; }
QCheckBox { spacing: 6px; }
QProgressBar { background: #101418; border: 0; border-radius: 4px; height: 8px; text-align: center; }
QProgressBar::chunk { background: #1cd6b0; border-radius: 4px; }
"""
