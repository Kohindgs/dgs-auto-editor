"""The editor window: same panels and order as the current DGS editor."""

from __future__ import annotations

import platform
import re
import shutil
import subprocess
from pathlib import Path

from PySide6.QtCore import QRect, Qt, QTimer
from PySide6.QtGui import QGuiApplication, QKeySequence, QPixmap, QShortcut
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMenu,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from .. import paths, theme
from ..core import card_match, deep_qa, edits, folder_sync, qa
from ..core.caption_video import (
    build_editable_chapter_from_video,
    copy_command,
    export_command,
    format_srt,
    hear,
    next_free_pair,
    probe_video,
    words_to_cues,
)
from ..core.plan import Heard, PlanIndex, scene_label
from ..core.project_store import (
    AUDIO_EXT,
    DEFAULT_LOGO_TRANSFORM,
    IMAGE_EXT,
    VIDEO_EXT,
    Project,
    create_blank_project,
    list_projects,
    load_project,
    script_engine,
)
from ..core.script_import import ScriptFormatError, check_master_format, read_script
from ..engine import chapter
from ..engine.bridge import Engine, EngineError, EngineJob
from ..engine.clock import PlayheadClock
from ..engine.ocr import CardReader
from ..engine.player import AudioDeck
from .dialogs import LogoTransformDialog, PoemTextDialog, UpdatesDialog
from .export_window import FilmoraExportWindow
from .media_pack_dialog import MediaPackDialog
from .preview_panel import PreviewPanel
from .side_panels import LeftPanel, RightPanel, SpecsPanel
from .timeline_view import TimelineDock


def _filter(exts: set[str], label: str) -> str:
    return f"{label} (" + " ".join(f"*{e}" for e in sorted(exts)) + ")"


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("D'Auto Aline")
        self.setMinimumSize(960, 620)
        self.resize(1440, 860)
        self.project: Project | None = None
        self.index: PlanIndex | None = None
        self.clock = PlayheadClock(self)
        self.audio = AudioDeck()
        self._force = True
        self._srt_preview = False
        self._enlarged = False
        self._was_maximized = True
        self._logo_dialog: LogoTransformDialog | None = None
        self.cards = CardReader(self)
        self._ocr_texts: dict[str, str] = {}
        self._swap_undo: list[dict] = []
        self._ocr_pid = ""
        self._job: EngineJob | None = None
        self._logo_job: dict | None = None
        self._logo_proc: subprocess.Popen | None = None
        self._undo: list[dict] = []
        self._redo: list[dict] = []

        root = QWidget()
        root.setObjectName("Root")
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(10, 8, 10, 8)
        outer.setSpacing(7)

        self.top = self._build_top_bar()
        outer.addWidget(self.top)

        self.left = LeftPanel()
        self.specs = SpecsPanel()
        self.preview = PreviewPanel()
        self.right = RightPanel()
        self.timeline = TimelineDock()

        self.columns = QSplitter(Qt.Orientation.Horizontal)
        self.columns.setChildrenCollapsible(False)
        for w in (self.left, self.specs, self.preview, self.right):
            self.columns.addWidget(w)
        self.left.setMinimumWidth(220)
        self.specs.setMinimumWidth(160)
        self.right.setMinimumWidth(220)
        self.columns.setStretchFactor(0, 2)
        self.columns.setStretchFactor(1, 1)
        self.columns.setStretchFactor(2, 5)
        self.columns.setStretchFactor(3, 2)
        self.columns.setSizes([315, 210, 635, 320])

        self.rows = QSplitter(Qt.Orientation.Vertical)
        self.rows.setChildrenCollapsible(False)
        self.rows.addWidget(self.columns)
        self.rows.addWidget(self.timeline)
        self.rows.setStretchFactor(0, 6)
        self.rows.setStretchFactor(1, 4)
        self.rows.setSizes([560, 300])
        outer.addWidget(self.rows, 1)

        self.status = QLabel("Open a project to begin.")
        self.status.setObjectName("StatusLine")
        outer.addWidget(self.status)

        self.toast = theme.NeonToast(self)
        self._responsive_initialized = False

        self._wire()
        self._shortcuts()
        self._set_index(None)

    def showEvent(self, e) -> None:  # noqa: N802
        super().showEvent(e)
        if not getattr(self, "_responsive_initialized", False):
            self._responsive_initialized = True
            QTimer.singleShot(0, self._apply_responsive_layout)

    def resizeEvent(self, e) -> None:  # noqa: N802
        super().resizeEvent(e)
        self._update_top_bar_density()
        if hasattr(self, "toast") and self.toast.isVisible():
            self.toast.reposition()

    def _apply_responsive_layout(self) -> None:
        """Proportion columns and rows cleanly across small laptops (1280x720) up to 4K monitors."""
        w = max(960, self.width())
        h = max(620, self.height())
        if w < 1380:
            self.left.setMinimumWidth(215)
            self.specs.setMinimumWidth(150)
            self.right.setMinimumWidth(215)
            self.columns.setSizes([int(w * 0.21), int(w * 0.13), int(w * 0.44), int(w * 0.22)])
        else:
            self.left.setMinimumWidth(250)
            self.specs.setMinimumWidth(180)
            self.right.setMinimumWidth(250)
            self.columns.setSizes([int(w * 0.20), int(w * 0.13), int(w * 0.45), int(w * 0.22)])
        self.rows.setSizes([int(h * 0.63), int(h * 0.37)])
        self._update_top_bar_density()

    def _update_top_bar_density(self) -> None:
        """Compact top-bar button padding on narrower laptop screens so all controls fit with zero scroll."""
        compact = self.width() < 1420
        pad_css = "padding: 2px 7px; font-size: 11px;" if compact else ""
        for tb_btn in getattr(self, "_top_btns", ()):
            tb_btn.setStyleSheet(pad_css)

    def notify_event(
        self,
        title: str,
        message: str,
        *,
        kind: str = "success",
        file_path: str | None = None,
        modal: bool = False,
        chime: bool = True,
    ) -> None:
        """Display a Cosmic Neon toast banner (and optional completion modal for exports)."""
        self.set_status(f"{title} · {message}" if title else message)
        if hasattr(self, "toast"):
            self.toast.show_toast(
                title or "D'Auto Aline",
                message,
                kind=kind,
                file_path=file_path,
                chime=chime,
            )
        if modal:
            theme.NeonCompletionDialog.show_modal(self, title or "Completed", message, file_path=file_path)

    # Build -----------------------------------------------------------------

    def _build_top_bar(self) -> QFrame:
        bar = QFrame()
        bar.setObjectName("TopBar")
        h = QHBoxLayout(bar)
        h.setContentsMargins(10, 5, 10, 5)
        h.setSpacing(6)

        # Compact logo-only glowing D'AA neon emblem (leaves maximum room for header controls with zero scroll)
        self.brand_widget = theme.DaaNeonBrandWidget(bar)
        h.addWidget(self.brand_widget)

        def make_capsule() -> tuple[QFrame, QHBoxLayout]:
            cap = QFrame()
            cap.setObjectName("TopCapsule")
            cl = QHBoxLayout(cap)
            cl.setContentsMargins(6, 3, 6, 3)
            cl.setSpacing(5)
            return cap, cl

        # Capsule 1: PROJECT WORKSPACE
        cap_proj, lp = make_capsule()
        self.btn_new = QPushButton("New Project")
        self.btn_new.setObjectName("Primary")
        theme.set_btn_neon_icon(self.btn_new, "plus", "#ffffff", 16)
        self.btn_new.setToolTip("Create a clean blank project workspace immediately (no sudden popups)")
        self.btn_new.clicked.connect(self.new_project)
        lp.addWidget(self.btn_new)

        self.btn_open = QPushButton("Open")
        theme.set_btn_neon_icon(self.btn_open, "folder", "#f472b6", 16)
        self.btn_open.setToolTip("Open a chapter folder saved by D'Auto Aline")
        self.btn_open.clicked.connect(self.open_project_dialog)
        lp.addWidget(self.btn_open)

        self.btn_recent = QPushButton("Recent")
        theme.set_btn_neon_icon(self.btn_recent, "clock", "#c084fc", 16)
        self.btn_recent.setToolTip("Switch to a recently opened project")
        self.recent_menu = QMenu(self)
        self.recent_menu.aboutToShow.connect(self._fill_recent)
        self.btn_recent.setMenu(self.recent_menu)
        lp.addWidget(self.btn_recent)

        self.btn_save = QPushButton("Save")
        theme.set_btn_neon_icon(self.btn_save, "save", "#38bdf8", 16)
        self.btn_save.setToolTip("Save the timeline, logo and file links of this chapter (Ctrl+S)")
        self.btn_save.clicked.connect(self.save)
        lp.addWidget(self.btn_save)
        h.addWidget(cap_proj)

        # Capsule 2: IMPORT & MEDIA SYNC
        cap_imp, li = make_capsule()
        self.btn_script = QPushButton("Add Script")
        self.btn_script.setObjectName("Accent")
        theme.set_btn_neon_icon(self.btn_script, "script", "#e879f9", 16)
        self.btn_script.setToolTip("Add the master script workbook (.xlsx) to this chapter")
        self.btn_script.clicked.connect(self.import_script)
        self.btn_script.setEnabled(False)
        li.addWidget(self.btn_script)

        self.btn_open_wfp = QPushButton("Filmora .wfp")
        theme.set_btn_neon_icon(self.btn_open_wfp, "film", "#c084fc", 16)
        self.btn_open_wfp.setToolTip("Open a Filmora .wfp or a collected .wfpbundle as a chapter")
        self.btn_open_wfp.clicked.connect(self.open_filmora_file)
        li.addWidget(self.btn_open_wfp)

        self.btn_caption = QPushButton("Video && SRT")
        theme.set_btn_neon_icon(self.btn_caption, "clapper", "#22d3ee", 16)
        self.btn_caption.setToolTip(
            "Starts a New Project from one video: speech becomes scenes, VO is pulled out, "
            "then you edit and Export like a normal chapter. SRT stays a separate file."
        )
        self.btn_caption.clicked.connect(self.import_logo_video)
        li.addWidget(self.btn_caption)

        self.btn_link = QPushButton("Link Folder")
        self.btn_link.setObjectName("Accent")
        theme.set_btn_neon_icon(self.btn_link, "link", "#f472b6", 16)
        self.btn_link.setToolTip("Pick the chapter folder on this PC. Pictures, videos, VO and poem files are matched by name and scene number.")
        self.btn_link.clicked.connect(self.link_source_folder)
        li.addWidget(self.btn_link)

        self.btn_refresh = QPushButton("Refresh")
        theme.set_btn_neon_icon(self.btn_refresh, "refresh", "#38bdf8", 16)
        self.btn_refresh.setToolTip("Read the linked folder again. New or replaced pictures and videos are put on their scene numbers.")
        self.btn_refresh.clicked.connect(self.refresh_folder)
        li.addWidget(self.btn_refresh)
        h.addWidget(cap_imp)

        h.addStretch(1)

        # Capsule 3: AI ENGINE & RENDER
        cap_eng, le = make_capsule()
        self.lang_box = QComboBox()
        self.lang_box.setObjectName("LangBox")
        self.lang_box.addItem("English", "en")
        self.lang_box.addItem("Marathi", "mr")
        self.lang_box.setToolTip("Engine for this chapter. English never uses the Marathi engine. Marathi never uses the English engine.")
        self.lang_box.setFixedWidth(92)
        self.lang_box.setFixedHeight(29)
        self.lang_box.currentIndexChanged.connect(self._on_language_picked)
        le.addWidget(self.lang_box)

        self.btn_align = QPushButton("Auto-Align")
        self.btn_align.setObjectName("NeonCyan")
        theme.set_btn_neon_icon(self.btn_align, "bolt", "#22d3ee", 16)
        self.btn_align.setToolTip(
            "Cut this chapter with the engine selected in the language box.\n"
            "English stays on the English engine. Marathi stays on the Marathi engine."
        )
        self.btn_align.clicked.connect(self.auto_align)
        le.addWidget(self.btn_align)

        self.btn_export = QPushButton("Export")
        self.btn_export.setObjectName("Primary")
        theme.set_btn_neon_icon(self.btn_export, "export", "#ffffff", 16)
        self.btn_export.setToolTip(
            "Export the video or the audio. The logo is included only when it is on. "
            "An SRT is saved next to an MP4 and is never burned into the picture."
        )
        self.btn_export.clicked.connect(self.open_export)
        le.addWidget(self.btn_export)

        self.btn_updates = QPushButton("Updates")
        theme.set_btn_neon_icon(self.btn_updates, "bell", "#fbbf24", 16)
        self.btn_updates.setToolTip("Version and published changes. Pings when a newer install is available.")
        self.btn_updates.clicked.connect(self.open_updates)
        le.addWidget(self.btn_updates)
        self._update_report: dict | None = None
        self._update_pinged = False
        QTimer.singleShot(1800, self._start_update_check)
        self._update_poll_timer = QTimer(self)
        self._update_poll_timer.setInterval(90_000)
        self._update_poll_timer.timeout.connect(self._poll_remote_updates)
        self._update_poll_timer.start()
        h.addWidget(cap_eng)

        self._top_btns = (
            self.btn_updates, self.btn_save, self.btn_recent, self.btn_new,
            self.btn_script, self.btn_open, self.btn_open_wfp, self.btn_caption,
            self.btn_align, self.btn_export, self.btn_link, self.btn_refresh,
        )
        for tb_btn in self._top_btns:
            tb_btn.setFixedHeight(29)
        return bar

    def _wire(self) -> None:
        self.clock.tick.connect(self._on_tick)
        self.clock.running_changed.connect(self._on_running)

        pv = self.preview
        pv.play_toggled.connect(self.toggle_play)
        pv.seek_requested.connect(self.seek)
        pv.jump_requested.connect(self.jump)
        pv.stop_requested.connect(self.stop)
        pv.volume_changed.connect(self._on_volume)
        pv.mute_toggled.connect(self._on_mute)
        pv.logo_toggled.connect(lambda on: self.set_flag("logo_enabled", on))
        pv.fill_toggled.connect(pv.surface.set_fill)
        pv.align_dock_toggled.connect(self.right.align_box.setVisible)
        pv.enlarge_toggled.connect(self.set_enlarged)
        pv.fullscreen_toggled.connect(self.toggle_fullscreen)
        pv.srt_toggled.connect(self._on_srt)
        pv.srt_btn.blockSignals(True)
        pv.srt_btn.setChecked(False)
        pv.srt_btn.blockSignals(False)
        pv.poem_text_requested.connect(self.open_poem_text)
        pv.surface.logo_moved.connect(self._on_logo_moved)
        pv.surface.lyric_moved.connect(self._on_lyric_moved)
        pv.surface.replace_placeholder.connect(self._replace_placeholder)
        pv.surface.logo_reset.connect(self.reset_logo_transform)

        tl = self.timeline
        tl.flag_toggled.connect(self.set_flag)
        tl.edit_requested.connect(self._on_edit)
        tl.canvas.seek_requested.connect(self.seek)
        tl.canvas.clip_selected.connect(self._on_clip_selected)
        tl.canvas.vo_selected.connect(lambda _i: self.timeline.refresh_edit_buttons())
        tl.canvas.clip_menu.connect(self._clip_menu)
        tl.canvas.vo_menu.connect(self._vo_menu)
        tl.canvas.clip_resized.connect(self._on_clip_resized)
        tl.canvas.vo_trimmed.connect(self._on_vo_trimmed)

        lp = self.left
        lp.image_folder.connect(lambda: self.link_folder("images"))
        lp.video_folder.connect(lambda: self.link_folder("videos"))
        lp.image_files.connect(lambda: self.link_files("images"))
        lp.video_files.connect(lambda: self.link_files("videos"))
        lp.media_pack.connect(self.open_media_pack)
        lp.narration_vo.connect(self.link_narration)
        lp.download_vo.connect(self.download_narration)
        lp.remove_vo.connect(self.remove_narration)
        lp.poem_vo.connect(self.link_poem)
        lp.download_poem.connect(self.download_poem_file)
        lp.remove_poem.connect(self.remove_poem)
        lp.logo_toggled.connect(lambda on: self.set_flag("logo_enabled", on))
        lp.change_logo.connect(self.change_logo)
        lp.logo_placement.connect(self.open_logo_placement)
        lp.logo_default.connect(self.default_logo)
        lp.import_script.connect(self.import_script)
        lp.save_template.connect(self.save_script_template)
        lp.jump_to.connect(self.seek)

        rp = self.right
        rp.jump_to.connect(self.seek)
        rp.ignored_changed.connect(lambda _k: self._dirty_changed())
        rp.read_cards.connect(lambda: self.read_cards(manual=True))
        rp.undo_swaps.connect(self.undo_swaps)
        rp.flags_changed.connect(self.timeline.canvas.set_flags)
        self.cards.progress.connect(self._on_cards_progress)
        self.cards.finished.connect(self._on_cards_read)
        self.cards.failed.connect(self._on_cards_failed)

    def _shortcuts(self) -> None:
        def sc(key, fn):
            s = QShortcut(QKeySequence(key), self)
            s.setContext(Qt.ShortcutContext.WindowShortcut)
            s.activated.connect(fn)

        sc(Qt.Key.Key_Space, self.toggle_play)
        sc(Qt.Key.Key_Left, lambda: self.step(-1 / 30))
        sc(Qt.Key.Key_Right, lambda: self.step(1 / 30))
        sc("Shift+Left", lambda: self.step(-1.0))
        sc("Shift+Right", lambda: self.step(1.0))
        sc(Qt.Key.Key_Home, lambda: self.jump("start"))
        sc(Qt.Key.Key_End, lambda: self.jump("end"))
        sc("Ctrl+S", self.save)
        sc("Ctrl+Z", lambda: self._on_edit("undo"))
        sc("Ctrl+Y", lambda: self._on_edit("redo"))
        sc("Ctrl+Shift+Z", lambda: self._on_edit("redo"))
        sc(Qt.Key.Key_Delete, lambda: self._on_edit("delete_vo" if self.timeline.canvas.selected_vo else "delete"))
        sc(Qt.Key.Key_Backspace, lambda: self._on_edit("delete_vo" if self.timeline.canvas.selected_vo else "delete"))
        sc("S", lambda: self._on_edit("split_vo" if self.timeline.canvas.selected_vo else "split"))
        sc("[", lambda: self._on_edit("trim_in"))
        sc("]", lambda: self._on_edit("trim_out"))
        sc(Qt.Key.Key_F11, self.toggle_fullscreen)
        sc(Qt.Key.Key_Escape, self._escape)

    # Project ---------------------------------------------------------------

    def _detach_session(self) -> None:
        """Drop playback, OCR, and UI state from the previous chapter.

        A new or other project must not keep the last chapter's VO, poem,
        pictures, Poem text, captions, or card swaps in memory.
        """
        from ..core.plan import set_scene_catalog

        set_scene_catalog(None)
        self.clock.pause()
        try:
            self.audio.pause()
        except Exception:
            pass
        self.cards.cancel()
        self._logo_job = None
        self._logo_proc = None
        self._ocr_texts, self._swap_undo, self._ocr_pid = {}, [], ""
        self._undo, self._redo = [], []
        self._language_override = None
        self._srt_preview = False
        self._still_pre = None
        self.right.card_issues = []
        self.right.set_cards_status("")
        self.right.btn_undo_swaps.setVisible(False)
        dlg = getattr(self, "_poem_dialog", None)
        if dlg is not None:
            try:
                dlg.close()
            except Exception:
                pass
            self._poem_dialog = None
        surf = self.preview.surface
        surf.logo_locked = False
        surf.set_video_frame(0, 0)
        try:
            surf.set_lyric("", {}, 0.0, 1.0)
            surf.set_caption("")
            surf.set_note("")
            surf.show_picture("", "image", 0.0, 1.0, False, True)
        except Exception:
            pass
        try:
            surf.drop_stills()
        except Exception:
            pass
        try:
            self.timeline.canvas.thumbs.clear()
        except Exception:
            pass
        try:
            self.timeline.canvas.selected_clip = -1
            self.timeline.canvas.selected_vo = ""
        except Exception:
            pass
        self._picture_text_off()

    def open_project(self, root: Path, *, confirm: bool = True) -> bool:
        if confirm and not self._confirm_discard():
            return False
        self._detach_session()
        try:
            proj = load_project(root)
        except (OSError, ValueError) as e:
            QMessageBox.warning(self, "Open project", str(e))
            return False
        self.project = proj
        self._set_index(PlanIndex(proj))
        # Every chapter opens with the narration off the picture. The same
        # export rule then applies: poem lyric only on a poem, SRT on its own.
        self._picture_text_off()
        self.seek(0.0)
        if self._resume_video_srt():
            return True
        idx = self.index
        found = sum(1 for f in idx.files if f[0])
        sound = sum(1 for n in {int(s.get('slot') or 1) for s in proj.slots} if idx.slot_file(n))
        self.set_status(
            f"Opened {proj.title} · {len(idx.clips)} scenes · {found} of {len(idx.clips)} pictures and "
            f"{sound} of {len(proj.slots) or 1} VO files found on this PC"
            + ("" if found == len(idx.clips) else " · use Link Source Folder for the rest")
        )
        QTimer.singleShot(0, self._check_script_format)
        QTimer.singleShot(0, self._refresh_qa)
        QTimer.singleShot(400, self.read_cards)
        return True

    # Script ----------------------------------------------------------------

    def _check_script_format(self) -> None:
        p = self.project
        if not p:
            self.left.set_script_report("", None)
            return
        name = str(p.script_meta.get("filename") or "")
        src = p.root / "script" / name if name else None
        if not src or not src.is_file():
            self.left.set_script_report("Script workbook is not in this chapter folder; format not checked.", None)
            return
        try:
            rep = check_master_format(src)
        except Exception as e:  # noqa: BLE001
            self.left.set_script_report(f"Could not read {name}: {e}", False)
            return
        self.left.set_script_report(rep.message() if rep.ok else f"Older layout (not the master format): {' '.join(rep.problems)}", rep.ok)

    def import_script(self) -> None:
        p = self.project
        if not p:
            return
        f, _ = QFileDialog.getOpenFileName(self, "Import master script", "", "Master script workbook (*.xlsx *.xlsm)")
        if not f:
            return
        src = Path(f)
        try:
            res = read_script(src, require_master=True)
        except ScriptFormatError as e:
            self.left.set_script_report(str(e), False)
            QMessageBox.warning(self, "Import script", str(e))
            return
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Import script", f"Could not read {src.name}: {e}")
            return
        if not res.scenes:
            QMessageBox.warning(self, "Import script", f"{src.name} passed the format check but has no scene rows in Sheet1.")
            return
        old = str(p.script_meta.get("filename") or "")
        if p.scenes and QMessageBox.question(
            self, "Import script", f"Replace the script {old or '(current)'} ({len(p.scenes)} scenes) with {src.name} ({len(res.scenes)} scenes)?"
        ) != QMessageBox.StandardButton.Yes:
            return
        try:
            p.set_script(res.scenes, res.meta, src)
        except OSError as e:
            QMessageBox.warning(self, "Import script", f"Could not save the script: {e}")
            return
        p.plan["language"] = script_engine(res.scenes)
        p.plan["language_choice"] = p.plan["language"]
        self._language_override = None
        self._reindex()
        self.left.set_script_report(res.report.message() if res.report else "", True)
        poem = res.meta["poem"]
        clip_screens = {str(c.get("screen")) for c in p.clips}
        script_screens = {s["screen"] for s in res.scenes}
        gap = len(script_screens - clip_screens)
        engine = "Marathi" if p.plan.get("language") == "mr" else "English"
        msg = (
            f"Imported {src.name} · {len(res.scenes)} scenes · {engine} engine"
            + (f" · poem {scene_label(poem['first_screen'])}–{scene_label(poem['last_screen'])}" if poem.get("has_poem") else "")
            + (f" · {gap} script scenes have no clip on Video 1 yet" if gap else "")
            + " · timeline timing unchanged"
        )
        self.notify_event("Master Script Imported", msg, kind="success")
        if self._ocr_texts:
            self._match_cards(auto_swap=True)

    def save_script_template(self) -> None:
        tpl = paths.script_template()
        if not tpl:
            return
        f, _ = QFileDialog.getSaveFileName(self, "Save master script template", "DGS_Master_Script_Template.xlsx", "Excel workbook (*.xlsx)")
        if not f:
            return
        try:
            shutil.copyfile(tpl, f)
        except OSError as e:
            QMessageBox.warning(self, "Save template", str(e))
            return
        self.set_status(f"Saved the master script template to {f}")

    # Card text (OCR) -------------------------------------------------------

    def _indic(self) -> bool:
        p = self.project
        if not p:
            return False
        pl = p.plan
        return pl.get("language") in ("mr", "hi") or pl.get("align_engine") == "marathi" or card_match.script_looks_indic(p.scenes)

    def _align_language(self) -> str:
        """One module for every chapter. A Marathi script uses the Marathi module.
        An English script uses the English module. The language box can override it."""
        p = self.project
        if not p:
            return "en"
        picked = getattr(self, "_language_override", None)
        if picked in ("en", "mr"):
            return picked
        return script_engine(p.scenes)

    def _show_language(self) -> None:
        box = getattr(self, "lang_box", None)
        if box is None:
            return
        lang = self._align_language() if self.project else "en"
        box.blockSignals(True)
        box.setCurrentIndex(1 if lang == "mr" else 0)
        box.blockSignals(False)

    def _on_language_picked(self) -> None:
        p = self.project
        if not p:
            return
        lang = str(self.lang_box.currentData() or "en")
        self._language_override = lang
        if str(p.plan.get("language_choice") or "") == lang and str(p.plan.get("language") or "") == lang:
            return
        p.plan["language"] = lang
        p.plan["language_choice"] = lang
        p.dirty = True
        self.specs.set_index(self.index)
        self._dirty_changed()
        self.set_status("English engine for this chapter." if lang == "en" else "Marathi engine for this chapter.")

    def read_cards(self, *, manual: bool = False) -> None:
        p = self.project
        if not p or self.cards.running:
            return
        self._manual_ocr = bool(manual)
        items = {img["id"]: img["path"] for img in p.image_media()}
        for i, c in enumerate(self.index.clips if self.index else []):
            mid = str(c.get("media_id") or "")
            path, kind = self.index.files[i]
            if c.get("kind") == "image" and mid and mid not in items and kind == "image":
                items[mid] = path
        if not items:
            self.right.set_cards_status("No pictures on this PC to read yet.")
            return
        if not paths.tesseract_exe():
            self.right.set_cards_status("Tesseract OCR is not bundled with this build.")
            return
        self._ocr_pid = p.pid
        self.right.btn_read_cards.setEnabled(False)
        self.right.set_cards_status(f"Reading cards… 0 / {len(items)} ({'Marathi + English' if self._indic() else 'English'})")
        self.cards.start(p.meta, items, self._indic())

    def _on_cards_progress(self, done: int, total: int) -> None:
        lang = "Marathi + English" if self._indic() else "English"
        self.right.set_cards_status(f"Reading cards… {done} / {total} ({lang})")

    def _on_cards_failed(self, msg: str) -> None:
        self.right.btn_read_cards.setEnabled(self.project is not None)
        self.right.set_cards_status(f"Card reading failed: {msg}")

    def _on_cards_read(self, texts: dict) -> None:
        self.right.btn_read_cards.setEnabled(self.project is not None)
        if not self.project or self.project.pid != self._ocr_pid:
            return
        self._ocr_texts = dict(texts)
        self._match_cards(auto_swap=True)

    def _match_cards(self, auto_swap: bool) -> None:
        p = self.project
        if not p:
            return
        texts = self._ocr_texts
        swaps_note = ""
        if auto_swap and not p.flag("video_track_locked"):
            images = [img for img in p.image_media() if img["id"] in texts]
            props = card_match.propose_auto_matches(p.clips, p.scenes, images, texts)
            if props:
                self._swap_undo += card_match.apply_auto_matches(p.clips, props)
                p.dirty = True
                old = {str(m.get("id")): str(m.get("filename") or "") for m in p.media if isinstance(m, dict)}
                swaps_note = "Auto-swapped " + "; ".join(
                    f"{scene_label(m.screen)}: {old.get(m.from_id) or 'picture'} → {m.to['filename']}" for m in props
                )
                folder_notes = folder_sync.apply_swaps_to_folder(p, props)
                if folder_notes:
                    swaps_note += " · folder: " + "; ".join(folder_notes)
                self._reindex()
        issues = card_match.build_card_text_issues(p.clips, p.scenes, texts)
        flagged = {str(i.get("screen") or "") for i in issues if i.get("screen")}
        issues = issues + card_match.build_matra_issues(p.clips, p.scenes, texts, flagged)
        heard = deep_qa.load_heard_words(p)
        issues = issues + deep_qa.build_deep_vo_and_card_issues(p.clips, p.scenes, texts, flagged, heard)
        self.right.set_card_issues(issues)
        self._refresh_qa()
        self.right.btn_undo_swaps.setVisible(bool(self._swap_undo))
        lang = "Marathi + English" if self._indic() else "English"
        summary_str = (
            f"Read {len(texts)} cards ({lang}) · {len(issues)} card bubble{'s' if len(issues) != 1 else ''}"
            + (" · Video 1 is locked, so no pictures were swapped" if auto_swap and p.flag("video_track_locked") else "")
        )
        self.right.set_cards_status(summary_str)
        if swaps_note:
            self.notify_event("Card OCR Auto-Swap", swaps_note, kind="success")
        elif getattr(self, "_manual_ocr", False):
            self.notify_event("Card OCR Scan Complete", summary_str, kind="success")
        self._manual_ocr = False
        self._dirty_changed()

    def undo_swaps(self) -> None:
        p = self.project
        if not p or not self._swap_undo:
            return
        n = card_match.undo_auto_matches(p.clips, list(reversed(self._swap_undo)))
        self._swap_undo = []
        p.dirty = True
        self._reindex()
        self._match_cards(auto_swap=False)
        self.set_status(f"Put back {n} picture{'s' if n != 1 else ''} the card match had swapped")

    def open_project_dialog(self) -> None:
        start = str(paths.data_dir() / "projects")
        folder = QFileDialog.getExistingDirectory(self, "Open a chapter folder", start)
        if not folder:
            return
        root = Path(folder)
        if root.name.lower() == "meta":
            root = root.parent
        if not (root / "meta" / "timeline.json").is_file():
            QMessageBox.information(self, "Open project", "That folder is not a DGS chapter (no meta/timeline.json).")
            return
        self.open_project(root)

    def _fill_recent(self) -> None:
        self.recent_menu.clear()
        items = list_projects()[:15]
        if not items:
            a = self.recent_menu.addAction("No chapters saved yet")
            a.setEnabled(False)
            return
        for s in items:
            a = self.recent_menu.addAction(f"{s.title}   ({s.pid})")
            a.triggered.connect(lambda _=False, r=s.root: self.open_project(r))
        self.recent_menu.addSeparator()
        a = self.recent_menu.addAction("Open the chapters folder…")
        a.triggered.connect(self.open_project_dialog)

    def _set_index(self, index: PlanIndex | None) -> None:
        self.index = index
        self.clock.set_duration(index.duration if index else 0.0)
        self.preview.duration = index.duration if index else 0.0
        self.timeline.set_index(index)
        self.left.set_index(index)
        self.specs.set_index(index)
        self.right.set_index(index)
        busy = bool(self._job and self._job.running)
        for b in (self.btn_save, self.btn_link, self.btn_refresh, self.btn_align, self.btn_export):
            b.setEnabled(index is not None and not busy)
        for b in (self.btn_new, self.btn_open, self.btn_open_wfp, self.btn_script):
            b.setEnabled(not busy if b is not self.btn_script else index is not None)
        self._apply_flags()
        self._show_language()
        self._force = True
        self._on_tick(self.clock.position())
        self._dirty_changed()

    def _reindex(self) -> None:
        """Rebuild lookups after links or flags change. Keeps the playhead."""
        if not self.project:
            return
        t = self.clock.position()
        scroll, px = self.timeline.canvas.scroll, self.timeline.canvas.px
        self._set_index(PlanIndex(self.project))
        self.timeline.canvas.px = px
        self.timeline.canvas.set_scroll(scroll)
        self.clock.seek(t)

    def _apply_flags(self) -> None:
        p = self.project
        surf = self.preview.surface
        if not p:
            surf.set_logo(False, "", {})
            self.preview.set_logo_state(False)
            return
        surf.set_logo(p.logo_enabled, p.logo_file(), p.logo_transform)
        self.preview.set_logo_state(p.logo_enabled)
        self.audio.vo_muted = p.flag("vo_muted")
        self.audio.poem_muted = p.flag("poem_muted")

    def set_flag(self, key: str, on: bool) -> None:
        p = self.project
        if not p:
            return
        if key == "logo_enabled":
            p.set_logo_enabled(on)
            if self._logo_job:
                # Placement stays locked to the Filmora corner. On/off still works.
                self.preview.surface.set_logo(on, p.logo_file(), DEFAULT_LOGO_TRANSFORM)
                self.preview.set_logo_state(on)
                self.set_status("Brand logo on" if on else "Brand logo off")
                return
        else:
            p.set_flag(key, on)
        self._reindex()
        names = {
            "logo_enabled": ("Brand logo on", "Brand logo off"),
            "video_track_hidden": ("Video 1 hidden in preview", "Video 1 shown"),
            "video_track_locked": ("Video 1 locked", "Video 1 unlocked"),
            "script_track_hidden": ("Script lane hidden", "Script lane shown"),
            "vo_muted": ("VoiceOver muted", "VoiceOver on"),
            "vo_track_locked": ("Voice locked", "Voice unlocked"),
            "poem_muted": ("Poem muted", "Poem on"),
            "poem_track_locked": ("Poem locked", "Poem unlocked"),
        }.get(key, (key, key))
        self.set_status(names[0] if on else names[1])

    def save(self, *, silent: bool = False) -> bool:
        if not self.project:
            return False
        try:
            self.project.save()
        except OSError as e:
            QMessageBox.warning(self, "Save", f"Could not save: {e}")
            return False
        self._dirty_changed()
        msg = f"Saved {self.project.title} to {self.project.meta}"
        if silent:
            self.set_status(msg)
        else:
            self.notify_event("Project Saved", msg, kind="success", chime=False)
        return True

    def _dirty_changed(self) -> None:
        from ..core.plan import chapter_title as printed_title

        p = self.project
        shown = ""
        if p:
            shown = printed_title() or str(p.title or "").strip()
        name = f"{shown} — " if shown else ""
        self.setWindowTitle(f"{'• ' if p and p.dirty else ''}{name}D'Auto Aline")

    def _confirm_discard(self) -> bool:
        if not self.project or not self.project.dirty:
            return True
        r = QMessageBox.question(
            self,
            "Unsaved changes",
            f"Save changes to {self.project.title}?",
            QMessageBox.StandardButton.Save | QMessageBox.StandardButton.Discard | QMessageBox.StandardButton.Cancel,
        )
        if r == QMessageBox.StandardButton.Save:
            self.save(silent=True)
            return not self.project.dirty
        return r == QMessageBox.StandardButton.Discard

    # Linking files ---------------------------------------------------------

    def link_source_folder(self) -> None:
        if not self.project:
            return
        folder = QFileDialog.getExistingDirectory(self, "Pick the chapter's source folder")
        if not folder:
            return
        rep = self.project.link_folder(Path(folder))
        self._reindex()
        audio = ", ".join(rep["audio"]) or "no VO or poem file names matched"
        msg = f"Linked {rep['named']} by name · {rep['images']} pictures and {rep['videos']} videos by scene number · {audio}"
        self.notify_event("Source Folder Linked", msg, kind="success")

    def _pull_linked_files(self) -> None:
        """Point every scene at the file now in the linked folder, then drop cached pictures."""
        p = self.project
        if not p or self._logo_job or p.plan.get("video_srt"):
            return
        rep = p.refresh_linked_media()
        if not rep.get("ok"):
            return
        self.preview.surface.drop_stills()
        self.timeline.canvas.thumbs.clear()
        self._reindex()

    def refresh_folder(self) -> None:
        p = self.project
        if not p:
            return
        rep = p.refresh_linked_media()
        if not rep.get("ok"):
            self.notify_event(
                "No Source Folder Linked",
                "Link Source Folder first. Refresh reads that folder for new pictures and videos.",
                kind="warn",
                chime=False,
            )
            return
        self.preview.surface.drop_stills()
        self.timeline.canvas.thumbs.clear()
        self._reindex()
        updated = int(rep.get("updated") or 0)
        note = f" · {updated} scene{'s' if updated != 1 else ''} now use a different file" if updated else ""
        msg = f"Refreshed the linked folder · {rep['images']} pictures and {rep['videos']} videos{note}"
        self.notify_event("Folder Refreshed", msg, kind="success", chime=False)

    def link_folder(self, kind: str) -> None:
        if not self.project:
            return
        folder = QFileDialog.getExistingDirectory(self, "Image Folder" if kind == "images" else "Video Folder")
        if not folder:
            return
        rep = self.project.link_folder(Path(folder), kind)
        self._reindex()
        self.left.scene_toggle.setChecked(True)
        msg = f"Added {rep.get('added', 0)} files from {folder}"
        self.notify_event(f"{'Image' if kind == 'images' else 'Video'} Folder Linked", msg, kind="success")

    def link_files(self, kind: str) -> None:
        if not self.project:
            return
        exts = IMAGE_EXT if kind == "images" else VIDEO_EXT
        files, _ = QFileDialog.getOpenFileNames(self, "Add files", "", _filter(exts, "Images" if kind == "images" else "Videos"))
        if not files:
            return
        n = self.project.link_files([Path(f) for f in files], kind)
        self._reindex()
        self.left.scene_toggle.setChecked(True)
        msg = f"Added {n} of {len(files)} files"
        self.notify_event("Media Files Added", msg, kind="success", chime=False)

    def open_media_pack(self) -> None:
        """Download chapter media for other apps, or upload replacements (Filmora-style)."""
        if not self.project:
            QMessageBox.information(self, "Media Pack", "Open a chapter first.")
            return

        def duration_of(path: Path) -> float:
            try:
                dur, _ = chapter.analyze_audio(path)
                return float(dur or 0)
            except Exception:
                return 0.0

        dlg = MediaPackDialog(self.project, self, duration_of=duration_of)
        dlg.exec()
        report = dlg.last_report
        if not report or not report.replaced:
            return
        # Re-register any VO / poem slots that were swapped so silences stay current.
        pid = self.project.pid
        vo_slots = sorted({
            int(m.split()[1]) for m in report.replaced
            if m.startswith("VO ") and m.split()[1:2] and str(m.split()[1]).isdigit()
        })
        poem_slots = sorted({
            int(m.split()[1]) for m in report.replaced
            if m.startswith("Poem ") and m.split()[1:2] and str(m.split()[1]).isdigit()
        })

        def work(eng: Engine, emit) -> str:
            for slot in vo_slots:
                path = Path(self.project.slot_path(slot))
                if path.is_file():
                    emit(f"Reading replaced VO {slot} ({path.name})…")
                    chapter.register_vo(eng, pid, slot, path)
            for slot in poem_slots:
                path = Path(self.project.poem_slot_path(slot))
                if path.is_file():
                    emit(f"Reading replaced Poem {slot} ({path.name})…")
                    chapter.register_poem(eng, pid, path, slot)
            return f"✓ Media Pack · {report.summary()}"

        if vo_slots or poem_slots:
            self._run_job("Updating replaced VO…", work)
        else:
            self.project.dirty = True
            self._reindex()
            self._refresh_qa()
            self.notify_event("Media Pack Updated", report.summary(), kind="success")

    def download_narration(self, slot: int) -> None:
        """Save the full Narration VO file (Media / VO tab Download…)."""
        if not self.project or not self.index:
            return
        path_str = self.index.slot_file(int(slot))
        if not path_str or not Path(path_str).is_file():
            QMessageBox.information(self, "Download VO", f"VO {slot} is not on this PC yet.")
            return
        src = Path(path_str)
        dest, _ = QFileDialog.getSaveFileName(
            self, f"Download Narration VO {slot}", src.name or f"VO_{slot}.mp3", _filter(AUDIO_EXT, "Audio")
        )
        if not dest:
            return
        out = Path(dest)
        if not out.suffix:
            out = out.with_suffix(src.suffix or ".mp3")
        try:
            if src.resolve() != out.resolve():
                shutil.copy2(src, out)
        except OSError as e:
            QMessageBox.warning(self, "Download VO", str(e) or "Could not save that file.")
            return
        self.notify_event(
            f"VO {slot} Downloaded",
            f"Saved VO {slot} → {out.name}. Edit it, then click Replace…",
            kind="success",
            file_path=str(out),
        )

    def download_poem_file(self, slot: int = 1) -> None:
        """Save the full Poem VO file."""
        if not self.project:
            return
        path_str = self.project.poem_slot_path(int(slot))
        if not path_str or not Path(path_str).is_file():
            QMessageBox.information(self, "Download poem", f"Poem {slot} is not on this PC yet.")
            return
        src = Path(path_str)
        dest, _ = QFileDialog.getSaveFileName(
            self, f"Download Poem {slot}", src.name or f"Poem_{slot}.mp3", _filter(AUDIO_EXT, "Audio")
        )
        if not dest:
            return
        out = Path(dest)
        if not out.suffix:
            out = out.with_suffix(src.suffix or ".mp3")
        try:
            if src.resolve() != out.resolve():
                shutil.copy2(src, out)
        except OSError as e:
            QMessageBox.warning(self, "Download poem", str(e) or "Could not save that file.")
            return
        self.notify_event(
            f"Poem {slot} Downloaded",
            f"Saved Poem {slot} → {out.name}. Edit it, then click Replace…",
            kind="success",
            file_path=str(out),
        )

    def link_narration(self, slot: int) -> None:
        if not self.project:
            return
        f, _ = QFileDialog.getOpenFileName(self, f"Replace Narration VO {slot}", "", _filter(AUDIO_EXT, "Audio"))
        if not f:
            return
        path = Path(f)
        self.project.set_slot_path(slot, path)
        # Filmora Media Library replace: keep every voice block; point pieces at the new file.
        from ..core.media_pack import _remap_slot_pieces

        def duration_of(p: Path) -> float:
            try:
                dur, _ = chapter.analyze_audio(p)
                return float(dur or 0)
            except Exception:
                return 0.0

        _remap_slot_pieces(self.project.plan, slot, str(path), duration_of, poem=False)
        self._reindex()
        pid = self.project.pid

        def work(eng: Engine, emit) -> str:
            emit(f"Reading VO {slot} ({path.name}) on this PC…")
            meta = chapter.register_vo(eng, pid, slot, path)
            return (
                f"✓ Narration VO {slot} replaced ({path.name}) · "
                f"Total VO {chapter.fmt(float(meta.get('duration') or 0))} · "
                "timeline voice blocks stayed (Filmora-style). Auto-align only if you need a fresh hear."
            )

        self._run_job(f"Linking VO {slot}…", work)

    def remove_narration(self, slot: int) -> None:
        p = self.project
        if not p or QMessageBox.question(self, "Remove VO", f"Remove VO {slot} from this chapter? The audio file stays on disk.") != QMessageBox.StandardButton.Yes:
            return
        p.links.get("vo_slots", {}).pop(str(slot), None)
        p.dirty = True
        pid = p.pid
        self._run_job(f"Removing VO {slot}…", lambda eng, emit: (chapter.remove_vo(eng, pid, slot), f"Removed VO {slot}")[1])

    def link_poem(self, slot: int = 1) -> None:
        if not self.project:
            return
        f, _ = QFileDialog.getOpenFileName(self, f"Poem {slot}", "", _filter(AUDIO_EXT, "Audio"))
        if not f:
            return
        path = Path(f)
        self.project.set_poem_slot_path(int(slot), path)
        self._reindex()
        pid = self.project.pid

        def work(eng: Engine, emit) -> str:
            emit(f"Reading Poem {slot} ({path.name}) on this PC…")
            meta = chapter.register_poem(eng, pid, path, int(slot))
            n = len(meta.get("slots") or [])
            return (
                f"✓ Poem {slot} replaced ({path.name}, {chapter.fmt(float(meta.get('duration') or 0))} all together)"
                f" · {n} poem file{'s' if n != 1 else ''} · timeline stays (Filmora-style). Auto-align only if you need a fresh lyric lock"
            )

        self._run_job(f"Linking Poem {slot}…", work)

    def remove_poem(self, slot: int) -> None:
        p = self.project
        if not p or QMessageBox.question(self, "Remove poem", f"Remove Poem {slot} from this chapter? The audio file stays on disk.") != QMessageBox.StandardButton.Yes:
            return
        p._link_map("poem_slots").pop(str(slot), None)
        if int(slot) == 1:
            p.links.pop("poem", None)
        p.dirty = True
        pid = p.pid
        self._run_job(f"Removing Poem {slot}…", lambda eng, emit: (chapter.remove_poem(eng, pid, slot), f"Removed Poem {slot}")[1])

    # Engine jobs -----------------------------------------------------------

    def _engine(self) -> Engine:
        return Engine.for_project(self.project.root) if self.project else Engine.for_data(paths.data_dir())

    def _run_job(self, label: str, work, done=None, reload: bool = True, on_progress=None) -> bool:
        """Save, then run ``work(engine, emit) -> message`` off the UI thread and reload the chapter."""
        if self._job and self._job.running:
            self.set_status("Still working on the previous step…")
            return False
        if self.project and not self.save(silent=True):
            return False
        eng = self._engine()
        job = EngineJob(lambda emit: work(eng, emit), self)
        job.progress.connect(self.set_status)
        if on_progress is not None:
            job.progress.connect(on_progress)
        job.done.connect(lambda r: self._job_finished(r, done, reload))
        job.failed.connect(self._job_failed)
        self._job = job
        self.set_status(label)
        job.start()
        self._set_busy()
        return True

    def _set_busy(self) -> None:
        busy = bool(self._job and self._job.running)
        on = self.index is not None and not busy
        for b in (self.btn_save, self.btn_link, self.btn_refresh, self.btn_align, self.btn_export):
            b.setEnabled(on)
        for b in (self.btn_new, self.btn_open, self.btn_open_wfp):
            b.setEnabled(not busy)
        self.btn_script.setEnabled(self.index is not None)

    def _job_finished(self, result, done, reload: bool) -> None:
        self._job_end()
        if reload and self.project:
            if self.project.plan.get("video_srt"):
                self.reload_project()
                self._resume_video_srt()
            else:
                self._logo_job = None
                self.preview.surface.logo_locked = False
                self.preview.surface.set_video_frame(0, 0)
                self.reload_project()
        elif self._logo_job:
            self._apply_logo_plan()
        if done:
            done(result)
        elif isinstance(result, str):
            title = "Auto-Align Complete" if "align" in result.lower() or "scenes" in result.lower() else "Task Complete"
            self.notify_event(title, result, kind="success")

    def _job_failed(self, msg: str) -> None:
        self._job_end()
        dlg = getattr(self, "_export_dlg", None)
        if dlg is not None and dlg.isVisible():
            dlg.mark_failed(msg)
        if self.project:
            self.reload_project()
        if self._logo_job:
            self._apply_logo_plan()
        title = "Auto-align" if msg.startswith(("STOPPED", "Waiting")) else "D'Auto Aline"
        self.notify_event(title, msg, kind="warn")
        QMessageBox.information(self, title, msg)

    def _job_end(self) -> None:
        if self._job:
            self._job.deleteLater()
        self._job = None
        self._set_busy()

    def reload_project(self) -> None:
        """Pick up what the engine wrote; keeps the playhead and the card reading."""
        p = self.project
        if not p:
            return
        t = self.clock.position()
        try:
            proj = load_project(p.root)
        except (OSError, ValueError) as e:
            self.set_status(f"Could not reload {p.title}: {e}")
            return
        self.project = proj
        self._swap_undo = []
        self.right.btn_undo_swaps.setVisible(False)
        self._set_index(PlanIndex(proj))
        self.seek(min(t, self.index.duration if self.index else 0.0))
        if self._ocr_texts and self._ocr_pid == proj.pid:
            self._match_cards(auto_swap=False)
        self._check_script_format()

    def new_project(self) -> None:
        """Create and open a fresh blank project immediately without sudden blocking popups."""
        if self._job and self._job.running:
            self.set_status("Still working on the previous step…")
            return
        if self.project and self.project.dirty:
            self.save(silent=True)
        try:
            root = create_blank_project()
        except OSError as e:
            QMessageBox.warning(self, "New project", f"Could not create a new project: {e}")
            return
        if not self.open_project(root, confirm=False):
            return
        self.notify_event(
            "New Project Created",
            "Blank workspace is ready. Use '📄 Add Script…', '📁 Image Folder', or '🎬 Video & SRT' whenever you are ready.",
            kind="info",
        )

    def open_filmora_file(self) -> None:
        if not self._confirm_discard():
            return
        f, _ = QFileDialog.getOpenFileName(
            self, "Open Filmora file", "", "Filmora project (*.wfp *.wfpbundle);;DGS project (*.dgsproj *.json *.zip)"
        )
        if not f:
            return
        path = Path(f)

        def work(eng: Engine, emit) -> Path:
            emit(f"Opening {path.name}…")
            pid = chapter.open_project_file(eng, path)
            return eng.data_dir / "projects" / pid

        def opened(root: Path) -> None:
            if self.open_project(root, confirm=False):
                self.notify_event(
                    "Filmora Project Imported",
                    f"Opened {path.name} as {self.project.title} · {len(self.project.clips)} clips",
                    kind="success",
                )

        self._run_job(f"Opening {path.name}…", work, opened, reload=False)

    def auto_align(self) -> None:
        p = self.project
        if not p:
            return
        if p.flag("video_track_locked"):
            QMessageBox.information(self, "Auto-align", "Video 1 is locked. Unlock it on the Video 1 track to re-cut the scenes.")
            return
        lang = str(self.lang_box.currentData() or self._align_language())
        p.plan["language"] = lang
        p.plan["language_choice"] = lang
        if (
            self._logo_job
            or p.plan.get("video_srt")
            or p.plan.get("from_uploaded_video")
            or (p.script_meta or {}).get("format") == "uploaded_video"
        ):
            clips = p.clips
            vid_path = str(
                (self._logo_job or {}).get("path")
                or (clips[0].get("media_path") if clips else "")
                or ""
            )
            if vid_path and Path(vid_path).is_file():
                try:
                    info = probe_video(Path(vid_path))
                except (OSError, RuntimeError) as exc:
                    QMessageBox.warning(self, "Auto-align", str(exc) or "The video file could not be read.")
                    return
                self._logo_job = {
                    "path": vid_path,
                    "info": info,
                    "language": "mr" if lang.lower() in ("mr", "marathi") else "en",
                    "cues": [],
                }
                self._hear_logo_video()
                return
        if p.clips and p.plan.get("manual_override") and QMessageBox.question(
            self, "Auto-align", "This timeline has hand edits. Auto-align re-cuts every scene to the heard VO. Continue?"
        ) != QMessageBox.StandardButton.Yes:
            return

        def work(eng: Engine, emit) -> str:
            return chapter.auto_align(eng, proj_copy, lang, emit)["message"]

        proj_copy = p
        self._run_job("Auto-align: preparing…", work)

    # Timeline edits --------------------------------------------------------

    def _refresh_qa(self) -> None:
        p, idx = self.project, self.index
        if not p or not idx:
            return
        native = qa.scan_timeline_qa(p.plan, p.scenes, idx.files)
        keep = [
            i for i in (p.plan.get("qa_issues") or [])
            if isinstance(i, dict)
            and i.get("source") not in ("native_scan", "ocr_native", "ocr_client")
            and i.get("kind") not in ("card_text", "missing_card", "uncovered_narration", "missing_poem_vo", "vo_mismatch")
        ]
        p.plan["qa_issues"] = keep + native
        self.right.set_card_issues(self.right.card_issues)

    def _push_undo(self) -> None:
        if self.project:
            self._undo.append(edits.snapshot(self.project.plan))
            self._undo = self._undo[-40:]
            self._redo.clear()

    def _restore(self, snap: dict) -> None:
        p = self.project
        if not p:
            return
        p.plan.clear()
        p.plan.update(edits.snapshot(snap))
        p.dirty = True
        self._reindex()
        self._refresh_qa()

    def _on_edit(self, cmd: str) -> None:
        p, idx = self.project, self.index
        if not p or not idx:
            return
        if cmd == "undo":
            if self._undo:
                self._redo.append(edits.snapshot(p.plan))
                self._restore(self._undo.pop())
                self.set_status("Undo")
            return
        if cmd == "redo":
            if self._redo:
                self._undo.append(edits.snapshot(p.plan))
                self._restore(self._redo.pop())
                self.set_status("Redo")
            return
        i = self.timeline.canvas.selected_clip
        t = self.clock.position()
        vo_id = self.timeline.canvas.selected_vo
        locked = p.flag("video_track_locked")
        vo_locked = p.flag("vo_track_locked")
        if cmd == "download":
            self._download_clip(i if i >= 0 else idx.clip_index_at(t))
            return
        if cmd == "download_vo":
            self._download_vo_section(vo_id or None)
            return
        if cmd == "replace_vo":
            if vo_locked:
                return
            self._replace_vo_section(vo_id or None)
            return
        if cmd in ("split_vo", "delete_vo") and (vo_locked or not vo_id):
            return
        if cmd not in ("split_vo", "delete_vo", "undo", "redo") and (locked or i < 0):
            return
        if cmd in ("replace", "replace_image", "replace_video"):
            scr = str((idx.clips[i] if 0 <= i < len(idx.clips) else {}).get("screen") or "")
            fk = "image" if cmd == "replace_image" else ("video" if cmd == "replace_video" else None)
            self._replace_media(scr, force_kind=fk, clip_index=i)
            return
        self._push_undo()
        plan = p.plan
        if cmd == "delete":
            edits.delete_clip(plan, i)
        elif cmd == "pull_prev":
            edits.delete_and_elongate_previous(plan, str(idx.clips[i].get("screen")))
        elif cmd == "pull_left":
            edits.elongate_left(plan, i)
        elif cmd == "pull_right":
            edits.elongate_right(plan, i)
        elif cmd == "fit":
            edits.fit_to_vo(plan, i)
        elif cmd == "split":
            edits.split_clip(plan, i, t)
        elif cmd == "trim_in":
            edits.trim_in(plan, i, t)
        elif cmd == "trim_out":
            edits.trim_out(plan, i, t)
        elif cmd == "split_vo":
            self._ensure_vo_pieces()
            edits.split_vo(plan, vo_id, t)
        elif cmd == "delete_vo":
            self._ensure_vo_pieces()
            edits.delete_vo(plan, vo_id)
        p.dirty = True
        self._reindex()
        self._refresh_qa()
        self.set_status(f"Edit: {cmd.replace('_', ' ')}")

    def _on_clip_resized(self, i: int, a: float, b: float) -> None:
        p = self.project
        if not p or p.flag("video_track_locked"):
            return
        self._push_undo()
        edits.apply_clips(p.plan, edits.resolve_overwrites(list(p.clips), i, a, b))
        p.dirty = True
        self._reindex()

    def _on_vo_trimmed(self, piece_id: str, edge: str, at: float) -> None:
        p = self.project
        if not p or p.flag("vo_track_locked"):
            return
        if not isinstance(p.plan.get("vo_pieces"), list):
            p.plan["vo_pieces"] = [dict(x) for x in (self.index.vo_pieces() if self.index else [])]
        self._push_undo()
        edits.trim_vo(p.plan, piece_id, edge, at)
        p.dirty = True
        self._reindex()

    def _replace_placeholder(self) -> None:
        idx = self.index
        if not idx:
            return
        i = idx.clip_index_at(self.clock.position())
        if i < 0:
            return
        self._replace_media(str(idx.clips[i].get("screen") or ""), clip_index=i)

    def _replace_media(self, screen: str, force_kind: str | None = None, clip_index: int | None = None) -> None:
        if not self.project or not screen:
            return
        import os
        from ..core.project_store import screen_number

        label = scene_label(screen)
        if force_kind == "image":
            dlg_title = f"Replace {label} with an Image"
            filt = f"{_filter(IMAGE_EXT, 'Images')};;{_filter(IMAGE_EXT | VIDEO_EXT, 'All Media')}"
        elif force_kind == "video":
            dlg_title = f"Replace {label} with a Video"
            filt = f"{_filter(VIDEO_EXT, 'Videos')};;{_filter(IMAGE_EXT | VIDEO_EXT, 'All Media')}"
        else:
            dlg_title = f"Replace {label} with Image or Video"
            filt = f"{_filter(IMAGE_EXT | VIDEO_EXT, 'Images & Videos')};;{_filter(IMAGE_EXT, 'Images')};;{_filter(VIDEO_EXT, 'Videos')}"
        f, _ = QFileDialog.getOpenFileName(self, dlg_title, "", filt)
        if not f:
            return
        path = Path(f)
        ext = path.suffix.lower()
        kind = "video" if ext in VIDEO_EXT else "image"
        sub = "videos" if kind == "video" else "images"
        other_sub = "images" if kind == "video" else "videos"
        dest_dir = self.project.root / "media" / sub
        dest_dir.mkdir(parents=True, exist_ok=True)
        m_num = re.search(r"(\d+)$", str(screen or ""))
        scene_no = int(m_num.group(1)) if m_num else None
        staged_name = path.name
        if scene_no is not None and screen_number(path.name) != scene_no:
            staged_name = f"{scene_no}{ext}"
        staged = dest_dir / staged_name
        try:
            if path.resolve() != staged.resolve():
                shutil.copy2(path, staged)
            os.utime(staged, None)
            path = staged
        except OSError:
            pass
        # Remove any stale opposite-kind staged files for this scene number inside the chapter folder
        if scene_no is not None:
            other_dir = self.project.root / "media" / other_sub
            if other_dir.is_dir():
                for old_f in list(other_dir.iterdir()):
                    if old_f.is_file() and screen_number(old_f.name) == scene_no:
                        try:
                            old_f.unlink()
                        except OSError:
                            pass
        prev_kind = "image"
        if self.index and clip_index is not None and 0 <= clip_index < len(self.index.clips):
            prev_kind = str(self.index.clips[clip_index].get("kind") or "image")
        else:
            for c in self.project.clips:
                if str(c.get("screen")) == screen:
                    prev_kind = str(c.get("kind") or "image")
                    break
        mid = f"local-{screen}-{path.name}"
        item = {
            "id": mid,
            "filename": path.name,
            "path": str(path),
            "kind": kind,
            "screen": screen,
            "local_only": True,
        }
        self.project._link_map(other_sub).pop(screen, None)
        self.project._link_map("media")[mid] = str(path)
        self.project._link_map(sub)[screen] = str(path)
        self.project.media = [
            m for m in (self.project.media or [])
            if isinstance(m, dict) and str(m.get("screen") or "") != screen and str(m.get("id") or "") != mid
        ]
        self.project.media.append(item)
        self._push_undo()
        edits.replace_media(self.project.plan, screen, item, clip_index=clip_index)
        self.project.dirty = True
        try:
            self.project.save()
        except OSError:
            pass
        try:
            self.preview.surface.drop_stills()
            self.timeline.canvas.thumbs.clear()
        except Exception:
            pass
        self._reindex()
        self._refresh_qa()
        swap_note = f"{prev_kind} → {kind}" if prev_kind != kind else kind
        self.notify_event(
            f"{label} Replaced",
            f"{label} replaced ({swap_note}): {path.name} (kept for Export / .wfp / bundle)",
            kind="success",
            chime=False,
        )

    def _clip_menu(self, i: int, pos) -> None:
        m = QMenu(self)
        clip = self.index.clips[i] if self.index and 0 <= i < len(self.index.clips) else {}
        screen = str(clip.get("screen") or "")
        kind = str(clip.get("kind") or "image")
        media_word = "video" if kind == "video" else "image"
        m.addAction(theme.neon_icon("download", "#38bdf8"), f"Download this {media_word}…").triggered.connect(lambda: self._download_clip(i))
        if kind == "video":
            m.addAction(theme.neon_icon("image", "#f472b6"), "Replace this video with an image…").triggered.connect(
                lambda: self._replace_media(screen, force_kind="image", clip_index=i)
            )
            m.addAction(theme.neon_icon("video", "#22d3ee"), "Replace this video with another video…").triggered.connect(
                lambda: self._replace_media(screen, force_kind="video", clip_index=i)
            )
        else:
            m.addAction(theme.neon_icon("video", "#22d3ee"), "Replace this image with a video…").triggered.connect(
                lambda: self._replace_media(screen, force_kind="video", clip_index=i)
            )
            m.addAction(theme.neon_icon("image", "#f472b6"), "Replace this image with another image…").triggered.connect(
                lambda: self._replace_media(screen, force_kind="image", clip_index=i)
            )
        m.addAction(theme.neon_icon("swap", "#c084fc"), "Replace with image or video…").triggered.connect(
            lambda: self._replace_media(screen, force_kind=None, clip_index=i)
        )
        vo_id = self._vo_id_for_clip(i)
        if vo_id:
            m.addSeparator()
            m.addAction(theme.neon_icon("download", "#38bdf8"), "Download cut VO for this scene…").triggered.connect(lambda: self._download_vo_section(vo_id))
            m.addAction(theme.neon_icon("swap", "#c084fc"), "Replace cut VO for this scene…").triggered.connect(lambda: self._replace_vo_section(vo_id))
        m.addSeparator()
        for cmd, ic_name, ic_col, label in (
            ("pull_right", "arrow_right", "#22d3ee", "Elongate Right (Cover Next VO)"),
            ("pull_left", "arrow_left", "#22d3ee", "Elongate Left (Cover Prev VO)"),
            ("fit", "fit", "#c084fc", "Fit to Narration & Fill Gap"),
            ("split", "split", "#f472b6", "Split Clip at Playhead"),
            ("trim_in", "bracket_in", "#38bdf8", "Set In at Playhead"),
            ("trim_out", "bracket_out", "#38bdf8", "Set Out at Playhead"),
            ("pull_prev", "arrow_left", "#fb7185", "Delete & Elongate Prev Image Over VO"),
            ("delete", "trash", "#ef4444", "Delete Image (Del)"),
        ):
            m.addAction(theme.neon_icon(ic_name, ic_col), label).triggered.connect(lambda _=False, c=cmd: self._on_edit(c))
        m.exec(pos)

    def _vo_menu(self, vo_id: str, pos) -> None:
        m = QMenu(self)
        slot = 1
        if self.index:
            piece = next((x for x in self.index.vo_pieces() if str(x.get("id") or "") == str(vo_id)), None)
            if piece:
                slot = int(piece.get("slot") or 1)
        m.addAction(theme.neon_icon("download", "#38bdf8"), "Download this cut VO…").triggered.connect(lambda: self._download_vo_section(vo_id))
        m.addAction(theme.neon_icon("swap", "#c084fc"), "Replace this cut VO…").triggered.connect(lambda: self._replace_vo_section(vo_id))
        m.addSeparator()
        m.addAction(theme.neon_icon("download", "#22d3ee"), f"Download full VO {slot}…").triggered.connect(lambda: self.download_narration(slot))
        m.addAction(theme.neon_icon("swap", "#f472b6"), f"Replace full VO {slot}…").triggered.connect(lambda: self.link_narration(slot))
        m.addSeparator()
        m.addAction(theme.neon_icon("split", "#f472b6"), "Split voice at playhead").triggered.connect(lambda: self._on_edit("split_vo"))
        m.addAction(theme.neon_icon("trash", "#ef4444"), "Delete this voice section").triggered.connect(lambda: self._on_edit("delete_vo"))
        m.exec(pos)

    def _vo_id_for_clip(self, i: int) -> str:
        """Voice piece that plays under this Video 1 clip (for cut-VO download/replace)."""
        idx = self.index
        if not idx or i < 0 or i >= len(idx.clips):
            return ""
        clip = idx.clips[i]
        a = float(clip.get("start") or 0)
        b = float(clip.get("end") or a)
        mid = (a + b) * 0.5
        screen = str(clip.get("screen") or "")
        best = ""
        best_overlap = 0.0
        for piece in idx.vo_pieces():
            if screen and str(piece.get("screen") or "") == screen:
                return str(piece.get("id") or "")
            pa, pb = float(piece.get("start") or 0), float(piece.get("end") or 0)
            if pa <= mid <= pb:
                return str(piece.get("id") or "")
            overlap = max(0.0, min(b, pb) - max(a, pa))
            if overlap > best_overlap:
                best_overlap = overlap
                best = str(piece.get("id") or "")
        return best if best_overlap >= 0.12 else ""

    def _download_clip(self, i: int) -> None:
        """Save the selected picture or video out so it can be edited elsewhere."""
        p, idx = self.project, self.index
        if not p or not idx or i < 0 or i >= len(idx.clips):
            QMessageBox.information(self, "Download", "Select a picture or video on Video 1 first.")
            return
        clip = idx.clips[i]
        path_str, kind = p.clip_file(clip)
        if not path_str or not Path(path_str).is_file():
            QMessageBox.information(self, "Download", f"{scene_label(clip.get('screen'))} has no file on this PC yet.")
            return
        src = Path(path_str)
        screen = scene_label(clip.get("screen"))
        suggested = src.name if src.name else f"{screen}{src.suffix}"
        filt = _filter(VIDEO_EXT, "Video") if kind == "video" or src.suffix.lower() in VIDEO_EXT else _filter(IMAGE_EXT, "Image")
        dest, _ = QFileDialog.getSaveFileName(self, f"Download {screen}", suggested, filt)
        if not dest:
            return
        out = Path(dest)
        if not out.suffix:
            out = out.with_suffix(src.suffix)
        try:
            if src.resolve() != out.resolve():
                shutil.copy2(src, out)
        except OSError as e:
            QMessageBox.warning(self, "Download", str(e) or "Could not save that file.")
            return
        self.set_status(f"Downloaded {screen} → {out.name}")

    def _cut_vo_download_name(self, piece: dict, slot: int, src_in: float) -> str:
        """Readable save name: CutVO_S02_Word_house_row_1.mp3 (not CutVO_VO1_0)."""
        from ..core.plan import screen_title, vo_block_label

        idx = self.index
        screen = str(piece.get("screen") or "")
        if not screen and idx:
            mid = (float(piece.get("start") or 0) + float(piece.get("end") or 0)) * 0.5
            for clip in idx.clips:
                a, b = float(clip.get("start") or 0), float(clip.get("end") or 0)
                if a <= mid <= b + 0.001:
                    screen = str(clip.get("screen") or "")
                    break
        # Prefer catalog section / title, then spoken line, then scene number.
        title = screen_title(screen) if screen else ""
        if not title:
            title = vo_block_label(piece, idx.clips if idx else None)
        # Strip scene prefixes so the file is "My_Word_Family" not "S1_My_Word_Family" twice.
        title = re.sub(r"^(S|Scene)\s*\d+\s*[·:\-–—]?\s*", "", str(title), flags=re.I).strip()
        title = title.split(":", 1)[0].strip()  # drop trailing spoken snippet after ":"
        if not title or title.upper() in {f"VO{slot}", f"VO {slot}", "VOICE", "NARRATION"}:
            n = re.search(r"(\d+)", screen or "")
            title = f"Scene_{n.group(1)}" if n else f"VO{slot}"
        num = ""
        m = re.search(r"(\d+)", screen or "")
        if m:
            num = f"S{int(m.group(1)):02d}_"
        safe = re.sub(r"[^\w]+", "_", title, flags=re.UNICODE).strip("_")
        safe = re.sub(r"_+", "_", safe)[:48] or f"VO{slot}"
        return f"CutVO_{num}{safe}.mp3"

    def _clip_narration_range(self, clip: dict | None) -> tuple[float, float] | None:
        """File cut for one Video 1 scene, or None when that scene has no spoken window."""
        if not isinstance(clip, dict):
            return None
        ni, no = clip.get("narration_in"), clip.get("narration_out")
        try:
            a = float(ni) if ni is not None else None
            b = float(no) if no is not None else None
        except (TypeError, ValueError):
            return None
        if a is None or b is None or b <= a + 0.05:
            return None
        return a, b

    def _active_video_clip(self) -> dict | None:
        """Selected Video 1 clip, else the one under the playhead."""
        idx = self.index
        if not idx or not idx.clips:
            return None
        i = self.timeline.canvas.selected_clip if self.timeline else -1
        if i < 0:
            i = idx.clip_index_at(self.clock.position())
        if 0 <= i < len(idx.clips):
            return idx.clips[i]
        return None

    def _piece_native_source_range(self, piece: dict) -> tuple[float, float]:
        """Stored file in/out for a VO lane piece (may be the whole master file)."""
        src_in = piece.get("source_in")
        src_out = piece.get("source_out")
        try:
            a = float(src_in) if src_in is not None else None
            b = float(src_out) if src_out is not None else None
        except (TypeError, ValueError):
            a = b = None
        if a is not None and b is not None and b > a + 0.05:
            return a, b
        idx = self.index
        if idx:
            screen = str(piece.get("screen") or "")
            if screen:
                for row in idx.clips:
                    if str(row.get("screen") or "") == screen:
                        found = self._clip_narration_range(row)
                        if found:
                            return found
        start = float(piece.get("start") or 0)
        end = float(piece.get("end") or start)
        return 0.0, max(0.12, end - start)

    def _clip_for_vo_piece(self, piece: dict | None) -> dict | None:
        """Video 1 clip that corresponds to a VO piece (by screen tag or piece midpoint)."""
        idx = self.index
        if not idx or not idx.clips or not isinstance(piece, dict):
            return None
        scr = str(piece.get("screen") or "")
        if scr:
            for c in idx.clips:
                if str(c.get("screen") or "") == scr:
                    return c
        pa = float(piece.get("start") or 0)
        pb = float(piece.get("end") or pa)
        if pb - pa < 8.0:
            mid = (pa + pb) * 0.5
            for c in idx.clips:
                if float(c.get("start") or 0) <= mid <= float(c.get("end") or 0) + 0.001:
                    return c
        return self._active_video_clip()

    def _piece_source_range(self, piece: dict, clip: dict | None = None) -> tuple[float, float]:
        """File in/out for a cut-VO download.

        Filmora-style chapters often keep one VO piece for the whole file
        (source 0→end). Cut-VO download must still use the *scene* narration
        window, not the entire master VO.
        """
        scene_range = self._clip_narration_range(clip)
        a, b = self._piece_native_source_range(piece)
        piece_span = max(0.0, b - a)
        tl_span = max(0.0, float(piece.get("end") or 0) - float(piece.get("start") or 0))
        covers_many = piece_span >= 8.0 or tl_span >= 8.0
        if scene_range and covers_many:
            return scene_range
        if scene_range and piece_span + 0.35 >= (scene_range[1] - scene_range[0]) * 1.65:
            # Piece spans two or more scenes (e.g. S59+S60) — cut to the active scene.
            return scene_range
        if a is not None and b is not None and b > a + 0.05 and not covers_many:
            return a, b
        if scene_range:
            return scene_range
        return a, b

    def _ensure_vo_pieces(self) -> list[dict]:
        """Persist derived voice cuts onto the plan so replace/export/bundle can use them."""
        p, idx = self.project, self.index
        if not p or not idx:
            return []
        plan = p.plan
        if not isinstance(plan.get("vo_pieces"), list) or not plan["vo_pieces"]:
            pieces = []
            for raw in idx.vo_pieces():
                piece = dict(raw)
                src_in, src_out = self._piece_native_source_range(piece)
                piece["source_in"] = src_in
                piece["source_out"] = src_out
                pieces.append(piece)
            plan["vo_pieces"] = pieces
        else:
            # Fill missing source ranges on older saves.
            for piece in plan["vo_pieces"]:
                if not isinstance(piece, dict):
                    continue
                try:
                    a = float(piece.get("source_in")) if piece.get("source_in") is not None else None
                    b = float(piece.get("source_out")) if piece.get("source_out") is not None else None
                except (TypeError, ValueError):
                    a = b = None
                if a is None or b is None or b <= a + 0.05:
                    src_in, src_out = self._piece_native_source_range(piece)
                    piece["source_in"] = src_in
                    piece["source_out"] = src_out
        return list(plan["vo_pieces"])

    def _stage_replaced_vo(self, src: Path, piece_id: str) -> Path:
        """Copy a cut-VO replace into the chapter folder so Export / .wfp / bundle can pack it."""
        assert self.project is not None
        dest_dir = self.project.root / "voiceover" / "replaced"
        dest_dir.mkdir(parents=True, exist_ok=True)
        safe = "".join(ch if ch.isalnum() or ch in "-_." else "_" for ch in str(piece_id))[:48] or "vo"
        dest = dest_dir / f"{safe}_{src.name}"
        if src.resolve() != dest.resolve():
            shutil.copy2(src, dest)
        return dest

    def _download_vo_section(self, vo_id: str | None = None) -> None:
        """Save this cut VO (trimmed to the voice block / scene)."""
        p, idx = self.project, self.index
        explicit_vo = bool(vo_id or (self.timeline.canvas.selected_vo if self.timeline else ""))
        clip = self._active_video_clip()
        vo_id = vo_id or (self.timeline.canvas.selected_vo if self.timeline else "")
        if not vo_id and idx:
            i = self.timeline.canvas.selected_clip
            if i < 0:
                i = idx.clip_index_at(self.clock.position())
            vo_id = self._vo_id_for_clip(i)
        if not p or not idx or not vo_id:
            QMessageBox.information(
                self,
                "Download cut VO",
                "Select a voice block on Audio · VO, or a Video 1 scene that has narration, then try again.",
            )
            return
        self._ensure_vo_pieces()
        piece = next((x for x in idx.vo_pieces() if str(x.get("id") or "") == str(vo_id)), None)
        if not piece:
            QMessageBox.information(self, "Download cut VO", "That voice section is gone.")
            return
        if explicit_vo:
            clip = self._clip_for_vo_piece(piece) or clip
        # Name / cut range follow the Video 1 scene when the VO lane is one long master file.
        name_piece = dict(piece)
        if clip and not name_piece.get("screen"):
            name_piece["screen"] = clip.get("screen")
        slot = int(piece.get("slot") or 1)
        src_path = str(piece.get("replace_path") or "") or idx.slot_file(slot)
        if not src_path or not Path(src_path).is_file():
            QMessageBox.information(self, "Download cut VO", f"VO {slot} is not on this PC yet.")
            return
        src = Path(src_path)
        # A prior cut-VO replace is already one scene — copy that file as-is.
        # Otherwise always slice to the scene / piece window (never the whole master VO).
        if piece.get("replace_path") and Path(str(piece.get("replace_path"))).is_file():
            src_in, src_out = 0.0, self._audio_file_duration(src) or max(0.12, float(piece.get("end") or 0) - float(piece.get("start") or 0))
            already_cut = True
        else:
            src_in, src_out = self._piece_source_range(piece, clip)
            already_cut = False
        span = max(0.12, src_out - src_in)
        suggested = self._cut_vo_download_name(name_piece, slot, src_in)
        dest, _ = QFileDialog.getSaveFileName(self, "Download this cut VO", suggested, _filter(AUDIO_EXT, "Audio"))
        if not dest:
            return
        out = Path(dest)
        if not out.suffix:
            out = out.with_suffix(".mp3")
        file_dur = self._audio_file_duration(src)
        need_cut = (not already_cut) and (
            src_in > 0.02 or (file_dur > 0.05 and span + 0.25 < file_dur) or (file_dur > 1.0 and span + 0.5 < file_dur)
        )
        try:
            if need_cut:
                if self._export_audio_slice(src, out, src_in, span):
                    self.set_status(f"Downloaded cut VO ({span:.2f}s) → {out.name}")
                    return
                QMessageBox.warning(
                    self,
                    "Download cut VO",
                    "Could not cut that section from the master VO. The full file was not saved.",
                )
                return
            if src.resolve() != out.resolve():
                shutil.copy2(src, out)
            self.set_status(f"Downloaded cut VO ({span:.2f}s) → {out.name}")
        except OSError as e:
            QMessageBox.warning(self, "Download cut VO", str(e) or "Could not save that audio.")

    def _audio_file_duration(self, path: Path) -> float:
        try:
            dur, _ = chapter.analyze_audio(path)
            return float(dur or 0)
        except Exception:
            return 0.0

    def _export_audio_slice(self, src: Path, dest: Path, start: float, duration: float) -> bool:
        ff = paths.ffmpeg_exe()
        if not ff:
            return False
        dest.parent.mkdir(parents=True, exist_ok=True)
        cmd = [
            str(ff), "-y", "-hide_banner", "-loglevel", "error",
            "-ss", f"{max(0.0, start):.3f}",
            "-i", str(src),
            "-t", f"{max(0.12, duration):.3f}",
            "-acodec", "libmp3lame" if dest.suffix.lower() == ".mp3" else "pcm_s16le",
            "-ar", "44100", "-ac", "1",
            str(dest),
        ]
        if dest.suffix.lower() not in (".mp3", ".wav"):
            cmd = [
                str(ff), "-y", "-hide_banner", "-loglevel", "error",
                "-ss", f"{max(0.0, start):.3f}",
                "-i", str(src),
                "-t", f"{max(0.12, duration):.3f}",
                "-c", "copy",
                str(dest),
            ]
        try:
            proc = subprocess.run(cmd, capture_output=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), timeout=120)
        except (OSError, subprocess.TimeoutExpired):
            return False
        return proc.returncode == 0 and dest.is_file() and dest.stat().st_size > 64

    def _replace_vo_section(self, vo_id: str | None = None) -> None:
        """Swap audio for one scene only. Other scenes keep the master VO."""
        p = self.project
        idx = self.index
        if not p or not idx:
            return
        explicit_vo = bool(vo_id or self.timeline.canvas.selected_vo)
        clip = self._active_video_clip()
        vo_id = vo_id or self.timeline.canvas.selected_vo
        if not vo_id:
            i = self.timeline.canvas.selected_clip
            if i < 0:
                i = idx.clip_index_at(self.clock.position())
            vo_id = self._vo_id_for_clip(i)
        if not vo_id:
            QMessageBox.information(
                self,
                "Replace cut VO",
                "Select a voice block on Audio · VO, or a Video 1 scene that has narration, then try again.",
            )
            return
        f, _ = QFileDialog.getOpenFileName(self, "Replace this cut VO", "", _filter(AUDIO_EXT, "Audio"))
        if not f:
            return
        path = Path(f)
        duration, _ = chapter.analyze_audio(path)
        if duration <= 0.05:
            QMessageBox.information(self, "Replace cut VO", "That audio file has no length to play.")
            return
        self._ensure_vo_pieces()
        piece = next((x for x in (p.plan.get("vo_pieces") or []) if str(x.get("id") or "") == str(vo_id)), None)
        if explicit_vo and piece:
            clip = self._clip_for_vo_piece(piece) or clip
        # Scene timeline window so a long master VO is split and only this scene is replaced.
        tl_start = tl_end = None
        screen = None
        if clip:
            screen = str(clip.get("screen") or "") or None
            tl_start = float(clip.get("start") or 0)
            tl_end = float(clip.get("end") or tl_start)
            narr = self._clip_narration_range(clip)
            if narr and (tl_end - tl_start) > (narr[1] - narr[0]) + 0.35:
                tl_end = tl_start + (narr[1] - narr[0])
        elif piece and piece.get("screen"):
            screen = str(piece.get("screen") or "")
            for row in idx.clips:
                if str(row.get("screen") or "") == screen:
                    tl_start = float(row.get("start") or 0)
                    tl_end = float(row.get("end") or tl_start)
                    narr = self._clip_narration_range(row)
                    if narr and (tl_end - tl_start) > (narr[1] - narr[0]) + 0.35:
                        tl_end = tl_start + (narr[1] - narr[0])
                    break
        staged = self._stage_replaced_vo(path, str(vo_id))
        self._push_undo()
        edits.replace_vo_section(
            p.plan,
            vo_id,
            str(staged),
            duration,
            tl_start=tl_start,
            tl_end=tl_end,
            screen=screen,
        )
        p.dirty = True
        self._reindex()
        self._refresh_qa()
        label = scene_label(screen) if screen else "this cut"
        self.set_status(
            f"Replaced cut VO on {label} with {path.name}. Other scenes keep the master VO."
        )

    def import_logo_video(self) -> None:
        """New Project + uploaded video in this window. Export stays the Export button."""
        if self._job and self._job.running:
            self.set_status("Still working on the previous step…")
            return
        path, _ = QFileDialog.getOpenFileName(self, "Import video", "", _filter(VIDEO_EXT, "Video"))
        if not path:
            return
        src = Path(path)
        try:
            info = probe_video(src)
        except (OSError, RuntimeError) as exc:
            QMessageBox.warning(self, "Video & SRT", str(exc) or "This file could not be read as a video")
            return
        if int(info.get("width") or 0) < 2 or float(info.get("duration") or 0) <= 0:
            QMessageBox.warning(self, "Video & SRT", "This file has no picture to play.")
            return
        box = QMessageBox(self)
        box.setWindowTitle("Speech")
        box.setText("Which speech is in this video?\nEnglish and Marathi stay on their own modules.")
        en = box.addButton("English", QMessageBox.ButtonRole.AcceptRole)
        mr = box.addButton("Marathi", QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        picked = box.clickedButton()
        if picked is not en and picked is not mr:
            return
        if not self._confirm_discard():
            return
        try:
            root = create_blank_project()
        except OSError as e:
            QMessageBox.warning(self, "Video & SRT", f"Could not create a new project: {e}")
            return
        if not self.open_project(root, confirm=False):
            return
        p = self.project
        if not p:
            return
        lang = "mr" if picked is mr else "en"
        # Keep the uploaded file’s name — never rename it to “Project …”.
        p.title = src.stem
        p.plan["title"] = src.stem
        p.plan["language"] = lang
        p.plan["language_choice"] = lang
        p.plan["video_srt"] = True
        p.plan["logo_enabled"] = True
        p.logo["enabled"] = True
        p.script_meta["filename"] = src.name
        p.set_logo_transform(DEFAULT_LOGO_TRANSFORM)
        self._logo_job = {
            "path": str(src),
            "info": info,
            "language": lang,
            "cues": [],
        }
        self._apply_logo_plan()
        self.clock.seek(0.0)
        self._show_language()
        try:
            p.save()
            p.dirty = False
        except OSError as e:
            QMessageBox.warning(self, "Video & SRT", f"Could not save the new project: {e}")
        self._dirty_changed()
        fps = float(info.get("fps") or 0)
        frames = int(info.get("frames") or 0)
        self.set_status(
            f"{src.stem} · {int(info['width'])}×{int(info['height'])} · {fps:.2f} fps · "
            f"{frames} frames · {float(info['duration']):.1f}s. Listening for speech to split scenes…"
        )
        self._hear_logo_video()

    def _apply_logo_plan(self) -> None:
        job = self._logo_job
        p = self.project
        if not job or not p or "info" not in job:
            return
        info = job["info"]
        dur = max(0.1, float(info.get("duration") or 0))
        logo_on = bool(p.logo_enabled)
        p.plan["clips"] = [{
            "id": "logo_video",
            "screen": "screen_1",
            "kind": "video",
            "media_path": job["path"],
            "start": 0.0,
            "end": dur,
            "source_in": 0.0,
            "source_out": dur,
            "fit": "passthrough",
        }]
        p.plan["total_duration"] = dur
        p.plan["srt_cues"] = list(job.get("cues") or [])
        p.plan["video_srt"] = True
        p.plan["logo_enabled"] = logo_on
        p.logo["enabled"] = logo_on
        p.plan["logo_transform"] = dict(DEFAULT_LOGO_TRANSFORM)
        p.plan["has_poem"] = False
        p.plan.pop("vo_pieces", None)
        # Placement is locked. On/off is not.
        self.preview.surface.logo_locked = True
        self.preview.surface.set_video_frame(int(info.get("width") or 0), int(info.get("height") or 0))
        self._reindex()
        # Re-apply after the index so the logo pixmap is on the real video frame.
        self.preview.surface.set_logo(logo_on, p.logo_file(), DEFAULT_LOGO_TRANSFORM)
        self.preview.set_logo_state(logo_on)

    def _resume_video_srt(self) -> bool:
        """When a Video & SRT project is opened again, convert it to an editable chapter with split VO, screens & alignments."""
        p = self.project
        if not p or not p.plan.get("video_srt"):
            return False
        clips = p.clips
        path = str((clips[0].get("media_path") if clips else "") or "")
        if not path or not Path(path).is_file():
            self.set_status(f"Opened {p.title}. The video file is missing on this PC.")
            return True
        try:
            info = probe_video(Path(path))
        except (OSError, RuntimeError) as exc:
            self.set_status(f"Opened {p.title}. The video could not be read: {exc}")
            return True
        lang = str(p.plan.get("language_choice") or p.plan.get("language") or "en")
        lang_code = "mr" if lang.lower() in ("mr", "marathi") else "en"
        cues = list(p.plan.get("srt_cues") or [])
        self._logo_job = {
            "path": path,
            "info": info,
            "language": lang_code,
            "cues": cues,
        }
        if cues:
            try:
                summary = build_editable_chapter_from_video(
                    p,
                    Path(path),
                    cues,
                    language=lang_code,
                    duration=float(info.get("duration") or 0) or None,
                )
                self._finish_uploaded_chapter(summary)
                return True
            except (OSError, RuntimeError, ValueError) as exc:
                self._apply_logo_plan()
                self.set_status(f"Opened {p.title}, but could not build scenes: {exc}")
                return True
        self._apply_logo_plan()
        self.clock.seek(0.0)
        self.set_status(
            f"Opened {p.title} · Video & SRT · {int(info.get('width') or 0)}×{int(info.get('height') or 0)}. "
            "Listening for speech to split VO, screens, and alignments…"
        )
        self._hear_logo_video()
        return True

    def _hear_logo_video(self) -> None:
        job = self._logo_job
        if not job:
            return
        path = str(job["path"])
        language = str(job["language"])

        def work(eng: Engine, emit) -> list:
            emit("Listening to the video…")
            return hear(Path(path), language)

        def done(words) -> None:
            if not self._logo_job or not self.project:
                return
            cues = words_to_cues(words or [])
            self._logo_job["cues"] = cues
            try:
                summary = build_editable_chapter_from_video(
                    self.project,
                    Path(self._logo_job["path"]),
                    cues,
                    language=str(self._logo_job["language"]),
                    duration=float((self._logo_job.get("info") or {}).get("duration") or 0) or None,
                )
            except (OSError, RuntimeError, ValueError) as exc:
                self._apply_logo_plan()
                self.project.dirty = True
                try:
                    self.project.save()
                    self.project.dirty = False
                except OSError:
                    pass
                self._dirty_changed()
                self.set_status(f"Could not build an editable chapter: {exc}")
                return
            self._finish_uploaded_chapter(summary)

        self._run_job("Listening to the video…", work, done=done, reload=False)

    def _finish_uploaded_chapter(self, summary: dict | None = None) -> None:
        """Leave the logo-only path and show the normal editable chapter timeline."""
        p = self.project
        if not p:
            return
        self._logo_job = None
        p.plan.pop("video_srt", None)
        self.preview.surface.logo_locked = False
        self.preview.surface.set_video_frame(0, 0)
        self._reindex()
        self._apply_flags()
        self.clock.seek(0.0)
        self._dirty_changed()
        QTimer.singleShot(0, self._refresh_qa)
        n = int((summary or {}).get("scenes") or len(p.clips))
        cues = int((summary or {}).get("cues") or len(p.plan.get("srt_cues") or []))
        vo_note = str((summary or {}).get("vo_note") or "")
        self.left.set_script_report(f"Video & SRT · {n} scenes aligned from speech", True)
        if cues:
            msg = (
                f"Built {n} scenes, {len(p.plan.get('vo_pieces') or [])} VO cuts, and {cues} SRT alignments. "
                "Edit like a normal chapter, then Export (SRT stays separate)."
            )
        else:
            msg = (
                f"No speech was heard — kept 1 full-video scene. "
                "Trim or replace, then Export."
            )
        if vo_note and not (summary or {}).get("voiceover"):
            msg += f" VO was not pulled out ({vo_note})."
        self.notify_event("Video & SRT Ready", msg, kind="success")

    def _run_ffmpeg(self, command: list[str], duration: float, emit) -> None:
        proc = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        self._logo_proc = proc
        tail = ""
        code = 1
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                tail = line.strip() or tail
                if line.startswith("out_time_ms="):
                    try:
                        ms = int(line.split("=", 1)[1])
                    except ValueError:
                        continue
                    pct = min(99, int((ms / 1_000_000) / max(0.1, duration) * 100))
                    emit(f"{pct}|Exporting {pct}%")
            code = proc.wait()
        finally:
            self._logo_proc = None
        if code != 0:
            raise EngineError(tail or "The video could not be written")

    def open_export(self) -> None:
        p = self.project
        if not p:
            return
        dlg = getattr(self, "_export_dlg", None)
        if dlg is None:
            dlg = FilmoraExportWindow(self)
            dlg.start_export.connect(self._begin_export)
            dlg.export_srt.connect(self.export_srt)
            dlg.save_wfp.connect(lambda dest: self.collect_filmora("wfp", dest))
            dlg.save_bundle.connect(lambda dest: self.collect_filmora("wfpbundle", dest))
            dlg.logo_toggled.connect(lambda on: self.set_flag("logo_enabled", on))
            dlg.cancel_export.connect(self._cancel_export)
            self._export_dlg = dlg
        images: list[tuple[str, str]] = []
        duration = 0.0
        still = 0.0
        spanned = 0.0
        if self.index:
            duration = self.index.duration
            for i, (path, kind) in enumerate(self.index.files):
                clip = self.index.clips[i]
                span = max(0.0, float(clip.get("end") or 0) - float(clip.get("start") or 0))
                spanned += span
                if clip.get("kind") != "video":
                    still += span
                if path and kind == "image":
                    images.append((path, scene_label(clip.get("screen"))))
        share = (still / spanned) if spanned > 0 else 1.0
        dlg.set_chapter(p.title, p.logo_enabled, duration, images, share)
        dlg.show()
        dlg.raise_()
        dlg.activateWindow()

    def _begin_export(self, settings: dict, dest: str) -> None:
        p = self.project
        dlg = getattr(self, "_export_dlg", None)
        if not p or dlg is None:
            return
        fmt = str(settings.get("format") or "mp4")
        if not (self._logo_job and fmt in ("mp4", "mov", "mkv", "avi")):
            self._pull_linked_files()
        logo_on = bool(settings.get("include_logo", p.logo_enabled))
        if self._logo_job:
            p.set_logo_enabled(logo_on)
            self.preview.surface.set_logo(logo_on, p.logo_file(), DEFAULT_LOGO_TRANSFORM)
            self.preview.set_logo_state(logo_on)
        pid, title = p.pid, p.title
        target = Path(dest)
        if self._logo_job and fmt in ("mp4", "mov", "mkv", "avi"):
            logo = p.logo_file()
            if logo_on and not logo:
                dlg.mark_failed("The logo file is missing.")
                return
            video = Path(self._logo_job["path"])
            info = dict(self._logo_job["info"])
            language = str(self._logo_job["language"])
            dlg.mark_running()
            final_out = [target]

            def work_logo(eng: Engine, emit) -> str:
                job = self._logo_job
                if not job:
                    raise EngineError("Import a video first.")
                if not job.get("cues"):
                    emit("0|Listening to the video…")
                    job["cues"] = words_to_cues(hear(video, language))
                out, srt = next_free_pair(target if target.suffix else target.with_suffix(f".{fmt}"))
                if out.suffix.lower() != f".{fmt}":
                    out = out.with_suffix(f".{fmt}")
                    srt = out.with_suffix(".srt")
                final_out[0] = out
                emit(f"0|Writing {out.name}")
                if logo_on:
                    command = export_command(
                        video, Path(logo), DEFAULT_LOGO_TRANSFORM, out,
                        {"width": int(info.get("width") or 0), "height": int(info.get("height") or 0)},
                    )
                else:
                    command = copy_command(video, out)
                self._run_ffmpeg(command, float(info.get("duration") or 1), emit)
                if job.get("cues"):
                    srt.write_text(format_srt(job["cues"]), encoding="utf-8")
                    return (
                        f"Exported {out.name} and {srt.name}. "
                        + ("Logo is in the video. " if logo_on else "Logo is off. ")
                        + "The words are not in the video."
                    )
                return (
                    f"Exported {out.name}. "
                    + ("Logo is in the video. " if logo_on else "Logo is off. ")
                    + "No speech was heard, so there is no SRT."
                )

            def done_logo(msg) -> None:
                dlg.mark_done(str(msg))
                self.notify_event(
                    f"Export {fmt.upper()} Complete",
                    str(msg),
                    kind="export",
                    file_path=str(final_out[0]),
                    modal=True,
                )

            if not self._run_job(f"Exporting {fmt.upper()}…", work_logo, done=done_logo, reload=False, on_progress=dlg.set_progress):
                dlg.mark_failed("Still working on the previous step.")
            return
        dlg.mark_running()
        exported_path = [str(target)]

        def work(eng: Engine, emit) -> str:
            out = chapter.export_media(eng, pid, title, fmt, target, emit, include_logo=logo_on, settings=settings)
            exported_path[0] = str(out)
            note = f"Exported {out}"
            if fmt in ("mp4", "mov", "mkv", "avi"):
                note += " Poem lines are on the poem screens. Narration is not in the video. Use Export SRT for the caption file."
                note += " Logo is in the video." if logo_on and settings.get("include_logo", True) else " Logo is off."
            return note

        def done(msg) -> None:
            dlg.mark_done(str(msg))
            self.notify_event(
                f"Export {fmt.upper()} Complete",
                str(msg),
                kind="export",
                file_path=exported_path[0],
                modal=True,
            )

        if not self._run_job(f"Exporting {fmt.upper()}…", work, done=done, reload=False, on_progress=dlg.set_progress):
            dlg.mark_failed("Still working on the previous step.")
            return

    def _cancel_export(self) -> None:
        proc = self._logo_proc
        if proc is not None:
            proc.kill()
            self.set_status("Export cancelled.")
            return
        if not self.project:
            return
        try:
            chapter.cancel_export(self._engine(), self.project.pid)
        except EngineError as exc:
            self.set_status(str(exc))

    def export_file(self, fmt: str, dest: str | None = None) -> None:
        p = self.project
        if not p:
            return
        if not dest:
            dest, _ = QFileDialog.getSaveFileName(self, f"Export {fmt.upper()}", f"{p.title}.{fmt}", f"{fmt.upper()} (*.{fmt})")
            if not dest:
                return
        self._pull_linked_files()
        if p.dirty:
            self.save(silent=True)
        pid, title = p.pid, p.title
        logo_on = bool(p.logo_enabled)
        target = Path(dest)
        exported_path = [str(target)]

        def work(eng: Engine, emit) -> str:
            out = chapter.export_media(eng, pid, title, fmt, target, emit, include_logo=logo_on)
            exported_path[0] = str(out)
            note = f"Exported {out}"
            if fmt in ("mp4", "mov", "mkv", "avi"):
                note += " Poem lines are on the poem screens. Narration is not in the video. Use Export SRT for the caption file."
                note += " Logo is in the video." if logo_on else " Logo is off."
            return note

        def done(msg) -> None:
            self.notify_event(
                f"Export {fmt.upper()} Complete",
                str(msg),
                kind="export",
                file_path=exported_path[0],
                modal=True,
            )

        self._run_job(f"Exporting {fmt.upper()}…", work, done=done, reload=False)

    def export_srt(self, dest: str | None = None) -> None:
        p = self.project
        if not p:
            return
        cues = list((self._logo_job or {}).get("cues") or p.plan.get("srt_cues") or [])
        if self._logo_job or p.plan.get("from_uploaded_video") or cues:
            if not cues:
                QMessageBox.information(self, "Export SRT", "No speech was heard yet, so there is no SRT.")
                return
            if not dest:
                stem = p.title or (Path(str((self._logo_job or {}).get("path") or "chapter")).stem)
                dest, _ = QFileDialog.getSaveFileName(self, "Export SRT", f"{stem}.srt", "SubRip (*.srt)")
                if not dest:
                    return
            Path(dest).write_text(format_srt(cues), encoding="utf-8")
            note = f"SRT saved: {dest}. The words are not in the video."
            dlg = getattr(self, "_export_dlg", None)
            if dlg is not None and dlg.isVisible():
                dlg.mark_done(note)
            self.notify_event("SRT Export Complete", note, kind="export", file_path=str(dest), modal=True)
            return
        if not dest:
            dest, _ = QFileDialog.getSaveFileName(self, "Export SRT", f"SRT_Only_{p.title}.srt", "SubRip (*.srt)")
            if not dest:
                return
        pid, title = p.pid, p.title
        saved_srt = [str(dest)]

        def work(eng: Engine, emit) -> str:
            emit("Building SRT…")
            out = chapter.export_srt(eng, pid, title, Path(dest))
            saved_srt[0] = str(out)
            return f"Standalone SRT saved: {out} (never burned into the video)"

        def done(msg) -> None:
            dlg = getattr(self, "_export_dlg", None)
            if dlg is not None and dlg.isVisible():
                dlg.mark_done(str(msg))
            self.notify_event("SRT Export Complete", str(msg), kind="export", file_path=saved_srt[0], modal=True)

        self._run_job("Exporting SRT…", work, done=done, reload=False)

    def collect_filmora(self, mode: str, dest: str | None = None) -> None:
        p = self.project
        if not p:
            return
        ext = "wfp" if mode == "wfp" else "wfpbundle"
        if not dest:
            dest, _ = QFileDialog.getSaveFileName(self, f"Save {ext}", f"{p.title}.{ext}", f"Filmora (*.{ext})")
            if not dest:
                return
        # Do not refresh the linked folder here — that would wipe Upload/Replace
        # and cut-VO takes that Export / .wfp / .wfpbundle must keep.
        has_cut_vo = any(
            isinstance(x, dict) and x.get("replace_path")
            for x in (p.plan.get("vo_pieces") or [])
        )
        if not has_cut_vo and not p.plan.get("manual_override"):
            self._pull_linked_files()
        pid, title = p.pid, p.title
        dlg = getattr(self, "_export_dlg", None)
        if dlg is not None:
            dlg.mark_running()
        saved_wfp = [str(dest)]

        def work(eng: Engine, emit) -> str:
            out = chapter.collect_filmora(eng, pid, title, mode, Path(dest), emit)
            saved_wfp[0] = str(out)
            return f"Saved {out}"

        def done(msg) -> None:
            if dlg is not None:
                dlg.mark_done(str(msg))
            self.notify_event(
                f"Filmora .{ext} Saved",
                str(msg),
                kind="export",
                file_path=saved_wfp[0],
                modal=True,
            )

        if not self._run_job(f"Packing {ext}…", work, done=done, reload=False, on_progress=dlg.set_progress if dlg is not None else None):
            if dlg is not None:
                dlg.mark_failed("Still working on the previous step.")
            return

    # Logo ------------------------------------------------------------------

    def change_logo(self) -> None:
        if not self.project:
            return
        f, _ = QFileDialog.getOpenFileName(self, "Brand logo", "", _filter(IMAGE_EXT, "Images"))
        if not f:
            return
        self.project.set_logo_file(Path(f))
        self._apply_flags()
        self.left.set_logo(self.index)
        self._dirty_changed()
        self.set_status(f"Logo → {f}")

    def default_logo(self) -> None:
        if not self.project:
            return
        self.project.reset_logo()
        self._apply_flags()
        self.left.set_logo(self.index)
        self._dirty_changed()
        self.set_status("Logo reset to the E-Class logo at the Filmora 16 default placement")

    def reset_logo_transform(self) -> None:
        if not self.project:
            return
        from ..core.project_store import DEFAULT_LOGO_TRANSFORM

        self._on_logo_moved(dict(DEFAULT_LOGO_TRANSFORM))
        self.set_status("Logo placement reset to the Filmora 16 default")

    def open_poem_text(self) -> None:
        if not self.project:
            return
        from ..core.plan import normalize_poem_overlay

        dlg = getattr(self, "_poem_dialog", None)
        if dlg is None:
            dlg = PoemTextDialog(self.project.plan.get("poem_overlay") or {}, self, indic=self._indic())
            dlg.changed.connect(self._on_lyric_moved)
            self._poem_dialog = dlg
        else:
            dlg.set_script(self._indic())
            dlg._load(normalize_poem_overlay(self.project.plan.get("poem_overlay") or {}))
        dlg.show()
        if self.index:
            t = self.clock.position()
            i = self.index.clip_index_at(t)
            clip = self.index.clips[i] if i >= 0 else None
            dlg.note_screen(clip, self.index.in_poem(t))
        self._place_clear_of_preview(dlg)
        QTimer.singleShot(0, lambda d=dlg: self._place_clear_of_preview(d))
        dlg.raise_()

    def _place_clear_of_preview(self, dlg) -> None:
        """Keep the poem controls off the picture so the lyric stays visible."""
        if dlg is None or not dlg.isVisible():
            return
        origin = self.preview.mapToGlobal(self.preview.rect().topLeft())
        preview = QRect(origin, self.preview.size())
        screen = QGuiApplication.screenAt(preview.center()) or dlg.screen() or QGuiApplication.primaryScreen()
        if screen is None:
            return
        avail = screen.availableGeometry()
        size = dlg.frameGeometry().size()
        w, h = max(size.width(), dlg.sizeHint().width(), dlg.width()), max(size.height(), dlg.height())
        gap = 12

        def on_screen(rect: QRect) -> QRect:
            rect = QRect(rect)
            if rect.top() < avail.top():
                rect.moveTop(avail.top())
            if rect.bottom() > avail.bottom():
                rect.moveBottom(avail.bottom())
            return rect

        right = on_screen(QRect(preview.right() + gap, preview.top(), w, h))
        left = on_screen(QRect(preview.left() - gap - w, preview.top(), w, h))
        below = on_screen(QRect(preview.left(), preview.bottom() + gap, w, h))
        chosen = None
        for cand in (right, left, below):
            if cand.left() >= avail.left() and cand.right() <= avail.right() and not cand.intersects(preview):
                chosen = cand
                break
        if chosen is None:
            # Stay beside the picture even when the window is tight. Do not slide back over it.
            chosen = right if preview.center().x() < avail.center().x() else left
            if chosen.intersects(preview):
                chosen = QRect(avail.left() if preview.left() > avail.center().x() else avail.right() - w, avail.top(), w, h)
        dlg.move(chosen.topLeft())

    def _on_lyric_moved(self, style: dict) -> None:
        if not self.project:
            return
        from ..core.plan import normalize_poem_overlay

        self.project.plan["poem_overlay"] = normalize_poem_overlay(style)
        self.project.dirty = True
        self._dirty_changed()
        dlg = getattr(self, "_poem_dialog", None)
        if dlg is not None:
            dlg.adopt_placement(self.project.plan["poem_overlay"])
        self._on_tick(self.clock.position())

    def _on_logo_moved(self, t: dict) -> None:
        if not self.project:
            return
        self.project.set_logo_transform(t)
        self._apply_flags()
        self.left.set_logo(self.index)
        self.timeline.canvas.invalidate()
        self._dirty_changed()

    def open_logo_placement(self) -> None:
        if not self.project:
            return
        if self._logo_dialog is not None:
            self._logo_dialog.raise_()
            return
        d = LogoTransformDialog(self.project.logo_transform, self)
        d.changed.connect(self._on_logo_moved)
        d.finished.connect(lambda _r: setattr(self, "_logo_dialog", None))
        self._logo_dialog = d
        d.show()

    # Playback --------------------------------------------------------------

    def toggle_play(self) -> None:
        if self.index:
            self._force = True
            self.clock.toggle()

    def seek(self, t: float) -> None:
        if not self.index:
            return
        self._force = True
        self.clock.seek(t)

    def step(self, dt: float) -> None:
        self.seek(self.clock.position() + dt)

    def stop(self) -> None:
        self.clock.pause()
        self.seek(0.0)

    def jump(self, where: str) -> None:
        idx = self.index
        if not idx:
            return
        t = self.clock.position()
        if where == "start":
            self.seek(0.0)
        elif where == "end":
            self.seek(idx.duration)
        elif idx.clips:
            i = idx.clip_index_at(t)
            if i < 0:
                i = max(0, sum(1 for c in idx.clips if float(c.get("start") or 0) <= t) - 1)
            start = float(idx.clips[i].get("start") or 0)
            if where == "prev":
                j = i - 1 if t - start < 0.6 else i
            else:
                j = i + 1
            j = max(0, min(len(idx.clips) - 1, j))
            self.seek(float(idx.clips[j].get("start") or 0) + 0.01)

    def _on_running(self, on: bool) -> None:
        self.preview.set_playing(on)
        self._force = True
        if not on:
            self.audio.pause()
            self.preview.surface.pause_video()

    def _on_volume(self, v: float) -> None:
        self.audio.volume = v

    def _on_mute(self, on: bool) -> None:
        self.audio.muted = on

    def _picture_text_off(self) -> None:
        """No narration line on the picture. Used for every chapter that is opened."""
        self._srt_preview = False
        btn = getattr(self.preview, "srt_btn", None)
        if btn is not None:
            btn.blockSignals(True)
            btn.setChecked(False)
            btn.blockSignals(False)
        self.preview.surface.set_caption("")

    def _on_srt(self, on: bool) -> None:
        self._srt_preview = bool(on)
        self.set_status("SRT preview on. The words stay out of the video." if on else "SRT preview off. Export SRT for the caption file.")
        self._on_tick(self.clock.position())

    def _on_clip_selected(self, i: int) -> None:
        self.timeline.refresh_edit_buttons()
        self.right.select_clip(i)
        if self.index and 0 <= i < len(self.index.clips):
            c = self.index.clips[i]
            self.set_status(f"{scene_label(c.get('screen'))} selected · {self.index.files[i][0] or 'picture not linked on this PC'}")

    def _on_tick(self, t: float) -> None:
        force, self._force = self._force, False
        idx = self.index
        playing = self.clock.running
        surf = self.preview.surface
        self.preview.set_time(t)
        self.timeline.canvas.set_playhead(t, playing)
        if not idx:
            surf.set_note("Open a project from Recent Files & Folders, or Open Project…")
            surf.show_picture("", "missing", 0, 1, False, False)
            self.right.update_time(t)
            return
        plan = idx.project.plan
        i = idx.clip_index_at(t)
        clip = idx.clips[i] if i >= 0 else None
        if plan.get("video_track_hidden"):
            surf.set_note("Video 1 is hidden (eye on the Video 1 track)")
            surf.show_picture("", "missing", 0, 1, False, False)
        elif clip is None:
            surf.set_note("")
            surf.show_picture("", "missing", 0, 1, False, False)
        else:
            path, kind = idx.files[i]
            if not path:
                surf.set_note(f"Missing image\n{scene_label(clip.get('screen'))} stays on this line.\nClick to replace the picture.")
            else:
                surf.set_note("")
            src_t, speed = idx.source_time(clip, t) if kind == "video" and path else (0.0, 1.0)
            surf.show_picture(path, kind, src_t, speed, playing, force)
            if playing and i + 1 < len(idx.clips):
                np, nk = idx.files[i + 1]
                if np and nk == "video":
                    nclip = idx.clips[i + 1]
                    ns, nspeed = idx.source_time(nclip, float(nclip.get("start") or 0) + 0.001)
                    surf.arm_next_video(np, ns, nspeed)
            if playing and i != getattr(self, "_still_pre", None):
                self._still_pre = i
                ahead = []
                for j in range(i + 1, min(i + 6, len(idx.files))):
                    nxt, nk = idx.files[j]
                    if nxt and nk != "video":
                        ahead.append(nxt)
                surf.preload_stills(ahead)
        if self._logo_job:
            surf.set_lyric("", {}, 0.0, 1.0)
            cap = idx.caption_at(t) if self._srt_preview else ""
            surf.set_caption(cap)
            if self.clock.at_end():
                self.clock.finish()
                playing = False
            self.audio.follow(Heard("narration", 0, str(self._logo_job["path"]), max(0.0, t)), playing, force)
            self.right.update_time(t)
            return
        from ..core.plan import normalize_poem_overlay

        lyric = idx.poem_lyric_at(t)
        dlg = getattr(self, "_poem_dialog", None)
        if dlg is not None and dlg.isVisible():
            dlg.note_screen(clip, idx.in_poem(t))
        local, dur = 0.0, 1.0
        if lyric and clip is not None:
            local = max(0.0, t - float(clip.get("start") or 0))
            dur = max(0.2, float(clip.get("end") or 0) - float(clip.get("start") or 0))
        surf.set_lyric(lyric, normalize_poem_overlay(plan.get("poem_overlay") or {}) if lyric else {}, local, dur)
        # SRT preview is player-only. A poem screen keeps the lyric you placed.
        # The video export never burns these words. Before the first sung word,
        # and on the Listen and sing heading, keep the preview clear of poem copy.
        cap = ""
        if self._srt_preview and not lyric and not plan.get("script_track_hidden"):
            lyric_start = float(plan.get("poem_lyric_start") or 0)
            poem_start = float(plan.get("poem_start_time") or 0)
            before_sung = (
                idx.has_poem
                and lyric_start > poem_start + 0.15
                and t < lyric_start - 0.02
            )
            if not before_sung:
                cap = idx.caption_at(t)
                if not cap and clip is not None:
                    cap = str(clip.get("caption_text") or clip.get("vo_text") or "").strip()
                if "listen and sing" in cap.lower():
                    # Heading card may keep its own line; never treat it as poem copy
                    # once the song window has started.
                    if idx.in_poem(t):
                        cap = ""
        surf.set_caption(cap)
        heard = idx.heard_at(t)
        if self.clock.at_end():
            # The picture is on the last frame. If the voice is still a little
            # behind, let the closing line finish instead of cutting it.
            end_heard = idx.heard_at(max(0.0, idx.duration - 0.02))
            if end_heard and self.audio.behind(end_heard, 0.1):
                self.audio.release(end_heard)
                self.right.update_time(t)
                return
            self.clock.finish()
            playing = False
        self.audio.follow(heard, playing, force)
        self.right.update_time(t)

    # Window ----------------------------------------------------------------

    def set_enlarged(self, on: bool) -> None:
        self._enlarged = on
        for w in (self.top, self.left, self.specs, self.right, self.timeline, self.status):
            w.setVisible(not on)
        self.preview.set_enlarged(on)
        if not on and self.isFullScreen():
            if getattr(self, "_was_maximized", True):
                self.showMaximized()
            else:
                self.showNormal()

    def toggle_fullscreen(self) -> None:
        if self.isFullScreen():
            if getattr(self, "_was_maximized", True):
                self.showMaximized()
            else:
                self.showNormal()
            self.set_enlarged(False)
        else:
            self._was_maximized = self.isMaximized()
            self.set_enlarged(True)
            self.showFullScreen()

    def _escape(self) -> None:
        if self.isFullScreen():
            if getattr(self, "_was_maximized", True):
                self.showMaximized()
            else:
                self.showNormal()
        if self._enlarged:
            self.set_enlarged(False)

    def set_status(self, text: str) -> None:
        self.status.setText(text)

    def open_updates(self) -> None:
        from ..core.update_check import check_remote

        if not (self._update_report or {}).get("updateAvailable"):
            try:
                fresh = check_remote(timeout=5.0)
                if fresh.get("latest"):
                    self._update_report = fresh
            except Exception:  # noqa: BLE001
                pass
        UpdatesDialog(self, self._update_report).exec()

    def _poll_remote_updates(self) -> None:
        if self._update_pinged:
            return
        worker = getattr(self, "_update_worker", None)
        if worker is not None and worker.isRunning():
            return
        self._start_update_check()

    def _start_update_check(self) -> None:
        """Ask the published feed after open and periodically. Offline = no ping, no error dialog."""
        from PySide6.QtCore import QThread

        from ..core.update_check import check_remote

        class _Worker(QThread):
            def __init__(self, parent=None) -> None:
                super().__init__(parent)
                self.report: dict = {}

            def run(self) -> None:  # noqa: N802
                try:
                    self.report = check_remote()
                except Exception as exc:  # noqa: BLE001
                    self.report = {
                        "current": "",
                        "latest": "",
                        "updateAvailable": False,
                        "notes": [],
                        "history": [],
                        "downloads": {},
                        "downloadUrl": "",
                        "platform": "",
                        "feedError": str(exc),
                    }

        worker = _Worker(self)

        def finished() -> None:
            self._on_update_report(dict(worker.report or {}))
            worker.deleteLater()

        worker.finished.connect(finished)
        self._update_worker = worker
        worker.start()

    def _on_update_report(self, report: dict) -> None:
        import sys

        self._update_report = report
        if not report.get("updateAvailable"):
            self.btn_updates.setText("Updates")
            theme.set_btn_neon_icon(self.btn_updates, "bell", "#fbbf24", 16)
            self.btn_updates.setObjectName("")
            self._update_top_bar_density()
            self.btn_updates.setToolTip("Version and published changes.")
            return
        latest = str(report.get("latest") or "")
        os_label = "Mac" if sys.platform == "darwin" else "Windows PC"
        self.btn_updates.setText("Updates · new")
        theme.set_btn_neon_icon(self.btn_updates, "bell", "#22d3ee", 16)
        self.btn_updates.setObjectName("Accent")
        self._update_top_bar_density()
        self.btn_updates.style().unpolish(self.btn_updates)
        self.btn_updates.style().polish(self.btn_updates)
        self.btn_updates.setToolTip(
            f"Version {latest} is available for this {os_label}. Click Updates to sync & restart."
        )
        if self._update_pinged:
            return
        self._update_pinged = True
        self.notify_event(
            "Update Available",
            f"D'Auto Aline {latest} is ready for this {os_label} · click Updates to sync",
            kind="info",
            chime=True,
        )
        box = QMessageBox(self)
        box.setWindowTitle("Update available")
        box.setIcon(QMessageBox.Icon.Information)
        box.setText(f"D'Auto Aline {latest} is ready to install on this {os_label}.")
        notes = [str(n) for n in (report.get("notes") or [])[:3] if n]
        if notes:
            box.setInformativeText("\n".join(f"• {n}" for n in notes))
        sync_now = box.addButton("Update & Restart Now", QMessageBox.ButtonRole.AcceptRole)
        box.addButton("Later", QMessageBox.ButtonRole.RejectRole)
        box.exec()
        if box.clickedButton() is sync_now:
            self.apply_update_and_restart(report)

    def apply_update_and_restart(self, report: dict | None = None) -> None:
        from ..core.update_check import apply_code_update

        try:
            self.set_status("Downloading and applying latest update…")
            res = apply_code_update(report, timeout=45.0)
            self.set_status(f"Updated {res.get('files_updated', 0)} files to {res.get('version')}. Restarting…")
            self.restart_after_update()
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "Update Failed", f"Could not apply update:\n{exc}")

    def restart_after_update(self) -> None:
        import subprocess
        import sys

        if self.project and self.project.dirty:
            try:
                self.project.save()
            except Exception:  # noqa: BLE001
                pass
        args = [sys.executable, "-m", "dgs_studio"]
        if self.project:
            args += ["--project", str(self.project.root)]
        subprocess.Popen(args, cwd=str(paths.ROOT), env=dict(os.environ))
        self.close()

    def closeEvent(self, e) -> None:  # noqa: N802
        if not self._confirm_discard():
            e.ignore()
            return
        self.clock.pause()
        self.audio.pause()
        self.preview.surface.pause_video()
        e.accept()

    def shutdown(self) -> None:
        """Called once after the event loop ends; libmpv crashes if freed while Qt is still painting."""
        self.cards.cancel()
        Engine.shutdown_all()
        self.timeline.canvas.thumbs.stop()
        if hasattr(self.left, "_preview_cache"):
            self.left._preview_cache._pool.clear()
            self.left._preview_cache._pool.waitForDone(1500)
        self.audio.shutdown()
        self.preview.surface.shutdown()

    def grab_after(self, ms: int, path: str, then_quit: bool = True) -> None:
        def shot() -> None:
            self.grab().save(path)
            if then_quit:
                self.close()

        QTimer.singleShot(ms, shot)
