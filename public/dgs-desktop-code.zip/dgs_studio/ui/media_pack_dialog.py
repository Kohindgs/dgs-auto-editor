"""Media Pack — download chapter media, edit elsewhere, upload to replace."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QTextBrowser,
    QVBoxLayout,
)

from ..core.media_pack import PackReport, collect_pack_items, export_media_pack, import_media_pack
from ..core.project_store import Project


class MediaPackDialog(QDialog):
    """Filmora-style Media Pack: download pictures/videos/VO, then upload replacements."""

    def __init__(self, project: Project, parent=None, *, duration_of=None) -> None:
        super().__init__(parent)
        self.project = project
        self._duration_of = duration_of
        self.last_report: PackReport | None = None
        self.setWindowTitle("Media Pack")
        self.resize(560, 420)
        lay = QVBoxLayout(self)

        head = QLabel("<b>Download → edit in Filmora / Photoshop → upload to replace</b>")
        head.setWordWrap(True)
        lay.addWidget(head)

        tip = QTextBrowser()
        tip.setOpenExternalLinks(False)
        tip.setMaximumHeight(180)
        tip.setHtml(
            "<p>Copies every picture, scene video, narration VO and poem file for this chapter "
            "into one folder so you can edit them in other software.</p>"
            "<ul>"
            "<li><b>Download Media Pack</b> — writes <code>images/</code>, <code>videos/</code>, "
            "<code>voiceover/</code>, <code>poem/</code> plus a <code>manifest.json</code>.</li>"
            "<li><b>Upload / Replace</b> — swaps files back in. Timeline blocks stay where they are "
            "(same as Filmora Media Library → Replace).</li>"
            "</ul>"
            "<p><b>VO replace (Filmora-style)</b></p>"
            "<ul>"
            "<li>Replace <code>VO_1.mp3</code> in the pack to swap the whole narration library file. "
            "Every voice block keeps its place; only the audio source changes.</li>"
            "<li>Or right-click one voice section on the timeline → <b>Replace this voice section…</b> "
            "to swap audio inside that block only (longer takes are trimmed to the block).</li>"
            "</ul>"
        )
        lay.addWidget(tip)

        items = collect_pack_items(project)
        counts = {"image": 0, "video": 0, "narration": 0, "poem": 0}
        for it in items:
            counts[it.kind] = counts.get(it.kind, 0) + 1
        summary = QLabel(
            f"This chapter: {counts.get('image', 0)} pictures · {counts.get('video', 0)} videos · "
            f"{counts.get('narration', 0)} narration VO · {counts.get('poem', 0)} poem"
        )
        summary.setObjectName("Muted")
        summary.setWordWrap(True)
        lay.addWidget(summary)

        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.status.setObjectName("Muted")
        lay.addWidget(self.status)

        row = QHBoxLayout()
        dl = QPushButton("Download Media Pack…")
        dl.setObjectName("Accent")
        dl.setToolTip("Copy every linked picture, video and VO into a folder you choose")
        dl.clicked.connect(self._download)
        row.addWidget(dl)
        up = QPushButton("Upload / Replace from folder…")
        up.setToolTip("Pick a Media Pack folder (or any folder of Scene N / VO_N files) and replace matching media")
        up.clicked.connect(self._upload)
        row.addWidget(up)
        lay.addLayout(row)

        close = QPushButton("Close")
        close.clicked.connect(self.accept)
        lay.addWidget(close, 0, Qt.AlignmentFlag.AlignRight)

    def _download(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Save Media Pack into folder")
        if not folder:
            return
        dest = Path(folder)
        # Prefer a named subfolder so we do not dump into a busy Downloads root.
        if any(dest.iterdir()):
            dest = dest / f"DGS_MediaPack_{self.project.pid[:8]}"
        try:
            report = export_media_pack(self.project, dest)
        except OSError as e:
            QMessageBox.warning(self, "Media Pack", str(e) or "Could not write the pack folder.")
            return
        self.last_report = report
        self.status.setText(f"Downloaded to {report.folder}\n{report.summary()}")
        QMessageBox.information(
            self,
            "Media Pack",
            f"Saved {len(report.copied)} files to:\n{report.folder}\n\n"
            "Edit them in Filmora or any other app, keep the same names, then Upload / Replace.",
        )

    def _upload(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Choose Media Pack folder to upload")
        if not folder:
            return
        src = Path(folder)
        # If user picked the parent that contains DGS_MediaPack_*, prefer the pack itself.
        if not (src / "manifest.json").is_file():
            packs = [p for p in src.iterdir() if p.is_dir() and (p / "manifest.json").is_file()]
            if len(packs) == 1:
                src = packs[0]
        parent = self.parent()
        if parent is not None and hasattr(parent, "_push_undo"):
            try:
                parent._push_undo()
            except Exception:
                pass
        try:
            report = import_media_pack(self.project, src, duration_of=self._duration_of)
        except OSError as e:
            QMessageBox.warning(self, "Media Pack", str(e) or "Could not read that folder.")
            return
        self.last_report = report
        self.status.setText(f"From {report.folder}\n{report.summary()}")
        detail = "\n".join(report.replaced[:24])
        if len(report.replaced) > 24:
            detail += f"\n… and {len(report.replaced) - 24} more"
        if not report.replaced:
            QMessageBox.information(
                self,
                "Media Pack",
                "No matching Scene / VO / Poem files were replaced.\n"
                "Use names like 5.png, Scene 5.mp4, VO_1.mp3, Poem_1.mp3, or keep manifest.json.",
            )
            return
        QMessageBox.information(
            self,
            "Media Pack",
            f"Replaced {len(report.replaced)} file(s). Timeline blocks stayed in place.\n\n{detail}",
        )
        self.accept()
