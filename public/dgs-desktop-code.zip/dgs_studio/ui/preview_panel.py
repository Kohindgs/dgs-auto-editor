"""Preview: header buttons, the 16:9 libmpv stage and the transport row."""

from __future__ import annotations

from PySide6.QtCore import QSize, Qt, Signal
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QSizePolicy, QSlider, QVBoxLayout, QWidget

from .. import theme
from ..core.plan import fmt_tc
from ..engine.player import PreviewSurface


class AspectBox(QWidget):
    """Keeps its child at 16:9 and centred."""

    def __init__(self, child: QWidget, parent=None) -> None:
        super().__init__(parent)
        self.child = child
        child.setParent(self)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setMinimumSize(QSize(320, 180))
        self.setStyleSheet("background: #050407; border-radius: 12px;")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

    def resizeEvent(self, e) -> None:  # noqa: N802
        w, h = self.width(), self.height()
        cw = min(w, int(h * 16 / 9))
        ch = int(cw * 9 / 16)
        self.child.setGeometry((w - cw) // 2, (h - ch) // 2, cw, ch)
        super().resizeEvent(e)


class PreviewPanel(QWidget):
    play_toggled = Signal()
    seek_requested = Signal(float)
    step_requested = Signal(float)
    jump_requested = Signal(str)  # start | end | prev | next
    stop_requested = Signal()
    volume_changed = Signal(float)
    mute_toggled = Signal(bool)
    logo_toggled = Signal(bool)
    fill_toggled = Signal(bool)
    align_dock_toggled = Signal(bool)
    enlarge_toggled = Signal(bool)
    fullscreen_toggled = Signal()
    srt_toggled = Signal(bool)
    poem_text_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Panel")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.duration = 0.0
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(6)

        head = QHBoxLayout()
        head.setSpacing(6)
        title = QLabel("Preview")
        title.setObjectName("PanelTitle")
        head.addWidget(title)
        self.status = QLabel("Timeline")
        self.status.setObjectName("Muted")
        head.addWidget(self.status, 1)
        self.logo_btn = self._pill("Logo OFF", True, "Show or hide the brand logo on every screen")
        self.logo_btn.toggled.connect(self._on_logo)
        self.logo_btn.setVisible(False)
        self.fill_btn = self._pill("16:9 Fit", True, "Switch between exact 16:9 Fit and Full Stage Fill")
        theme.set_btn_neon_icon(self.fill_btn, "fit", "#22d3ee", 14)
        self.fill_btn.toggled.connect(self._on_fill)
        self.dock_btn = self._pill("Align Dock", True, "Toggle the Live Scene & Voiceover Alignment panel")
        theme.set_btn_neon_icon(self.dock_btn, "sliders", "#c084fc", 14)
        self.dock_btn.setChecked(True)
        self.dock_btn.toggled.connect(self._on_dock)
        self.enlarge_btn = self._pill("Enlarge", True, "Enlarge video to cinema screen (Esc closes)")
        theme.set_btn_neon_icon(self.enlarge_btn, "fullscreen", "#f472b6", 14)
        self.enlarge_btn.toggled.connect(self._on_enlarge)
        for b in (self.fill_btn, self.dock_btn, self.enlarge_btn):
            head.addWidget(b)
        lay.addLayout(head)

        self.surface = PreviewSurface()
        self.stage = AspectBox(self.surface)
        lay.addWidget(self.stage, 1)

        self.scrub = QSlider(Qt.Orientation.Horizontal)
        self.scrub.setRange(0, 1000)
        self.scrub.sliderMoved.connect(self._on_scrub)
        self.scrub.sliderPressed.connect(lambda: self._on_scrub(self.scrub.value()))
        lay.addWidget(self.scrub)

        tr = QHBoxLayout()
        tr.setSpacing(5)
        self.btn_start = self._tbtn("skip_start", "#c084fc", "Go to start (Home)", lambda: self.jump_requested.emit("start"))
        self.btn_back = self._tbtn("step_back", "#38bdf8", "Previous scene", lambda: self.jump_requested.emit("prev"))
        self.btn_play = self._tbtn("play", "#f472b6", "Play / Pause (Space)", self.play_toggled.emit)
        self.btn_play.setFixedWidth(40)
        self.btn_next = self._tbtn("step_fwd", "#38bdf8", "Next scene", lambda: self.jump_requested.emit("next"))
        self.btn_stop = self._tbtn("stop", "#fb7185", "Stop and return to start", self.stop_requested.emit)
        for b in (self.btn_start, self.btn_back, self.btn_play, self.btn_next, self.btn_stop):
            tr.addWidget(b)
        tr.addSpacing(8)
        self.mute_btn = self._tbtn("volume", "#22d3ee", "Mute", None)
        self.mute_btn.setCheckable(True)
        self.mute_btn.toggled.connect(self._on_mute)
        tr.addWidget(self.mute_btn)
        self.vol = QSlider(Qt.Orientation.Horizontal)
        self.vol.setRange(0, 100)
        self.vol.setValue(100)
        self.vol.setFixedWidth(90)
        self.vol.valueChanged.connect(lambda v: self.volume_changed.emit(v / 100))
        tr.addWidget(self.vol)
        tr.addSpacing(8)
        self.tc = QLabel("00:00:00:00 / 00:00:00:00")
        self.tc.setStyleSheet("font-family: Consolas; font-size: 12px; font-weight: 600;")
        tr.addWidget(self.tc)
        tr.addStretch(1)
        self.srt_btn = self._pill("SRT", True, "Preview the SRT in the player. The words are never burned into the video. Export SRT writes the file.")
        theme.set_btn_neon_icon(self.srt_btn, "cc", "#22d3ee", 14)
        self.srt_btn.setChecked(False)
        self.srt_btn.toggled.connect(self.srt_toggled.emit)
        tr.addWidget(self.srt_btn)
        self.poem_btn = self._pill("Poem text", False, "Place and style the poem lyric. The look is used on every poem screen.")
        theme.set_btn_neon_icon(self.poem_btn, "type", "#e879f9", 14)
        self.poem_btn.clicked.connect(self.poem_text_requested.emit)
        tr.addWidget(self.poem_btn)
        self.fs_btn = self._tbtn("fullscreen", "#c084fc", "Full screen (F11). Esc closes.", self.fullscreen_toggled.emit)
        tr.addWidget(self.fs_btn)
        lay.addLayout(tr)

    def _pill(self, text: str, checkable: bool, tip: str) -> QPushButton:
        b = QPushButton(text)
        b.setObjectName("Pill")
        b.setCheckable(checkable)
        b.setFixedHeight(29)
        b.setToolTip(tip)
        return b

    def _tbtn(self, icon_name: str, color: str, tip: str, slot) -> QPushButton:
        b = QPushButton("")
        b.setObjectName("IconSquare")
        theme.set_btn_neon_icon(b, icon_name, color, 16)
        b.setToolTip(tip)
        b.setFixedSize(32, 29)
        if slot:
            b.clicked.connect(slot)
        return b

    def _on_logo(self, on: bool) -> None:
        self.logo_btn.setText("Logo ON" if on else "Logo OFF")
        self.logo_toggled.emit(on)

    def _on_fill(self, on: bool) -> None:
        self.fill_btn.setText("Fill Stage" if on else "16:9 Fit")
        self.fill_toggled.emit(on)

    def _on_dock(self, on: bool) -> None:
        self.dock_btn.setText("Align Dock" if on else "Show Align")
        self.align_dock_toggled.emit(on)

    def _on_enlarge(self, on: bool) -> None:
        self.enlarge_btn.setText("Close (Esc)" if on else "Enlarge")
        self.enlarge_toggled.emit(on)

    def _on_mute(self, on: bool) -> None:
        theme.set_btn_neon_icon(self.mute_btn, "mute" if on else "volume", "#ef4444" if on else "#22d3ee", 16)
        self.mute_toggled.emit(on)

    def _on_scrub(self, v: int) -> None:
        if self.duration > 0:
            self.seek_requested.emit(self.duration * v / 1000)

    def set_logo_state(self, on: bool) -> None:
        self.logo_btn.blockSignals(True)
        self.logo_btn.setChecked(on)
        self.logo_btn.setText("Logo ON" if on else "Logo OFF")
        self.logo_btn.blockSignals(False)

    def set_enlarged(self, on: bool) -> None:
        self.enlarge_btn.blockSignals(True)
        self.enlarge_btn.setChecked(on)
        self.enlarge_btn.setText("Close (Esc)" if on else "Enlarge")
        self.enlarge_btn.blockSignals(False)

    def set_time(self, t: float) -> None:
        self.tc.setText(f"{fmt_tc(t)} / {fmt_tc(self.duration)}")
        if not self.scrub.isSliderDown() and self.duration > 0:
            self.scrub.blockSignals(True)
            self.scrub.setValue(int(1000 * t / self.duration))
            self.scrub.blockSignals(False)

    def set_playing(self, on: bool) -> None:
        theme.set_btn_neon_icon(self.btn_play, "pause" if on else "play", "#22d3ee" if on else "#f472b6", 16)
