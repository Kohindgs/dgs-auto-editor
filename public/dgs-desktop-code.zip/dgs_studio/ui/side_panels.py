"""Left (Media / Script / VO / Brand Logo), middle-left (Project Specs) and
right (Live Scene & VO Alignment / Scene Queue / QA) panels.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

from PySide6.QtCore import QObject, QPointF, QRectF, QRunnable, QSize, Qt, QThreadPool, QTimer, Signal
from PySide6.QtGui import (
    QColor,
    QFont,
    QFontMetrics,
    QIcon,
    QImage,
    QImageReader,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QListView,
    QListWidget,
    QListWidgetItem,
    QPushButton,
    QSizePolicy,
    QTabWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .. import paths, theme
from ..core.plan import PlanIndex, fmt_short, media_block_label, num, qa_key, scene_label
from ..core.qa import poem_clock_false_sync


def _title(text: str) -> QLabel:
    l = QLabel(text)
    l.setObjectName("PanelTitle")
    return l


def _muted(text: str = "") -> QLabel:
    l = QLabel(text)
    l.setObjectName("Muted")
    l.setWordWrap(True)
    return l


def _panel() -> QFrame:
    f = QFrame()
    f.setObjectName("Panel")
    return f


# Filmora-style 16:9 media thumbnail generator --------------------------------

THUMB_W = 128
THUMB_H = 72
THUMB_DPR = 2.0


def _file_mtime_ns(path: str) -> int:
    try:
        return os.stat(path).st_mtime_ns
    except OSError:
        return 0


def _compose_preview_card(
    raw: QImage | None,
    *,
    badge_left: str,
    badge_right: str,
    dur_text: str,
    kind: str,
    ok: bool,
) -> QImage:
    """Render a 2x supersampled High-DPI 128x72 16:9 Filmora-style media preview tile with badges."""
    pw = int(round(THUMB_W * THUMB_DPR))
    ph = int(round(THUMB_H * THUMB_DPR))
    canvas = QImage(pw, ph, QImage.Format.Format_ARGB32_Premultiplied)
    canvas.setDevicePixelRatio(THUMB_DPR)
    canvas.fill(Qt.GlobalColor.transparent)
    p = QPainter(canvas)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)

    rect = QRectF(1.0, 1.0, THUMB_W - 2.0, THUMB_H - 2.0)
    clip_path = QPainterPath()
    clip_path.addRoundedRect(rect, 7.0, 7.0)
    p.save()
    p.setClipPath(clip_path)

    # Cosmic dark backdrop
    bg = QLinearGradient(rect.topLeft(), rect.bottomRight())
    if not ok:
        bg.setColorAt(0.0, QColor(44, 16, 28))
        bg.setColorAt(1.0, QColor(24, 10, 18))
    elif kind == "video":
        bg.setColorAt(0.0, QColor(20, 28, 52))
        bg.setColorAt(1.0, QColor(12, 16, 32))
    else:
        bg.setColorAt(0.0, QColor(30, 18, 48))
        bg.setColorAt(1.0, QColor(14, 9, 26))
    p.fillRect(rect, bg)

    if raw is not None and not raw.isNull():
        tw = int(round(rect.width() * THUMB_DPR))
        th = int(round(rect.height() * THUMB_DPR))
        scaled = raw.scaled(
            tw,
            th,
            Qt.AspectRatioMode.KeepAspectRatioByExpanding,
            Qt.TransformationMode.SmoothTransformation,
        )
        sx = max(0, (scaled.width() - tw) // 2)
        sy = max(0, (scaled.height() - th) // 2)
        p.drawImage(
            rect,
            scaled,
            QRectF(sx, sy, tw, th),
        )
    else:
        # Crisp neon vector icon centered when loading or unlinked
        ic_name = "video" if kind == "video" else ("image" if ok else "bell")
        ic_col = "#22d3ee" if kind == "video" else ("#f472b6" if ok else "#ef4444")
        ic_pix = theme._render_neon_icon_pixmap(ic_name, ic_col, 24, THUMB_DPR)
        p.drawPixmap(QPointF(rect.center().x() - 12, rect.center().y() - 12), ic_pix)

    # Top and bottom subtle dark scrims for crisp badge contrast
    top_scrim = QLinearGradient(0, rect.top(), 0, rect.top() + 22)
    top_scrim.setColorAt(0.0, QColor(6, 4, 14, 185))
    top_scrim.setColorAt(1.0, QColor(6, 4, 14, 0))
    p.fillRect(QRectF(rect.left(), rect.top(), rect.width(), 22), top_scrim)

    bot_scrim = QLinearGradient(0, rect.bottom() - 22, 0, rect.bottom())
    bot_scrim.setColorAt(0.0, QColor(6, 4, 14, 0))
    bot_scrim.setColorAt(1.0, QColor(6, 4, 14, 210))
    p.fillRect(QRectF(rect.left(), rect.bottom() - 22, rect.width(), 22), bot_scrim)

    font = QFont("Segoe UI")
    font.setPixelSize(9)
    font.setWeight(QFont.Weight.Bold)
    p.setFont(font)
    fm = QFontMetrics(font)

    # Top-left scene pill (#1, #2, ...)
    if badge_left:
        bw = min(int(rect.width() * 0.58), fm.horizontalAdvance(badge_left) + 10)
        pill_r = QRectF(rect.left() + 4, rect.top() + 4, bw, 15)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(236, 72, 153, 215) if ok else QColor(239, 68, 68, 220))
        p.drawRoundedRect(pill_r, 4, 4)
        p.setPen(QColor("#ffffff"))
        elided = fm.elidedText(badge_left, Qt.TextElideMode.ElideRight, int(bw - 6))
        p.drawText(pill_r, Qt.AlignmentFlag.AlignCenter, elided)

    # Top-right kind pill (VID / IMG)
    if badge_right:
        rw = fm.horizontalAdvance(badge_right) + 8
        r_pill = QRectF(rect.right() - rw - 4, rect.top() + 4, rw, 15)
        p.setPen(Qt.PenStyle.NoPen)
        if kind == "video":
            p.setBrush(QColor(249, 115, 22, 220))
        else:
            p.setBrush(QColor(34, 211, 238, 185))
        p.drawRoundedRect(r_pill, 4, 4)
        p.setPen(QColor("#ffffff"))
        p.drawText(r_pill, Qt.AlignmentFlag.AlignCenter, badge_right)

    # Bottom-right duration pill
    if dur_text:
        dw = fm.horizontalAdvance(dur_text) + 9
        d_pill = QRectF(rect.right() - dw - 4, rect.bottom() - 18, dw, 14)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(8, 5, 18, 215))
        p.drawRoundedRect(d_pill, 4, 4)
        p.setPen(QColor("#f3e8ff"))
        p.drawText(d_pill, Qt.AlignmentFlag.AlignCenter, dur_text)

    p.restore()

    # Crisp glowing card border
    if not ok:
        border_col = QColor(239, 68, 68, 175)
    elif kind == "video":
        border_col = QColor(56, 189, 248, 165)
    else:
        border_col = QColor(216, 114, 255, 145)
    p.setPen(QPen(border_col, 1.2))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawRoundedRect(rect, 7.0, 7.0)
    p.end()
    return canvas


class _MediaThumbSignals(QObject):
    done = Signal(object, QImage)


class _MediaThumbJob(QRunnable):
    def __init__(self, cache_key: tuple, meta: dict, signals: _MediaThumbSignals) -> None:
        super().__init__()
        self.cache_key = cache_key
        self.meta = meta
        self.signals = signals

    def run(self) -> None:
        raw = QImage()
        path = str(self.meta.get("path") or "")
        kind = str(self.meta.get("kind") or "image")
        ok = bool(self.meta.get("ok", True))
        try:
            read_path = path
            if ok and path and kind == "video":
                # Check if a matching still image exists next to the video or in Scene Images
                p_obj = Path(path)
                stem = p_obj.stem
                num_part = "".join(ch for ch in stem if ch.isdigit())
                candidates = []
                for ext in (".png", ".jpg", ".jpeg", ".webp"):
                    candidates.append(p_obj.with_suffix(ext))
                    if num_part:
                        candidates.append(p_obj.parent / f"{num_part}{ext}")
                        candidates.append(p_obj.parent.parent / "Scene Images" / f"{num_part}{ext}")
                        candidates.append(p_obj.parent.parent / "images" / f"{num_part}{ext}")
                read_path = ""
                for c in candidates:
                    if c.is_file():
                        read_path = str(c)
                        break
            if ok and read_path:
                reader = QImageReader(read_path)
                reader.setAutoTransform(True)
                sz = reader.size()
                if sz.isValid() and sz.height() > 0:
                    w = max(THUMB_W, round(sz.width() * (THUMB_H * 2) / sz.height()))
                    reader.setScaledSize(QSize(w, THUMB_H * 2))
                raw = reader.read()
        except Exception:  # noqa: BLE001
            raw = QImage()
        card = _compose_preview_card(
            raw if not raw.isNull() else None,
            badge_left=str(self.meta.get("badge_left") or ""),
            badge_right=str(self.meta.get("badge_right") or ""),
            dur_text=str(self.meta.get("dur_text") or ""),
            kind=kind,
            ok=ok,
        )
        self.signals.done.emit(self.cache_key, card)


class _MediaPreviewCache(QObject):
    """Asynchronous 16:9 frame/image cache for the Filmora-style Media Bin."""

    batch_ready = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._placeholders: dict[tuple[str, bool], QIcon] = {}
        self._icons: dict[tuple, QIcon] = {}
        self._pending: set[tuple] = set()
        self._pool = QThreadPool(self)
        self._pool.setMaxThreadCount(2)
        self._sig = _MediaThumbSignals()
        self._sig.done.connect(self._on_done)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(90)
        self._timer.timeout.connect(self.batch_ready.emit)

    def placeholder_for(self, kind: str, ok: bool) -> QIcon:
        pkey = (kind, ok)
        ic = self._placeholders.get(pkey)
        if ic is None:
            card = _compose_preview_card(
                None,
                badge_left="",
                badge_right="VID" if kind == "video" else "IMG",
                dur_text="",
                kind=kind,
                ok=ok,
            )
            ic = QIcon(QPixmap.fromImage(card))
            self._placeholders[pkey] = ic
        return ic

    def icon_for(
        self,
        path: str,
        *,
        badge_left: str,
        badge_right: str,
        dur_text: str,
        kind: str,
        ok: bool,
    ) -> QIcon:
        stamp = _file_mtime_ns(path) if (path and ok) else 0
        cache_key = (path, stamp, badge_left, badge_right, dur_text, kind, ok)
        cached_icon = self._icons.get(cache_key)
        if cached_icon is not None:
            return cached_icon

        if cache_key not in self._pending:
            self._pending.add(cache_key)
            meta = {
                "path": path,
                "badge_left": badge_left,
                "badge_right": badge_right,
                "dur_text": dur_text,
                "kind": kind,
                "ok": ok,
            }
            self._pool.start(_MediaThumbJob(cache_key, meta, self._sig))

        return self.placeholder_for(kind, ok)

    def _on_done(self, cache_key: tuple, card: QImage) -> None:
        self._pending.discard(cache_key)
        if not card.isNull():
            self._icons[cache_key] = QIcon(QPixmap.fromImage(card))
            if not self._timer.isActive():
                self._timer.start()


class LeftPanel(QFrame):
    image_folder = Signal()
    video_folder = Signal()
    image_files = Signal()
    video_files = Signal()
    media_pack = Signal()
    narration_vo = Signal(int)
    download_vo = Signal(int)
    remove_vo = Signal(int)
    poem_vo = Signal(int)
    download_poem = Signal(int)
    remove_poem = Signal(int)
    logo_toggled = Signal(bool)
    change_logo = Signal()
    logo_placement = Signal()
    logo_default = Signal()
    import_script = Signal()
    save_template = Signal()
    jump_to = Signal(float)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Panel")
        self.index: PlanIndex | None = None
        self._grid_mode = True
        self._preview_cache = _MediaPreviewCache(self)
        self._preview_cache.batch_ready.connect(self._on_preview_batch_ready)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 6, 8, 6)
        lay.setSpacing(4)
        self.tabs = QTabWidget()
        lay.addWidget(self.tabs, 1)

        media = QWidget()
        ml = QVBoxLayout(media)
        ml.setContentsMargins(0, 4, 0, 0)
        ml.setSpacing(4)

        # Clean symmetric 3x2 CTA grid
        grid = QGridLayout()
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setHorizontalSpacing(5)
        grid.setVerticalSpacing(4)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        self.btn_img_folder = QPushButton("Image Folder")
        theme.set_btn_neon_icon(self.btn_img_folder, "folder", "#f472b6", 15)
        self.btn_img_files = QPushButton("+ Image Files")
        theme.set_btn_neon_icon(self.btn_img_files, "image", "#fb7185", 15)
        self.btn_vid_folder = QPushButton("Video Folder")
        theme.set_btn_neon_icon(self.btn_vid_folder, "folder", "#22d3ee", 15)
        self.btn_vid_files = QPushButton("+ Video Files")
        theme.set_btn_neon_icon(self.btn_vid_files, "video", "#38bdf8", 15)
        self.btn_add_script = QPushButton("Add Script (.xlsx)…")
        self.btn_add_script.setObjectName("Accent")
        theme.set_btn_neon_icon(self.btn_add_script, "script", "#e879f9", 15)
        self.btn_add_script.setToolTip("Add the master chapter workbook: Sheet1, Sheet2, Narration VO, Poem VO, Audio Manifest")
        self.btn_media_pack = QPushButton("Media Pack…")
        theme.set_btn_neon_icon(self.btn_media_pack, "box", "#c084fc", 15)
        self.btn_media_pack.setToolTip(
            "Download all pictures, videos and VO into a folder for Filmora/Photoshop, "
            "then upload to replace (timeline blocks stay — Filmora Media Library style)"
        )
        self.btn_img_folder.clicked.connect(self.image_folder.emit)
        self.btn_img_files.clicked.connect(self.image_files.emit)
        self.btn_vid_folder.clicked.connect(self.video_folder.emit)
        self.btn_vid_files.clicked.connect(self.video_files.emit)
        self.btn_add_script.clicked.connect(self.import_script.emit)
        self.btn_media_pack.clicked.connect(self.media_pack.emit)
        for b in (
            self.btn_img_folder,
            self.btn_img_files,
            self.btn_vid_folder,
            self.btn_vid_files,
            self.btn_add_script,
            self.btn_media_pack,
        ):
            b.setFixedHeight(28)
            b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        grid.addWidget(self.btn_img_folder, 0, 0)
        grid.addWidget(self.btn_img_files, 0, 1)
        grid.addWidget(self.btn_vid_folder, 1, 0)
        grid.addWidget(self.btn_vid_files, 1, 1)
        grid.addWidget(self.btn_add_script, 2, 0)
        grid.addWidget(self.btn_media_pack, 2, 1)
        ml.addLayout(grid)

        # VO Quick-Link buttons host inside Media tab
        self.voice_host = QWidget()
        self.voice_lay = QVBoxLayout(self.voice_host)
        self.voice_lay.setContentsMargins(0, 1, 0, 1)
        self.voice_lay.setSpacing(3)
        ml.addWidget(self.voice_host)

        # Filmora-style Media Previews header + view toggle
        hdr_row = QHBoxLayout()
        hdr_row.setContentsMargins(0, 0, 0, 0)
        hdr_row.setSpacing(5)
        self.scene_toggle = QToolButton()
        self.scene_toggle.setObjectName("Accordion")
        self.scene_toggle.setCheckable(True)
        self.scene_toggle.setChecked(True)
        self.scene_toggle.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        self.scene_toggle.setArrowType(Qt.ArrowType.DownArrow)
        self.scene_toggle.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.scene_toggle.setFixedHeight(26)
        self.scene_toggle.toggled.connect(self._toggle_scenes)
        self.scene_toggle.setText("Media Previews")
        hdr_row.addWidget(self.scene_toggle, 1)

        self.view_mode_btn = QPushButton("Grid")
        theme.set_btn_neon_icon(self.view_mode_btn, "grid", "#22d3ee", 14)
        self.view_mode_btn.setObjectName("Pill")
        self.view_mode_btn.setCheckable(True)
        self.view_mode_btn.setChecked(True)
        self.view_mode_btn.setFixedHeight(26)
        self.view_mode_btn.setToolTip("Switch between Filmora 2-Column Thumbnail Grid and Detailed Thumbnail List")
        self.view_mode_btn.toggled.connect(self._on_view_mode_toggled)
        hdr_row.addWidget(self.view_mode_btn)
        ml.addLayout(hdr_row)

        self.media_list = QListWidget()
        self.media_list.itemClicked.connect(self._jump_item)
        self.media_list.setVisible(True)
        self._apply_media_list_mode()
        ml.addWidget(self.media_list, 1)
        self.tabs.addTab(media, "Media")

        script = QWidget()
        sl = QVBoxLayout(script)
        sl.setContentsMargins(0, 6, 0, 0)
        sl.setSpacing(6)
        srow = QHBoxLayout()
        srow.setSpacing(6)
        self.btn_import_script = QPushButton("Add Script (.xlsx)…")
        self.btn_import_script.setObjectName("Accent")
        theme.set_btn_neon_icon(self.btn_import_script, "script", "#e879f9", 15)
        self.btn_import_script.setFixedHeight(30)
        self.btn_import_script.setToolTip("Master chapter workbook: Sheet1, Sheet2, Narration VO, Poem VO, Audio Manifest")
        self.btn_import_script.clicked.connect(self.import_script.emit)
        srow.addWidget(self.btn_import_script, 1)
        self.btn_template = QPushButton("Save Template…")
        self.btn_template.setFixedHeight(30)
        self.btn_template.setToolTip("Save a blank master script workbook (English + Marathi) to fill in")
        self.btn_template.clicked.connect(self.save_template.emit)
        self.btn_template.setVisible(paths.script_template() is not None)
        srow.addWidget(self.btn_template)
        sl.addLayout(srow)
        self.script_info = _muted()
        sl.addWidget(self.script_info)
        self.script_format = _muted()
        sl.addWidget(self.script_format)
        self.script_list = QListWidget()
        self.script_list.setWordWrap(True)
        self.script_list.itemClicked.connect(self._jump_item)
        sl.addWidget(self.script_list, 1)
        self.tabs.addTab(script, "Script")

        vo = QWidget()
        self.vo_lay = QVBoxLayout(vo)
        self.vo_lay.setContentsMargins(0, 6, 0, 0)
        self.vo_lay.setSpacing(6)
        self.tabs.addTab(vo, "VO / Replace")

        # Compact, aligned Brand Logo card (never clips logo thumbnail on any screen width)
        logo = _panel()
        ll = QVBoxLayout(logo)
        ll.setContentsMargins(8, 5, 8, 5)
        ll.setSpacing(4)
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(6)
        self.logo_thumb = QLabel()
        self.logo_thumb.setFixedSize(68, 24)
        self.logo_thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.logo_thumb.setStyleSheet(
            "background: rgba(255,255,255,0.06); border: 1px solid rgba(192,132,252,0.28); border-radius: 5px; padding: 1px;"
        )
        row.addWidget(self.logo_thumb)

        logo_meta_col = QVBoxLayout()
        logo_meta_col.setContentsMargins(0, 0, 0, 0)
        logo_meta_col.setSpacing(0)
        logo_meta_col.addWidget(_title("Brand Logo"))
        self.logo_readout = _muted()
        self.logo_readout.setStyleSheet("font-size: 10px;")
        logo_meta_col.addWidget(self.logo_readout)
        row.addLayout(logo_meta_col, 1)

        self.logo_pill = QPushButton("OFF")
        self.logo_pill.setObjectName("Pill")
        self.logo_pill.setCheckable(True)
        self.logo_pill.setFixedHeight(22)
        self.logo_pill.toggled.connect(self._on_logo_pill)
        row.addWidget(self.logo_pill)
        ll.addLayout(row)

        row3 = QHBoxLayout()
        row3.setContentsMargins(0, 0, 0, 0)
        row3.setSpacing(4)
        for text, ic_name, ic_col, sig, tip in (
            ("Change…", "image", "#f472b6", self.change_logo, "Upload a custom PNG/JPG logo for this chapter"),
            ("Transform", "sliders", "#22d3ee", self.logo_placement, "Filmora-style Transform & placement numbers"),
            ("Default", "refresh", "#c084fc", self.logo_default, "Restore E-Class logo at the Filmora 16 default placement"),
        ):
            b = QPushButton(text)
            theme.set_btn_neon_icon(b, ic_name, ic_col, 14)
            b.setFixedHeight(24)
            b.setToolTip(tip)
            b.clicked.connect(sig.emit)
            row3.addWidget(b, 1)
        ll.addLayout(row3)
        lay.addWidget(logo)

    def resizeEvent(self, e) -> None:  # noqa: N802
        super().resizeEvent(e)
        if self._grid_mode:
            self._apply_media_list_mode()

    def _apply_media_list_mode(self) -> None:
        if self._grid_mode:
            avail_w = max(210, self.width() - 38)
            cell_w = max(96, min(160, (avail_w - 8) // 2))
            icon_w = max(84, cell_w - 12)
            icon_h = max(47, round(icon_w * 9 / 16))
            cell_h = icon_h + 24
            self.media_list.setViewMode(QListView.ViewMode.IconMode)
            self.media_list.setIconSize(QSize(icon_w, icon_h))
            self.media_list.setGridSize(QSize(cell_w, cell_h))
            self.media_list.setResizeMode(QListView.ResizeMode.Adjust)
            self.media_list.setMovement(QListView.Movement.Static)
            self.media_list.setWrapping(True)
            self.media_list.setWordWrap(False)
            self.media_list.setSpacing(4)
        else:
            self.media_list.setViewMode(QListView.ViewMode.ListMode)
            self.media_list.setIconSize(QSize(76, 43))
            self.media_list.setGridSize(QSize())
            self.media_list.setResizeMode(QListView.ResizeMode.Adjust)
            self.media_list.setMovement(QListView.Movement.Static)
            self.media_list.setWrapping(False)
            self.media_list.setWordWrap(True)
            self.media_list.setSpacing(3)

    def _on_view_mode_toggled(self, grid_on: bool) -> None:
        self._grid_mode = grid_on
        self.view_mode_btn.setText("Grid" if grid_on else "List")
        theme.set_btn_neon_icon(self.view_mode_btn, "grid" if grid_on else "list", "#22d3ee", 14)
        self._apply_media_list_mode()
        self._fill_media()

    def _on_logo_pill(self, on: bool) -> None:
        self.logo_pill.setText("ON" if on else "OFF")
        self.logo_toggled.emit(on)

    def _jump_item(self, item: QListWidgetItem) -> None:
        t = item.data(Qt.ItemDataRole.UserRole)
        if isinstance(t, (int, float)):
            self.jump_to.emit(float(t))

    def set_index(self, index: PlanIndex | None) -> None:
        self.index = index
        enabled = index is not None
        for b in (
            self.btn_img_folder, self.btn_img_files, self.btn_vid_folder, self.btn_vid_files,
            self.btn_add_script, self.btn_import_script, self.btn_media_pack,
        ):
            b.setEnabled(enabled)
        self._fill_media()
        self._fill_script()
        self._fill_vo()
        self.set_logo(index)

    def _toggle_scenes(self, open_: bool) -> None:
        self.media_list.setVisible(open_)
        self.scene_toggle.setArrowType(Qt.ArrowType.DownArrow if open_ else Qt.ArrowType.RightArrow)

    def _on_preview_batch_ready(self) -> None:
        """Update icons in-place as background thumbnail decoding completes."""
        for r in range(self.media_list.count()):
            item = self.media_list.item(r)
            meta = item.data(Qt.ItemDataRole.UserRole + 2)
            if isinstance(meta, dict):
                item.setIcon(self._preview_cache.icon_for(**meta))

    def _fill_media(self) -> None:
        self.media_list.clear()
        idx = self.index
        if not idx:
            self.scene_toggle.setText("Media Previews")
            return
        if not idx.clips:
            items = [m for m in idx.project.media if isinstance(m, dict) and m.get("filename")]
            self.scene_toggle.setText(f"Uploaded Media · {len(items)}" if items else "Media Previews")
            if items and not self.scene_toggle.isChecked():
                self.scene_toggle.setChecked(True)
            for idx_m, m in enumerate(items, 1):
                path = str(m.get("path") or "")
                ok = bool(path) and Path(path).is_file()
                screen = str(m.get("screen") or idx_m)
                fname = str(m.get("filename") or "")
                ext = Path(fname).suffix.lower()
                kind = "video" if (m.get("kind") == "video" or ext in {".mp4", ".mov", ".webm", ".mkv"}) else "image"
                badge_left = f"#{screen}"
                badge_right = "VID" if kind == "video" else "IMG"
                caption = f"{scene_label(screen, short=True)}\n{fname}" if self._grid_mode else f"{scene_label(screen)} · {fname}"
                item = QListWidgetItem(caption)
                meta = {
                    "path": path,
                    "badge_left": badge_left,
                    "badge_right": badge_right,
                    "dur_text": "",
                    "kind": kind,
                    "ok": ok,
                }
                item.setData(Qt.ItemDataRole.UserRole + 2, meta)
                item.setIcon(self._preview_cache.icon_for(**meta))
                item.setForeground(QColor(theme.INK if ok else theme.MISSING))
                item.setToolTip(path or "Not on this PC")
                if self._grid_mode:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
                self.media_list.addItem(item)
            return

        linked = 0
        for i, c in enumerate(idx.clips):
            path, kind = idx.files[i]
            ok = bool(path)
            linked += ok
            name = Path(path).name if path else str(c.get("filename") or "")
            kind = "video" if (c.get("kind") == "video" or (path and Path(path).suffix.lower() in {".mp4", ".mov", ".webm", ".mkv"})) else "image"
            scr = str(c.get("screen") or (i + 1))
            a, b = float(c.get("start") or 0), float(c.get("end") or 0)
            dur = max(0.0, b - a)
            badge_left = f"S{scr}"
            badge_right = "VID" if kind == "video" else "IMG"
            dur_text = f"{dur:.1f}s" if dur > 0 else ""

            full_title = media_block_label(c, kind=kind, filename=name, short=False)
            short_title = scene_label(scr, short=True)
            if self._grid_mode:
                label_clean = short_title if len(short_title) <= 16 else (short_title[:14] + "…")
                text = label_clean
            else:
                text = f"{full_title}\n{fmt_short(a)} – {fmt_short(b)} ({dur:.1f}s)"

            item = QListWidgetItem(text)
            meta = {
                "path": path,
                "badge_left": badge_left,
                "badge_right": badge_right,
                "dur_text": dur_text,
                "kind": kind,
                "ok": ok,
            }
            item.setData(Qt.ItemDataRole.UserRole + 2, meta)
            item.setIcon(self._preview_cache.icon_for(**meta))
            item.setForeground(QColor(theme.INK if ok else theme.MISSING))
            tip = (
                f"{full_title}\nTime: {fmt_short(a)} – {fmt_short(b)} ({dur:.2f}s)\nFile: {path}"
                if path
                else f"{full_title}\nNot on this PC yet. Use Image Folder / Video Folder or Link Source Folder."
            )
            item.setToolTip(tip)
            item.setData(Qt.ItemDataRole.UserRole, a + 0.01)
            if self._grid_mode:
                item.setTextAlignment(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
            self.media_list.addItem(item)
        self.scene_toggle.setText(f"Previews · {linked}/{len(idx.clips)} linked")

    def _fill_script(self) -> None:
        self.script_list.clear()
        idx = self.index
        if not idx:
            self.script_info.setText("No script loaded.")
            return
        start_of = {str(c.get("screen")): float(c.get("start") or 0) for c in reversed(idx.clips)}
        scenes = idx.project.scenes or []
        for s in scenes:
            screen = str(s.get("screen") or "")
            text = str(s.get("voiceover_text") or s.get("onscreen_text") or "").strip()
            label = scene_label(screen)
            item = QListWidgetItem(f"{label}\n{text[:140]}" if text else label)
            if screen in start_of:
                item.setData(Qt.ItemDataRole.UserRole, start_of[screen] + 0.01)
            item.setToolTip(f"{label}\n{text}" if text else label)
            self.script_list.addItem(item)
        meta = idx.project.script_meta
        name = meta.get("filename") or "script"
        poem = meta.get("poem") if isinstance(meta.get("poem"), dict) else {}
        extra = ""
        if poem.get("has_poem"):
            extra = f" · poem {scene_label(poem.get('first_screen'))}–{scene_label(poem.get('last_screen'))}"
        self.script_info.setText(f"{name} · {len(scenes)} scenes{extra}")

    def set_script_report(self, text: str, ok: bool | None) -> None:
        color = theme.MUTED if ok is None else ("#86efac" if ok else "#fca5a5")
        self.script_format.setStyleSheet(f"color: {color};")
        self.script_format.setText(text)

    def _clear_lay(self, lay: QVBoxLayout) -> None:
        while lay.count():
            it = lay.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
            elif it.layout():
                self._clear_lay(it.layout())  # type: ignore[arg-type]

    def _fill_vo(self) -> None:
        self._clear_lay(self.voice_lay)
        self._clear_lay(self.vo_lay)
        self._populate_voice(self.voice_lay, compact=True)
        self._populate_voice(self.vo_lay, compact=False)

    def _script_has_poem(self, p) -> bool:
        poem = p.script_meta.get("poem") if isinstance(p.script_meta.get("poem"), dict) else {}
        if poem.get("has_poem") or p.plan.get("has_poem") or p.poem_vo:
            return True
        return any(s.get("is_poem") for s in p.scenes)

    def _populate_voice(self, lay: QVBoxLayout, *, compact: bool = False) -> None:
        idx = self.index
        if not idx:
            if not compact:
                lay.addWidget(_muted("Open a project to link narration and the poem."))
                lay.addStretch(1)
            return
        p = idx.project
        slots = p.slots or [{"slot": 1, "filename": p.voiceover.get("filename") or ""}]
        used = {int(s.get("slot") or 1) for s in slots}
        nxt = next((n for n in range(1, 11) if n not in used), None)
        has_poem = self._script_has_poem(p)
        poem_slots = (p.poem_slots() or [{"slot": 1, "filename": ""}]) if has_poem else []
        used_poem = {int(s.get("slot") or 1) for s in poem_slots}
        nxt_poem = next((n for n in range(1, 11) if n not in used_poem), None) if has_poem else None
        btn_h = 24 if compact else 28

        # Header row: Narration VO title + (+ VO N) (+ Poem N when compact)
        hdr = QWidget()
        hl = QHBoxLayout(hdr)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setSpacing(4)
        hl.addWidget(_title("Audio & VO Links" if compact and has_poem else "Narration VO"), 1)
        if nxt is not None:
            add_btn = QPushButton(f"+ VO {nxt}" if compact else f"+ Add VO {nxt}")
            add_btn.setObjectName("Pill")
            add_btn.setFixedHeight(21 if compact else 24)
            add_btn.setToolTip(
                "Up to 10 narration files. VO 1 … VO 10 play one after another, "
                "with a 0.5 s gap, and Auto-align locks the pictures to that run."
            )
            add_btn.clicked.connect(lambda _=False, k=nxt: self.narration_vo.emit(k))
            hl.addWidget(add_btn)
        if compact and has_poem and nxt_poem is not None:
            add_p_top = QPushButton(f"+ Poem {nxt_poem}")
            add_p_top.setObjectName("Pill")
            add_p_top.setFixedHeight(21)
            add_p_top.setToolTip("Up to 10 poem files. They play in order with a 0.5 s gap.")
            add_p_top.clicked.connect(lambda _=False, k=nxt_poem: self.poem_vo.emit(k))
            hl.addWidget(add_p_top)
        lay.addWidget(hdr)

        if not compact:
            tip = _muted("Click any VO button below to link/replace its audio file, or ⬇ to save a copy.")
            tip.setToolTip(
                "Download saves the full narration file. Replace swaps that library file. "
                "Right-click one voice block on the timeline to download/replace only that section."
            )
            lay.addWidget(tip)

        for sl in slots:
            n = int(sl.get("slot") or 1)
            path = idx.slot_file(n)
            dur = num(sl.get("duration"))
            fname = str(sl.get("filename") or "").strip()
            if path and not fname:
                fname = Path(path).name
            dur_str = f" · {fmt_short(dur).split('.')[0]}" if dur else ""

            w = QWidget()
            row = QHBoxLayout(w)
            row.setContentsMargins(0, 0, 0, 0)
            row.setSpacing(4)

            if path:
                short_fn = fname if len(fname) <= 17 else (fname[:14] + "…")
                btn_text = f"VO {n} · {short_fn}{dur_str}"
                vo_btn = QPushButton(btn_text)
                theme.set_btn_neon_icon(vo_btn, "mic", "#22d3ee", 14)
                vo_btn.setObjectName("VoLinkBtn")
                vo_btn.setToolTip(f"Linked: {path}\nClick to replace Narration VO {n}")
            else:
                vo_btn = QPushButton(f"Link Narration VO {n}…")
                theme.set_btn_neon_icon(vo_btn, "mic", "#f472b6", 14)
                vo_btn.setObjectName("VoLinkMissing")
                vo_btn.setToolTip(f"Click to link Narration VO {n} (.mp3 / .wav / .m4a)")
            vo_btn.setFixedHeight(btn_h)
            vo_btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            vo_btn.clicked.connect(lambda _=False, k=n: self.narration_vo.emit(k))
            row.addWidget(vo_btn, 1)

            if path:
                dl = QPushButton("")
                theme.set_btn_neon_icon(dl, "download", "#38bdf8", 14)
                dl.setObjectName("IconSquare")
                dl.setFixedSize(btn_h, btn_h)
                dl.setToolTip(f"Save VO {n} ({fname}) to a folder")
                dl.clicked.connect(lambda _=False, k=n: self.download_vo.emit(k))
                row.addWidget(dl)

            if n > 1:
                x = QPushButton("")
                theme.set_btn_neon_icon(x, "close", "#fb7185", 13)
                x.setObjectName("IconSquare")
                x.setFixedSize(btn_h, btn_h)
                x.setToolTip(f"Remove VO {n} from this chapter")
                x.clicked.connect(lambda _=False, k=n: self.remove_vo.emit(k))
                row.addWidget(x)
            elif path:
                rep = QPushButton("")
                theme.set_btn_neon_icon(rep, "swap", "#c084fc", 14)
                rep.setObjectName("IconSquare")
                rep.setFixedSize(btn_h, btn_h)
                rep.setToolTip(f"Replace VO {n} file (timeline voice blocks stay)")
                rep.clicked.connect(lambda _=False, k=n: self.narration_vo.emit(k))
                row.addWidget(rep)
            lay.addWidget(w)

        if has_poem:
            if not compact:
                p_hdr = QWidget()
                phl = QHBoxLayout(p_hdr)
                phl.setContentsMargins(0, 1, 0, 0)
                phl.setSpacing(6)
                phl.addWidget(_title("Poem VO"), 1)
                if nxt_poem is not None:
                    add_p = QPushButton(f"+ Add Poem {nxt_poem}")
                    add_p.setObjectName("Pill")
                    add_p.setFixedHeight(22)
                    add_p.setToolTip("Up to 10 poem files. They play in order with a 0.5 s gap.")
                    add_p.clicked.connect(lambda _=False, k=nxt_poem: self.poem_vo.emit(k))
                    phl.addWidget(add_p)
                lay.addWidget(p_hdr)

            for sl in poem_slots:
                n = int(sl.get("slot") or 1)
                path = p.poem_slot_path(n)
                dur = num(sl.get("duration"))
                fname = str(sl.get("filename") or "").strip()
                if path and not fname:
                    fname = Path(path).name
                dur_str = f" · {fmt_short(dur).split('.')[0]}" if dur else ""

                w = QWidget()
                row = QHBoxLayout(w)
                row.setContentsMargins(0, 0, 0, 0)
                row.setSpacing(4)

                if path:
                    short_fn = fname if len(fname) <= 15 else (fname[:12] + "…")
                    p_btn = QPushButton(f"Poem {n} · {short_fn}{dur_str}")
                    theme.set_btn_neon_icon(p_btn, "music", "#e879f9", 14)
                    p_btn.setObjectName("VoLinkBtn")
                    p_btn.setToolTip(f"Linked Poem {n}: {path}\nClick to replace Poem {n}")
                else:
                    p_btn = QPushButton(f"Link Poem VO {n}…")
                    theme.set_btn_neon_icon(p_btn, "music", "#f472b6", 14)
                    p_btn.setObjectName("VoLinkMissing")
                    p_btn.setToolTip("The script has a poem. Click to link the poem audio file.")
                p_btn.setFixedHeight(btn_h)
                p_btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
                p_btn.clicked.connect(lambda _=False, k=n: self.poem_vo.emit(k))
                row.addWidget(p_btn, 1)

                if path:
                    dl = QPushButton("")
                    theme.set_btn_neon_icon(dl, "download", "#38bdf8", 14)
                    dl.setObjectName("IconSquare")
                    dl.setFixedSize(btn_h, btn_h)
                    dl.setToolTip(f"Save Poem {n} so you can edit it, then Replace…")
                    dl.clicked.connect(lambda _=False, k=n: self.download_poem.emit(k))
                    row.addWidget(dl)

                if len(poem_slots) > 1 or n > 1:
                    x = QPushButton("")
                    theme.set_btn_neon_icon(x, "close", "#fb7185", 13)
                    x.setObjectName("IconSquare")
                    x.setFixedSize(btn_h, btn_h)
                    x.setToolTip(f"Remove Poem {n} from this chapter")
                    x.clicked.connect(lambda _=False, k=n: self.remove_poem.emit(k))
                    row.addWidget(x)
                elif path:
                    rep = QPushButton("")
                    theme.set_btn_neon_icon(rep, "swap", "#c084fc", 14)
                    rep.setObjectName("IconSquare")
                    rep.setFixedSize(btn_h, btn_h)
                    rep.setToolTip(f"Replace Poem {n} audio file")
                    rep.clicked.connect(lambda _=False, k=n: self.poem_vo.emit(k))
                    row.addWidget(rep)
                lay.addWidget(w)

            if not compact:
                if idx.has_poem:
                    lay.addWidget(_muted(f"Poem window {fmt_short(idx.poem_start)} – {fmt_short(idx.poem_end)}. Narration is silent while the song plays."))
                else:
                    lay.addWidget(_muted("The script has a poem. Link the poem voice, then Auto-align locks the lyric."))
        if not compact:
            lay.addStretch(1)

    def set_logo(self, index: PlanIndex | None) -> None:
        on = bool(index and index.project.logo_enabled)
        self.logo_pill.blockSignals(True)
        self.logo_pill.setChecked(on)
        self.logo_pill.setText("ON" if on else "OFF")
        self.logo_pill.blockSignals(False)
        self.logo_pill.setEnabled(index is not None)
        if not index:
            self.logo_readout.setText("")
            self.logo_thumb.clear()
            return
        f = index.project.logo_file()
        pix = QPixmap(f) if f else QPixmap()
        if not pix.isNull():
            dpr = max(2.0, float(self.devicePixelRatioF()))
            scaled = pix.scaled(
                int(round(62 * dpr)),
                int(round(20 * dpr)),
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            scaled.setDevicePixelRatio(dpr)
            self.logo_thumb.setPixmap(scaled)
        t = index.project.logo_transform
        self.logo_readout.setText(f"Scale {t['scale_w']:.1f}% · Pos {t['pos_x']:.0f}, {t['pos_y']:.0f}")
        self.logo_readout.setToolTip(
            f"Scale {t['scale_w']:.1f}% · Pos {t['pos_x']:.0f}, {t['pos_y']:.0f}\n"
            f"Anchor {t['anchor_x']:.0f}, {t['anchor_y']:.0f} · Rot {t['rotate']:.0f}°"
        )


class SpecsPanel(QFrame):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Panel")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)
        lay.addWidget(_title("Project Specs"))

        # Cosmic Neon KPI Cards (inspired by the Planfix cosmic dashboard reference)
        kpi_grid = QGridLayout()
        kpi_grid.setContentsMargins(0, 0, 0, 0)
        kpi_grid.setSpacing(6)
        kpi_grid.setColumnStretch(0, 1)
        kpi_grid.setColumnStretch(1, 1)
        self._kpi_vals: dict[str, QLabel] = {}
        kpis = [
            ("scenes", "SCENES", "0", "SpecCardPink"),
            ("duration", "DURATION", "00:00", "SpecCardAmber"),
            ("format", "OUTPUT HD", "1080p", "SpecCardCyan"),
            ("engine", "ENGINE", "—", "SpecCardPurple"),
        ]
        for idx_k, (key, label, default_val, card_id) in enumerate(kpis):
            card = QFrame()
            card.setObjectName(card_id)
            cl = QVBoxLayout(card)
            cl.setContentsMargins(8, 6, 8, 6)
            cl.setSpacing(1)
            big = QLabel(default_val)
            big.setAlignment(Qt.AlignmentFlag.AlignCenter)
            big.setStyleSheet("font-size: 15px; font-weight: 800; color: #ffffff;")
            sub = QLabel(label)
            sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
            sub.setStyleSheet("font-size: 9px; font-weight: 700; color: rgba(248,242,252,0.72); letter-spacing: 0.5px;")
            cl.addWidget(big)
            cl.addWidget(sub)
            self._kpi_vals[key] = big
            kpi_grid.addWidget(card, idx_k // 2, idx_k % 2)
        lay.addLayout(kpi_grid)

        self._vals: dict[str, QLabel] = {}
        grid = QGridLayout()
        grid.setVerticalSpacing(6)
        grid.setHorizontalSpacing(8)
        rows = ["Name", "Resolution", "Frame Rate", "Color Space", "Sample Rate", "Duration", "Scenes", "Narration", "Language"]
        for i, key in enumerate(rows):
            k = QLabel(key)
            k.setObjectName("SpecKey")
            v = QLabel("—")
            v.setObjectName("SpecVal")
            v.setWordWrap(True)
            v.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            grid.addWidget(k, i, 0, Qt.AlignmentFlag.AlignTop)
            grid.addWidget(v, i, 1)
            self._vals[key] = v
        grid.setColumnStretch(1, 1)
        lay.addLayout(grid)
        lay.addSpacing(4)
        lay.addWidget(_title("Sync"))
        self.sync = _muted("—")
        self.sync.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(self.sync)
        lay.addStretch(1)

    def set_index(self, index: PlanIndex | None) -> None:
        v = self._vals
        v["Resolution"].setText("1920 × 1080")
        v["Frame Rate"].setText("30 fps")
        v["Color Space"].setText("SDR - Rec.709")
        v["Sample Rate"].setText("44100 Hz")
        if not index:
            for k in ("Name", "Duration", "Scenes", "Narration", "Language"):
                v[k].setText("—")
            self._kpi_vals["scenes"].setText("0")
            self._kpi_vals["duration"].setText("00:00")
            self._kpi_vals["engine"].setText("—")
            self.sync.setText("—")
            return
        p = index.project
        v["Name"].setText(p.title.replace("_", "_\u200b"))
        v["Name"].setToolTip(p.title)
        v["Duration"].setText(fmt_short(index.duration))
        v["Scenes"].setText(str(len(index.clips)))
        slots = p.slots
        if slots:
            v["Narration"].setText(f"{len(slots)} VO file{'s' if len(slots) != 1 else ''}" + (" + Poem" if index.has_poem else ""))
        else:
            v["Narration"].setText("Poem only" if index.has_poem else "None")
        lang = str(p.plan.get("language") or "")
        lang_label = {"mr": "Marathi", "en": "English", "hi": "Hindi"}.get(lang, lang or "English")
        v["Language"].setText(lang_label)

        self._kpi_vals["scenes"].setText(str(len(index.clips)))
        self._kpi_vals["duration"].setText(fmt_short(index.duration).split(".")[0])
        self._kpi_vals["engine"].setText(lang_label[:3].upper())

        rep = p.plan.get("sync_report")
        if isinstance(rep, dict):
            text = str(rep.get("summary") or rep.get("message") or "")
        else:
            text = str(rep or "")
        self.sync.setText(text or str(p.plan.get("align_note") or "Not checked yet"))


class RightPanel(QFrame):
    jump_to = Signal(float)
    ignored_changed = Signal(list)
    read_cards = Signal()
    undo_swaps = Signal()
    flags_changed = Signal(dict)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Panel")
        self.index: PlanIndex | None = None
        self.card_issues: list[dict] = []
        self._last_clip = -2
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(6)

        self.align_box = QWidget()
        al = QVBoxLayout(self.align_box)
        al.setContentsMargins(0, 0, 0, 0)
        al.setSpacing(4)
        al.addWidget(_title("Live Scene & VO Alignment"))
        self.live_scene = QLabel("—")
        self.live_scene.setStyleSheet("font-size: 13px; font-weight: 700; color: #ffffff;")
        al.addWidget(self.live_scene)
        self.live_times = _muted()
        al.addWidget(self.live_times)
        self.live_heard = _muted()
        al.addWidget(self.live_heard)
        self.live_text = QLabel()
        self.live_text.setWordWrap(True)
        self.live_text.setStyleSheet(
            "background: rgba(8, 5, 18, 0.55); border: 1px solid rgba(192, 132, 252, 0.20); "
            "border-radius: 8px; padding: 6px; font-family: 'Nirmala UI';"
        )
        self.live_text.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        al.addWidget(self.live_text)
        lay.addWidget(self.align_box)

        lay.addWidget(_title("Scene Alignment Queue"))
        self.queue = QListWidget()
        self.queue.itemClicked.connect(self._jump_item)
        lay.addWidget(self.queue, 3)

        qa_top = QHBoxLayout()
        qa_top.setContentsMargins(0, 2, 0, 0)
        qa_top.setSpacing(6)
        self.qa_title = _title("QA Inspector")
        qa_top.addWidget(self.qa_title, 1)
        self.btn_undo_swaps = QPushButton("Undo Swaps")
        theme.set_btn_neon_icon(self.btn_undo_swaps, "undo", "#fbbf24", 14)
        self.btn_undo_swaps.setObjectName("Pill")
        self.btn_undo_swaps.setFixedHeight(26)
        self.btn_undo_swaps.setToolTip("Put back the pictures the card match swapped")
        self.btn_undo_swaps.clicked.connect(self.undo_swaps.emit)
        self.btn_undo_swaps.setVisible(False)
        qa_top.addWidget(self.btn_undo_swaps)
        self.btn_read_cards = QPushButton("Read Cards (OCR)")
        theme.set_btn_neon_icon(self.btn_read_cards, "scan", "#22d3ee", 14)
        self.btn_read_cards.setObjectName("Accent")
        self.btn_read_cards.setFixedHeight(28)
        self.btn_read_cards.setToolTip(
            "Read the text on every picture (English or Marathi) and compare it with the script.\n"
            "Clear-cut wrong pictures are swapped automatically; every swap is listed in the status line."
        )
        self.btn_read_cards.clicked.connect(self.read_cards.emit)
        qa_top.addWidget(self.btn_read_cards)
        lay.addLayout(qa_top)

        self.cards_status = _muted()
        self.cards_status.setVisible(False)
        lay.addWidget(self.cards_status)

        # Single aligned 3-button QA action row
        qa_head = QHBoxLayout()
        qa_head.setContentsMargins(0, 0, 0, 0)
        qa_head.setSpacing(5)
        self.btn_ignore = QPushButton("Ignore Selected")
        theme.set_btn_neon_icon(self.btn_ignore, "check", "#38bdf8", 13)
        self.btn_ignore.setObjectName("Pill")
        self.btn_ignore.setFixedHeight(28)
        self.btn_ignore.clicked.connect(self._ignore_selected)
        self.btn_ignore_all = QPushButton("Ignore All")
        theme.set_btn_neon_icon(self.btn_ignore_all, "check", "#22d3ee", 13)
        self.btn_ignore_all.setObjectName("Pill")
        self.btn_ignore_all.setFixedHeight(28)
        self.btn_ignore_all.clicked.connect(self._ignore_all)
        self.btn_restore = QPushButton("Restore")
        theme.set_btn_neon_icon(self.btn_restore, "refresh", "#c084fc", 13)
        self.btn_restore.setObjectName("Pill")
        self.btn_restore.setFixedHeight(28)
        self.btn_restore.clicked.connect(self._restore)
        qa_head.addWidget(self.btn_ignore, 1)
        qa_head.addWidget(self.btn_ignore_all, 1)
        qa_head.addWidget(self.btn_restore, 1)
        lay.addLayout(qa_head)

        self.qa_list = QListWidget()
        self.qa_list.setWordWrap(True)
        self.qa_list.itemClicked.connect(self._jump_item)
        lay.addWidget(self.qa_list, 2)

    def _jump_item(self, item: QListWidgetItem) -> None:
        t = item.data(Qt.ItemDataRole.UserRole)
        if isinstance(t, (int, float)):
            self.jump_to.emit(float(t))

    def set_index(self, index: PlanIndex | None) -> None:
        self.index = index
        self._last_clip = -2
        self.queue.clear()
        if index:
            for i, c in enumerate(index.clips):
                path = index.files[i][0] if i < len(index.files) else ""
                kind = "video" if c.get("kind") == "video" else "image"
                title = media_block_label(c, kind=kind, filename=Path(path).name if path else "", short=False)
                text = str(c.get("vo_text") or c.get("caption_text") or c.get("script_text") or "").replace("\n", " ")
                item = QListWidgetItem(f"{title}  {fmt_short(c.get('start'))}–{fmt_short(c.get('end'))}\n{text[:90]}")
                item.setToolTip(f"{title}\n{text}" if text else title)
                item.setData(Qt.ItemDataRole.UserRole, float(c.get("start") or 0) + 0.01)
                self.queue.addItem(item)
        self._fill_qa()
        self.update_time(0.0)

    def _ignored(self) -> list[str]:
        if not self.index:
            return []
        keys = self.index.project.plan.get("ignored_qa_keys")
        return [str(k) for k in keys] if isinstance(keys, list) else []

    def set_card_issues(self, issues: list[dict]) -> None:
        self.card_issues = list(issues)
        self._fill_qa()

    def set_cards_status(self, text: str) -> None:
        self.cards_status.setText(text)
        self.cards_status.setVisible(bool(text))

    def _fill_qa(self) -> None:
        self.qa_list.clear()
        self.btn_read_cards.setEnabled(self.index is not None)
        if not self.index:
            self.qa_title.setText("QA 💭")
            for b in (self.btn_ignore_all, self.btn_restore, self.btn_ignore):
                b.setEnabled(False)
            self.flags_changed.emit({})
            return
        ignored = set(self._ignored())
        stored = [
            i for i in (self.index.project.plan.get("qa_issues") or [])
            if isinstance(i, dict) and not poem_clock_false_sync(i, self.index.project.plan)
        ]
        # Saved OCR card bubbles are replaced by the fresh reading.
        if self.card_issues:
            stored = [i for i in stored if i.get("kind") != "card_text"]
        issues = sorted(stored + self.card_issues, key=lambda i: float(i.get("time") or 0))
        shown = [i for i in issues if qa_key(i) not in ignored]
        flags: dict[str, str] = {}
        for i in shown:
            scr = str(i.get("screen") or "")
            if scr and flags.get(scr) != "error":
                flags[scr] = "error" if i.get("severity") == "error" else "warning"
        self.flags_changed.emit(flags)
        for i in shown:
            sev = str(i.get("severity") or "warning")
            item = QListWidgetItem(f"{'⛔' if sev == 'error' else '💭'} {i.get('message') or ''}")
            item.setForeground(QColor("#fca5a5" if sev == "error" else "#fde68a"))
            item.setData(Qt.ItemDataRole.UserRole, float(i.get("time") or 0) + 0.01)
            item.setData(Qt.ItemDataRole.UserRole + 1, qa_key(i))
            tip = "\n".join(x for x in (str(i.get("expected") or ""), str(i.get("found") or "")) if x)
            item.setToolTip(tip)
            self.qa_list.addItem(item)
        n_ign = len([i for i in issues if qa_key(i) in ignored])
        self.qa_title.setText(f"QA Inspector ({len(shown)})")
        self.btn_ignore_all.setText(f"All ({len(shown)})")
        self.btn_ignore_all.setEnabled(bool(shown))
        self.btn_restore.setText(f"Restore ({n_ign})")
        self.btn_restore.setEnabled(n_ign > 0)
        self.btn_ignore.setEnabled(bool(shown))

    def _set_ignored(self, keys: list[str]) -> None:
        if not self.index:
            return
        self.index.project.plan["ignored_qa_keys"] = keys
        self.index.project.dirty = True
        self._fill_qa()
        self.ignored_changed.emit(keys)

    def _ignore_selected(self) -> None:
        item = self.qa_list.currentItem()
        if item is None:
            return
        keys = self._ignored()
        k = item.data(Qt.ItemDataRole.UserRole + 1)
        if k and k not in keys:
            self._set_ignored(keys + [k])

    def _ignore_all(self) -> None:
        keys = self._ignored()
        for r in range(self.qa_list.count()):
            k = self.qa_list.item(r).data(Qt.ItemDataRole.UserRole + 1)
            if k and k not in keys:
                keys.append(k)
        self._set_ignored(keys)

    def _restore(self) -> None:
        self._set_ignored([])

    def update_time(self, t: float) -> None:
        idx = self.index
        if not idx:
            self.live_scene.setText("—")
            self.live_times.setText("")
            self.live_heard.setText("")
            self.live_text.setText("")
            return
        i = idx.clip_index_at(t)
        heard = idx.heard_at(t)
        if heard:
            src = "Poem" if heard.kind == "poem" else f"VO {heard.slot}"
            self.live_heard.setText(f"Hearing {src} at {fmt_short(heard.offset)} in {Path(heard.path).name}")
        elif idx.in_poem(t):
            self.live_heard.setText("Poem window · poem file not linked on this PC")
        else:
            merged = idx.merged_narration_time(t)
            self.live_heard.setText("Silence" if merged is None else "Narration file not linked on this PC")
        if i == self._last_clip:
            return
        self._last_clip = i
        if i < 0:
            self.live_scene.setText("Gap")
            self.live_times.setText("")
            self.live_text.setText("")
            return
        c = idx.clips[i]
        ni, no = num(c.get("narration_in")), num(c.get("narration_out"))
        vo = f" · VO {fmt_short(ni)}–{fmt_short(no)}" if ni is not None and no is not None else ""
        path = idx.files[i][0] if idx.files[i][0] else ""
        kind = "video" if c.get("kind") == "video" else "image"
        title = media_block_label(c, kind=kind, filename=Path(path).name if path else "", short=False)
        self.live_scene.setText(title if path else f"{title} · picture missing")
        self.live_times.setText(f"Picture {fmt_short(c.get('start'))}–{fmt_short(c.get('end'))}{vo} · fit {c.get('fit') or 'hold'}")
        self.live_text.setText(str(c.get("vo_text") or c.get("script_text") or ""))
        if self.queue.count() > i:
            self.queue.blockSignals(True)
            self.queue.setCurrentRow(i)
            self.queue.scrollToItem(self.queue.item(i))
            self.queue.blockSignals(False)

    def select_clip(self, i: int) -> None:
        self._last_clip = -2
        if self.queue.count() > i >= 0:
            self.queue.setCurrentRow(i)
