"""Timeline dock: track headers with their toggles, painted lanes, zoom.

Lanes are painted into a cached pixmap. Only the playhead is drawn on each
tick, so playback never rebuilds the tracks.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from PySide6.QtCore import QObject, QPointF, QRectF, QRunnable, QSize, Qt, QThreadPool, Signal
from PySide6.QtGui import QBrush, QColor, QFont, QFontMetrics, QImage, QImageReader, QLinearGradient, QPainter, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QScrollBar,
    QSlider,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from .. import theme
from ..core.plan import PlanIndex, fmt_short, media_block_label, scene_label, vo_block_label

RULER_H = 24
LANE_H = 36
HEADER_W = 156
VO_COLORS = [("#ff8a65", "#ff5c6c"), ("#38bdf8", "#0ea5e9"), ("#34d399", "#10b981"), ("#fbbf24", "#f59e0b")]


@dataclass
class Row:
    key: str  # logo | video | script | vo | poem
    label: str
    slot: int = 0


def build_rows(index: PlanIndex | None) -> list[Row]:
    if index is None:
        return [Row("video", "Video 1"), Row("script", "Script"), Row("vo", "Audio · VO")]
    p = index.project
    rows: list[Row] = []
    if p.logo_enabled:
        rows.append(Row("logo", "Video 2 · Logo"))
    rows += [Row("video", "Video 1"), Row("script", "Script")]
    slots = [int(s.get("slot") or 1) for s in (p.plan.get("voiceover_slots") or []) if float(s.get("end") or 0) > float(s.get("start") or 0) + 0.05]
    if len(slots) >= 2:
        rows += [Row("vo", f"Audio · VO {n}", n) for n in slots]
    else:
        rows.append(Row("vo", "Audio · VO"))
    if index.has_poem:
        rows.append(Row("poem", "Audio · Poem"))
    return rows


# Thumbnails ----------------------------------------------------------------


def _file_stamp(path: str) -> int:
    try:
        return os.stat(path).st_mtime_ns
    except OSError:
        return 0


class _ThumbSignals(QObject):
    # stamp is st_mtime_ns — too large for a 32-bit Qt int on Windows.
    done = Signal(str, object, QImage)


class _ThumbJob(QRunnable):
    def __init__(self, path: str, stamp: int, height: int, signals: _ThumbSignals) -> None:
        super().__init__()
        self.path, self.stamp, self.height, self.signals = path, stamp, height, signals

    def run(self) -> None:
        reader = QImageReader(self.path)
        reader.setAutoTransform(True)
        size = reader.size()
        if size.isValid() and size.height() > 0:
            w = max(1, round(size.width() * self.height / size.height()))
            reader.setScaledSize(QSize(w, self.height))
        img = reader.read()
        self.signals.done.emit(self.path, self.stamp, img)


class ThumbCache(QObject):
    changed = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._pix: dict[str, tuple[int, QPixmap | None]] = {}
        self._pool = QThreadPool(self)
        self._pool.setMaxThreadCount(2)
        self._sig = _ThumbSignals()
        self._sig.done.connect(self._on_done)

    def get(self, path: str) -> QPixmap | None:
        if not path:
            return None
        stamp = _file_stamp(path)
        cached = self._pix.get(path)
        if cached and cached[0] == stamp:
            return cached[1]
        self._pix[path] = (stamp, None)
        self._pool.start(_ThumbJob(path, stamp, (LANE_H - 10) * 2, self._sig))
        return None

    def clear(self) -> None:
        self._pix.clear()
        self.changed.emit()

    def stop(self) -> None:
        self._pool.clear()
        self._pool.waitForDone(3000)

    def _on_done(self, path: str, stamp: int, img: QImage) -> None:
        if self._pix.get(path, (None, None))[0] != stamp or img.isNull():
            return
        self._pix[path] = (stamp, QPixmap.fromImage(img))
        self.changed.emit()


# Canvas ----------------------------------------------------------------------


class TimelineCanvas(QWidget):
    seek_requested = Signal(float)
    clip_selected = Signal(int)
    vo_selected = Signal(str)
    clip_menu = Signal(int, object)
    vo_menu = Signal(str, object)
    clip_resized = Signal(int, float, float)
    vo_trimmed = Signal(str, str, float)
    scroll_changed = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.index: PlanIndex | None = None
        self.rows: list[Row] = build_rows(None)
        self.px = 12.0
        self.scroll = 0.0
        self.playhead = 0.0
        self.selected_clip = -1
        self.selected_vo = ""
        self.follow = True
        self._cache: QPixmap | None = None
        self._scrubbing = False
        self._drag = None
        self._vo_pieces: list[dict] = []
        self.flags: dict[str, str] = {}
        self.thumbs = ThumbCache(self)
        self.thumbs.changed.connect(self.invalidate)
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self._fit_height()

    # Data ------------------------------------------------------------------

    def set_index(self, index: PlanIndex | None) -> None:
        keep_clip, keep_vo = self.selected_clip, self.selected_vo
        self.index = index
        self.rows = build_rows(index)
        self._vo_pieces = index.vo_pieces() if index else []
        n = len(index.clips) if index else 0
        self.selected_clip = keep_clip if 0 <= keep_clip < n else -1
        self.selected_vo = keep_vo if any(str(p.get("id") or "") == keep_vo for p in self._vo_pieces) else ""
        self._fit_height()
        self.invalidate()

    def set_flags(self, flags: dict[str, str]) -> None:
        """Screens with a visible QA issue (screen -> severity) get a 💭 dot on Video 1."""
        if flags != self.flags:
            self.flags = dict(flags)
            self.invalidate()

    def _fit_height(self) -> None:
        self.setFixedHeight(RULER_H + LANE_H * len(self.rows) + 2)

    @property
    def duration(self) -> float:
        return self.index.duration if self.index else 0.0

    def content_width(self) -> float:
        return max(self.width(), self.duration * self.px + 80)

    def set_px(self, px: float, anchor_x: float | None = None) -> None:
        px = max(2.0, min(120.0, px))
        if abs(px - self.px) < 1e-6:
            return
        ax = self.width() / 2 if anchor_x is None else anchor_x
        t = (ax + self.scroll) / self.px
        self.px = px
        self.set_scroll(t * px - ax)

    def set_scroll(self, s: float) -> None:
        s = max(0.0, min(s, max(0.0, self.content_width() - self.width())))
        if abs(s - self.scroll) > 0.1:
            self.scroll = s
            self.scroll_changed.emit()
        self.invalidate()

    def invalidate(self) -> None:
        self._cache = None
        self.update()

    def set_playhead(self, t: float, playing: bool) -> None:
        old_x = self.playhead * self.px - self.scroll
        self.playhead = t
        x = t * self.px - self.scroll
        if self.follow and (x > self.width() - 30 or x < 0) and not self._scrubbing:
            self.set_scroll(t * self.px - (self.width() * 0.15 if playing else self.width() * 0.4))
            return
        lo, hi = int(min(old_x, x)) - 40, int(max(old_x, x)) + 60
        self.update(lo, 0, hi - lo, self.height())

    def rows_y(self) -> list[int]:
        return [RULER_H + i * LANE_H for i in range(len(self.rows))]

    # Painting --------------------------------------------------------------

    def resizeEvent(self, e) -> None:  # noqa: N802
        self._cache = None
        super().resizeEvent(e)

    def paintEvent(self, _e) -> None:  # noqa: N802
        if self._cache is None or self._cache.size() != self.size() * self.devicePixelRatioF():
            self._cache = self._render_lanes()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        p.drawPixmap(0, 0, self._cache)
        x = self.playhead * self.px - self.scroll
        if -10 <= x <= self.width() + 10:
            color = QColor(theme.PLAYHEAD)
            p.setPen(QPen(QColor(255, 255, 255, 90), 4))
            p.drawLine(int(x), 0, int(x), self.height())
            p.setPen(QPen(color, 2))
            p.drawLine(int(x), 0, int(x), self.height())
            p.setBrush(color)
            p.setPen(Qt.PenStyle.NoPen)
            p.drawPolygon(QPolygonF([QPointF(x - 6, 0), QPointF(x + 6, 0), QPointF(x, 8)]))
        p.end()

    def _render_lanes(self) -> QPixmap:
        dpr = self.devicePixelRatioF()
        pix = QPixmap(self.size() * dpr)
        pix.setDevicePixelRatio(dpr)
        pix.fill(QColor(10, 7, 12))
        p = QPainter(pix)
        p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        p.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        w = self.width()
        p.fillRect(0, 0, w, RULER_H, QColor(0, 0, 0, 72))
        self._paint_ruler(p)
        for row, y in zip(self.rows, self.rows_y()):
            p.setPen(QColor(255, 255, 255, 13))
            p.drawLine(0, y + LANE_H - 1, w, y + LANE_H - 1)
            off = self._row_off(row)
            if row.key == "logo":
                self._paint_logo(p, y)
            elif row.key == "video":
                self._paint_video(p, y)
            elif row.key == "script":
                self._paint_script(p, y)
            elif row.key == "vo":
                self._paint_vo(p, y, row.slot)
            elif row.key == "poem":
                self._paint_poem(p, y)
            if self._row_locked(row):
                p.save()
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(QColor(251, 191, 36, 18), Qt.BrushStyle.BDiagPattern))
                p.drawRect(0, y, w, LANE_H - 1)
                p.restore()
            if off:
                p.fillRect(0, y, w, LANE_H - 1, QColor(10, 7, 12, 165))
        p.end()
        return pix

    def _row_off(self, row: Row) -> bool:
        if not self.index:
            return False
        pl = self.index.project.plan
        return bool({"video": pl.get("video_track_hidden"), "script": pl.get("script_track_hidden"),
                     "vo": pl.get("vo_muted"), "poem": pl.get("poem_muted")}.get(row.key))

    def _row_locked(self, row: Row) -> bool:
        if not self.index:
            return False
        pl = self.index.project.plan
        return bool({"video": pl.get("video_track_locked"), "vo": pl.get("vo_track_locked"),
                     "poem": pl.get("poem_track_locked")}.get(row.key))

    def _x(self, t: float) -> float:
        return t * self.px - self.scroll

    def _visible(self, a: float, b: float) -> bool:
        return self._x(b) >= -2 and self._x(a) <= self.width() + 2

    def _paint_ruler(self, p: QPainter) -> None:
        step = 1.0
        for s in (1, 2, 5, 10, 15, 30, 60, 120, 300):
            if s * self.px >= 70:
                step = s
                break
        else:
            step = 600
        t0 = int(self.scroll / self.px / step) * step
        font = QFont("Segoe UI")
        font.setPixelSize(10)
        p.setFont(font)
        t = t0
        while self._x(t) < self.width():
            x = self._x(t)
            p.setPen(QColor(255, 255, 255, 60))
            p.drawLine(int(x), RULER_H - 7, int(x), RULER_H)
            p.setPen(QColor(theme.MUTED))
            p.drawText(int(x) + 4, 15, fmt_short(t)[:-3] if step >= 1 else fmt_short(t))
            t += step
        p.setPen(QColor(255, 255, 255, 30))
        p.drawLine(0, RULER_H - 1, self.width(), RULER_H - 1)

    def _block(self, p: QPainter, y: int, a: float, b: float, c1: str, c2: str, label: str,
               selected: bool = False, thumb: QPixmap | None = None, striped: bool = False, min_w: float = 2) -> None:
        x = self._x(a)
        w = max(min_w, (b - a) * self.px)
        rect = QRectF(x + 0.5, y + 4, max(1.0, w - 1.5), LANE_H - 9)
        if striped:
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(QColor(30, 30, 36, 230))
            p.drawRoundedRect(rect, 6, 6)
            p.setBrush(QBrush(QColor(239, 68, 68, 90), Qt.BrushStyle.BDiagPattern))
            p.drawRoundedRect(rect, 6, 6)
        else:
            g = QLinearGradient(rect.topLeft(), rect.bottomRight())
            g.setColorAt(0, QColor(c1))
            g.setColorAt(1, QColor(c2))
            p.setPen(Qt.PenStyle.NoPen)
            p.setBrush(g)
            p.drawRoundedRect(rect, 6, 6)
        text_x = rect.left() + 6
        if thumb is not None and rect.width() > thumb.width() + 10:
            p.drawPixmap(int(rect.left() + 3), int(rect.top() + 1), thumb)
            text_x += thumb.width() + 2
        if selected:
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.setPen(QPen(QColor("#ffffff"), 2))
            p.drawRoundedRect(rect.adjusted(1, 1, -1, -1), 6, 6)
        room = rect.right() - text_x - 4
        if room > 14 and label:
            font = QFont("Segoe UI")
            font.setPixelSize(10)
            font.setWeight(QFont.Weight.DemiBold)
            p.setFont(font)
            p.setPen(QColor("#ffffff"))
            text = QFontMetrics(font).elidedText(label, Qt.TextElideMode.ElideRight, int(room))
            p.drawText(QRectF(text_x, rect.top(), room, rect.height()), Qt.AlignmentFlag.AlignVCenter, text)

    def _paint_logo(self, p: QPainter, y: int) -> None:
        if not self.index:
            return
        scale = self.index.project.logo_transform.get("scale_w", 10)
        self._block(p, y, 0, max(self.duration, 40 / self.px), "#1cd6b0", "#0ea5e9",
                    f"Brand Logo · E-Class™ Digital Education (All Screens · Scale {scale:.0f}%)")

    def _paint_video(self, p: QPainter, y: int) -> None:
        if not self.index or not self.index.clips:
            self._empty(p, y, "Drag and drop media here after auto-align — or build timeline first")
            return
        for i, c in enumerate(self.index.clips):
            a, b = float(c.get("start") or 0), float(c.get("end") or 0)
            if self._drag and self._drag.get("kind") == "clip" and self._drag.get("idx") == i:
                a, b = float(self._drag.get("na", a)), float(self._drag.get("nb", b))
            if not self._visible(a, b):
                continue
            path, kind = self.index.files[i]
            missing = c.get("fit") == "missing" or not path
            is_video = (c.get("kind") == "video") or kind == "video"
            c1, c2 = ("#fb923c", "#f97316") if is_video else ("#fb7185", "#ff5c6c")
            thumb = self.thumbs.get(path) if path and kind == "image" and (b - a) * self.px > 46 else None
            fname = Path(path).name if path else str(c.get("filename") or "")
            label = media_block_label(c, kind="video" if is_video else "image", filename=fname, short=True)
            if missing:
                label = f"Missing · {scene_label(c.get('screen'), short=True)}"
            self._block(p, y, a, b, c1, c2, label, selected=i == self.selected_clip, thumb=thumb, striped=missing)
            sev = self.flags.get(str(c.get("screen")))
            if sev and (b - a) * self.px >= 14:
                cx = min(self._x(b) - 9, self._x(a) + (b - a) * self.px - 9)
                p.setPen(QPen(QColor(0, 0, 0, 160), 1))
                p.setBrush(QColor("#fca5a5" if sev == "error" else "#fde047"))
                p.drawEllipse(QPointF(cx, y + 9), 5, 5)

    def _paint_script(self, p: QPainter, y: int) -> None:
        if not self.index:
            return
        segs = self.index.segments
        for i, seg in enumerate(segs):
            a, b = float(seg.get("start") or 0), float(seg.get("end") or 0)
            text = str(seg.get("script_text") or seg.get("vo_text") or "").replace("\n", " ")
            if not self._visible(a, b + 30):
                continue
            end = b
            if text:
                for nxt in segs[i + 1:]:
                    if nxt.get("script_text") or nxt.get("vo_text"):
                        break
                    end = float(nxt.get("end") or end)
            self._block(p, y, a, b, "#4a304e", "#4a304e", "")
            if text and self._x(end) > 0:
                font = QFont("Nirmala UI")
                font.setPixelSize(10)
                p.setFont(font)
                p.setPen(QColor(theme.INK))
                room = max(8, (end - a) * self.px - 12)
                shown = QFontMetrics(font).elidedText(text, Qt.TextElideMode.ElideRight, int(room))
                p.drawText(QRectF(self._x(a) + 6, y + 4, room, LANE_H - 9), Qt.AlignmentFlag.AlignVCenter, shown)
            elif (b - a) * self.px > 40:
                font = QFont("Segoe UI")
                font.setPixelSize(10)
                p.setFont(font)
                p.setPen(QColor(theme.MUTED))
                p.drawText(QRectF(self._x(a) + 6, y + 4, (b - a) * self.px - 8, LANE_H - 9), Qt.AlignmentFlag.AlignVCenter, "Pause")

    def _paint_vo(self, p: QPainter, y: int, slot: int) -> None:
        pieces = [x for x in self._vo_pieces if not slot or int(x.get("slot") or 1) == slot]
        if not pieces:
            self._empty(p, y, "Upload narration VO" if not slot else "Voice gap", subtle=True)
            return
        for piece in pieces:
            a, b = float(piece.get("start") or 0), float(piece.get("end") or 0)
            if self._drag and self._drag.get("kind") == "vo" and self._drag.get("id") == piece.get("id") and "at" in self._drag:
                if self._drag.get("edge") == "start":
                    a = max(0.0, min(b - 0.12, float(self._drag["at"])))
                else:
                    b = max(a + 0.12, float(self._drag["at"]))
            if not self._visible(a, b):
                continue
            c1, c2 = VO_COLORS[(int(piece.get("slot") or 1) - 1) % 4]
            label = vo_block_label(piece, self.index.clips if self.index else None)
            self._block(p, y, a, b, c1, c2, label,
                        selected=piece.get("id") == self.selected_vo, min_w=8)

    def _paint_poem(self, p: QPainter, y: int) -> None:
        if not self.index or not self.index.has_poem:
            return
        name = str(self.index.project.poem_vo.get("filename") or "Poem")
        blocks = self.index.poem_blocks()
        if len(blocks) <= 1:
            self._block(p, y, self.index.poem_start, self.index.poem_end, theme.POEM, theme.ACCENT_2, f"♪ {name}")
            return
        for block in blocks:
            self._block(
                p, y, float(block["start"]), float(block["end"]), theme.POEM, theme.ACCENT_2,
                f"♪ {block.get('filename') or name}",
            )

    def _empty(self, p: QPainter, y: int, text: str, subtle: bool = False) -> None:
        r = QRectF(10, y + 5, self.width() - 20, LANE_H - 10)
        if not subtle:
            p.setPen(QPen(QColor(255, 180, 200, 50), 1, Qt.PenStyle.DashLine))
            p.setBrush(Qt.BrushStyle.NoBrush)
            p.drawRoundedRect(r, 8, 8)
        font = QFont("Segoe UI")
        font.setPixelSize(10)
        p.setFont(font)
        p.setPen(QColor(theme.MUTED))
        p.drawText(r.adjusted(10, 0, 0, 0), Qt.AlignmentFlag.AlignVCenter | (Qt.AlignmentFlag.AlignLeft if subtle else Qt.AlignmentFlag.AlignHCenter), text)

    # Input -----------------------------------------------------------------

    def time_at(self, x: float) -> float:
        return max(0.0, min(self.duration, (x + self.scroll) / self.px))

    def _row_at(self, y: float) -> Row | None:
        if y < RULER_H:
            return None
        i = int((y - RULER_H) // LANE_H)
        return self.rows[i] if 0 <= i < len(self.rows) else None

    def mousePressEvent(self, e) -> None:  # noqa: N802
        if not self.index:
            return
        t = self.time_at(e.position().x())
        row = self._row_at(e.position().y())
        if e.button() == Qt.MouseButton.RightButton:
            if row and row.key == "video":
                for i, c in enumerate(self.index.clips):
                    if float(c.get("start") or 0) <= t < float(c.get("end") or 0):
                        self.selected_clip = i
                        self.selected_vo = ""
                        self.invalidate()
                        self.clip_selected.emit(i)
                        self.clip_menu.emit(i, e.globalPosition().toPoint())
                        return
            if row and row.key == "vo":
                for piece in self._vo_pieces:
                    if (not row.slot or int(piece.get("slot") or 1) == row.slot) and float(piece.get("start") or 0) <= t < float(piece.get("end") or 0):
                        self.selected_vo = str(piece.get("id") or "")
                        self.selected_clip = -1
                        self.invalidate()
                        self.vo_selected.emit(self.selected_vo)
                        self.vo_menu.emit(self.selected_vo, e.globalPosition().toPoint())
                        return
            return
        if e.button() != Qt.MouseButton.LeftButton:
            return
        if row and row.key == "video":
            for i, c in enumerate(self.index.clips):
                a, b = float(c.get("start") or 0), float(c.get("end") or 0)
                if a <= t < b:
                    self.selected_clip = i
                    self.selected_vo = ""
                    self.invalidate()
                    self.clip_selected.emit(i)
                    edge = 8 / max(self.px, 1)
                    if t - a <= edge:
                        self._drag = {"kind": "clip", "edge": "start", "idx": i, "a": a, "b": b}
                    elif b - t <= edge:
                        self._drag = {"kind": "clip", "edge": "end", "idx": i, "a": a, "b": b}
                    elif not (a <= self.playhead < b):
                        self.seek_requested.emit(a + 0.01)
                    return
        if row and row.key == "vo":
            for piece in self._vo_pieces:
                a, b = float(piece.get("start") or 0), float(piece.get("end") or 0)
                if (not row.slot or int(piece.get("slot") or 1) == row.slot) and a <= t < b:
                    self.selected_vo = str(piece.get("id") or "")
                    self.selected_clip = -1
                    self.invalidate()
                    self.vo_selected.emit(self.selected_vo)
                    edge = 8 / max(self.px, 1)
                    if t - a <= edge:
                        self._drag = {"kind": "vo", "edge": "start", "id": self.selected_vo}
                    elif b - t <= edge:
                        self._drag = {"kind": "vo", "edge": "end", "id": self.selected_vo}
                    elif not (a <= self.playhead < b):
                        self.seek_requested.emit(a + 0.01)
                    return
        self._scrubbing = True
        self.seek_requested.emit(t)

    def mouseMoveEvent(self, e) -> None:  # noqa: N802
        t = self.time_at(e.position().x())
        if self._drag:
            d = self._drag
            if d["kind"] == "clip":
                a, b = d["a"], d["b"]
                if d["edge"] == "start":
                    a = max(0.0, min(b - 0.25, t))
                else:
                    b = max(a + 0.25, t)
                d["na"], d["nb"] = a, b
                self.setCursor(Qt.CursorShape.SizeHorCursor)
                self.invalidate()
            else:
                d["at"] = t
                self.setCursor(Qt.CursorShape.SizeHorCursor)
                self.invalidate()
            return
        if self._scrubbing:
            self.seek_requested.emit(t)
            return
        if not self.index:
            return
        t = self.time_at(e.position().x())
        row = self._row_at(e.position().y())
        tip = ""
        if row and row.key == "video":
            c = self.index.clip_at(t)
            if c and float(c.get("start") or 0) <= t < float(c.get("end") or 0):
                i = self.index.clips.index(c)
                path = self.index.files[i][0]
                tip = (
                    f"{media_block_label(c, kind=str(c.get('kind') or ''), filename=Path(path).name if path else '', short=False)}"
                    f" ({fmt_short(c.get('start'))}–{fmt_short(c.get('end'))})\n"
                    f"{path or 'Picture not linked on this PC'}"
                )
        elif row and row.key == "script":
            for seg in self.index.segments:
                if float(seg.get("start") or 0) <= t < float(seg.get("end") or 0):
                    tip = f"{scene_label(seg.get('screen'))} ({fmt_short(seg.get('start'))}–{fmt_short(seg.get('end'))}): {seg.get('script_text') or seg.get('vo_text') or 'Pause'}"
                    break
        elif row and row.key == "vo":
            for piece in self._vo_pieces:
                if (not row.slot or int(piece.get("slot") or 1) == row.slot) and float(piece.get("start") or 0) <= t < float(piece.get("end") or 0):
                    tip = (
                        f"{vo_block_label(piece, self.index.clips)}"
                        f" ({fmt_short(piece.get('start'))}–{fmt_short(piece.get('end'))})"
                    )
                    break
        self.setToolTip(tip)

    def mouseReleaseEvent(self, _e) -> None:  # noqa: N802
        d = self._drag
        if d and d.get("kind") == "clip" and "na" in d:
            self.clip_resized.emit(d["idx"], d["na"], d["nb"])
        elif d and d.get("kind") == "vo" and "at" in d:
            self.vo_trimmed.emit(d["id"], d["edge"], d["at"])
        self._drag = None
        self._scrubbing = False
        self.unsetCursor()

    def wheelEvent(self, e) -> None:  # noqa: N802
        d = e.angleDelta().y() or e.angleDelta().x()
        if e.modifiers() & Qt.KeyboardModifier.ControlModifier:
            self.set_px(self.px * (1.15 if d > 0 else 1 / 1.15), e.position().x())
        else:
            self.set_scroll(self.scroll - d * 0.8)
        e.accept()


# Header ----------------------------------------------------------------------


class TrackHeader(QWidget):
    toggled = Signal(str, bool)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setFixedWidth(HEADER_W)
        self._lay = QVBoxLayout(self)
        self._lay.setContentsMargins(0, 0, 0, 0)
        self._lay.setSpacing(0)

    def rebuild(self, rows: list[Row], plan: dict | None) -> None:
        while self._lay.count():
            item = self._lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        spacer = QWidget()
        spacer.setFixedHeight(RULER_H)
        self._lay.addWidget(spacer)
        plan = plan or {}
        for row in rows:
            box = QWidget()
            box.setFixedHeight(LANE_H)
            h = QHBoxLayout(box)
            h.setContentsMargins(10, 0, 8, 0)
            h.setSpacing(4)
            lab = QLabel(row.label)
            lab.setStyleSheet("font-size: 11px; font-weight: 600;")
            h.addWidget(lab, 1)
            for key, on_ic, on_col, off_ic, off_col, tip_on, tip_off in self._toggles(row):
                btn = QToolButton()
                btn.setObjectName("Track")
                btn.setCheckable(True)
                val = bool(plan.get(key, True)) if key == "logo_enabled" else bool(plan.get(key))
                btn.setChecked(val)
                theme.set_btn_neon_icon(btn, on_ic if val else off_ic, on_col if val else off_col, 14)
                btn.setToolTip(tip_on if val else tip_off)
                btn.toggled.connect(lambda v, k=key: self.toggled.emit(k, v))
                h.addWidget(btn)
            off = {"video": plan.get("video_track_hidden"), "script": plan.get("script_track_hidden"),
                   "vo": plan.get("vo_muted"), "poem": plan.get("poem_muted")}.get(row.key)
            locked = {"video": plan.get("video_track_locked"), "vo": plan.get("vo_track_locked"),
                      "poem": plan.get("poem_track_locked")}.get(row.key)
            if off:
                lab.setStyleSheet("font-size: 11px; font-weight: 600; color: rgba(246,238,244,0.45); text-decoration: line-through;")
            if locked:
                lab.setText(row.label + " (Locked)")
            self._lay.addWidget(box)
        self._lay.addStretch(1)

    @staticmethod
    def _toggles(row: Row):
        if row.key == "logo":
            return [("logo_enabled", "eye", "#22d3ee", "eye_off", "#94a3b8", "Hide Brand Logo", "Show Brand Logo")]
        if row.key == "video":
            return [("video_track_hidden", "eye_off", "#ef4444", "eye", "#22d3ee", "Show Video 1 in preview", "Hide Video 1 in preview"),
                    ("video_track_locked", "lock", "#fbbf24", "unlock", "#c084fc", "Unlock Video 1 (allow editing)", "Lock Video 1 (prevent accidental edits)")]
        if row.key == "script":
            return [("script_track_hidden", "eye_off", "#ef4444", "cc", "#c084fc", "Show the script lane", "Hide the script lane")]
        if row.key == "vo":
            return [("vo_muted", "mute", "#ef4444", "volume", "#38bdf8", "Unmute VoiceOver", "Mute VoiceOver"),
                    ("vo_track_locked", "lock", "#fbbf24", "unlock", "#c084fc", "Unlock voice", "Lock voice")]
        if row.key == "poem":
            return [("poem_muted", "mute", "#ef4444", "music", "#e879f9", "Unmute Poem audio", "Mute Poem audio"),
                    ("poem_track_locked", "lock", "#fbbf24", "unlock", "#c084fc", "Unlock Poem", "Lock Poem position")]
        return []


class TimelineDock(QWidget):
    """Toolbar, headers, lanes and the horizontal scroll bar."""

    flag_toggled = Signal(str, bool)
    edit_requested = Signal(str)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("Panel")
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        outer = QVBoxLayout(self)
        outer.setContentsMargins(10, 8, 10, 8)
        outer.setSpacing(6)

        # Keep title/info/zoom outside the scroll strip so the window can fit
        # a normal screen; the long edit-button row scrolls instead of forcing
        # a ~1900px minimum width past the desktop edges.
        head = QHBoxLayout()
        head.setSpacing(6)
        title = QLabel("Timeline")
        title.setObjectName("PanelTitle")
        head.addWidget(title)
        self.info = QLabel("")
        self.info.setObjectName("Muted")
        head.addWidget(self.info)
        head.addStretch(1)
        self.manual_pill = QLabel("Manual Override (VO Sync Locked)")
        self.manual_pill.setStyleSheet("color:#fde68a; background: rgba(251,191,36,0.12); border:1px solid rgba(251,191,36,0.4); border-radius: 10px; padding: 3px 10px; font-weight: 600;")
        self.manual_pill.setVisible(False)
        head.addWidget(self.manual_pill)
        self.follow_btn = QPushButton("Follow playhead")
        self.follow_btn.setObjectName("Pill")
        self.follow_btn.setCheckable(True)
        self.follow_btn.setChecked(True)
        self.follow_btn.setFixedHeight(28)
        self.follow_btn.setToolTip("Keep the playhead in view while playing")
        head.addWidget(self.follow_btn)
        zl = QLabel("Zoom")
        zl.setObjectName("Muted")
        head.addWidget(zl)
        self.zoom = QSlider(Qt.Orientation.Horizontal)
        self.zoom.setRange(2, 120)
        self.zoom.setValue(12)
        self.zoom.setFixedWidth(150)
        head.addWidget(self.zoom)
        outer.addLayout(head)

        tools = QWidget()
        tools.setStyleSheet("background: transparent;")
        bar = QHBoxLayout(tools)
        bar.setContentsMargins(0, 0, 0, 0)
        bar.setSpacing(6)
        self.edit_btns: dict[str, QPushButton] = {}
        for key, ic_name, ic_col, label, tip in (
            ("undo", "undo", "#c084fc", "Undo", "Undo timeline edit (Ctrl+Z)"),
            ("redo", "redo", "#c084fc", "Redo", "Redo timeline edit (Ctrl+Y)"),
            ("delete", "trash", "#ef4444", "Delete", "Delete this scene from Video 1 without moving VO (Delete)"),
            ("pull_prev", "arrow_left", "#fb7185", "Delete && Pull Prev", "Delete this scene and stretch the previous screen over its VO"),
            ("pull_left", "arrow_left", "#38bdf8", "Pull Left", "Stretch this screen left over the previous gap / VO"),
            ("pull_right", "arrow_right", "#38bdf8", "Pull Over Next", "Stretch this screen right over the next gap / VO"),
            ("fit", "fit", "#22d3ee", "Fit to VO", "Snap this screen to its narration and any empty gap beside it"),
            ("split", "split", "#f472b6", "Split", "Split the selected clip at the playhead (S)"),
            ("trim_in", "bracket_in", "#c084fc", "In", "Set the start of the clip to the playhead"),
            ("trim_out", "bracket_out", "#c084fc", "Out", "Set the end of the clip to the playhead"),
            ("download", "download", "#38bdf8", "Download", "Save this picture or video to a folder (edit in Filmora/Photoshop, then Replace)"),
            ("replace_image", "image", "#f472b6", "Replace with Image", "Replace the selected scene (video or image) with an image. The timeline block stays."),
            ("replace_video", "video", "#22d3ee", "Replace with Video", "Replace the selected scene (image or video) with a video. The timeline block stays."),
            ("replace", "swap", "#c084fc", "Replace Media", "Upload a new picture or video for this scene. The timeline block stays."),
            ("split_vo", "split", "#fb7185", "Split voice", "Split the selected voice piece at the playhead"),
            ("delete_vo", "trash", "#ef4444", "Delete voice", "Delete the selected voice section. Pictures stay. A silence longer than 4 seconds closes to 4 seconds."),
            ("download_vo", "download", "#22d3ee", "Cut VO", "Download the cut narration for the selected voice block or Video 1 scene"),
            ("replace_vo", "swap", "#f472b6", "Replace cut VO", "Upload a new take for that cut. The block stays; Export / .wfp / bundle use it."),
        ):
            b = QPushButton(label)
            theme.set_btn_neon_icon(b, ic_name, ic_col, 14)
            b.setToolTip(tip)
            b.setObjectName("Pill")
            b.setFixedHeight(28)
            b.clicked.connect(lambda _=False, k=key: self.edit_requested.emit(k))
            self.edit_btns[key] = b
            bar.addWidget(b)
        self.logo_btn = QPushButton("+ Add Logo Track")
        self.logo_btn.setCheckable(True)
        self.logo_btn.toggled.connect(lambda v: self.flag_toggled.emit("logo_enabled", v))
        self.logo_btn.setVisible(False)
        bar.addStretch(1)
        tool_scroll = QScrollArea()
        tool_scroll.setWidget(tools)
        tool_scroll.setWidgetResizable(True)
        tool_scroll.setFrameShape(QFrame.Shape.NoFrame)
        tool_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        tool_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        tool_scroll.setFixedHeight(34)
        tool_scroll.setStyleSheet("QScrollArea { background: transparent; }")
        outer.addWidget(tool_scroll)

        body = QHBoxLayout()
        body.setSpacing(0)
        self.header = TrackHeader()
        self.header.setStyleSheet("background: rgba(0,0,0,0.28); border-radius: 8px;")
        self.header.toggled.connect(self.flag_toggled.emit)
        body.addWidget(self.header, 0, Qt.AlignmentFlag.AlignTop)
        lanes = QVBoxLayout()
        lanes.setSpacing(2)
        self.canvas = TimelineCanvas()
        lanes.addWidget(self.canvas)
        self.hbar = QScrollBar(Qt.Orientation.Horizontal)
        self.hbar.setObjectName("TimelineHBar")
        self.hbar.setFixedHeight(16)
        self.hbar.setSingleStep(48)
        lanes.addWidget(self.hbar)
        lanes.addStretch(1)
        body.addLayout(lanes, 1)
        outer.addLayout(body, 1)

        self.zoom.valueChanged.connect(lambda v: self.canvas.set_px(float(v)))
        self.hbar.valueChanged.connect(lambda v: self.canvas.set_scroll(float(v)))
        self.canvas.scroll_changed.connect(self._sync_bar)
        self.follow_btn.toggled.connect(lambda v: setattr(self.canvas, "follow", v))

    def set_index(self, index: PlanIndex | None) -> None:
        self.canvas.set_index(index)
        plan = index.project.plan if index else None
        self.header.rebuild(self.canvas.rows, plan)
        self.header.setFixedHeight(self.canvas.height())
        on = bool(index and index.project.logo_enabled)
        self.logo_btn.blockSignals(True)
        self.logo_btn.setChecked(on)
        self.logo_btn.setText("Logo Track: Active" if on else "+ Add Logo Track")
        self.logo_btn.blockSignals(False)
        self.manual_pill.setVisible(bool(plan and plan.get("manual_override")))
        self.refresh_edit_buttons()
        if index:
            n = len(index.clips)
            self.info.setText(f"{n} clips · {fmt_short(index.duration)}")
        else:
            self.info.setText("")
        self._sync_bar()

    def refresh_edit_buttons(self) -> None:
        plan = self.canvas.index.project.plan if self.canvas.index else None
        locked = bool(plan and plan.get("video_track_locked"))
        vo_locked = bool(plan and plan.get("vo_track_locked"))
        has = self.canvas.index is not None
        sel = has and self.canvas.selected_clip >= 0
        vo_sel = has and bool(self.canvas.selected_vo)
        sel_kind = ""
        if sel and self.canvas.index and 0 <= self.canvas.selected_clip < len(self.canvas.index.clips):
            sel_kind = str(self.canvas.index.clips[self.canvas.selected_clip].get("kind") or "image")
        img_btn = self.edit_btns.get("replace_image")
        vid_btn = self.edit_btns.get("replace_video")
        if img_btn is not None:
            img_btn.setText("Replace Video → Image" if sel_kind == "video" else "Replace with Image")
        if vid_btn is not None:
            vid_btn.setText("Replace Image → Video" if sel_kind == "image" else "Replace with Video")
        for key, b in self.edit_btns.items():
            if key in ("undo", "redo"):
                b.setEnabled(has)
            elif key == "download":
                b.setEnabled(sel)
            elif key == "download_vo":
                # Cut VO works from a VO selection or a Video 1 scene with narration.
                b.setEnabled(vo_sel or sel)
            elif key == "replace_vo":
                b.setEnabled((vo_sel or sel) and not vo_locked)
            elif key in ("split_vo", "delete_vo"):
                b.setEnabled(vo_sel and not vo_locked)
            else:
                b.setEnabled(sel and not locked)

    def _sync_bar(self) -> None:
        c = self.canvas
        span = int(max(0.0, c.content_width() - c.width()))
        page = max(1, int(c.width() * 0.85))
        step = max(24, int(round(c.px * 2)))
        self.hbar.blockSignals(True)
        self.hbar.setRange(0, span)
        self.hbar.setPageStep(page)
        self.hbar.setSingleStep(step)
        self.hbar.setValue(int(c.scroll))
        self.hbar.blockSignals(False)
        self.zoom.blockSignals(True)
        self.zoom.setValue(int(round(c.px)))
        self.zoom.blockSignals(False)

    def resizeEvent(self, e) -> None:  # noqa: N802
        super().resizeEvent(e)
        self._sync_bar()
