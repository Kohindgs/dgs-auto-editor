import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import './App.css'
import { buildStoredZipArchiveInBrowser, extractBundleInBrowser, type ZipBuildEntry } from './bundleArchive'
import { AiNeonThumbBadge, DgsNeonBrandLogo, NeonIcon } from './components/NeonIcons'
import { PreviewPane } from './components/PreviewPane'
import { playheadBus } from './playheadBus'
import { TimelineEditor } from './components/TimelineEditor'
import { isLocalWebCodecsSupported, renderProjectLocallyOnMachine } from './localRenderer'
import {
  cancelBrowserVoQaScan,
  hearVoiceoverWords,
  type AsrWord,
} from './voAndCardDeepQa'
import {
  buildRenamePlan,
  canRenameInPlace,
  hasReadWritePermission,
  loadDirHandleFromIdb,
  loadSwaps,
  pickMediaDirectoryHandle,
  renameInFolder,
  saveDirHandleToIdb,
  saveSwaps,
  writeReplacedFileToFolder,
  type AutoSwapRecord,
  type FsDirHandle,
} from './imageRenumber'
import { buildCardTextIssues, scriptLooksIndic } from './cardTextQa'
import { applyStretchAlignToPlan } from './stretchClipsToVo'
import { poemSyncArgs, verifySync } from './syncVerify'
import type { ExportSettings, LogoTransform, MediaItem, PoemInfo, PoemOverlayStyle, QAIssue, Scene, SyncReport, TimelinePlan } from './types'
import { DEFAULT_LOGO_TRANSFORM, DEFAULT_POEM_OVERLAY_STYLE, fmt, getQaIssueKey, normalizeLogoTransform, normalizePoemOverlayStyle } from './types'

const DEFAULT_BRAND_LOGO = {
  filename: 'E-Class Logo.png (Default)',
  path: '/eclass-logo.png',
  enabled: false,
}

const API = import.meta.env.VITE_API_URL || ''

type DesktopBridge = {
  pickProjectFile?: () => Promise<string | null>
  pathForFile?: (file: File) => string
}

function desktopBridge(): DesktopBridge | null {
  return (window as Window & { dgsDesktop?: DesktopBridge }).dgsDesktop || null
}

function getOrCreateClientId(): string {
  try {
    let cid = window.localStorage.getItem('dgs_client_id')
    if (!cid) {
      cid = `pc-${Math.random().toString(36).slice(2, 8)}-${Date.now().toString(36).slice(-4)}`
      window.localStorage.setItem('dgs_client_id', cid)
    }
    return cid
  } catch {
    return 'pc-local'
  }
}

function getOrCreateClientLabel(cid: string): string {
  try {
    const saved = window.localStorage.getItem('dgs_client_label')
    if (saved && saved.trim()) return saved.trim()
    const ua = navigator.userAgent || ''
    const os = /Mac/i.test(ua)
      ? 'Mac'
      : /Win/i.test(ua)
        ? 'Windows PC'
        : /Linux/i.test(ua)
          ? 'Linux PC'
          : 'PC'
    return `${os} · ${cid.slice(3, 7).toUpperCase()}`
  } catch {
    return `PC · ${cid.slice(0, 6)}`
  }
}

// Browser-local IndexedDB store so each individual PC keeps its own uploaded media/VO blobs locally
const IDB_NAME = 'dgs_pc_local_files_v1'
const IDB_STORE = 'files'
let localDbPromise: Promise<IDBDatabase | null> | null = null

function openLocalDb(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null)
  if (!localDbPromise) {
    localDbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open(IDB_NAME, 1)
        req.onupgradeneeded = () => {
          const db = req.result
          if (!db.objectStoreNames.contains(IDB_STORE)) {
            db.createObjectStore(IDB_STORE)
          }
        }
        req.onsuccess = () => resolve(req.result)
        req.onerror = () => {
          localDbPromise = null
          resolve(null)
        }
      } catch {
        localDbPromise = null
        resolve(null)
      }
    })
  }
  return localDbPromise
}

async function idbPutFile(key: string, file: Blob | string, fallbackKey?: string): Promise<void> {
  const db = await openLocalDb()
  if (!db) return
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, 'readwrite')
      const store = tx.objectStore(IDB_STORE)
      store.put(file, key)
      if (
        fallbackKey &&
        fallbackKey !== key &&
        !fallbackKey.startsWith('pc:media:') &&
        !fallbackKey.startsWith('pc:vo:') &&
        !fallbackKey.startsWith('pc:thumb:')
      ) {
        store.put(file, fallbackKey)
      }
      tx.oncomplete = () => resolve()
      tx.onerror = () => resolve()
    } catch {
      resolve()
    }
  })
}

async function idbGetFile(key: string): Promise<File | Blob | null> {
  const db = await openLocalDb()
  if (!db) return null
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, 'readonly')
      const req = tx.objectStore(IDB_STORE).get(key)
      req.onsuccess = () => resolve((req.result as File | Blob) || null)
      req.onerror = () => resolve(null)
    } catch {
      resolve(null)
    }
  })
}

async function idbGetString(key: string): Promise<string | null> {
  const db = await openLocalDb()
  if (!db) return null
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_STORE, 'readonly')
      const req = tx.objectStore(IDB_STORE).get(key)
      req.onsuccess = () => resolve(typeof req.result === 'string' ? req.result : null)
      req.onerror = () => resolve(null)
    } catch {
      resolve(null)
    }
  })
}

async function probeVideoBrowser(
  blobUrl: string,
): Promise<{ duration: number; thumbDataUrl: string }> {
  return new Promise((resolve) => {
    const v = document.createElement('video')
    v.preload = 'auto'
    v.muted = true
    v.playsInline = true
    let done = false
    const finish = (dur: number, thumb = '') => {
      if (done) return
      done = true
      v.removeAttribute('src')
      v.load()
      resolve({ duration: dur > 0 && Number.isFinite(dur) ? Math.round(dur * 1000) / 1000 : 5, thumbDataUrl: thumb })
    }
    const timer = window.setTimeout(() => finish(v.duration || 5, ''), 4000)

    const captureThumb = () => {
      try {
        const c = document.createElement('canvas')
        const srcW = v.videoWidth || 1280
        const srcH = v.videoHeight || 720
        const maxW = 1280
        const scale = Math.min(1, maxW / srcW)
        c.width = Math.max(16, Math.round(srcW * scale))
        c.height = Math.max(16, Math.round(srcH * scale))
        const ctx = c.getContext('2d')
        if (ctx && (v.videoWidth || 0) > 0) {
          ctx.drawImage(v, 0, 0, c.width, c.height)
          const thumb = c.toDataURL('image/jpeg', 0.86)
          window.clearTimeout(timer)
          finish(v.duration || 5, thumb)
          return
        }
      } catch {
        /* ignore */
      }
      window.clearTimeout(timer)
      finish(v.duration || 5, '')
    }

    v.onseeked = () => {
      captureThumb()
    }

    v.onloadedmetadata = () => {
      try {
        const targetTime = Math.min(0.25, Math.max(0.05, (v.duration || 1) * 0.1))
        v.currentTime = targetTime
      } catch {
        captureThumb()
      }
    }

    v.onloadeddata = () => {
      // Fallback in case seek doesn't trigger or video has 0 duration
      setTimeout(() => {
        if (!done) captureThumb()
      }, 600)
    }

    v.onerror = () => {
      window.clearTimeout(timer)
      finish(5, '')
    }
    v.src = blobUrl
  })
}

async function probeAudioDurationOnly(file: File | Blob): Promise<number> {
  return new Promise((resolve) => {
    const a = document.createElement('audio')
    const url = URL.createObjectURL(file)
    const done = (d: number) => {
      URL.revokeObjectURL(url)
      resolve(d > 0 && Number.isFinite(d) ? Math.round(d * 1000) / 1000 : 10)
    }
    const timer = window.setTimeout(() => done(10), 20_000)
    a.onloadedmetadata = () => {
      window.clearTimeout(timer)
      done(a.duration || 10)
    }
    a.onerror = () => {
      window.clearTimeout(timer)
      done(10)
    }
    a.src = url
  })
}

async function analyzeAudioBrowser(
  file: File | Blob,
): Promise<{ duration: number; silences: [number, number][]; audioBuffer: AudioBuffer | null }> {
  const DECODE_MS = 90_000
  try {
    const arrayBuf = await file.arrayBuffer()
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    const ctx = new Ctx()
    try {
      if (ctx.state === 'suspended') {
        await ctx.resume().catch(() => undefined)
      }
      const audioBuf = await Promise.race([
        ctx.decodeAudioData(arrayBuf.slice(0)),
        new Promise<never>((_, reject) => {
          window.setTimeout(() => reject(new Error('decode timeout')), DECODE_MS)
        }),
      ])
      const duration = Math.round(audioBuf.duration * 1000) / 1000
      const chan = audioBuf.getChannelData(0)
      const sr = audioBuf.sampleRate
      const winSamples = Math.max(1, Math.floor(sr * 0.02)) // 20ms window
      const thresh = Math.pow(10, -34 / 20) // -34 dB (~0.02)
      const minSilSec = 0.18
      const silences: [number, number][] = []
      let silStart: number | null = null
      for (let i = 0; i < chan.length; i += winSamples) {
        let sumSq = 0
        const end = Math.min(chan.length, i + winSamples)
        for (let j = i; j < end; j++) {
          sumSq += chan[j] * chan[j]
        }
        const rms = Math.sqrt(sumSq / Math.max(1, end - i))
        const t = i / sr
        if (rms < thresh) {
          if (silStart === null) silStart = t
        } else if (silStart !== null) {
          if (t - silStart >= minSilSec) {
            silences.push([Math.round(silStart * 1000) / 1000, Math.round(t * 1000) / 1000])
          }
          silStart = null
        }
      }
      if (silStart !== null && duration - silStart >= minSilSec) {
        silences.push([Math.round(silStart * 1000) / 1000, duration])
      }
      return { duration, silences, audioBuffer: audioBuf }
    } finally {
      void ctx.close().catch(() => undefined)
    }
  } catch {
    // Duration-only fallback so "Analyzing VO…" never hangs forever on a stubborn MP3 decode.
    const duration = await probeAudioDurationOnly(file)
    return { duration, silences: [], audioBuffer: null }
  }
}

function encodeAudioBuffersToWavBlob(buffers: AudioBuffer[], gapSec = 0.5): Blob {
  const sr = buffers[0]?.sampleRate || 44100
  const gapSamples = Math.floor(sr * gapSec)
  let totalSamples = 0
  for (let i = 0; i < buffers.length; i++) {
    totalSamples += Math.floor((buffers[i].duration || 0) * sr)
    if (i < buffers.length - 1) totalSamples += gapSamples
  }
  const pcm = new Int16Array(totalSamples)
  let offset = 0
  for (let i = 0; i < buffers.length; i++) {
    const b = buffers[i]
    const ch0 = b.getChannelData(0)
    const ch1 = b.numberOfChannels > 1 ? b.getChannelData(1) : ch0
    if (b.sampleRate === sr) {
      for (let s = 0; s < ch0.length && offset < pcm.length; s++, offset++) {
        const v = Math.max(-1, Math.min(1, 0.5 * (ch0[s] + ch1[s])))
        pcm[offset] = v < 0 ? v * 0x8000 : v * 0x7fff
      }
    } else {
      const outLen = Math.floor(b.duration * sr)
      const ratio = b.sampleRate / sr
      for (let s = 0; s < outLen && offset < pcm.length; s++, offset++) {
        const srcIdx = Math.min(ch0.length - 1, Math.floor(s * ratio))
        const v = Math.max(-1, Math.min(1, 0.5 * (ch0[srcIdx] + ch1[srcIdx])))
        pcm[offset] = v < 0 ? v * 0x8000 : v * 0x7fff
      }
    }
    if (i < buffers.length - 1) {
      offset = Math.min(pcm.length, offset + gapSamples)
    }
  }
  const byteLen = pcm.length * 2
  const wav = new ArrayBuffer(44 + byteLen)
  const view = new DataView(wav)
  const writeStr = (pos: number, str: string) => {
    for (let i = 0; i < str.length; i++) view.setUint8(pos + i, str.charCodeAt(i))
  }
  writeStr(0, 'RIFF')
  view.setUint32(4, 36 + byteLen, true)
  writeStr(8, 'WAVE')
  writeStr(12, 'fmt ')
  view.setUint32(16, 16, true)
  view.setUint16(20, 1, true)
  view.setUint16(22, 1, true)
  view.setUint32(24, sr, true)
  view.setUint32(28, sr * 2, true)
  view.setUint16(32, 2, true)
  view.setUint16(34, 16, true)
  writeStr(36, 'data')
  view.setUint32(40, byteLen, true)
  new Int16Array(wav, 44).set(pcm)
  return new Blob([wav], { type: 'audio/wav' })
}

const SUNDHARAM_BR: ExportSettings = {
  format: 'mp4',
  resolution: '1920x1080',
  fps: 30,
  encoder: 'h264',
  quality_preset: 'high',
  bitrate_mode: 'vbr',
  video_bitrate_kbps: 20000,
  compression_mode: 'by_quality',
  compression_quality: 70,
  audio_encoder: 'aac',
  audio_bitrate_kbps: 320,
  audio_sample_rate: 44100,
  audio_channels: 'stereo',
  color_space: 'bt709',
  advanced_compression: true,
  export_multitrack: false,
  export_video_only: false,
  backup_to_cloud: false,
  auto_highlight: false,
  export_srt_sidecar: false,
  preset_name: 'Sundharam BR',
}

function computePresetBitrate(
  resolution: string,
  quality: ExportSettings['quality_preset'],
  encoder: ExportSettings['encoder'],
  fallback: number,
): number {
  if (quality === 'custom') return fallback
  const base = quality === 'high' ? 20000 : quality === 'medium' ? 10000 : 5000
  const resFactor =
    resolution === '3840x2160' ? 2.0 : resolution === '1280x720' ? 0.5 : 1.0
  const encFactor = encoder === 'h265' ? 0.7 : encoder === 'mpeg4' ? 1.15 : 1.0
  return Math.max(500, Math.round((base * resFactor * encFactor) / 100) * 100)
}

function computeBitrateSignal(s: ExportSettings, planObj?: TimelinePlan | null) {
  const baseVideoKbps = Math.max(500, Number(s.video_bitrate_kbps) || 20000)
  const compActive = Boolean(s.advanced_compression && s.compression_mode !== 'none')
  const compPct = Math.max(10, Math.min(95, Number(s.compression_quality) || 70))
  const keepRatio = compActive ? Math.max(0.05, (100 - compPct) / 100) : 1

  // VBV Maxrate ceiling (6,000 kbps at 70% compression of 20,000 kbps base, matching CRF 28 vbv_maxrate=6000)
  const targetVideoKbps = compActive
    ? Math.max(400, Math.round(baseVideoKbps * keepRatio))
    : baseVideoKbps
  const targetVideoMbps = (targetVideoKbps / 1000).toFixed(2)

  // Realistic H.264/H.265 CRF stream bitrate across still-image vs video clips (produces ~1,280 kbps / ~73 MB at 70% compression)
  let contentFactor = 0.215
  if (planObj?.clips?.length) {
    let vidDur = 0
    let imgDur = 0
    for (const c of planObj.clips) {
      const cd = Math.max(0, (c.end || 0) - (c.start || 0))
      if (c.kind === 'video') vidDur += cd
      else imgDur += cd
    }
    const total = Math.max(1, vidDur + imgDur)
    contentFactor = (vidDur * 0.44 + imgDur * 0.09) / total
  }
  const isQualityMode = s.compression_mode !== 'by_bitrate' && s.bitrate_mode !== 'cbr'
  const realisticBaseVideoKbps = isQualityMode
    ? Math.max(600, Math.round(baseVideoKbps * contentFactor))
    : baseVideoKbps
  const effectiveStreamVideoKbps = compActive
    ? Math.max(250, Math.round(realisticBaseVideoKbps * keepRatio))
    : realisticBaseVideoKbps

  const audioKbps = s.export_video_only
    ? 0
    : s.audio_encoder === 'pcm'
      ? 1411
      : Number(s.audio_bitrate_kbps) || 320
  const totalKbps = targetVideoKbps + audioKbps
  const totalMbps = (totalKbps / 1000).toFixed(2)
  const crf =
    compActive && s.compression_mode === 'by_quality'
      ? Math.max(18, Math.min(35, Math.round(18 + (compPct / 100) * 14)))
      : s.quality_preset === 'low'
        ? 26
        : s.quality_preset === 'medium'
          ? 22
          : 19

  let level: 'master' | 'optimal' | 'balanced' | 'low' = 'master'
  let bars = 4
  let badge = 'STUDIO MASTER HD'
  let color = '#10b981'
  let dot = '●'
  let advice = 'Maximum sharpness for 1080p/4K displays & smartboards'

  if (targetVideoKbps >= 14000) {
    level = 'master'
    bars = 4
    badge = 'STUDIO MASTER HD'
    color = '#10b981'
    dot = '●'
    advice = 'Broadcast-grade sharpness for large classroom smartboards & YouTube HD'
  } else if (targetVideoKbps >= 5000) {
    level = 'optimal'
    bars = 3
    badge = 'OPTIMAL CLASSROOM HD'
    color = '#1cd6b0'
    dot = '●'
    advice = `Crisp 1080p quality · ~${effectiveStreamVideoKbps.toLocaleString()} kbps avg stream (<100 MB)`
  } else if (targetVideoKbps >= 2500) {
    level = 'balanced'
    bars = 2
    badge = 'COMPACT WEB / MOBILE'
    color = '#f59e0b'
    dot = '●'
    advice = 'Lightweight stream suitable for WhatsApp & mobile sharing'
  } else {
    level = 'low'
    bars = 1
    badge = 'LOW BITRATE (HEAVY COMPRESSION)'
    color = '#f43f5e'
    dot = '●'
    advice = 'High compression — smallest file size'
  }

  return {
    baseVideoKbps,
    realisticBaseVideoKbps,
    effectiveStreamVideoKbps,
    compActive,
    compPct,
    targetVideoKbps,
    targetVideoMbps,
    audioKbps,
    totalKbps,
    totalMbps,
    crf,
    level,
    bars,
    badge,
    color,
    dot,
    advice,
    modeUpper: s.bitrate_mode.toUpperCase(),
  }
}

function estimateExportSizeMb(
  planOrDur: TimelinePlan | number | null | undefined,
  s: ExportSettings,
): { estimatedMb: number; baseMb: number } {
  const planObj = typeof planOrDur === 'object' && planOrDur !== null ? planOrDur : null
  const dur = Math.max(
    1,
    planObj ? planObj.total_duration || 0 : typeof planOrDur === 'number' ? planOrDur : 0,
  )
  const sig = computeBitrateSignal(s, planObj)
  const baseMb = Math.max(1, Math.round((dur * (sig.realisticBaseVideoKbps + sig.audioKbps)) / 8192))
  if (sig.compActive) {
    const estimatedMb = Math.max(
      1,
      Math.round((dur * (sig.effectiveStreamVideoKbps + sig.audioKbps)) / 8192),
    )
    return { estimatedMb, baseMb }
  }
  return { estimatedMb: baseMb, baseMb }
}

export default function App() {
  const [projectId, setProjectId] = useState<string | null>(null)
  const [media, setMedia] = useState<MediaItem[]>([])
  const [selectedMediaId, setSelectedMediaId] = useState<string | null>(null)
  const [scenes, setScenes] = useState<Scene[]>([])
  const [voInfo, setVoInfo] = useState<{ filename: string; duration?: number | null } | null>(null)
  const [voSlots, setVoSlots] = useState<number[]>([1])
  const [voFiles, setVoFiles] = useState<Record<number, { filename: string; duration?: number | null }>>({})
  const [poemVoInfo, setPoemVoInfo] = useState<{ filename: string; duration?: number | null } | null>(null)
  const [logoInfo, setLogoInfo] = useState<{ filename: string; path?: string; enabled: boolean }>(
    () => ({ ...DEFAULT_BRAND_LOGO }),
  )
  const [logoTransform, setLogoTransform] = useState<LogoTransform>(() => ({
    ...DEFAULT_LOGO_TRANSFORM,
  }))
  const [showLogoPlacement, setShowLogoPlacement] = useState<boolean>(false)
  const [poemOverlay, setPoemOverlay] = useState<PoemOverlayStyle>(() => ({
    ...DEFAULT_POEM_OVERLAY_STYLE,
  }))
  const [showPoemStudio, setShowPoemStudio] = useState<boolean>(false)
  const poemAutoOpenedRef = useRef<string | null>(null)
  const [ignoredQaKeys, setIgnoredQaKeys] = useState<string[]>([])
  const [poemInfo, setPoemInfo] = useState<PoemInfo | null>(null)
  const [timeline, setTimeline] = useState<TimelinePlan | null>(null)
  const [language, setLanguage] = useState<'auto' | 'en' | 'mr' | 'en+mr'>('en+mr')
  const [exportSettings, setExportSettings] = useState<ExportSettings>({ ...SUNDHARAM_BR })
  const [title, setTitle] = useState('Auto Edit')
  const [busy, setBusy] = useState<string | null>(null)
  const [log, setLog] = useState('Import media, script, and VO — then Auto-align')
  const [showUpdates, setShowUpdates] = useState(false)
  const [appRelease, setAppRelease] = useState<{
    current: string
    latest: string
    updateAvailable: boolean
    notes: string[]
    history: { version: string; date: string; notes: string[] }[]
    downloads: { win?: string; mac?: string }
    platform: string
    feedError?: string
  } | null>(null)
  const [appAssets, setAppAssets] = useState<{ eng: boolean; mar: boolean; whisper: string } | null>(null)
  const [presetName, setPresetName] = useState('Sundharam BR')
  const [serverPresets, setServerPresets] = useState<Record<string, ExportSettings>>({
    'Sundharam BR': SUNDHARAM_BR,
  })
  const [playhead, setPlayhead] = useState<number>(0)
  const timelineRef = useRef<TimelinePlan | null>(null)
  timelineRef.current = timeline
  // Scene changes and clicks update React. Playback only moves the bus,
  // so the timeline clips are not rebuilt on every frame.
  const movePlayhead = useCallback((t: number | ((prev: number) => number)) => {
    const prev = playheadBus.get()
    const next = typeof t === 'function' ? t(prev) : t
    // The playhead line and the sound follow this clock. React state is not
    // updated here: that rebuild was what froze the page while seeking.
    playheadBus.set(next, 'user')
    const clips = timelineRef.current?.clips
    const screenAt = (time: number) =>
      clips?.find((c) => time >= c.start && time < c.end)?.screen || ''
    if (screenAt(next) !== screenAt(prev)) setPlayhead(next)
  }, [])
  const [playing, setPlaying] = useState(false)
  const [pxPerSec, setPxPerSec] = useState(14)
  const [showExport, setShowExport] = useState(false)
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [exportTab, setExportTab] = useState<'local' | 'device' | 'social' | 'dvd'>('local')
  const [deviceTarget, setDeviceTarget] = useState('iPhone / iPad (1080p)')
  const [thumbClipIdx, setThumbClipIdx] = useState<number>(0)
  const [renderEngine, setRenderEngine] = useState<'machine' | 'server'>(() =>
    isLocalWebCodecsSupported() ? 'machine' : 'server',
  )
  const exportCancelledRef = useRef<boolean>(false)
  const [exportError, setExportError] = useState<string | null>(null)
  const [exportNotice, setExportNotice] = useState<string | null>(null)
  const [exportProgress, setExportProgress] = useState<{
    running: boolean
    percent: number
    message: string
    done?: number
    total?: number
    screen?: string
    mediaId?: string | null
  } | null>(null)
  const [exportResult, setExportResult] = useState<{
    filename: string
    saved_to: string
    srt_saved_to?: string
    size_mb?: number
    download: string
    bitrate_info?: {
      target_video_kbps?: number
      target_video_mbps?: number
      audio_kbps?: number
      target_total_kbps?: number
      actual_total_kbps?: number | null
      actual_video_kbps?: number | null
      bitrate_mode?: string
      signal_label?: string
    }
  } | null>(null)
  const [collectResult, setCollectResult] = useState<{
    mode: 'wfpbundle' | 'folder' | 'zip'
    folder_path: string
    bundle_path?: string | null
    zip_path?: string | null
    wfp_path: string
    size_mb: number
    file_count: number
    download_url?: string | null
  } | null>(null)
  const [saveTo, setSaveTo] = useState('')
  // The browser's selected folder is a real writable handle, not just a label.
  const exportDirectoryHandleRef = useRef<FileSystemDirectoryHandle | null>(null)
  const [dirty, setDirty] = useState(false)
  const [sideTab, setSideTab] = useState<'media' | 'script' | 'voiceovers'>('media')
  const [showSaveMenu, setShowSaveMenu] = useState(false)
  const [clientId] = useState<string>(() => getOrCreateClientId())
  const [clientLabel, setClientLabel] = useState<string>(() => getOrCreateClientLabel(getOrCreateClientId()))
  const [localMediaUrls, setLocalMediaUrls] = useState<Record<string, string>>({})
  const [localThumbUrls, setLocalThumbUrls] = useState<Record<string, string>>({})
  const [localNarrUrl, setLocalNarrUrl] = useState<string | null>(null)
  const [localPoemUrl, setLocalPoemUrl] = useState<string | null>(null)
  const [localLogoUrl, setLocalLogoUrl] = useState<string | null>(null)
  const localMediaFilesRef = useRef<Record<string, { file: File | Blob; kind: 'images' | 'videos'; filename: string }>>({})
  const localVoSlotFilesRef = useRef<Record<number, { file: File | Blob; filename: string; buffer?: AudioBuffer | null }>>({})
  const localPoemFileRef = useRef<{ file: File | Blob; filename: string } | null>(null)
  const localLogoFileRef = useRef<{ file: File | Blob; filename: string } | null>(null)

  const [ocrProgress, setOcrProgress] = useState<{ done: number; total: number } | null>(null)
  const [nativeOcr, setNativeOcr] = useState<Record<string, string> | null>(null)
  const asrWordsRef = useRef<AsrWord[] | null>(null)
  const [voQaProgress, setVoQaProgress] = useState<{ done: number; total: number } | null>(null)
  const decodedVo16kRef = useRef<Float32Array | null>(null)
  const [autoSwaps, setAutoSwaps] = useState<AutoSwapRecord[]>([])
  const [renumberBusy, setRenumberBusy] = useState(false)
  const [renumberResult, setRenumberResult] = useState<string | null>(null)
  const imageDirHandleRef = useRef<FsDirHandle | null>(null)
  const videoDirHandleRef = useRef<FsDirHandle | null>(null)
  const chapterDirHandleRef = useRef<FsDirHandle | null>(null)
  const [linkedFolderName, setLinkedFolderName] = useState<string | null>(null)
  const [folderSyncGranted, setFolderSyncGranted] = useState<boolean>(false)
  const lastWordAlignSigRef = useRef<string | null>(null)
  /** When true, background VO Whisper must not start (Auto-align owns the worker). */
  const suppressVoQaRef = useRef(false)
  const [syncedCopyKeys, setSyncedCopyKeys] = useState<string[]>([])
  const autoMatchAppliedRef = useRef<Set<string>>(new Set())
  const isRemoteServer =
    typeof window !== 'undefined' &&
    !desktopBridge() &&
    window.location.hostname !== '127.0.0.1' &&
    window.location.hostname !== 'localhost'

  useEffect(() => {
    asrWordsRef.current = null
    setVoQaProgress(null)
    decodedVo16kRef.current = null
    autoMatchAppliedRef.current = new Set()
    setAutoSwaps(loadSwaps(projectId))
    setRenumberResult(null)
    setSyncedCopyKeys([])
    if (!projectId) {
      imageDirHandleRef.current = null
      videoDirHandleRef.current = null
      chapterDirHandleRef.current = null
    lastWordAlignSigRef.current = null
      setLinkedFolderName(null)
      setFolderSyncGranted(false)
      setIgnoredQaKeys([])
      return
    }
    try {
      const rawIgnored = window.localStorage.getItem(`dgs-ignored-qa:${projectId}`)
      const parsedIgnored = rawIgnored ? (JSON.parse(rawIgnored) as string[]) : []
      setIgnoredQaKeys(Array.isArray(parsedIgnored) ? parsedIgnored : [])
    } catch {
      setIgnoredQaKeys([])
    }
    void (async () => {
      const [imgH, vidH, chapH] = await Promise.all([
        loadDirHandleFromIdb(`${projectId}:dir:images`),
        loadDirHandleFromIdb(`${projectId}:dir:videos`),
        loadDirHandleFromIdb(`${projectId}:dir:chapter`),
      ])
      imageDirHandleRef.current = imgH
      videoDirHandleRef.current = vidH
      chapterDirHandleRef.current = chapH
      const primary = imgH || chapH || vidH
      setLinkedFolderName(primary?.name || null)
      if (primary) {
        const granted = await hasReadWritePermission(primary, false)
        setFolderSyncGranted(granted)
      } else {
        setFolderSyncGranted(false)
      }
    })()
  }, [projectId])

  // Sync ignored_qa_keys and logo_transform from loaded timeline
  useEffect(() => {
    if (!timeline) return
    if (Array.isArray(timeline.ignored_qa_keys) && timeline.ignored_qa_keys.length > 0) {
      setIgnoredQaKeys((prev) => {
        const merged = Array.from(new Set([...prev, ...(timeline.ignored_qa_keys || [])]))
        if (projectId) {
          try {
            window.localStorage.setItem(`dgs-ignored-qa:${projectId}`, JSON.stringify(merged))
          } catch {
            /* ignore */
          }
        }
        return merged
      })
    }
    if (timeline.logo_transform) {
      setLogoTransform(normalizeLogoTransform(timeline.logo_transform))
    }
    if (timeline.poem_overlay) {
      setPoemOverlay(normalizePoemOverlayStyle(timeline.poem_overlay))
    }
  }, [timeline?.project_id, timeline?.ignored_qa_keys, timeline?.logo_transform, timeline?.poem_overlay, projectId])

  useEffect(() => {
    let cancel = false
    void (async () => {
      try {
        const versionRes = await fetch(`${API}/api/app/version`)
        if (versionRes.ok && !cancel) {
          const release = await versionRes.json()
          setAppRelease(release)
          if (release?.updateAvailable && release?.latest) {
            setLog(`Update available · ${release.latest}. Open Updates to download.`)
          }
        }
      } catch {
        /* the local log stays empty until the editor server answers */
      }
      try {
        const assetRes = await fetch(`${API}/api/app/assets/ensure`, { method: 'POST' })
        if (assetRes.ok && !cancel) setAppAssets(await assetRes.json())
      } catch {
        /* card files stay on the next open */
      }
    })()
    return () => {
      cancel = true
    }
  }, [])

  // Card reading uses Tesseract. Marathi chapters use mar+eng once that
  // file is on the machine. English mismatch bubbles stay off for Devanagari.
  const nativeOcrKey = useRef('')
  useEffect(() => {
    if (!projectId || !scenes.length) return
    const ocrLang = language === 'mr' || scriptLooksIndic(scenes) ? 'mr' : 'en'
    if (ocrLang === 'mr' && appAssets && !appAssets.mar) return
    const key = `${projectId}:${ocrLang}`
    if (nativeOcrKey.current === key) return
    nativeOcrKey.current = key
    let cancel = false
    void (async () => {
      try {
        const st = await fetch(`${API}/api/engine/status`)
        if (!st.ok) return
        const status = await st.json()
        if (!status?.ocr || cancel) return
        setOcrProgress({ done: 0, total: 1 })
        const r = await fetch(`${API}/api/projects/${projectId}/engine/ocr`, {
          method: 'POST',
          headers: clientHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ language: ocrLang }),
        })
        if (!r.ok || cancel) return
        const data = await r.json()
        if (!cancel && data.texts && typeof data.texts === 'object') setNativeOcr(data.texts)
      } catch {
        /* no local Tesseract — card bubbles stay off */
      } finally {
        if (!cancel) setOcrProgress(null)
      }
    })()
    return () => {
      cancel = true
    }
  }, [projectId, scenes, language, appAssets])

  // Whisper hearing does NOT start on each VO link. It waits until Auto-align, after every
  // open narration VO slot (and Poem VO when the script has a poem) is uploaded — one hear, full lock.

  // Always re-measure picture↔VO drift in the browser so status never lies about "all synced".
  const measuredSync: SyncReport | null = useMemo(() => {
    if (!timeline?.clips?.length) return null
    return verifySync(timeline.clips, {
      repair: false,
      voDuration: Number(voInfo?.duration || timeline.sync_report?.vo_duration || 0),
      ...poemSyncArgs(timeline, scenes),
    })
  }, [timeline, voInfo?.duration, scenes])

  // Timeline shown in the UI — keep measured sync issues (strip other stub QA noise).
  const { displayTimeline, ignoredIssueCount } = useMemo<{
    displayTimeline: TimelinePlan | null
    ignoredIssueCount: number
  }>(() => {
    if (!timeline) return { displayTimeline: null, ignoredIssueCount: 0 }
    const syncIssues = (measuredSync?.issues || []).filter((q) => q.kind === 'vo_sync')
    const serverSyncIssues = (timeline.qa_issues || []).filter((q) => q.kind === 'vo_sync')
    const cardIssues =
      nativeOcr && timeline.clips && !scriptLooksIndic(scenes)
        ? buildCardTextIssues(timeline.clips, scenes, nativeOcr)
        : []
    const qaIssues = [...(syncIssues.length ? syncIssues : serverSyncIssues), ...cardIssues]
    const ignored = new Set(ignoredQaKeys)
    const visible = qaIssues.filter((q) => !ignored.has(getQaIssueKey(q)))
    const summary = measuredSync?.summary || timeline.sync_report?.summary || timeline.qa_summary || ''
    return {
      displayTimeline: {
        ...timeline,
        logo_path: timeline.logo_path || logoInfo?.path || '/eclass-logo.png',
        logo_enabled: timeline.logo_enabled !== undefined ? timeline.logo_enabled : logoInfo.enabled,
        logo_transform: normalizeLogoTransform(timeline.logo_transform || logoTransform),
        poem_overlay: normalizePoemOverlayStyle(timeline.poem_overlay || poemOverlay),
        ignored_qa_keys: ignoredQaKeys,
        sync_report: measuredSync || timeline.sync_report || null,
        qa_issues: visible,
        qa_summary: summary,
      },
      ignoredIssueCount: qaIssues.length - visible.length,
    }
  }, [timeline, logoInfo, logoTransform, poemOverlay, measuredSync, ignoredQaKeys, nativeOcr, scenes])

  // Auto-repair drifted cuts when the timeline is not a hand edit (honest sync, not a fake OK).
  const syncRepairKeyRef = useRef<string>('')
  useEffect(() => {
    if (!timeline?.clips?.length || !measuredSync) return
    if (timeline.manual_override) return
    if (measuredSync.ok || measuredSync.spoken_count === 0) return
    const key = `${timeline.project_id}:${measuredSync.drifted_count}:${measuredSync.max_drift}`
    if (syncRepairKeyRef.current === key) return
    syncRepairKeyRef.current = key
    const clips = timeline.clips.map((c) => ({ ...c }))
    const report = verifySync(clips, {
      repair: true,
      voDuration: Number(voInfo?.duration || measuredSync.vo_duration || 0),
      ...poemSyncArgs(timeline, scenes),
    })
    if (!report.repaired && report.drifted_count > 0) {
      setLog(report.summary)
      return
    }
    const narration_segments = (timeline.narration_segments || []).map((seg) => {
      const clip =
        clips.find(
          (c) =>
            c.screen === seg.screen &&
            c.narration_in != null &&
            Math.abs(Number(c.narration_in) - Number(seg.narration_in ?? c.narration_in)) < 0.25,
        ) || clips.find((c) => c.screen === seg.screen)
      if (!clip) return seg
      return { ...seg, start: Number(clip.start), end: Number(clip.end) }
    })
    const srt_cues = (timeline.srt_cues || []).map((cue) => {
      const clip = clips.find((c) => c.screen === cue.screen && c.narration_in != null)
      if (!clip || clip.narration_in == null) return cue
      const shift = Number(clip.start) - Number(clip.narration_in)
      if (Math.abs(shift) < 0.2) return cue
      return {
        ...cue,
        start: Math.round((Number(cue.start) + shift) * 1000) / 1000,
        end: Math.round((Number(cue.end) + shift) * 1000) / 1000,
      }
    })
    const next: TimelinePlan = {
      ...timeline,
      clips,
      narration_segments,
      srt_cues,
      total_duration: clips.length ? Math.max(...clips.map((c) => Number(c.end || 0))) : timeline.total_duration,
      sync_report: report,
      qa_issues: [...(timeline.qa_issues || []).filter((q) => q.kind !== 'vo_sync'), ...report.issues],
      qa_summary: report.summary,
      manual_override: false,
    }
    setTimeline(next)
    setLog(
      report.ok
        ? `✓ ${report.summary}${report.repaired ? ` · repaired ${report.repaired} cut(s)` : ''}`
        : report.summary,
    )
    if (projectId) void persistTimelineToServer(next)
    // persistTimelineToServer is defined later; intentional one-shot repair on measured FAIL.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [measuredSync?.ok, measuredSync?.drifted_count, measuredSync?.max_drift, timeline?.manual_override, timeline?.project_id])

  function persistIgnoredQaKeys(nextKeys: string[]) {
    setIgnoredQaKeys(nextKeys)
    if (projectId) {
      try {
        window.localStorage.setItem(`dgs-ignored-qa:${projectId}`, JSON.stringify(nextKeys))
      } catch {
        /* ignore */
      }
    }
    if (timeline) {
      saveManualEdits({ ...timeline, ignored_qa_keys: nextKeys }, false)
    }
  }

  function handleIgnoreQaIssue(issue: QAIssue) {
    const key = getQaIssueKey(issue)
    const next = Array.from(new Set([...ignoredQaKeys, key]))
    persistIgnoredQaKeys(next)
    setLog(
      `✓ Ignored QA warning on ${issue.screen.replace('screen_', 'Scene ')} (${issue.message.slice(0, 70)})`,
    )
  }

  function handleIgnoreAllQaIssues() {
    if (!displayTimeline?.qa_issues?.length) return
    const addKeys = displayTimeline.qa_issues.map((q) => getQaIssueKey(q))
    const next = Array.from(new Set([...ignoredQaKeys, ...addKeys]))
    persistIgnoredQaKeys(next)
    setLog(`✓ Ignored all ${addKeys.length} QA warning${addKeys.length !== 1 ? 's' : ''} / error${addKeys.length !== 1 ? 's' : ''}`)
  }

  function handleRestoreIgnoredQaIssues() {
    persistIgnoredQaKeys([])
    setLog('↺ Restored all ignored QA warnings & errors')
  }

  // ===== Live Source-Folder Sync: keep local folder in step with auto-swaps AND manual timeline changes =====
  const renamePlan = useMemo(() => {
    if (!timeline || !timeline.clips.length) return { steps: [], skipped: [] as string[] }
    const raw = buildRenamePlan(
      autoSwaps,
      timeline.clips,
      media.filter((m) => m.kind === 'image').map((m) => m.filename),
      timeline.narration_segments,
      media,
    )
    const syncedSet = new Set(syncedCopyKeys)
    return {
      steps: raw.steps.filter((s) => !(s.action === 'copy' && syncedSet.has(`${s.screen}:${s.from}->${s.to}`))),
      skipped: raw.skipped,
    }
  }, [timeline, autoSwaps, media, syncedCopyKeys])

  async function renumberImageFolder(promptIfNeeded = true) {
    if (!projectId || !renamePlan.steps.length || renumberBusy) return
    const steps = renamePlan.steps
    setRenumberBusy(true)
    if (promptIfNeeded) setRenumberResult(null)
    try {
      let where = ''
      let freshBuffers: Map<string, ArrayBuffer> | null = null
      if (canRenameInPlace()) {
        const localFileBlobs = new Map<string, Blob>()
        for (const [mId, ent] of Object.entries(localMediaFilesRef.current)) {
          if (ent?.file) {
            localFileBlobs.set(mId, ent.file)
            localFileBlobs.set(ent.filename.toLowerCase(), ent.file)
          }
        }
        const r = await renameInFolder(steps, imageDirHandleRef.current, localFileBlobs, promptIfNeeded)
        freshBuffers = r.buffers
        imageDirHandleRef.current = r.dirHandle
        setLinkedFolderName(r.dirHandle.name)
        setFolderSyncGranted(true)
        void saveDirHandleToIdb(`${projectId}:dir:images`, r.dirHandle)
        where = `in your folder "${r.folder}" (originals backed up in "${r.folder}/${r.backup}")`
      } else {
        if (!promptIfNeeded) return
        // Firefox etc.: download the whole image folder with corrected names as a ZIP
        const toByFrom = new Map(steps.map((s) => [s.from.toLowerCase(), s.to]))
        const entries: ZipBuildEntry[] = []
        for (const m of media.filter((x) => x.kind === 'image')) {
          let blob: Blob | null = localMediaFilesRef.current[m.id]?.file || null
          if (!blob) {
            const resp = await fetch(`${API}/api/projects/${projectId}/media-file/${m.id}`, { headers: clientHeaders() })
            if (resp.ok) blob = await resp.blob()
          }
          if (!blob) continue
          entries.push({ entryPath: `Scene Images/${toByFrom.get(m.filename.toLowerCase()) || m.filename}`, blob })
        }
        const zip = await buildStoredZipArchiveInBrowser(entries)
        const a = document.createElement('a')
        a.href = URL.createObjectURL(zip)
        a.download = `${(title || 'Project').replace(/[^\w .-]/g, '_')} - Scene Images (renumbered).zip`
        a.click()
        setTimeout(() => URL.revokeObjectURL(a.href), 60000)
        where = 'as a downloaded ZIP "Scene Images (renumbered).zip" — replace your image folder with it'
      }

      const renameOnlySteps = steps.filter((s) => s.action !== 'copy')
      const copyOnlySteps = steps.filter((s) => s.action === 'copy')

      if (renameOnlySteps.length > 0) {
        // Keep the project in step: same media ids, new filenames
        const resp = await fetch(`${API}/api/projects/${projectId}/media-rename`, {
          method: 'POST',
          headers: clientHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ renames: renameOnlySteps.map((s) => ({ id: s.mediaId, to: s.to })) }),
        })
        if (resp.ok) {
          const data = await resp.json()
          if (Array.isArray(data.media)) setMedia(data.media)
        }
        const newNameById = new Map(renameOnlySteps.map((s) => [s.mediaId, s.to]))
        const freshUrls: Record<string, string> = {}
        for (const s of renameOnlySteps) {
          const ent = localMediaFilesRef.current[s.mediaId]
          if (ent) {
            const buf = freshBuffers?.get(s.from)
            if (buf) {
              ent.file = new File([buf], s.to, { type: (ent.file as File).type || 'image/png' })
              freshUrls[s.mediaId] = URL.createObjectURL(ent.file)
            }
            ent.filename = s.to
            void idbPutFile(`${projectId}:media:images:${s.to.toLowerCase()}`, ent.file, `pc:media:images:${s.to.toLowerCase()}`)
          }
        }
        if (Object.keys(freshUrls).length) {
          setLocalMediaUrls((prev) => ({ ...prev, ...freshUrls }))
          setLocalThumbUrls((prev) => ({ ...prev, ...freshUrls }))
        }
        setTimeline((prev) =>
          prev
            ? {
                ...prev,
                clips: prev.clips.map((c) =>
                  c.media_id && newNameById.has(c.media_id) ? { ...c, filename: newNameById.get(c.media_id)! } : c,
                ),
              }
            : prev,
        )
      }

      if (copyOnlySteps.length > 0) {
        setSyncedCopyKeys((prev) => [
          ...new Set([...prev, ...copyOnlySteps.map((s) => `${s.screen}:${s.from}->${s.to}`)]),
        ])
      }

      saveSwaps(projectId, [])
      setAutoSwaps([])
      const list = steps.map((s) => `${s.from} → ${s.to}`).join(', ')
      const msg = `✓ Synced ${steps.length} file${steps.length !== 1 ? 's' : ''} ${where}: ${list}`
      setRenumberResult(msg)
      setLog(msg)
    } catch (e) {
      const err = e instanceof Error ? e.message : String(e)
      if (!promptIfNeeded) {
        setFolderSyncGranted(false)
      } else if (/abort/i.test(err)) {
        setRenumberResult('Folder sync cancelled — no files were changed.')
      } else {
        setRenumberResult(`⚠ Could not sync folder: ${err}`)
      }
    } finally {
      setRenumberBusy(false)
    }
  }

  // NEVER auto-write the Scene Images folder after Auto-align / timeline rebuild.
  // A bad word-lock used to fire renamePlan → renameInFolder and delete/scramble files on disk.
  // Folder sync is explicit only (user clicks "Sync to folder").

  async function linkOrSyncSourceFolder() {
    if (!canRenameInPlace()) {
      if (renamePlan.steps.length > 0) await renumberImageFolder(true)
      else setLog('Direct folder sync requires Chrome or Edge.')
      return
    }
    try {
      // If we already have a stored handle in IndexedDB/ref, try requesting readwrite permission on it first
      let handle = imageDirHandleRef.current || chapterDirHandleRef.current || videoDirHandleRef.current
      if (handle) {
        const granted = await hasReadWritePermission(handle, true)
        if (granted) {
          setFolderSyncGranted(true)
          setLinkedFolderName(handle.name)
          if (renamePlan.steps.length > 0) {
            await renumberImageFolder(true)
          } else {
            setLog(`✓ Source folder "${handle.name}" is synced — all replacements & timeline edits will update this folder automatically.`)
          }
          return
        }
      }
      // Otherwise let the user pick their folder once
      const picked = await pickMediaDirectoryHandle('images')
      if (!picked) return
      const pid = await ensureProject()
      imageDirHandleRef.current = picked.mediaDirHandle
      void saveDirHandleToIdb(`${pid}:dir:images`, picked.mediaDirHandle)
      if (picked.chapterDirHandle) {
        chapterDirHandleRef.current = picked.chapterDirHandle
        void saveDirHandleToIdb(`${pid}:dir:chapter`, picked.chapterDirHandle)
      }
      setLinkedFolderName(picked.mediaDirHandle.name)
      setFolderSyncGranted(true)
      if (!media.some((m) => m.kind === 'image') && picked.files.length > 0) {
        await uploadMediaFolder('images', picked.files)
      }
      if (renamePlan.steps.length > 0) {
        await renumberImageFolder(true)
      } else {
        setLog(`✓ Linked folder "${picked.mediaDirHandle.name}" — all replacements & timeline edits will sync directly to this folder.`)
      }
    } catch (e) {
      const err = e instanceof Error ? e.message : String(e)
      if (!/abort/i.test(err)) setLog(`Folder sync error: ${err}`)
    }
  }

  const [showRecentMenu, setShowRecentMenu] = useState(false)
  const [recentProjects, setRecentProjects] = useState<
    Array<{
      project_id: string
      title: string
      script_filename: string
      vo_filename: string
      media_count: number
      scene_count: number
      clip_count: number
      total_duration: number
      updated_at: string
      client_id?: string | null
      client_label?: string | null
      is_this_pc?: boolean
    }>
  >([])
  const [recentPaths, setRecentPaths] = useState<
    Array<{ kind: string; path: string; label: string }>
  >([])
  const [sceneFilter, setSceneFilter] = useState('')
  const [sceneEdits, setSceneEdits] = useState<
    Record<string, { voiceover_text: string; onscreen_text: string }>
  >({})

  const hasPoem = useMemo(() => {
    if (poemInfo?.has_poem) return true
    if (poemVoInfo) return true
    return scenes.some(
      (s) =>
        s.is_poem ||
        /\bpoem\b/i.test(s.section || '') ||
        /\bpoem\s+visual\b/i.test(s.visual_direction || s.visual_type || '') ||
        /\b(stanza|couplet|lines?\s*\d+[-–—]\d+)\b/i.test(s.section || ''),
    )
  }, [poemInfo, poemVoInfo, scenes])

  /** True when the script has lyric/poem cards that need a separate Poem VO file. */
  function chapterNeedsPoemVo(): boolean {
    return scenes.some(
      (s) =>
        s.is_poem ||
        (/\bpoem\b/i.test(s.section || '') &&
          !/\b(instruction|question|answer|heading|activity|summary|title|prompt)\b/i.test(
            s.section || '',
          )),
    )
  }

  /**
   * Audio still missing before Whisper may start. Every open VO slot must have a file;
   * Poem VO is required when the chapter has poem scenes.
   */
  function listMissingAudioForHear(): string[] {
    const missing: string[] = []
    const slots = voSlots.length ? voSlots : [1]
    for (const slot of slots) {
      if (!localVoSlotFilesRef.current[slot]?.file) missing.push(`VO ${slot}`)
    }
    if (chapterNeedsPoemVo() && !localPoemFileRef.current?.file) {
      missing.push('Poem VO')
    }
    return missing
  }

  const poemRange = useMemo(() => {
    if (poemInfo?.has_poem && poemInfo.first_screen) {
      return {
        first: poemInfo.first_screen || 'screen_?',
        last: poemInfo.last_screen || 'screen_?',
        count: poemInfo.scene_count || 0,
        suno: poemInfo.suno_duration ?? null,
      }
    }
    const poemScenes = scenes.filter(
      (s) =>
        s.is_poem ||
        (/\bpoem\b/i.test(s.section || '') &&
          !/\b(instruction|question|answer|heading|activity|summary|title|prompt)\b/i.test(
            s.section || '',
          )),
    )
    if (!poemScenes.length) return null
    return {
      first: poemScenes[0].screen,
      last: poemScenes[poemScenes.length - 1].screen,
      count: poemScenes.length,
      suno: null as number | null,
    }
  }, [poemInfo, scenes])

  function clientHeaders(extra: Record<string, string> = {}) {
    return {
      'X-Client-Id': clientId,
      'X-Client-Label': clientLabel,
      ...extra,
    }
  }

  function renamePcLabel() {
    const next = window.prompt('Set display name for this PC (for upload & project identification):', clientLabel)
    if (!next || !next.trim()) return
    const clean = next.trim().slice(0, 32)
    setClientLabel(clean)
    try {
      window.localStorage.setItem('dgs_client_label', clean)
    } catch {
      /* ignore */
    }
  }

  async function rebuildLocalNarrUrlFromSlots(): Promise<string | null> {
    const entries = Object.entries(localVoSlotFilesRef.current)
      .map(([k, v]) => ({ slot: Number(k), ...v }))
      .filter((e) => e.slot >= 1 && e.file)
      .sort((a, b) => a.slot - b.slot)
    if (!entries.length) {
      setLocalNarrUrl(null)
      return null
    }
    if (entries.length === 1) {
      const url = URL.createObjectURL(entries[0].file)
      setLocalNarrUrl(url)
      return url
    }
    const buffers: AudioBuffer[] = []
    for (const e of entries) {
      if (e.buffer) {
        buffers.push(e.buffer)
      } else {
        const res = await analyzeAudioBrowser(e.file)
        if (res.audioBuffer) {
          e.buffer = res.audioBuffer
          buffers.push(res.audioBuffer)
        }
      }
    }
    if (buffers.length === entries.length) {
      const wavBlob = encodeAudioBuffersToWavBlob(buffers, 0.5)
      const url = URL.createObjectURL(wavBlob)
      setLocalNarrUrl(url)
      return url
    }
    const url = URL.createObjectURL(entries[0].file)
    setLocalNarrUrl(url)
    return url
  }

  async function restoreLocalFilesFromIdb(
    pid: string,
    mediaList: MediaItem[],
    voSlotsData: Array<{ slot: number; filename: string }>,
    poemVoData: { filename?: string } | null,
    logoData: { filename?: string } | null,
    fallbackPid?: string | null,
  ) {
    const nextMediaUrls: Record<string, string> = {}
    const nextThumbUrls: Record<string, string> = {}
    localMediaFilesRef.current = {}
    await Promise.all(
      mediaList.map(async (m) => {
        const folderKind = m.kind === 'video' ? 'videos' : 'images'
        const fnameLower = m.filename.toLowerCase()
        let blob = await idbGetFile(`${pid}:media:${folderKind}:${fnameLower}`)
        if (!blob && fallbackPid && fallbackPid !== pid) {
          blob = await idbGetFile(`${fallbackPid}:media:${folderKind}:${fnameLower}`)
        }
        if (!blob) {
          const dir = folderKind === 'videos' ? videoDirHandleRef.current : imageDirHandleRef.current
          if (dir) {
            try {
              const fh = await dir.getFileHandle(m.filename)
              blob = await fh.getFile()
              if (blob) {
                void idbPutFile(`${pid}:media:${folderKind}:${fnameLower}`, blob)
              }
            } catch {
              /* not in dir */
            }
          }
        }
        if (blob) {
          const url = URL.createObjectURL(blob)
          nextMediaUrls[m.id] = url
          if (m.kind === 'image') {
            nextThumbUrls[m.id] = url
          } else {
            const vThumb = await idbGetString(`${pid}:thumb:${fnameLower}`)
            if (vThumb) nextThumbUrls[m.id] = vThumb
          }
          localMediaFilesRef.current[m.id] = { file: blob, kind: folderKind, filename: m.filename }
        }
      }),
    )
    setLocalMediaUrls(nextMediaUrls)
    setLocalThumbUrls(nextThumbUrls)

    localVoSlotFilesRef.current = {}
    await Promise.all(
      voSlotsData.map(async (s) => {
        const sn = Number(s.slot) || 1
        let blob = await idbGetFile(`${pid}:vo:${sn}`)
        if (!blob && fallbackPid && fallbackPid !== pid) {
          blob = await idbGetFile(`${fallbackPid}:vo:${sn}`)
        }
        if (!blob && s.filename) {
          const dir = chapterDirHandleRef.current || imageDirHandleRef.current
          if (dir) {
            try {
              const fh = await dir.getFileHandle(s.filename)
              blob = await fh.getFile()
              if (blob) {
                void idbPutFile(`${pid}:vo:${sn}`, blob)
              }
            } catch {
              /* not in dir */
            }
          }
        }
        if (blob) {
          localVoSlotFilesRef.current[sn] = { file: blob, filename: s.filename || `VO_${sn}.mp3` }
        }
      }),
    )
    await rebuildLocalNarrUrlFromSlots()

    if (poemVoData?.filename) {
      const pFnLower = poemVoData.filename.toLowerCase()
      let pBlob = await idbGetFile(`${pid}:poem_vo`)
      if (!pBlob && fallbackPid && fallbackPid !== pid) {
        pBlob = await idbGetFile(`${fallbackPid}:poem_vo`)
      }
      if (!pBlob && pFnLower) {
        pBlob = await idbGetFile(`pc:poem_vo:${pFnLower}`)
      }
      if (pBlob) {
        localPoemFileRef.current = { file: pBlob, filename: poemVoData.filename }
        setLocalPoemUrl(URL.createObjectURL(pBlob))
      } else {
        localPoemFileRef.current = null
        setLocalPoemUrl(null)
      }
    } else {
      localPoemFileRef.current = null
      setLocalPoemUrl(null)
    }

    if (logoData?.filename) {
      const lFnLower = logoData.filename.toLowerCase()
      let lBlob = await idbGetFile(`${pid}:logo`)
      if (!lBlob && fallbackPid && fallbackPid !== pid) {
        lBlob = await idbGetFile(`${fallbackPid}:logo`)
      }
      if (!lBlob && lFnLower) {
        lBlob = await idbGetFile(`pc:logo:${lFnLower}`)
      }
      if (lBlob) {
        localLogoFileRef.current = { file: lBlob, filename: logoData.filename }
        setLocalLogoUrl(URL.createObjectURL(lBlob))
      } else {
        localLogoFileRef.current = null
        setLocalLogoUrl(null)
      }
    } else {
      localLogoFileRef.current = null
      setLocalLogoUrl(null)
    }
  }

  async function refreshRecent(autoRestoreIfEmpty = false) {
    try {
      const r = await fetch(`${API}/api/projects/recent?client_id=${encodeURIComponent(clientId)}`, {
        headers: clientHeaders(),
      })
      if (!r.ok) return
      const data = await r.json()
      const projs = data.projects || []
      setRecentProjects(projs)
      setRecentPaths(data.recent_paths || [])
      if (autoRestoreIfEmpty && projs.length > 0) {
        const savedPid = window.sessionStorage.getItem('dgs_active_project_id')
        const target =
          (savedPid && projs.find((p: { project_id: string }) => p.project_id === savedPid)) ||
          projs.find((p: { is_this_pc?: boolean; clip_count: number; media_count: number }) => p.is_this_pc && (p.clip_count > 0 || p.media_count > 0)) ||
          projs.find((p: { clip_count: number; media_count: number }) => p.clip_count > 0 || p.media_count > 0) ||
          projs[0]
        if (target?.project_id) {
          void loadRecentProject(target.project_id)
        }
      }
    } catch {
      /* ignore */
    }
  }

  useEffect(() => {
    if (projectId) {
      window.sessionStorage.setItem('dgs_active_project_id', projectId)
    }
  }, [projectId])

  function resetToNewSession() {
    window.sessionStorage.removeItem('dgs_active_project_id')
    setProjectId(null)
    setSelectedMediaId(null)
    setTitle('My Balbharati Lesson')
    setScenes([])
    setMedia([])
    setVoInfo(null)
    setVoSlots([1])
    setVoFiles({})
    setPoemInfo(null)
    setPoemVoInfo(null)
    setLogoInfo({ ...DEFAULT_BRAND_LOGO })
    setLogoTransform({ ...DEFAULT_LOGO_TRANSFORM })
    setIgnoredQaKeys([])
    setTimeline(null)
    movePlayhead(0)
    setPlaying(false)
    setDirty(false)
    setSceneEdits({})
    setLocalMediaUrls({})
    setLocalThumbUrls({})
    setLocalNarrUrl(null)
    setLocalPoemUrl(null)
    setLocalLogoUrl(null)
    localMediaFilesRef.current = {}
    localVoSlotFilesRef.current = {}
    localPoemFileRef.current = null
    localLogoFileRef.current = null
    imageDirHandleRef.current = null
    videoDirHandleRef.current = null
    chapterDirHandleRef.current = null
    lastWordAlignSigRef.current = null
    setLinkedFolderName(null)
    setFolderSyncGranted(false)
    setLog('Started a fresh session — drop your Script, Media & Voiceover or open a previous project from Recent Files.')
    void refreshRecent(false)
  }

  useEffect(() => {
    fetch(`${API}/api/presets`)
      .then((r) => r.json())
      .then((data) => {
        const map: Record<string, ExportSettings> = { 'Sundharam BR': SUNDHARAM_BR }
        for (const p of data.presets || []) {
          const merged = { ...SUNDHARAM_BR, ...p.settings }
          if (merged.advanced_compression && merged.compression_mode === 'none') {
            merged.compression_mode = 'by_quality'
          }
          map[p.name] = merged
        }
        setServerPresets(map)
        if (data.default_save_to) setSaveTo(data.default_save_to)
      })
      .catch(() => undefined)
    // Always start a fresh new session on page load/refresh while loading this PC's previous projects into Recent Files
    window.sessionStorage.removeItem('dgs_active_project_id')
    void refreshRecent(false)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function ensureProject() {
    if (projectId) return projectId
    const r = await fetch(`${API}/api/projects`, {
      method: 'POST',
      headers: clientHeaders({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ client_id: clientId, client_label: clientLabel }),
    })
    const data = await r.json()
    setProjectId(data.project_id)
    return data.project_id as string
  }

  async function parseApiError(r: Response): Promise<string> {
    const raw = await r.text().catch(() => '')
    if (!raw) return `Server error (${r.status})`
    try {
      const parsed = JSON.parse(raw)
      if (parsed?.detail) return String(parsed.detail)
      if (parsed?.error) return String(parsed.error)
      if (parsed?.message) return String(parsed.message)
    } catch {
      /* not JSON */
    }
    if (raw.includes('<html') || raw.includes('<!DOCTYPE')) {
      return `Upload / request error (${r.status} ${r.statusText || ''}). Retrying in chunks…`
    }
    return raw.slice(0, 260)
  }

  async function uploadFileSmart(opts: {
    file: File
    directUrl: string
    target:
      | 'voiceover'
      | 'poem_voiceover'
      | 'script'
      | 'logo'
      | 'scene_vo'
      | 'media_images'
      | 'media_videos'
      | 'open_file'
    projectId?: string | null
    extraFields?: Record<string, string | number>
    label?: string
  }) {
    const { file, directUrl, target, projectId: pid, extraFields = {}, label = file.name } = opts
    const CHUNK_SIZE = 3 * 1024 * 1024 // 3 MB per chunk (safe for all CDNs/proxies)

    // For small files (< 3.5 MB), try direct single POST first, falling back to chunked upload if proxy rejects
    if (file.size <= 3.5 * 1024 * 1024) {
      try {
        const fd = new FormData()
        fd.append('file', file, file.name)
        const r = await fetch(directUrl, { method: 'POST', headers: clientHeaders(), body: fd })
        if (r.ok) {
          return await r.json()
        }
        if (r.status !== 413 && r.status !== 502 && r.status !== 504 && r.status !== 408) {
          throw new Error(await parseApiError(r))
        }
      } catch (err) {
        if (err instanceof Error && !err.message.includes('Failed to fetch') && !err.message.includes('chunks')) {
          throw err
        }
      }
    }

    // Chunked upload for large files (> 3.5 MB) or when proxy limits single POST
    const totalChunks = Math.max(1, Math.ceil(file.size / CHUNK_SIZE))
    const uploadId = `${Date.now()}_${Math.random().toString(36).slice(2, 9)}`
    const chunkEndpoint = pid
      ? `${API}/api/projects/${pid}/upload-chunk`
      : `${API}/api/upload-chunk`

    let lastData: any = null
    for (let idx = 0; idx < totalChunks; idx++) {
      const start = idx * CHUNK_SIZE
      const end = Math.min(file.size, start + CHUNK_SIZE)
      const blob = file.slice(start, end)
      const pct = Math.round(((idx + 1) / totalChunks) * 100)
      setBusy(
        totalChunks > 1
          ? `Uploading ${label} (${pct}% · part ${idx + 1}/${totalChunks})…`
          : `Uploading ${label}…`,
      )

      const fd = new FormData()
      fd.append('upload_id', uploadId)
      fd.append('chunk_index', String(idx))
      fd.append('total_chunks', String(totalChunks))
      fd.append('target', target)
      fd.append('filename', file.name)
      if (pid) fd.append('project_id', pid)
      for (const [k, v] of Object.entries(extraFields)) {
        fd.append(k, String(v))
      }
      fd.append('chunk', blob, file.name)

      const r = await fetch(chunkEndpoint, { method: 'POST', headers: clientHeaders(), body: fd })
      if (!r.ok) {
        throw new Error(await parseApiError(r))
      }
      lastData = await r.json()
    }
    return lastData
  }

  async function uploadMediaFolder(kind: 'images' | 'videos', files: FileList | File[] | null) {
    if (!files || !files.length) return
    const allowedExt =
      kind === 'images'
        ? /\.(png|jpe?g|webp|bmp|gif|svg|avif|jfif|heic)$/i
        : /\.(mp4|mov|webm|mkv|avi|m4v|3gp|ts|mts|flv|wmv|mpe?g)$/i
    const list = Array.from(files).filter((f) => allowedExt.test(f.name))
    if (!list.length) {
      setLog(`No valid ${kind} found in selection`)
      return
    }
    setBusy(`Linking ${list.length} local ${kind} from this PC (${clientLabel})…`)
    try {
      const pid = await ensureProject()
      const blobByFilename: Record<string, { file: File; url: string; thumb: string; duration: number | null }> = {}
      const metaItems: Array<{ filename: string; size: number; duration: number | null; folder: string }> = []

      // Probe video durations locally on the user's PC in parallel batches of 8 (0 bytes uploaded!)
      const batchSize = 8
      for (let i = 0; i < list.length; i += batchSize) {
        const batch = list.slice(i, i + batchSize)
        if (kind === 'videos') {
          setBusy(`Reading local video durations (${Math.min(i + batch.length, list.length)} / ${list.length})…`)
        }
        await Promise.all(
          batch.map(async (f) => {
            const url = URL.createObjectURL(f)
            const fnLow = f.name.toLowerCase()
            const key = `${pid}:media:${kind}:${fnLow}`
            void idbPutFile(key, f)
            let duration: number | null = null
            let thumb = kind === 'images' ? url : ''
            if (kind === 'videos') {
              const probed = await probeVideoBrowser(url)
              duration = probed.duration
              thumb = probed.thumbDataUrl
              if (thumb) void idbPutFile(`${pid}:thumb:${fnLow}`, thumb)
            }
            blobByFilename[fnLow] = { file: f, url, thumb, duration }
            metaItems.push({
              filename: f.name,
              size: f.size,
              duration,
              folder: kind,
            })
          }),
        )
      }

      const r = await fetch(`${API}/api/projects/${pid}/media-meta`, {
        method: 'POST',
        headers: clientHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          kind,
          items: metaItems,
          replace_kind: true,
          client_id: clientId,
          client_label: clientLabel,
        }),
      })
      if (!r.ok) throw new Error(await parseApiError(r))
      const data = await r.json()
      const latestMedia: MediaItem[] = data.media || []

      setLocalMediaUrls((prev) => {
        const next = { ...prev }
        for (const m of media) {
          if ((kind === 'videos' && m.kind === 'video') || (kind === 'images' && m.kind === 'image')) {
            delete next[m.id]
            delete localMediaFilesRef.current[m.id]
          }
        }
        for (const m of latestMedia) {
          const hit = blobByFilename[m.filename.toLowerCase()]
          if (hit && ((kind === 'images' && m.kind === 'image') || (kind === 'videos' && m.kind === 'video'))) {
            next[m.id] = hit.url
            localMediaFilesRef.current[m.id] = { file: hit.file, kind, filename: m.filename }
          }
        }
        return next
      })
      setLocalThumbUrls((prev) => {
        const next = { ...prev }
        for (const m of media) {
          if ((kind === 'videos' && m.kind === 'video') || (kind === 'images' && m.kind === 'image')) {
            delete next[m.id]
          }
        }
        for (const m of latestMedia) {
          const hit = blobByFilename[m.filename.toLowerCase()]
          if (hit?.thumb && ((kind === 'images' && m.kind === 'image') || (kind === 'videos' && m.kind === 'video'))) {
            next[m.id] = hit.thumb
          }
        }
        return next
      })

      setMedia(latestMedia)
      setSelectedMediaId(null)

      // Automatically re-align timeline with newly linked videos/media
      if (scenes.length > 0) {
        try {
          const br = await fetch(`${API}/api/projects/${pid}/build`, {
            method: 'POST',
            headers: clientHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ language, force_realign: true }),
          })
          if (br.ok) {
            const rebuilt = (await br.json()) as TimelinePlan
            setTimeline(rebuilt)
          }
        } catch {
          /* ignore */
        }
      }

      setLog(`✓ ${kind}: linked ${data.saved || list.length} local files on ${clientLabel} (0 MB server upload) · library ${latestMedia.length} files`)
      void refreshRecent()
    } catch (e) {
      setLog(`Error linking local ${kind}: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setBusy(null)
    }
  }

  async function clearMediaKind(kind: 'videos' | 'images') {
    if (!projectId) return
    const count = media.filter((m) => m.kind === (kind === 'videos' ? 'video' : 'image')).length
    if (!count) return
    if (!window.confirm(`Remove all ${count} ${kind} from this project? Slide images will be shown on Video 1 instead.`)) return
    setBusy(`Removing all ${kind}…`)
    try {
      const r = await fetch(`${API}/api/projects/${projectId}/media/${kind}`, {
        method: 'DELETE',
        headers: clientHeaders(),
      })
      if (!r.ok) throw new Error(await parseApiError(r))
      const data = await r.json()
      const latestMedia: MediaItem[] = data.media || []
      setLocalMediaUrls((prev) => {
        const next = { ...prev }
        for (const m of media) {
          if ((kind === 'videos' && m.kind === 'video') || (kind === 'images' && m.kind === 'image')) {
            delete next[m.id]
            delete localMediaFilesRef.current[m.id]
          }
        }
        return next
      })
      setLocalThumbUrls((prev) => {
        const next = { ...prev }
        for (const m of media) {
          if ((kind === 'videos' && m.kind === 'video') || (kind === 'images' && m.kind === 'image')) {
            delete next[m.id]
          }
        }
        return next
      })
      setMedia(latestMedia)
      setSelectedMediaId(null)
      if (kind === 'videos') {
        videoDirHandleRef.current = null
      } else {
        imageDirHandleRef.current = null
      }
      if (scenes.length > 0) {
        const br = await fetch(`${API}/api/projects/${projectId}/build`, {
          method: 'POST',
          headers: clientHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ language, force_realign: true }),
        })
        if (br.ok) {
          const rebuilt = (await br.json()) as TimelinePlan
          setTimeline(rebuilt)
        }
      }
      setLog(`✓ Cleared all ${kind} from project — slide images restored`)
    } catch (e) {
      setLog(`Error clearing ${kind}: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setBusy(null)
    }
  }

  function pickFiles(kind: 'images' | 'videos') {
    const input = document.getElementById(
      kind === 'images' ? 'cloud-img-files-input' : 'cloud-vid-files-input',
    ) as HTMLInputElement | null
    input?.click()
  }

  async function pickFolder(kind: 'images' | 'videos') {
    if (canRenameInPlace()) {
      try {
        const picked = await pickMediaDirectoryHandle(kind)
        if (!picked) return
        const pid = await ensureProject()
        if (kind === 'images') {
          imageDirHandleRef.current = picked.mediaDirHandle
          void saveDirHandleToIdb(`${pid}:dir:images`, picked.mediaDirHandle)
        } else {
          videoDirHandleRef.current = picked.mediaDirHandle
          void saveDirHandleToIdb(`${pid}:dir:videos`, picked.mediaDirHandle)
        }
        if (picked.chapterDirHandle) {
          chapterDirHandleRef.current = picked.chapterDirHandle
          void saveDirHandleToIdb(`${pid}:dir:chapter`, picked.chapterDirHandle)
        }
        setLinkedFolderName(picked.mediaDirHandle.name)
        setFolderSyncGranted(true)
        await uploadMediaFolder(kind, picked.files)
        return
      } catch (e) {
        const err = e instanceof Error ? e.message : String(e)
        if (/abort/i.test(err)) {
          setLog('Folder selection cancelled')
          return
        }
      }
    }
    if (isRemoteServer) {
      const input = document.getElementById(
        kind === 'images' ? 'cloud-img-folder-input' : 'cloud-vid-folder-input',
      ) as HTMLInputElement | null
      input?.click()
      return
    }
    setBusy(kind === 'images' ? 'Select image folder…' : 'Select video folder…')
    try {
      const pid = await ensureProject()
      const r = await fetch(`${API}/api/projects/${pid}/pick-folder/${kind}`, { method: 'POST' })
      if (!r.ok) throw new Error(await parseApiError(r))
      const data = await r.json()
      if (data.cloud) {
        const input = document.getElementById(
          kind === 'images' ? 'cloud-img-folder-input' : 'cloud-vid-folder-input',
        ) as HTMLInputElement | null
        input?.click()
        return
      }
      if (data.cancelled) {
        setLog('Folder selection cancelled')
        return
      }
      setMedia(data.media || [])
      setLog(`${kind}: imported ${data.saved} · library ${data.count} files`)
    } catch {
      const input = document.getElementById(
        kind === 'images' ? 'cloud-img-folder-input' : 'cloud-vid-folder-input',
      ) as HTMLInputElement | null
      input?.click()
    } finally {
      setBusy(null)
    }
  }

  async function onScript(file: File | null) {
    if (!file) return
    setBusy('Uploading & parsing script…')
    try {
      const newBase = file.name.replace(/\.(xlsx|xlsm|xls|txt|md)$/i, '').trim().toLowerCase()
      const currBase = (title || '').trim().toLowerCase()
      const isSwitchingChapter = Boolean(
        projectId &&
        scenes.length > 0 &&
        currBase !== newBase &&
        !newBase.includes(currBase) &&
        !currBase.includes(newBase),
      )

      let pid = projectId
      if (!pid || isSwitchingChapter) {
        // Switching to a different chapter — create a fresh project so previous chapter's media/videos don't bleed over
        const r = await fetch(`${API}/api/projects`, {
          method: 'POST',
          headers: clientHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ client_id: clientId, client_label: clientLabel }),
        })
        const pdata = await r.json()
        pid = pdata.project_id as string
        setProjectId(pid)
        setScenes([])
        setMedia([])
        setVoInfo(null)
        setVoSlots([1])
        setVoFiles({})
        setPoemInfo(null)
        setPoemVoInfo(null)
        asrWordsRef.current = null
        setVoQaProgress(null)
        setTimeline(null)
        movePlayhead(0)
        setPlaying(false)
        setDirty(false)
        setSceneEdits({})
        setLocalMediaUrls({})
        setLocalThumbUrls({})
        setLocalNarrUrl(null)
        setLocalPoemUrl(null)
        localMediaFilesRef.current = {}
        localVoSlotFilesRef.current = {}
        localPoemFileRef.current = null
        syncedServerKeysRef.current = new Set()
        imageDirHandleRef.current = null
        videoDirHandleRef.current = null
        chapterDirHandleRef.current = null
    lastWordAlignSigRef.current = null
        setLinkedFolderName(null)
        setFolderSyncGranted(false)
      }

      const data = await uploadFileSmart({
        file,
        directUrl: `${API}/api/projects/${pid}/script`,
        target: 'script',
        projectId: pid,
        label: `Script (${file.name})`,
      })
      const nextScenes = (data.scenes || []) as Scene[]
      setScenes(nextScenes)
      const poem = (data.poem || null) as PoemInfo | null
      const poemScenesFromData = nextScenes.filter(
        (s) =>
          s.is_poem ||
          (/\bpoem\b/i.test(s.section || '') &&
            !/\b(instruction|question|answer|heading|activity|summary|title|prompt)\b/i.test(
              s.section || '',
            )),
      )
      const detected = Boolean(poem?.has_poem) || poemScenesFromData.length > 0
      setPoemInfo(
        poem?.has_poem
          ? poem
          : detected
            ? {
                has_poem: true,
                scene_count: poemScenesFromData.length,
                first_screen: poemScenesFromData[0]?.screen,
                last_screen: poemScenesFromData[poemScenesFromData.length - 1]?.screen,
              }
            : { has_poem: false },
      )
      if (!detected) setPoemVoInfo(null)
      setTitle(file.name.replace(/\.(xlsx|xlsm|xls|txt|md)$/i, '') || 'Auto Edit')

      // If media was already imported in this project, rebuild timeline with new script scenes
      if (media.length > 0 && !isSwitchingChapter) {
        try {
          const br = await fetch(`${API}/api/projects/${pid}/build`, {
            method: 'POST',
            headers: clientHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ language, force_realign: true }),
          })
          if (br.ok) {
            const rebuilt = (await br.json()) as TimelinePlan
            setTimeline(rebuilt)
          }
        } catch {
          /* ignore */
        }
      }

      setLog(
        detected
          ? `✓ Script loaded (${nextScenes.length} scenes) · poem ${poem?.first_screen || poemScenesFromData[0]?.screen || 'detected'} — Poem VO enabled`
          : `✓ Script loaded · ${nextScenes.length} scenes`,
      )
      void refreshRecent()
    } catch (e) {
      setLog(`Script upload error: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setBusy(null)
    }
  }

  async function onVoice(file: File | null, slot = 1) {
    if (!file) return
    setBusy(`Analyzing local Narration VO ${slot} (${file.name}) on ${clientLabel}…`)
    setLog(`Decoding VO ${slot} (${file.name}) — large MP3s can take up to ~90s…`)
    try {
      const pid = await ensureProject()
      const { duration, silences, audioBuffer } = await analyzeAudioBrowser(file)
      // Keep the file in memory first so Auto-align can hear even if IndexedDB/server is slow.
      setBusy(`Linking VO ${slot} (${file.name})…`)
      setLog(`VO ${slot} decoded (${fmt(duration)}) — saving locally & registering…`)
      localVoSlotFilesRef.current[slot] = { file, filename: file.name, buffer: audioBuffer }
      await rebuildLocalNarrUrlFromSlots()
      const idbPromise = idbPutFile(`${pid}:vo:${slot}`, file, `pc:vo:${file.name.toLowerCase()}`)

      const ctrl = new AbortController()
      const abortTimer = window.setTimeout(() => ctrl.abort(), 45_000)
      let data: {
        filename?: string
        duration?: number
        path?: string
        slots?: Array<{
          slot: number
          filename: string
          duration?: number
          start_offset?: number
          end_offset?: number
          path?: string
        }>
      }
      try {
        const r = await fetch(`${API}/api/projects/${pid}/voiceover-meta?slot=${slot}`, {
          method: 'POST',
          headers: clientHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({
            slot,
            filename: file.name,
            duration,
            silences,
            client_id: clientId,
            client_label: clientLabel,
          }),
          signal: ctrl.signal,
        })
        if (!r.ok) throw new Error(await parseApiError(r))
        data = await r.json()
      } catch (netErr) {
        // Local file is already usable — don't block the user on a slow/hung meta call.
        console.warn('[VO link] meta failed; keeping local link', netErr)
        data = {
          filename: file.name,
          duration,
          path: 'local_vo',
          slots: [
            {
              slot,
              filename: file.name,
              duration,
              start_offset: 0,
              end_offset: duration,
            },
          ],
        }
        setLog(
          `VO ${slot} saved locally (${file.name}, ${fmt(duration)}) — server register slow/failed; you can still continue linking audio, then Auto-align.`,
        )
      } finally {
        window.clearTimeout(abortTimer)
      }
      void idbPromise.catch(() => undefined)

      setVoInfo({ filename: data.filename || file.name, duration: data.duration ?? duration })
      const nextFiles: Record<number, { filename: string; duration?: number | null }> = { ...voFiles }
      const returnedSlotNums: number[] = []
      for (const s of data.slots || []) {
        const sn = Number(s.slot) || 1
        returnedSlotNums.push(sn)
        nextFiles[sn] = { filename: s.filename, duration: s.duration }
      }
      if (!data.slots?.length) {
        returnedSlotNums.push(slot)
        nextFiles[slot] = { filename: data.filename || file.name, duration: data.duration }
      }
      setVoFiles(nextFiles)
      setVoSlots((prev) => {
        const merged = Array.from(new Set([...prev, ...returnedSlotNums, slot])).sort((a, b) => a - b)
        return merged.length ? merged : [1]
      })
      const mappedSlots = (data.slots || []).map((s: {
        slot: number
        filename: string
        duration?: number
        start_offset?: number
        end_offset?: number
        path?: string
      }) => ({
        slot: Number(s.slot) || 1,
        filename: s.filename,
        duration: s.duration || 0,
        start_offset: s.start_offset || 0,
        end_offset: s.end_offset || (s.start_offset || 0) + (s.duration || 0),
        start: s.start_offset || 0,
        end: s.end_offset || (s.start_offset || 0) + (s.duration || 0),
        path: s.path,
      }))
      setTimeline((prev) => {
        const lastEnd = mappedSlots.length ? Math.max(...mappedSlots.map((s: { end: number }) => s.end)) : data.duration || 0
        if (!prev) {
          return {
            project_id: pid,
            total_duration: Math.max(lastEnd, 10),
            clips: [],
            voiceover_path: data.path || 'local_vo',
            voiceover_slots: mappedSlots,
            language,
          }
        }
        return {
          ...prev,
          voiceover_path: data.path || prev.voiceover_path || 'local_vo',
          voiceover_slots: mappedSlots.length ? mappedSlots : prev.voiceover_slots,
          total_duration: Math.max(prev.total_duration, lastEnd),
        }
      })
      const stillMissing = listMissingAudioForHear().filter((m) => m !== `VO ${slot}`)
      setLog(
        stillMissing.length
          ? `✓ Narration VO ${slot} linked (${file.name}) · Total VO: ${fmt(data.duration || 0)} — still need: ${stillMissing.join(', ')} before Auto-align hears`
          : `✓ Narration VO ${slot} linked (${file.name}) · Total VO: ${fmt(data.duration || 0)} — all audio ready · click Auto-align to hear & lock`,
      )
      void refreshRecent()
    } catch (e) {
      setLog(`VO ${slot} load failed: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setBusy(null)
    }
  }

  function addNextVoSlot() {
    setVoSlots((prev) => {
      if (prev.length >= 10) return prev
      for (let s = 1; s <= 10; s++) {
        if (!prev.includes(s)) return [...prev, s].sort((a, b) => a - b)
      }
      return prev
    })
  }

  async function removeVoSlot(slot: number) {
    setVoSlots((prev) => (prev.length > 1 ? prev.filter((x) => x !== slot) : prev))
    setVoFiles((prev) => {
      const copy = { ...prev }
      delete copy[slot]
      return copy
    })
    delete localVoSlotFilesRef.current[slot]
    await rebuildLocalNarrUrlFromSlots()
    if (!projectId) return
    try {
      const r = await fetch(`${API}/api/projects/${projectId}/voiceover/${slot}`, {
        method: 'DELETE',
        headers: clientHeaders(),
      })
      if (!r.ok) return
      const data = await r.json()
      setVoInfo(data.path ? { filename: data.filename, duration: data.duration } : null)
      setLog(`Removed VO ${slot}`)
    } catch {
      /* ignore */
    }
  }

  async function onPoemVoice(file: File | null) {
    if (!file) return
    setPoemInfo((prev) => {
      if (prev?.has_poem) return prev
      const poemScenes = scenes.filter(
        (s) =>
          s.is_poem ||
          (/\bpoem\b/i.test(s.section || '') &&
            !/\b(instruction|question|answer|heading|activity|summary|title|prompt)\b/i.test(
              s.section || '',
            )),
      )
      return {
        has_poem: true,
        scene_count: poemScenes.length || undefined,
        first_screen: poemScenes[0]?.screen || undefined,
        last_screen: poemScenes[poemScenes.length - 1]?.screen || undefined,
      }
    })
    setScenes((prev) =>
      prev.map((s) => {
        if (
          !s.is_poem &&
          /\bpoem\b/i.test(s.section || '') &&
          !/\b(instruction|question|answer|heading|activity|summary|title|prompt)\b/i.test(
            s.section || '',
          )
        ) {
          return { ...s, is_poem: true }
        }
        return s
      }),
    )
    setBusy(`Linking local Poem VO (${file.name})…`)
    setLog(`Reading Poem VO length (${file.name})…`)
    try {
      const pid = await ensureProject()
      // Duration only — a full decode of a Suno MP3 was freezing this step.
      const duration = await probeAudioDurationOnly(file)
      localPoemFileRef.current = { file, filename: file.name }
      setLocalPoemUrl(URL.createObjectURL(file))
      const idbPromise = idbPutFile(`${pid}:poem_vo`, file, `pc:poem_vo:${file.name.toLowerCase()}`)

      const ctrl = new AbortController()
      const abortTimer = window.setTimeout(() => ctrl.abort(), 20_000)
      let data: { filename?: string; duration?: number; path?: string }
      try {
        const r = await fetch(`${API}/api/projects/${pid}/poem-voiceover-meta`, {
          method: 'POST',
          headers: clientHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({
            filename: file.name,
            duration,
            client_id: clientId,
            client_label: clientLabel,
          }),
          signal: ctrl.signal,
        })
        if (!r.ok) throw new Error(await parseApiError(r))
        data = await r.json()
      } catch (netErr) {
        console.warn('[Poem link] meta failed; keeping local link', netErr)
        data = { filename: file.name, duration, path: 'local_poem_vo' }
      } finally {
        window.clearTimeout(abortTimer)
      }
      void idbPromise.catch(() => undefined)
      setPoemVoInfo({ filename: data.filename || file.name, duration: data.duration ?? duration })
      setTimeline((prev) =>
        prev
          ? {
              ...prev,
              poem_voiceover_path: data.path || prev.poem_voiceover_path || 'local_poem_vo',
              has_poem: true,
            }
          : prev,
      )
      // Do not hear/align yet — wait until every narration VO slot is linked, then Auto-align.
      const stillMissing = listMissingAudioForHear().filter((m) => m !== 'Poem VO')
      setLog(
        stillMissing.length
          ? `✓ Poem VO linked (${data.filename || file.name}, ${fmt(data.duration || duration)}) — still need: ${stillMissing.join(', ')} before Auto-align hears`
          : `✓ Poem VO linked (${data.filename || file.name}, ${fmt(data.duration || duration)}) — all audio ready · click Auto-align to hear & lock`,
      )
    } catch (e) {
      setLog(`Poem VO error: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setBusy(null)
    }
  }

  async function onClientLogo(file: File | null) {
    if (!file) return
    setBusy(`Linking local brand logo (${file.name})…`)
    try {
      const pid = await ensureProject()
      await idbPutFile(`${pid}:logo`, file, `pc:logo:${file.name.toLowerCase()}`)
      localLogoFileRef.current = { file, filename: file.name }
      setLocalLogoUrl(URL.createObjectURL(file))

      const r = await fetch(`${API}/api/projects/${pid}/logo-meta`, {
        method: 'POST',
        headers: clientHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          filename: file.name,
          client_id: clientId,
          client_label: clientLabel,
          transform: logoTransform,
        }),
      })
      if (!r.ok) throw new Error(await parseApiError(r))
      const data = await r.json()
      setLogoInfo({ filename: data.filename, path: data.path, enabled: true })
      setTimeline((prev) =>
        prev
          ? {
              ...prev,
              logo_path: data.path,
              logo_enabled: true,
              logo_transform: logoTransform,
            }
          : prev,
      )
      setLog(`✓ Custom brand logo linked: ${data.filename} (shown on all screens)`)
    } catch (e) {
      setLog(`Logo error: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setBusy(null)
    }
  }

  async function resetBrandLogoToDefault() {
    localLogoFileRef.current = null
    setLocalLogoUrl(null)
    const defaultT = { ...DEFAULT_LOGO_TRANSFORM }
    setLogoInfo({ ...DEFAULT_BRAND_LOGO })
    setLogoTransform(defaultT)
    if (timeline) {
      saveManualEdits(
        {
          ...timeline,
          logo_path: DEFAULT_BRAND_LOGO.path,
          logo_enabled: true,
          logo_transform: defaultT,
        },
        true,
      )
    }
    if (projectId) {
      try {
        await fetch(`${API}/api/projects/${projectId}/logo-meta`, {
          method: 'POST',
          headers: clientHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({
            filename: 'E-Class Logo.png',
            is_default: true,
            enabled: true,
            transform: defaultT,
          }),
        })
      } catch {
        /* ignore */
      }
    }
    setLog(
      '↺ Reset to default E-Class™ Brand Logo & default placement (Scale 10%, Pos 1034.21 / 565.98, Anchor 1900 / 1065)',
    )
  }

  function updateLogoTransform(next: LogoTransform, commitImmediate = false) {
    const norm = normalizeLogoTransform(next)
    setLogoTransform(norm)
    if (timeline) {
      saveManualEdits({ ...timeline, logo_transform: norm }, commitImmediate)
    }
  }

  function updatePoemOverlay(next: PoemOverlayStyle, commitImmediate = false) {
    const norm = normalizePoemOverlayStyle(next)
    setPoemOverlay(norm)
    if (timeline) {
      saveManualEdits({ ...timeline, poem_overlay: norm }, commitImmediate)
    }
  }

  // Auto-open Poem Studio Palette whenever a poem is detected in the project
  useEffect(() => {
    if (hasPoem && projectId && poemAutoOpenedRef.current !== projectId) {
      poemAutoOpenedRef.current = projectId
      setShowPoemStudio(true)
    }
  }, [hasPoem, projectId])

  async function toggleClientLogo(enabled: boolean) {
    setLogoInfo((prev) => ({ ...(prev || DEFAULT_BRAND_LOGO), enabled }))
    if (timeline) {
      saveManualEdits(
        {
          ...timeline,
          logo_path: timeline.logo_path || logoInfo?.path || DEFAULT_BRAND_LOGO.path,
          logo_enabled: enabled,
          logo_transform: normalizeLogoTransform(timeline.logo_transform || logoTransform),
        },
        true,
      )
    }
    setLog(
      enabled
        ? '✓ Brand Logo enabled across all screens'
        : 'Brand Logo hidden (toggle ON anytime)',
    )
    if (!projectId) return
    try {
      const r = await fetch(`${API}/api/projects/${projectId}/logo/toggle?enabled=${enabled}`, {
        method: 'POST',
      })
      if (!r.ok) return
      const data = await r.json()
      setLogoInfo((prev) => ({
        filename: data.filename || prev.filename || DEFAULT_BRAND_LOGO.filename,
        path: data.path || prev.path || DEFAULT_BRAND_LOGO.path,
        enabled: Boolean(data.enabled),
      }))
    } catch {
      /* ignore */
    }
  }

  async function saveProjectFile() {
    if (!projectId) {
      setLog('Create or import a project before saving a .wfp project file')
      setExportError('Create or import a project before saving a .wfp project file')
      return
    }
    setExportError(null)
    try {
      if (dirty && timeline) {
        await fetch(`${API}/api/projects/${projectId}/timeline`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(timeline),
        })
        setDirty(false)
      }
      const safeName = (title || 'Project').trim()
      const url = `${API}/api/projects/${projectId}/project-file?title=${encodeURIComponent(safeName)}&ext=wfp`
      const a = document.createElement('a')
      a.href = url
      a.download = `${safeName}.wfp`
      document.body.appendChild(a)
      a.click()
      a.remove()
      const msg = `✓ Saved Filmora 15 & DGS project file: ${safeName}.wfp`
      setLog(msg)
      setExportNotice(msg)
    } catch (e) {
      const errMsg = e instanceof Error ? e.message : String(e)
      setLog(errMsg)
      setExportError(errMsg)
    }
  }

  const syncedServerKeysRef = useRef<Set<string>>(new Set())

  async function syncLocalFilesToServerIfNeeded(pid: string) {
    const mediaEntries = Object.values(localMediaFilesRef.current).filter(
      (e) => !syncedServerKeysRef.current.has(`${pid}:media:${e.kind}:${e.filename.toLowerCase()}`),
    )
    const imgEntries = mediaEntries.filter((e) => e.kind === 'images')
    const vidEntries = mediaEntries.filter((e) => e.kind === 'videos')

    if (imgEntries.length > 0) {
      const batchSize = 12
      for (let i = 0; i < imgEntries.length; i += batchSize) {
        const chunk = imgEntries.slice(i, i + batchSize)
        const fd = new FormData()
        for (const item of chunk) {
          fd.append('files', item.file, item.filename)
        }
        const msg = `Syncing local images for render (${Math.min(i + chunk.length, imgEntries.length)}/${imgEntries.length})…`
        setBusy(msg)
        setExportProgress((prev) =>
          prev ? { ...prev, running: true, message: msg } : { running: true, percent: 3, message: msg },
        )
        const r = await fetch(`${API}/api/projects/${pid}/media/images`, {
          method: 'POST',
          headers: clientHeaders(),
          body: fd,
        })
        if (!r.ok) throw new Error(await parseApiError(r))
        for (const item of chunk) {
          syncedServerKeysRef.current.add(`${pid}:media:${item.kind}:${item.filename.toLowerCase()}`)
        }
      }
    }

    for (let j = 0; j < vidEntries.length; j++) {
      const vf = vidEntries[j]
      const fObj = vf.file instanceof File ? vf.file : new File([vf.file], vf.filename)
      await uploadFileSmart({
        file: fObj,
        directUrl: `${API}/api/projects/${pid}/media/videos`,
        target: 'media_videos',
        projectId: pid,
        label: `${vf.filename} (${j + 1}/${vidEntries.length})`,
      })
      syncedServerKeysRef.current.add(`${pid}:media:${vf.kind}:${vf.filename.toLowerCase()}`)
    }

    const voSlotsArr = Object.entries(localVoSlotFilesRef.current)
      .map(([k, v]) => ({ slot: Number(k), ...v }))
      .filter((s) => !syncedServerKeysRef.current.has(`${pid}:vo:${s.slot}:${s.filename.toLowerCase()}`))
      .sort((a, b) => a.slot - b.slot)
    for (const s of voSlotsArr) {
      const fObj = s.file instanceof File ? s.file : new File([s.file], s.filename)
      await uploadFileSmart({
        file: fObj,
        directUrl: `${API}/api/projects/${pid}/voiceover?slot=${s.slot}`,
        target: 'voiceover',
        projectId: pid,
        extraFields: { slot: s.slot },
        label: `VO ${s.slot} (${s.filename})`,
      })
      syncedServerKeysRef.current.add(`${pid}:vo:${s.slot}:${s.filename.toLowerCase()}`)
    }

    if (
      localPoemFileRef.current &&
      !syncedServerKeysRef.current.has(`${pid}:poem:${localPoemFileRef.current.filename.toLowerCase()}`)
    ) {
      const pf = localPoemFileRef.current
      const fObj = pf.file instanceof File ? pf.file : new File([pf.file], pf.filename)
      await uploadFileSmart({
        file: fObj,
        directUrl: `${API}/api/projects/${pid}/poem-voiceover`,
        target: 'poem_voiceover',
        projectId: pid,
        label: `Poem VO (${pf.filename})`,
      })
      syncedServerKeysRef.current.add(`${pid}:poem:${pf.filename.toLowerCase()}`)
    }

    if (
      localLogoFileRef.current &&
      !syncedServerKeysRef.current.has(`${pid}:logo:${localLogoFileRef.current.filename.toLowerCase()}`)
    ) {
      const lf = localLogoFileRef.current
      const fObj = lf.file instanceof File ? lf.file : new File([lf.file], lf.filename)
      await uploadFileSmart({
        file: fObj,
        directUrl: `${API}/api/projects/${pid}/logo`,
        target: 'logo',
        projectId: pid,
        label: `Logo (${lf.filename})`,
      })
      syncedServerKeysRef.current.add(`${pid}:logo:${lf.filename.toLowerCase()}`)
    }
  }

  async function collectProjectFiles(mode: 'wfpbundle' | 'folder' | 'zip' = 'wfpbundle') {
    if (!projectId) {
      setLog('Create or import a project before collecting files')
      setExportError('Create or import a project before collecting files')
      return
    }
    setCollectResult(null)
    setExportError(null)
    setExportNotice(null)
    setExportProgress({
      running: true,
      percent: 4,
      message:
        mode === 'wfpbundle'
          ? 'Creating Filmora 16 .wfpbundle archive (Medias/{GUID} + .wfp)…'
          : mode === 'zip'
            ? 'Collecting .wfp + all media, audio & timeline clips into portable .ZIP…'
            : 'Collecting .wfp + all media, audio & timeline clips into portable archive…',
    })
    setBusy(
      mode === 'wfpbundle'
        ? 'Saving .wfpbundle archive…'
        : mode === 'zip'
          ? 'Collecting project .ZIP…'
          : 'Collecting project files…',
    )
    let poll = 0
    try {
      if (dirty && timeline) {
        await fetch(`${API}/api/projects/${projectId}/timeline`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(timeline),
        })
        setDirty(false)
      }

      const safeTitle = (title || 'Project').trim().replace(/[<>:"/\\|?*]+/g, '_') || 'Project'

      // Fast Path: Build .wfpbundle / .zip directly on this PC in ~1.5s using /wfp-manifest + local Blobs!
      if (mode === 'wfpbundle' || mode === 'zip' || isRemoteServer) {
        const mr = await fetch(
          `${API}/api/projects/${projectId}/wfp-manifest?title=${encodeURIComponent(safeTitle)}`,
          { headers: clientHeaders() },
        )
        if (mr.ok) {
          const manifest = await mr.json()
          const wfpBytes = Uint8Array.from(atob(manifest.wfp_base64), (c) => c.charCodeAt(0))
          const innerWfpBlob = new Blob([wfpBytes], { type: 'application/octet-stream' })
          const zipEntries: ZipBuildEntry[] = []
          let allResolved = true

          const entriesList = manifest.entries || []
          for (let i = 0; i < entriesList.length; i++) {
            const ent = entriesList[i]
            let fileBlob: Blob | null = null
            const fnameLow = String(ent.filename || '').toLowerCase()

            if (ent.media_id && localMediaFilesRef.current[ent.media_id]?.file) {
              fileBlob = localMediaFilesRef.current[ent.media_id].file
            }
            if (!fileBlob && (ent.kind === 'image' || ent.kind === 'video')) {
              const byNameHit = Object.values(localMediaFilesRef.current).find(
                (v) => v.filename.toLowerCase() === fnameLow,
              )
              if (byNameHit?.file) fileBlob = byNameHit.file
              if (!fileBlob) {
                const folderKind = ent.kind === 'video' ? 'videos' : 'images'
                fileBlob = await idbGetFile(`${projectId}:media:${folderKind}:${fnameLow}`)
              }
            }
            if (!fileBlob && ent.vo_slot != null) {
              const slotNum = Number(ent.vo_slot) || 1
              if (localVoSlotFilesRef.current[slotNum]?.file) {
                fileBlob = localVoSlotFilesRef.current[slotNum].file
              } else {
                fileBlob = await idbGetFile(`${projectId}:vo:${slotNum}`)
              }
            }
            if (!fileBlob && ent.is_poem_vo) {
              fileBlob = localPoemFileRef.current?.file || (await idbGetFile(`${projectId}:poem_vo`))
            }
            if (!fileBlob && ent.is_logo) {
              fileBlob = localLogoFileRef.current?.file || (await idbGetFile(`${projectId}:logo`))
              if (!fileBlob) {
                try {
                  const defResp = await fetch('/eclass-logo.png')
                  if (defResp.ok) fileBlob = await defResp.blob()
                } catch {
                  /* ignore */
                }
              }
            }
            // Fallback to fetching from server if file is stored on server
            if (!fileBlob && ent.exists_on_server) {
              let fetchUrl = ''
              if (ent.media_id) fetchUrl = `${API}/api/projects/${projectId}/media-file/${ent.media_id}`
              else if (ent.vo_slot != null) fetchUrl = `${API}/api/projects/${projectId}/voiceover-slot/${ent.vo_slot}`
              else if (ent.is_poem_vo) fetchUrl = `${API}/api/projects/${projectId}/audio/poem`
              else if (ent.is_logo) fetchUrl = `${API}/api/projects/${projectId}/logo-file`
              else if (ent.kind === 'audio') fetchUrl = `${API}/api/projects/${projectId}/audio/narration`
              if (fetchUrl) {
                const fr = await fetch(fetchUrl)
                if (fr.ok) fileBlob = await fr.blob()
              }
            }

            if (fileBlob) {
              zipEntries.push({ entryPath: ent.entry_path, blob: fileBlob })
            } else {
              allResolved = false
              break
            }
          }

          if (allResolved) {
            zipEntries.push({
              entryPath: manifest.inner_wfp_name || `${safeTitle}.wfp`,
              blob: innerWfpBlob,
            })
            const archiveBlob = await buildStoredZipArchiveInBrowser(
              zipEntries,
              manifest.dgs_comment || '',
              (pct, msg) => {
                setExportProgress({ running: true, percent: pct, message: msg })
                setBusy(msg)
              },
            )
            const sizeMb = Math.round((archiveBlob.size / (1024 * 1024)) * 100) / 100
            const outFilename =
              mode === 'wfpbundle' ? `${safeTitle}.wfpbundle` : `${safeTitle}_Collected.zip`
            const dlUrl = URL.createObjectURL(archiveBlob)

            setExportProgress({
              running: false,
              percent: 100,
              message:
                mode === 'wfpbundle'
                  ? `✓ Filmora 16 .wfpbundle created on this PC (${sizeMb} MB · ${zipEntries.length} files)!`
                  : `✓ Portable .ZIP collected on this PC (${sizeMb} MB · ${zipEntries.length} files)!`,
            })
            setCollectResult({
              mode,
              folder_path: `Browser Downloads / ${outFilename}`,
              bundle_path: outFilename,
              zip_path: outFilename,
              wfp_path: `${safeTitle}.wfp`,
              size_mb: sizeMb,
              file_count: zipEntries.length,
              download_url: dlUrl,
            })
            const a = document.createElement('a')
            a.href = dlUrl
            a.download = outFilename
            document.body.appendChild(a)
            a.click()
            a.remove()
            setLog(
              `✓ Saved ${outFilename} (${sizeMb} MB · ${zipEntries.length} files) — opens in Filmora 16 & DGS Auto Editor`,
            )
            return
          }
        }
      }

      poll = window.setInterval(async () => {
        try {
          const sr = await fetch(`${API}/api/projects/${projectId}/collect/status`)
          if (sr.ok) {
            const st = await sr.json()
            if (st && typeof st.percent === 'number') {
              setExportProgress({
                running: Boolean(st.running),
                percent: st.percent,
                message: st.message || 'Collecting project files…',
              })
            }
          }
        } catch {
          /* ignore */
        }
      }, 450)

      await syncLocalFilesToServerIfNeeded(projectId)
      const r = await fetch(`${API}/api/projects/${projectId}/collect`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          title: (title || 'Project').trim(),
          save_to: saveTo || null,
        }),
      })
      if (!r.ok) throw new Error(await parseApiError(r))
      const data = await r.json()
      const rawDl = data.download_url || data.download || data.wfpbundle_download
      const dlUrl = rawDl ? `${API}${rawDl}` : null
      setExportProgress({
        running: false,
        percent: 100,
        message:
          mode === 'wfpbundle'
            ? 'Filmora 16 .wfpbundle archive created successfully!'
            : 'Project files collected successfully!',
      })
      setCollectResult({
        mode,
        folder_path: data.folder_path || data.path || '',
        bundle_path: data.bundle_path || data.path || '',
        zip_path: data.zip_path || data.path || '',
        wfp_path: data.wfp_path || data.path || '',
        size_mb: data.size_mb || 0,
        file_count: data.file_count || 0,
        download_url: dlUrl,
      })
      if ((isRemoteServer || mode !== 'folder') && dlUrl) {
        const a = document.createElement('a')
        a.href = dlUrl
        a.download =
          data.filename ||
          (mode === 'wfpbundle'
            ? `${(title || 'Project').trim()}.wfpbundle`
            : `${(title || 'Project').trim()}_Collected.zip`)
        document.body.appendChild(a)
        a.click()
        a.remove()
      } else {
        await revealCollectInFolder()
      }
      setLog(
        mode === 'wfpbundle'
          ? `✓ Saved Filmora 16 .wfpbundle (${data.size_mb || 0} MB · ${data.file_count || 0} files): ${data.bundle_path || data.filename || data.wfp_path}`
          : mode === 'zip'
            ? `✓ Collected portable .ZIP (${data.size_mb || 0} MB · ${data.file_count || 0} files): ${data.zip_path || data.filename}`
            : `✓ Collected portable package (${data.size_mb || 0} MB · ${data.file_count || 0} files): ${data.folder_path || data.filename}`,
      )
    } catch (e) {
      setExportProgress(null)
      const errMsg = e instanceof Error ? e.message : String(e)
      setExportError(errMsg)
      setLog(errMsg)
    } finally {
      if (poll) window.clearInterval(poll)
      setBusy(null)
    }
  }

  async function revealCollectInFolder() {
    if (!projectId) return
    if (
      (isRemoteServer || collectResult?.download_url?.startsWith('blob:')) &&
      collectResult?.download_url
    ) {
      const a = document.createElement('a')
      a.href = collectResult.download_url
      a.download =
        collectResult.mode === 'wfpbundle'
          ? `${(title || 'Project').trim()}.wfpbundle`
          : `${(title || 'Project').trim()}_Collected.zip`
      document.body.appendChild(a)
      a.click()
      a.remove()
      return
    }
    try {
      await fetch(`${API}/api/projects/${projectId}/reveal-collect`, { method: 'POST' })
    } catch {
      /* ignore */
    }
  }

  async function openProjectFromDisk(diskPath: string) {
    const name = diskPath.split(/[/\\]/).pop() || 'project.wfpbundle'
    const holder = new File([], name)
    Object.defineProperty(holder, 'dgsDiskPath', { value: diskPath })
    await openProjectFile(holder)
  }

  async function openProjectFile(file: File | null) {
    if (!file) return
    setBusy(`Opening project file (${file.name})…`)
    try {
      const diskPath =
        (file as File & { dgsDiskPath?: string }).dgsDiskPath ||
        desktopBridge()?.pathForFile?.(file) ||
        ''
      let extracted: Awaited<ReturnType<typeof extractBundleInBrowser>> = null
      let data: any
      if (diskPath) {
        setBusy(`Reading ${file.name} from this PC…`)
        const opened = await fetch(`${API}/api/projects/open-path`, {
          method: 'POST',
          headers: clientHeaders({ 'Content-Type': 'application/json' }),
          body: JSON.stringify({ path: diskPath }),
        })
        if (!opened.ok) throw new Error(await parseApiError(opened))
        data = await opened.json()
      } else {
        // Fast Path: If file is a .wfpbundle or .zip, extract the ~300KB .wfp + zero-copy media Blobs directly in the browser!
        extracted = await extractBundleInBrowser(file)
        if (!extracted && /\.wfpbundle$/i.test(file.name)) {
          throw new Error(
            `${file.name} could not be read. Save it again from Filmora as a .wfpbundle, then open that file.`,
          )
        }
        const fileToUpload = extracted ? extracted.innerWfpFile : file
        data = await uploadFileSmart({
          file: fileToUpload,
          directUrl: `${API}/api/projects/open-file`,
          target: 'open_file',
          projectId: null,
          label: `Project (${file.name})`,
        })
      }

      // If we extracted media/audio Blobs from a .wfpbundle or .zip in the browser, store them in IndexedDB for this project!
      if (extracted && extracted.mediaEntries.length > 0) {
        setBusy(`Linking ${extracted.mediaEntries.length} bundled media & audio files locally…`)
        const byName = new Map<string, Blob>()
        for (const ent of extracted.mediaEntries) {
          byName.set(ent.filename.toLowerCase(), ent.blob)
        }
        for (const m of (data.media || []) as MediaItem[]) {
          const folderKind = m.kind === 'video' ? 'videos' : 'images'
          const fnLow = m.filename.toLowerCase()
          const blob = byName.get(fnLow)
          if (blob) {
            await idbPutFile(`${data.project_id}:media:${folderKind}:${fnLow}`, blob, `pc:media:${folderKind}:${fnLow}`)
          }
        }
        const voSlotsList = data.voiceover?.slots?.length
          ? data.voiceover.slots
          : data.voiceover?.filename
            ? [{ slot: 1, filename: data.voiceover.filename }]
            : []
        for (const s of voSlotsList) {
          const sn = Number(s.slot) || 1
          const sFnLow = String(s.filename || '').toLowerCase()
          const blob =
            byName.get(`slot_${sn}_${sFnLow}`) ||
            byName.get(sFnLow) ||
            Array.from(byName.entries()).find(([k]) => k.endsWith(sFnLow) || (k.endsWith('.mp3') && voSlotsList.length === 1))?.[1]
          if (blob) {
            await idbPutFile(`${data.project_id}:vo:${sn}`, blob, sFnLow ? `pc:vo:${sFnLow}` : undefined)
          }
        }
        if (data.poem_voiceover?.filename) {
          const pFnLow = String(data.poem_voiceover.filename).toLowerCase()
          const pBlob = byName.get(pFnLow)
          if (pBlob) await idbPutFile(`${data.project_id}:poem_vo`, pBlob, `pc:poem_vo:${pFnLow}`)
        }
        if (data.logo?.filename) {
          const lFnLow = String(data.logo.filename).toLowerCase()
          const lBlob = byName.get(lFnLow)
          if (lBlob) await idbPutFile(`${data.project_id}:logo`, lBlob, `pc:logo:${lFnLow}`)
        }
      }

      await restoreLocalFilesFromIdb(
        data.project_id,
        data.media || [],
        data.voiceover?.slots?.length
          ? data.voiceover.slots
          : data.voiceover?.filename
            ? [{ slot: 1, filename: data.voiceover.filename }]
            : [],
        data.poem_voiceover || null,
        data.logo || null,
        data.source_project_id || null,
      )
      setProjectId(data.project_id)
      setTitle(data.title || 'Project')
      setScenes(data.scenes || [])
      setMedia(data.media || [])
      setPoemInfo(data.poem || { has_poem: (data.scenes || []).some((s: Scene) => s.is_poem) })
      setVoInfo(data.voiceover ? { filename: data.voiceover.filename || 'Narration VO', duration: data.voiceover.duration } : null)
      if (data.voiceover?.slots?.length) {
        const sNums: number[] = []
        const sMap: Record<number, { filename: string; duration?: number | null }> = {}
        for (const s of data.voiceover.slots) {
          const n = Number(s.slot) || 1
          sNums.push(n)
          sMap[n] = { filename: s.filename, duration: s.duration }
        }
        setVoSlots(sNums.length ? sNums.sort((a, b) => a - b) : [1])
        setVoFiles(sMap)
      } else {
        setVoSlots([1])
        setVoFiles(
          data.voiceover?.filename
            ? { 1: { filename: data.voiceover.filename, duration: data.voiceover.duration } }
            : {},
        )
      }
      setPoemVoInfo(
        data.poem_voiceover
          ? { filename: data.poem_voiceover.filename || 'Poem VO', duration: data.poem_voiceover.duration }
          : null,
      )
      setLogoInfo(
        data.logo?.path
          ? {
              filename: data.logo.filename || 'E-Class Logo.png (Default)',
              path: data.logo.path,
              enabled: Boolean(data.logo.enabled ?? true),
            }
          : { ...DEFAULT_BRAND_LOGO },
      )
      setLogoTransform(
        normalizeLogoTransform(
          data.timeline?.logo_transform || data.logo?.transform || DEFAULT_LOGO_TRANSFORM,
        ),
      )
      const opened = data.timeline || null
      if (opened && data.voiceover?.slots?.length && !opened.voiceover_slots?.length) {
        opened.voiceover_slots = data.voiceover.slots.map((s: {
          slot: number
          filename: string
          duration?: number
          start_offset?: number
          end_offset?: number
          path?: string
        }) => ({
          slot: Number(s.slot) || 1,
          filename: s.filename,
          duration: s.duration || 0,
          start_offset: s.start_offset || 0,
          end_offset: s.end_offset || 0,
          start: s.start_offset || 0,
          end: s.end_offset || 0,
          path: s.path,
        }))
        opened.total_duration = Math.max(
          opened.total_duration || 0,
          ...opened.voiceover_slots.map((s: { end: number }) => s.end),
        )
      }
      setTimeline(opened)
      movePlayhead(0)
      setPlaying(false)
      setDirty(false)
      setLog(`✓ Opened project: ${data.title} (${data.project_id}) · ${(data.media || []).length} media · ${(opened?.clips || []).length} timeline clips`)
      void refreshRecent(false)
    } catch (e) {
      setLog(String(e))
    } finally {
      setBusy(null)
    }
  }

  async function build() {
    if (!projectId) {
      setLog('Upload media + script first')
      return
    }
    setPlaying(false)
    suppressVoQaRef.current = true
    cancelBrowserVoQaScan()
    try {
      // Reload slot blobs from IndexedDB if memory was cleared (refresh / chapter switch).
      const slotNums = Object.keys(voFiles || {})
        .map((k) => Number(k))
        .filter((n) => n >= 1)
      const needRestore = slotNums.filter((sn) => !localVoSlotFilesRef.current[sn]?.file)
      for (const sn of needRestore.length ? needRestore : []) {
        const blob = await idbGetFile(`${projectId}:vo:${sn}`)
        if (blob) {
          localVoSlotFilesRef.current[sn] = {
            file: blob,
            filename: voFiles[sn]?.filename || `VO_${sn}.mp3`,
          }
        }
      }
      if (!Object.keys(localVoSlotFilesRef.current).length) {
        for (let sn = 1; sn <= 10; sn++) {
          const blob = await idbGetFile(`${projectId}:vo:${sn}`)
          if (blob) {
            localVoSlotFilesRef.current[sn] = {
              file: blob,
              filename: voFiles[sn]?.filename || `VO_${sn}.mp3`,
            }
          }
        }
      }
      // Also restore open slots from IDB (user may have VO 1+2 and Poem from a prior session).
      for (const sn of voSlots) {
        if (localVoSlotFilesRef.current[sn]?.file) continue
        const blob = await idbGetFile(`${projectId}:vo:${sn}`)
        if (blob) {
          localVoSlotFilesRef.current[sn] = {
            file: blob,
            filename: voFiles[sn]?.filename || `VO_${sn}.mp3`,
          }
        }
      }
      if (chapterNeedsPoemVo() && !localPoemFileRef.current?.file) {
        const pBlob = await idbGetFile(`${projectId}:poem_vo`)
        if (pBlob) {
          localPoemFileRef.current = {
            file: pBlob,
            filename: poemVoInfo?.filename || 'poem.mp3',
          }
        }
      }

      // Gate: do not start Whisper until every open VO slot (+ Poem VO if needed) is present.
      const missingAudio = listMissingAudioForHear()
      if (missingAudio.length) {
        setLog(
          `Waiting — upload ${missingAudio.join(', ')} first, then Auto-align. ` +
            `Hearing starts only when all narration VOs` +
            (chapterNeedsPoemVo() ? ' and the Poem VO' : '') +
            ` are linked so cuts lock together.`,
        )
        return
      }

      // Prefer raw File/Blob (never a stale revoked blob: URL). Hostinger is often local_only.
      const mergedLocalUrl = await rebuildLocalNarrUrlFromSlots()
      const slotEntries = Object.entries(localVoSlotFilesRef.current)
        .map(([k, v]) => ({ slot: Number(k), ...v }))
        .filter((e) => e.slot >= 1 && e.file)
        .sort((a, b) => a.slot - b.slot)
      let voSrc: string | Blob | null = null
      if (slotEntries.length === 1) {
        voSrc = slotEntries[0].file
      } else if (slotEntries.length > 1) {
        // Merged WAV blob URL from rebuild — fetch into a Blob so decode never hits a revoked URL mid-scan.
        if (mergedLocalUrl) {
          try {
            voSrc = await fetch(mergedLocalUrl).then((r) => {
              if (!r.ok) throw new Error(`HTTP ${r.status}`)
              return r.blob()
            })
          } catch {
            voSrc = slotEntries[0].file
          }
        } else {
          voSrc = slotEntries[0].file
        }
      } else {
        voSrc =
          localNarrUrl ||
          (projectId ? `${API}/api/projects/${projectId}/voiceover-audio` : null)
      }
      if (!voSrc) {
        setLog('No narration VO linked — import VO 1 (and VO 2 if needed) before Auto-align.')
        return
      }

      // English chapters: NEVER Auto-align on estimates. Must hear the full VO first.
      // On this PC, faster-whisper hears the files. The browser hears only if that is missing.
      let wordsForAlign: AsrWord[] | undefined
      const expectVoDur = Number(voInfo?.duration || 0)
      const mustHearVo = language !== 'mr' && expectVoDur > 1
      const hearLang = language === 'mr' ? 'mr' : 'en'
      const wordsCover = (list: AsrWord[], dur: number, frac: number, minDur: number) => {
        const maxT = list.reduce((m, w) => Math.max(m, Number(w.end || w.start || 0)), 0)
        return { maxT, ok: list.length >= 6 && (dur <= minDur || maxT >= dur * frac) }
      }
      const hearOnPc = async (kind: 'narration' | 'poem'): Promise<AsrWord[] | null> => {
        try {
          const st = await fetch(`${API}/api/engine/status`)
          if (!st.ok) return null
          const status = await st.json()
          if (!status?.hear) return null
          setLog(kind === 'poem' ? 'Hearing Poem VO on this PC…' : 'Hearing narration on this PC…')
          const r = await fetch(`${API}/api/projects/${projectId}/engine/hear`, {
            method: 'POST',
            headers: clientHeaders({ 'Content-Type': 'application/json' }),
            body: JSON.stringify({ kind, language: hearLang }),
          })
          if (!r.ok) return null
          const data = await r.json()
          const raw = Array.isArray(data.words) ? data.words : []
          const words: AsrWord[] = raw
            .map((w: { text?: string; word?: string; start?: number; end?: number }) => ({
              text: String(w.text || w.word || '').trim(),
              start: Number(w.start),
              end: Number(w.end),
            }))
            .filter((w: AsrWord) => w.text && Number.isFinite(w.start))
          return words.length >= 6 ? words : null
        } catch {
          return null
        }
      }
      if (expectVoDur > 1) {
        setBusy('Hearing VO on this PC…')
        const pcWords = await hearOnPc('narration')
        if (pcWords) {
          const cover = wordsCover(pcWords, expectVoDur, 0.82, 30)
          if (cover.ok) {
            wordsForAlign = pcWords
            asrWordsRef.current = pcWords
            lastWordAlignSigRef.current = `${projectId}:${expectVoDur.toFixed(3)}:${voInfo?.filename || ''}`
            setLog(`Heard ${pcWords.length} VO words on this PC through ${fmt(cover.maxT)} · next: Poem VO (if any)…`)
          } else if (mustHearVo) {
            setLog(
              `STOPPED — this PC heard only part of the VO (${pcWords.length} words through ${fmt(cover.maxT)} of ${fmt(expectVoDur)}). ` +
                `Link both VO files, then Auto-align again.`,
            )
            return
          } else {
            setLog(`PC Whisper covered ${fmt(cover.maxT)} of ${fmt(expectVoDur)} — continuing with the chapter aligner.`)
          }
        }
      }
      if (mustHearVo && !wordsForAlign) {
        setBusy('Hearing VO words (Whisper)…')
        setVoQaProgress({ done: 0, total: 1 })
        setLog('Hearing narration VO — no estimates; waiting for real spoken words…')
        const sig = `${projectId}:${expectVoDur.toFixed(3)}:${voInfo?.filename || ''}:align`
        const heard = await hearVoiceoverWords(
          projectId,
          sig,
          voSrc,
          timeline?.clips || [],
          (done, total) => setVoQaProgress({ done, total }),
          { expectDurationSec: expectVoDur, skipCache: true, exclusive: true },
        )
        setVoQaProgress(null)
        if (heard.reason !== 'ok' || heard.words.length < 6) {
          const through = fmt(heard.maxWordT)
          const ofDur = fmt(expectVoDur)
          if (heard.reason === 'decode_failed') {
            setLog(
              `STOPPED — could not decode narration audio (${heard.detail || 'decode failed'}). ` +
                `Re-link VO 1 (and VO 2), wait until linking finishes, then Auto-align again.`,
            )
          } else if (heard.reason === 'partial') {
            setLog(
              `STOPPED — only heard part of the VO (${heard.words.length} words through ${through} of ${ofDur}). ` +
                `Link both VO 1 and VO 2 if this chapter has two files, wait for merge, then Auto-align again.`,
            )
          } else if (heard.reason === 'asr_failed' || heard.reason === 'timeout') {
            setLog(
              `STOPPED — Whisper failed while hearing VO (${heard.detail || heard.reason}). ` +
                `Check network (model CDN), then Auto-align again. No estimate cuts.`,
            )
          } else {
            setLog(
              `STOPPED — did not hear the VO (heard ${heard.words.length} words through ${through} of ${ofDur}` +
                `${heard.detail ? ` · ${heard.detail}` : ''}). ` +
                `Re-link VO 1 and VO 2, wait for merge, then Auto-align again. No estimate cuts will be applied.`,
            )
          }
          return
        }
        wordsForAlign = heard.words
        asrWordsRef.current = heard.words
        lastWordAlignSigRef.current = `${projectId}:${expectVoDur.toFixed(3)}:${voInfo?.filename || ''}`
        setLog(`Heard ${heard.words.length} VO words through ${fmt(heard.maxWordT)} · next: Poem VO (if any)…`)
      }

      // Poem VO: same rule — hear sung/spoken poem words before locking lyric cards.
      let poemWordsForAlign: AsrWord[] | undefined
      const expectPoemDur = Number(poemVoInfo?.duration || 0)
      const poemScenesExist = scenes.some(
        (s) =>
          s.is_poem ||
          (/\bpoem\b/i.test(s.section || '') &&
            !/\b(instruction|question|answer|heading|activity|summary|title|prompt)\b/i.test(
              s.section || '',
            )),
      )
      const hasLocalPoem =
        Boolean(localPoemFileRef.current?.file) || Boolean(localPoemUrl) || Boolean(poemVoInfo)
      const mustHearPoem =
        language !== 'mr' && expectPoemDur > 1 && hasLocalPoem && poemScenesExist
      if (expectPoemDur > 1 && hasLocalPoem && poemScenesExist) {
        setBusy('Hearing Poem VO on this PC…')
        const pcPoem = await hearOnPc('poem')
        if (pcPoem) {
          const cover = wordsCover(pcPoem, expectPoemDur, 0.55, 20)
          if (cover.ok) {
            poemWordsForAlign = pcPoem
            setLog(
              `Heard ${wordsForAlign?.length || 0} narration words` +
                ` + ${pcPoem.length} poem words on this PC through ${fmt(cover.maxT)} · Align + Cut + Stretch…`,
            )
          } else if (mustHearPoem) {
            setLog(
              `STOPPED — this PC did not hear the Poem VO (heard ${pcPoem.length} words through ${fmt(cover.maxT)} of ${fmt(expectPoemDur)}). ` +
                `Re-link Poem VO, then Auto-align again.`,
            )
            return
          }
        }
      }
      if (mustHearPoem && !poemWordsForAlign) {
        if (!localPoemFileRef.current?.file && projectId) {
          const pBlob = await idbGetFile(`${projectId}:poem_vo`)
          if (pBlob) {
            localPoemFileRef.current = {
              file: pBlob,
              filename: poemVoInfo?.filename || 'poem.mp3',
            }
          }
        }
        const poemSrc =
          localPoemFileRef.current?.file ||
          localPoemUrl ||
          (projectId ? `${API}/api/projects/${projectId}/poem-audio` : null)
        if (!poemSrc) {
          setLog('STOPPED — Poem VO is linked but the audio blob is missing. Re-link Poem VO, then Auto-align again.')
          return
        }
        setBusy('Hearing Poem VO words (Whisper)…')
        setVoQaProgress({ done: 0, total: 1 })
        setLog('Hearing Poem VO — no poem estimates; waiting for real sung/spoken words…')
        const poemSig = `${projectId}:poem:${expectPoemDur.toFixed(3)}:${poemVoInfo?.filename || ''}:align`
        const poemHeard = await hearVoiceoverWords(
          projectId,
          poemSig,
          poemSrc,
          (timeline?.clips || []).filter((c) => {
            const sc = scenes.find((s) => s.screen === c.screen)
            return Boolean(
              sc?.is_poem ||
                (sc &&
                  /\bpoem\b/i.test(sc.section || '') &&
                  !/\b(instruction|question|answer|heading|activity|summary|title|prompt)\b/i.test(
                    sc.section || '',
                  )),
            )
          }),
          (done, total) => setVoQaProgress({ done, total }),
          // Poems often have instrumental intro/outro — don't use the strict narration 82% cutoff.
          { expectDurationSec: 0, skipCache: true, exclusive: true },
        )
        setVoQaProgress(null)
        const maxPoemT = poemHeard.maxWordT
        if (
          poemHeard.reason === 'decode_failed' ||
          poemHeard.reason === 'asr_failed' ||
          poemHeard.reason === 'timeout' ||
          poemHeard.words.length < 6 ||
          (expectPoemDur > 20 && maxPoemT < expectPoemDur * 0.55)
        ) {
          setLog(
            `STOPPED — did not hear Poem VO words (heard ${poemHeard.words.length} words through ${fmt(maxPoemT)} of ${fmt(expectPoemDur)}` +
              `${poemHeard.detail ? ` · ${poemHeard.detail}` : ''}). ` +
              `Re-link Poem VO, then Auto-align again. No estimate poem cuts will be applied.`,
          )
          return
        }
        poemWordsForAlign = poemHeard.words
        setLog(
          `Heard ${wordsForAlign?.length || 0} narration words` +
            ` + ${poemHeard.words.length} poem words through ${fmt(maxPoemT)} · Align + Cut + Stretch…`,
        )
      }

      setBusy('Align + Cut + Stretch to heard VO…')
      const r = await fetch(`${API}/api/projects/${projectId}/build`, {
        method: 'POST',
        headers: clientHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          language,
          use_ollama: true,
          words: wordsForAlign,
          poem_words: poemWordsForAlign,
          force_realign: true,
          require_heard_words: mustHearVo,
          require_heard_poem: mustHearPoem,
        }),
      })
      if (!r.ok) {
        const detail = await parseApiError(r).catch(() => r.statusText)
        throw new Error(detail || `Align failed (${r.status})`)
      }
      const plan = (await r.json()) as TimelinePlan & { scenes?: Scene[] }
      if (Array.isArray(plan.scenes) && plan.scenes.length) {
        setScenes(plan.scenes)
        const pScenes = plan.scenes.filter((s) => s.is_poem)
        setPoemInfo(
          pScenes.length
            ? {
                has_poem: true,
                scene_count: pScenes.length,
                first_screen: pScenes[0].screen,
                last_screen: pScenes[pScenes.length - 1].screen,
              }
            : { has_poem: false },
        )
      }
      // Keep each scene's previous picture/video — Auto-align only retimes cuts, never reshuffles media.
      const prevByScreen = new Map((timeline?.clips || []).map((c) => [c.screen, c]))
      const planWithMedia: TimelinePlan = {
        ...plan,
        clips: (plan.clips || []).map((c) => {
          const prev = prevByScreen.get(c.screen)
          if (!prev?.media_id) return c
          return {
            ...c,
            media_id: prev.media_id,
            media_path: prev.media_path || c.media_path,
            filename: prev.filename || c.filename,
            kind: prev.kind || c.kind,
            fit:
              c.fit === 'missing'
                ? prev.kind === 'video'
                  ? 'stretch'
                  : 'hold'
                : c.fit,
          }
        }),
      }
      // 2) Align + Cut + Stretch on the same VO clock (images held, videos time-stretched, SRT rebuilt).
      setBusy('Cutting & stretching images/videos to VO…')
      const stretched = applyStretchAlignToPlan(planWithMedia, media)
      const clientSync = verifySync(stretched.clips || [], {
        repair: false,
        voDuration: Number(voInfo?.duration || plan.sync_report?.vo_duration || 0),
        ...poemSyncArgs(stretched, scenes),
      })
      const withSync: TimelinePlan = {
        ...stretched,
        sync_report: clientSync,
        qa_summary: clientSync.summary || stretched.qa_summary || plan.qa_summary || '',
        qa_issues: [
          ...(plan.qa_issues || []).filter((q) => q.kind !== 'vo_sync'),
          ...clientSync.issues,
        ],
      }
      setTimeline(withSync)
      movePlayhead(0)
      setDirty(false)
      syncRepairKeyRef.current = ''
      void persistTimelineToServer(withSync)
      const cueN = Array.isArray(withSync.srt_cues) ? withSync.srt_cues.length : 0
      if (mustHearVo && withSync.align_engine !== 'english_word') {
        setLog('STOPPED — server did not lock to heard VO words (refused estimate path). Re-link VO and retry Auto-align.')
        return
      }
      if (mustHearPoem && withSync.poem_align_engine !== 'poem_word') {
        setLog(
          'STOPPED — server did not lock poem lyric cards to heard Poem VO words (refused estimate path). Re-link Poem VO and retry Auto-align.',
        )
        return
      }
      const stretchN = withSync.clips.filter((c) => c.fit === 'stretch').length
      const imageN = withSync.clips.filter((c) => c.kind !== 'video' && c.narration_in != null).length
      setLog(
        `Align + Cut + Stretch done · heard VO` +
          (mustHearPoem ? ' + Poem VO' : '') +
          ` only (no estimates)` +
          ` · ${imageN} images aligned/held to VO` +
          ` · ${stretchN} videos stretched to VO` +
          ` · ${cueN} SRT cues aligned` +
          ` · ${fmt(withSync.total_duration)} · ${clientSync.summary}`,
      )
    } catch (e) {
      setLog(String(e))
    } finally {
      suppressVoQaRef.current = false
      setBusy(null)
      setVoQaProgress(null)
    }
  }

  const saveTimerRef = useRef<number | null>(null)

  async function persistTimelineToServer(plan: TimelinePlan) {
    if (!projectId) return
    try {
      const r = await fetch(`${API}/api/projects/${projectId}/timeline`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(plan),
      })
      if (r.ok) {
        const updated = (await r.json()) as TimelinePlan
        setTimeline((prev) =>
          prev
            ? {
                ...prev,
                qa_issues: updated.qa_issues ?? prev.qa_issues,
                qa_summary: updated.qa_summary ?? prev.qa_summary,
                sync_report: updated.sync_report ?? prev.sync_report,
                narration_segments: updated.narration_segments ?? prev.narration_segments,
                manual_override: updated.manual_override ?? prev.manual_override ?? true,
                srt_cues: updated.srt_cues ?? prev.srt_cues,
              }
            : updated,
        )
      }
      setDirty(false)
    } catch {
      setLog('Could not save manual edit — will retry on export')
    }
  }

  function saveManualEdits(plan: TimelinePlan, commitImmediate = true) {
    setTimeline(plan)
    setDirty(true)
    if (!projectId) return
    if (saveTimerRef.current) {
      window.clearTimeout(saveTimerRef.current)
      saveTimerRef.current = null
    }
    if (commitImmediate) {
      void persistTimelineToServer(plan)
    } else {
      saveTimerRef.current = window.setTimeout(() => {
        void persistTimelineToServer(plan)
      }, 320)
    }
  }

  async function replaceClipMediaOnTimeline(screen: string, file: File) {
    if (!projectId) return
    setBusy(`Replacing media for ${screen.replace('screen_', 'Scene ')} (${file.name})…`)
    try {
      const fd = new FormData()
      fd.append('file', file)
      const r = await fetch(
        `${API}/api/projects/${projectId}/clips/${encodeURIComponent(screen)}/replace-media`,
        {
          method: 'POST',
          headers: clientHeaders(),
          body: fd,
        },
      )
      if (!r.ok) throw new Error(await parseApiError(r))
      const data = await r.json()
      const replacedItem = data.replaced_item as MediaItem | undefined
      let folderMsg = ''
      if (replacedItem) {
        const folderKind = replacedItem.kind === 'video' ? 'videos' : 'images'
        await idbPutFile(
          `${projectId}:media:${folderKind}:${replacedItem.filename.toLowerCase()}`,
          file,
          `pc:media:${folderKind}:${replacedItem.filename.toLowerCase()}`,
        )
        const objUrl = URL.createObjectURL(file)
        localMediaFilesRef.current[replacedItem.id] = {
          file,
          filename: replacedItem.filename,
          kind: folderKind,
        }
        setLocalMediaUrls((prev) => ({ ...prev, [replacedItem.id]: objUrl }))
        if (replacedItem.kind === 'image') {
          setLocalThumbUrls((prev) => ({ ...prev, [replacedItem.id]: objUrl }))
          // Clear cached OCR for this media ID so the newly replaced card is re-scanned
          try {
            localStorage.removeItem(`dgs-ocr-v3:${projectId}:${replacedItem.id}`)
            localStorage.removeItem(`dgs-ocrw-v1:${projectId}:${replacedItem.id}`)
          } catch {
            /* ignore */
          }
        }
        const targetDir =
          folderKind === 'videos'
            ? videoDirHandleRef.current || chapterDirHandleRef.current
            : imageDirHandleRef.current || chapterDirHandleRef.current
        if (targetDir) {
          const ok = await writeReplacedFileToFolder(targetDir, replacedItem.filename, file)
          if (ok) {
            folderMsg = ` · also updated "${replacedItem.filename}" in your folder "${targetDir.name}"`
          }
        }
      }
      if (Array.isArray(data.media)) setMedia(data.media)
      if (data.timeline) {
        setTimeline(data.timeline)
        setDirty(false)
      }
      setLog(
        `✓ Replaced ${screen.replace('screen_', 'Scene ')} with ${replacedItem?.filename || file.name} (VO & narration sync preserved)${folderMsg}`,
      )
    } catch (e) {
      setLog(`Replace media error: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setBusy(null)
    }
  }

  async function cancelExport() {
    exportCancelledRef.current = true
    if (projectId) {
      try {
        await fetch(`${API}/api/projects/${projectId}/export/cancel`, { method: 'POST' })
      } catch {
        /* ignore */
      }
    }
    setExportProgress(null)
    setBusy(null)
    setExportNotice('Export cancelled.')
    setLog('Export cancelled.')
  }

  async function exportVideo(forceServer = false) {
    if (!projectId || !timeline) {
      const msg = 'Build timeline before export'
      setLog(msg)
      setExportError(msg)
      return
    }
    exportCancelledRef.current = false
    setExportResult(null)
    setExportError(null)
    setExportNotice(null)
    const sig = computeBitrateSignal(exportSettings, timeline)
    const compDesc = sig.compActive
      ? `${sig.compPct}% Compression · ~${sig.effectiveStreamVideoKbps.toLocaleString()} kbps stream (${sig.targetVideoKbps.toLocaleString()} kbps max)`
      : `${sig.modeUpper} ${sig.targetVideoKbps.toLocaleString()} kbps (${sig.targetVideoMbps} Mbps)`

    const fmtLower = String(exportSettings.format || 'mp4').toLowerCase()
    const useLocalMachineGpu =
      !forceServer &&
      renderEngine === 'machine' &&
      isLocalWebCodecsSupported() &&
      fmtLower !== 'mp3' &&
      fmtLower !== 'wav'

    setExportProgress({
      running: true,
      percent: 3,
      message: useLocalMachineGpu
        ? `⚡ Preparing local PC GPU render (${compDesc})…`
        : `☁️ Preparing server render (${compDesc})…`,
    })
    setBusy(
      useLocalMachineGpu
        ? `⚡ Rendering on this PC (${compDesc})…`
        : `☁️ Rendering & exporting (${compDesc})…`,
    )

    try {
      if (dirty) {
        await fetch(`${API}/api/projects/${projectId}/timeline`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(timeline),
        })
        setDirty(false)
      }

      if (useLocalMachineGpu) {
        const [wStr, hStr] = String(exportSettings.resolution || '1920x1080')
          .toLowerCase()
          .replace('*', 'x')
          .split('x')
        const width = parseInt(wStr, 10) || 1920
        const height = parseInt(hStr, 10) || 1080
        const fps = Number(exportSettings.fps) || 30

        const voSlotEntries = Object.entries(localVoSlotFilesRef.current)
          .map(([k, v]) => ({ slot: Number(k), file: v.file }))
          .filter((e) => e.slot >= 1 && e.file)
          .sort((a, b) => a.slot - b.slot)
          .map((e) => e.file)

        const logoEnabled = timeline.logo_enabled !== false && logoInfo?.enabled !== false && exportSettings.include_logo !== false
        const resolvedLogoUrl = logoEnabled
          ? localLogoUrl ||
            (timeline.logo_path && timeline.logo_path !== '/eclass-logo.png'
              ? `${API}/api/projects/${projectId}/logo`
              : '/eclass-logo.png')
          : null
        const resolvedLogoTransform = normalizeLogoTransform(
          timeline.logo_transform || logoTransform || DEFAULT_LOGO_TRANSFORM,
        )

        // WebCodecs VideoEncoder is a target-bitrate encoder (no CRF mode); empirically on 10fps slides + 30fps videos,
        // actual output stream is ~0.44x configured bitrate (6000 configured -> 2618 actual = 126 MB).
        // Configuring with ~2.15x effectiveStreamVideoKbps (~2750 configured -> ~1250 kbps actual) yields ~70-75 MB (<100 MB), matching CRF 28!
        const localEncoderTargetKbps = sig.compActive
          ? Math.max(600, Math.round(sig.effectiveStreamVideoKbps * 2.15))
          : sig.targetVideoKbps

        const localRes = await renderProjectLocallyOnMachine({
          clips: timeline.clips,
          narrationSegments: timeline.narration_segments,
          voPieces: timeline.vo_pieces,
          voSlots: timeline.voiceover_slots,
          totalDuration: Number(timeline.total_duration || 0),
          width,
          height,
          fps,
          videoBitrateKbps: localEncoderTargetKbps,
          bitrateMode: exportSettings.bitrate_mode === 'cbr' ? 'cbr' : 'vbr',
          audioBitrateKbps: sig.audioKbps,
          audioSampleRate: Number(exportSettings.audio_sample_rate) || 44100,
          audioChannels: exportSettings.audio_channels === 'mono' ? 1 : 2,
          exportVideoOnly: Boolean(exportSettings.export_video_only),
          resolveMediaUrl: (clip) => {
            if (!clip.media_id) return null
            return (
              localMediaUrls[clip.media_id] ||
              `${API}/api/projects/${projectId}/media-file/${clip.media_id}`
            )
          },
          logoUrl: resolvedLogoUrl,
          logoTransform: resolvedLogoTransform,
          voBlobs: voSlotEntries,
          voFallbackUrl:
            timeline.voiceover_path || (timeline.voiceover_slots && timeline.voiceover_slots.length > 0)
              ? localNarrUrl || `${API}/api/projects/${projectId}/voiceover-audio`
              : null,
          poemBlob: localPoemFileRef.current?.file || null,
          poemFallbackUrl: timeline.poem_voiceover_path
            ? localPoemUrl || `${API}/api/projects/${projectId}/poem-audio`
            : null,
          hasPoem: Boolean(timeline.has_poem),
          poemStartTime: Number(timeline.poem_start_time || 0),
          poemEndTime: Number(timeline.poem_end_time || 0),
          isCancelled: () => exportCancelledRef.current,
          onProgress: (pct, msg, detail) => {
            setExportProgress({
              running: true,
              percent: pct,
              message: msg,
              done: detail?.done,
              total: detail?.total,
              screen: detail?.screen,
              mediaId: detail?.mediaId || null,
            })
            setBusy(detail ? `Rendering ${detail.done} / ${detail.total}` : msg)
          },
        })

        const safeTitle = (title || 'Export').trim().replace(/[<>:"/\\|?*]+/g, '_') || 'Export'
        const outFilename = `${safeTitle}.mp4`
        const blobUrl = URL.createObjectURL(localRes.blob)
        const destination = await saveExportFile(localRes.blob, outFilename)

        setExportProgress({
          running: false,
          percent: 100,
          message: `⚡ Local PC GPU Export completed! (${localRes.sizeMb} MB · ${localRes.actualVideoKbps.toLocaleString()} kbps)`,
        })
        setExportResult({
          filename: outFilename,
          saved_to: destination,
          srt_saved_to: exportSettings.export_srt_sidecar ? `${safeTitle}.srt` : undefined,
          size_mb: localRes.sizeMb,
          download: blobUrl,
          bitrate_info: {
            target_video_kbps: sig.targetVideoKbps,
            target_video_mbps: Number(sig.targetVideoMbps),
            audio_kbps: sig.audioKbps,
            target_total_kbps: sig.totalKbps,
            actual_total_kbps: localRes.actualTotalKbps,
            actual_video_kbps: localRes.actualVideoKbps,
            bitrate_mode: sig.modeUpper,
            signal_label: sig.badge,
          },
        })

        // The MP4 was saved once above to the selected folder (or downloaded when none is selected).
        if (exportSettings.export_srt_sidecar) {
          await saveExportUrl(
            `${API}/api/projects/${projectId}/srt/download?title=${encodeURIComponent(safeTitle)}`,
            `${safeTitle}.srt`,
          )
        }

        setLog(
          `✓ Local PC GPU Export completed (${localRes.actualVideoKbps.toLocaleString()} kbps ${sig.modeUpper}): ${outFilename} (${localRes.sizeMb} MB)`,
        )
        setShowAdvanced(false)
        void refreshRecent()
        return
      }

      await syncLocalFilesToServerIfNeeded(projectId)
      const r = await fetch(`${API}/api/projects/${projectId}/export`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          settings: { ...exportSettings, save_to: saveTo || null },
          title,
          save_to: saveTo || null,
        }),
      })
      if (!r.ok) throw new Error(await parseApiError(r))
      let finalData = await r.json()

      // Non-blocking background export: poll /export/status until running === false
      if (finalData.async || finalData.running) {
        while (true) {
          if (exportCancelledRef.current) {
            throw new Error('Export cancelled by user.')
          }
          await new Promise((resolve) => window.setTimeout(resolve, 600))
          const sr = await fetch(`${API}/api/projects/${projectId}/export/status`)
          if (!sr.ok) continue
          const st = await sr.json()
          if (st.error) {
            throw new Error(st.error)
          }
          if (st.cancelled) {
            throw new Error('Export cancelled by user.')
          }
          if (typeof st.percent === 'number') {
            const parsed = String(st.message || '').match(/scene\s+(\d+)\s*\/\s*(\d+)\s*\((screen_\d+)/i)
            const done = Number(st.done) || (parsed ? Number(parsed[1]) : undefined)
            const total = Number(st.total) || (parsed ? Number(parsed[2]) : undefined)
            const screen = st.screen || parsed?.[3]
            setExportProgress({
              running: Boolean(st.running),
              percent: st.percent,
              message: st.message || `Rendering (${compDesc})…`,
              done,
              total,
              screen,
              mediaId: st.media_id || null,
            })
            if (done && total) setBusy(`Rendering ${done} / ${total}`)
            else if (st.message) setBusy(st.message)
          }
          if (!st.running && (st.done || st.percent === 100 || st.download)) {
            finalData = st
            break
          }
          if (!st.running && !st.download && st.percent === 0) {
            throw new Error(st.message || 'Export stopped unexpectedly on server.')
          }
        }
      }

      const dlPath = finalData.download || `/api/projects/${projectId}/download`
      const dlUrl = `${API}${dlPath}`
      setExportProgress({
        running: false,
        percent: 100,
        message: 'Export completed successfully!',
      })
      const exportFilename = finalData.filename || `${title}.mp4`
      // Server exports are staged on the backend, never directly on the user's chosen drive.
      // Copy the completed file to the user-selected writable folder when one is linked.
      const shouldTransfer = Boolean(exportDirectoryHandleRef.current) || isRemoteServer ||
        !finalData.saved_to || finalData.saved_to === finalData.filename
      const actualDestination = shouldTransfer
        ? await saveExportUrl(dlUrl, exportFilename)
        : (finalData.path || finalData.saved_to)
      setExportResult({
        filename: exportFilename,
        saved_to: actualDestination,
        srt_saved_to: finalData.srt_saved_to,
        size_mb: finalData.size_mb,
        download: dlUrl,
        bitrate_info: finalData.bitrate_info,
      })
      setLog(
        `✓ Export successful (${sig.targetVideoKbps.toLocaleString()} kbps ${sig.modeUpper}): ${
          finalData.filename || `${title}.mp4`
        }${finalData.size_mb ? ` (${finalData.size_mb} MB)` : ''}`,
      )
      setShowAdvanced(false)
      void refreshRecent()
    } catch (e) {
      setExportProgress(null)
      const errMsg = e instanceof Error ? e.message : String(e)
      setExportError(errMsg)
      setLog(`Export error: ${errMsg}`)
    } finally {
      setBusy(null)
    }
  }

  async function revealExportInFolder() {
    if (!projectId) return
    if ((isRemoteServer || exportResult?.download?.startsWith('blob:')) && exportResult?.download) {
      const a = document.createElement('a')
      a.href = exportResult.download
      a.download = exportResult.filename || `${(title || 'Export').trim()}.mp4`
      document.body.appendChild(a)
      a.click()
      a.remove()
      return
    }
    try {
      await fetch(`${API}/api/projects/${projectId}/reveal-export`, { method: 'POST' })
    } catch {
      /* ignore */
    }
  }

  async function saveExportFile(blob: Blob, filename: string): Promise<string> {
    const folder = exportDirectoryHandleRef.current
    if (folder) {
      const fileHandle = await folder.getFileHandle(filename, { create: true })
      const writable = await fileHandle.createWritable()
      try {
        await writable.write(blob)
        await writable.close()
      } catch (error) {
        await writable.abort().catch(() => undefined)
        throw error
      }
      return `Selected folder: ${folder.name}/${filename}`
    }
    const downloadUrl = URL.createObjectURL(blob)
    try {
      const a = document.createElement('a')
      a.href = downloadUrl
      a.download = filename
      document.body.appendChild(a)
      a.click()
      a.remove()
    } finally {
      window.setTimeout(() => URL.revokeObjectURL(downloadUrl), 60000)
    }
    return `Browser Downloads (or browser-configured download location): ${filename}`
  }

  async function saveExportUrl(url: string, filename: string): Promise<string> {
    if (exportDirectoryHandleRef.current) {
      const response = await fetch(url)
      if (!response.ok) throw new Error(`Could not download exported file (HTTP ${response.status})`)
      return saveExportFile(await response.blob(), filename)
    }
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    a.remove()
    return `Browser Downloads (or browser-configured download location): ${filename}`
  }

  async function pickSaveToFolder() {
    const winAny = window as unknown as {
      showDirectoryPicker?: (options?: { mode?: 'readwrite' }) => Promise<FileSystemDirectoryHandle>
    }
    if (typeof winAny.showDirectoryPicker !== 'function') {
      exportDirectoryHandleRef.current = null
      setSaveTo('Browser Downloads (folder selection unavailable in this browser)')
      setExportNotice('Folder selection is unavailable. Exports will use your browser download location.')
      return
    }
    try {
      const handle = await winAny.showDirectoryPicker({ mode: 'readwrite' })
      if (!handle) return
      exportDirectoryHandleRef.current = handle
      setSaveTo(`Selected PC folder: ${handle.name}`)
      setExportNotice(`Destination selected: ${handle.name}. Exports will be written directly to this folder.`)
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') return
      setExportError(`Could not select export folder: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  async function saveAsPreset() {
    const name = window.prompt('Save preset as:', exportSettings.preset_name || 'Custom Preset')
    if (!name || !name.trim()) return
    const trimmed = name.trim()
    try {
      const r = await fetch(`${API}/api/presets`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: trimmed, settings: { ...exportSettings, preset_name: trimmed } }),
      })
      if (!r.ok) throw new Error(await r.text())
      const data = await r.json()
      const map: Record<string, ExportSettings> = { ...serverPresets }
      for (const p of data.presets || []) map[p.name] = { ...SUNDHARAM_BR, ...p.settings }
      setServerPresets(map)
      setPresetName(trimmed)
      setExportSettings((prev) => ({ ...prev, preset_name: trimmed }))
      const msg = `✓ Saved custom preset: ${trimmed}`
      setLog(msg)
      setExportNotice(msg)
    } catch (e) {
      const errMsg = e instanceof Error ? e.message : String(e)
      setLog(errMsg)
      setExportError(errMsg)
    }
  }

  async function exportSrt() {
    if (!projectId || !timeline) {
      const msg = 'Build timeline before exporting SRT'
      setLog(msg)
      setExportError(msg)
      return
    }
    setExportError(null)
    try {
      if (dirty) {
        await fetch(`${API}/api/projects/${projectId}/timeline`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(timeline),
        })
        setDirty(false)
      }
      const safeBase = (title || 'subtitles').trim()
      const srtName = `SRT_Only_${safeBase}.srt`
      const url = `${API}/api/projects/${projectId}/srt/download?title=${encodeURIComponent(safeBase)}`
      const destination = await saveExportUrl(url, srtName)
      const msg = `✓ Standalone SRT saved: ${destination} (never encoded or attached to video)`
      setLog(msg)
      setExportNotice(msg)
    } catch (e) {
      const errMsg = e instanceof Error ? e.message : String(e)
      setLog(errMsg)
      setExportError(errMsg)
    }
  }

  async function saveWfpToChosenFolder() {
    if (!projectId) {
      setLog('Create or open a project before saving .wfp')
      return
    }
    setShowSaveMenu(false)
    if (isRemoteServer) {
      await saveProjectFile()
      return
    }
    setBusy('Select destination folder for .wfp…')
    try {
      if (dirty && timeline) {
        await fetch(`${API}/api/projects/${projectId}/timeline`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(timeline),
        })
        setDirty(false)
      }
      const r = await fetch(
        `${API}/api/projects/${projectId}/save-wfp-to?title=${encodeURIComponent(
          (title || 'Project').trim(),
        )}`,
        { method: 'POST' },
      )
      if (!r.ok) throw new Error(await parseApiError(r))
      const data = await r.json()
      if (data.cancelled) {
        setLog('Save .wfp cancelled')
        return
      }
      if (data.download_url) {
        const a = document.createElement('a')
        a.href = `${API}${data.download_url}`
        a.download = data.filename || `${(title || 'Project').trim()}.wfp`
        document.body.appendChild(a)
        a.click()
        a.remove()
      }
      setLog(`✓ Saved Filmora 15 & DGS .wfp to: ${data.saved_to || data.filename}`)
      void refreshRecent()
    } catch (e) {
      setLog(e instanceof Error ? e.message : String(e))
    } finally {
      setBusy(null)
    }
  }

  async function loadRecentProject(pid: string) {
    setShowRecentMenu(false)
    setBusy(`Loading project ${pid}…`)
    try {
      const r = await fetch(`${API}/api/projects/${pid}/load`, {
        headers: clientHeaders(),
      })
      if (!r.ok) throw new Error(await r.text())
      const data = await r.json()
      await restoreLocalFilesFromIdb(
        data.project_id,
        data.media || [],
        data.voiceover?.slots || (data.voiceover?.filename ? [{ slot: 1, filename: data.voiceover.filename }] : []),
        data.poem_voiceover || null,
        data.logo || null,
      )
      setProjectId(data.project_id)
      setTitle(data.title || `Project ${pid}`)
      setScenes(data.scenes || [])
      setMedia(data.media || [])
      setPoemInfo(data.poem || { has_poem: (data.scenes || []).some((s: Scene) => s.is_poem) })
      setVoInfo(
        data.voiceover
          ? { filename: data.voiceover.filename || 'Narration VO', duration: data.voiceover.duration }
          : null,
      )
      if (data.voiceover?.slots?.length) {
        const sNums: number[] = []
        const sMap: Record<number, { filename: string; duration?: number | null }> = {}
        for (const s of data.voiceover.slots) {
          const n = Number(s.slot) || 1
          sNums.push(n)
          sMap[n] = { filename: s.filename, duration: s.duration }
        }
        setVoSlots(sNums.length ? sNums.sort((a, b) => a - b) : [1])
        setVoFiles(sMap)
      } else {
        setVoSlots([1])
        setVoFiles(
          data.voiceover?.filename
            ? { 1: { filename: data.voiceover.filename, duration: data.voiceover.duration } }
            : {},
        )
      }
      setPoemVoInfo(
        data.poem_voiceover
          ? { filename: data.poem_voiceover.filename || 'Poem VO', duration: data.poem_voiceover.duration }
          : null,
      )
      setLogoInfo(
        data.logo?.path
          ? {
              filename: data.logo.filename || 'E-Class Logo.png (Default)',
              path: data.logo.path,
              enabled: Boolean(data.logo.enabled ?? true),
            }
          : { ...DEFAULT_BRAND_LOGO },
      )
      setLogoTransform(
        normalizeLogoTransform(
          data.timeline?.logo_transform || data.logo?.transform || DEFAULT_LOGO_TRANSFORM,
        ),
      )
      setTimeline(data.timeline || null)
      movePlayhead(0)
      setPlaying(false)
      setDirty(false)
      setSceneEdits({})
      setLog(`✓ Loaded recent project: ${data.title} (${pid})`)
    } catch (e) {
      setLog(String(e))
    } finally {
      setBusy(null)
    }
  }

  async function importFromRecentPath(kind: 'images' | 'videos', path: string) {
    setShowRecentMenu(false)
    setBusy(`Importing ${kind} from recent folder…`)
    try {
      const pid = await ensureProject()
      const r = await fetch(`${API}/api/projects/${pid}/import-recent`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ kind, path }),
      })
      if (!r.ok) throw new Error(await r.text())
      const data = await r.json()
      setMedia(data.media || [])
      setLog(`✓ Imported ${data.saved} ${kind} from recent folder: ${path}`)
      void refreshRecent()
    } catch (e) {
      setLog(String(e))
    } finally {
      setBusy(null)
    }
  }

  async function saveSceneText(screen: string) {
    if (!projectId) return
    const sc = scenes.find((x) => x.screen === screen)
    const edit = sceneEdits[screen] || {
      voiceover_text: sc?.voiceover_text ?? sc?.text ?? '',
      onscreen_text: sc?.onscreen_text ?? '',
    }
    setBusy(`Updating script & VO text for ${screen}…`)
    try {
      const r = await fetch(`${API}/api/projects/${projectId}/scenes/${encodeURIComponent(screen)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          voiceover_text: edit.voiceover_text,
          onscreen_text: edit.onscreen_text,
        }),
      })
      if (!r.ok) throw new Error(await r.text())
      const data = await r.json()
      if (data.scenes) setScenes(data.scenes)
      if (data.timeline) setTimeline(data.timeline)
      let folderMsg = ''
      const scriptDir = chapterDirHandleRef.current || imageDirHandleRef.current
      if (scriptDir && data.script_filename) {
        try {
          const dl = await fetch(`${API}/api/projects/${projectId}/script/download`, {
            headers: clientHeaders(),
          })
          if (dl.ok) {
            const blob = await dl.blob()
            const wrote = await writeReplacedFileToFolder(scriptDir, data.script_filename, blob)
            if (wrote) {
              folderMsg = ` · saved "${data.script_filename}" to "${scriptDir.name}"`
            }
          }
        } catch {
          /* ignore */
        }
      }
      setLog(
        `✓ Updated script & VO text for ${screen}${folderMsg}${
          data.timeline?.qa_summary ? ` · ${data.timeline.qa_summary}` : ''
        }`,
      )
    } catch (e) {
      setLog(String(e))
    } finally {
      setBusy(null)
    }
  }

  async function replaceSceneVo(screen: string, file: File | null) {
    if (!file || !projectId) return
    const sc = scenes.find((x) => x.screen === screen)
    const edit = sceneEdits[screen] || {
      voiceover_text: sc?.voiceover_text ?? '',
      onscreen_text: sc?.onscreen_text ?? '',
    }
    setBusy(`Replacing narrated VO for ${screen} (${file.name})…`)
    try {
      const q = new URLSearchParams()
      if (edit.voiceover_text.trim()) q.set('voiceover_text', edit.voiceover_text.trim())
      if (edit.onscreen_text.trim()) q.set('onscreen_text', edit.onscreen_text.trim())
      const data = await uploadFileSmart({
        file,
        directUrl: `${API}/api/projects/${projectId}/scenes/${encodeURIComponent(screen)}/voiceover?${q.toString()}`,
        target: 'scene_vo',
        projectId,
        extraFields: {
          screen,
          voiceover_text: edit.voiceover_text.trim(),
          onscreen_text: edit.onscreen_text.trim(),
        },
        label: `Scene VO (${screen})`,
      })
      if (data.scenes) setScenes(data.scenes)
      const voFn = data.voiceover?.filename || voInfo?.filename || 'VO.mp3'
      if (data.voiceover) {
        setVoInfo({
          filename: voFn,
          duration: data.voiceover.duration,
        })
      }
      if (data.timeline) setTimeline(data.timeline)
      if (data.spoken_text) {
        setSceneEdits((prev) => ({
          ...prev,
          [screen]: {
            voiceover_text: data.spoken_text,
            onscreen_text: edit.onscreen_text,
          },
        }))
      }
      let folderMsg = ''
      try {
        const voResp = await fetch(`${API}/api/projects/${projectId}/audio/narration?t=${Date.now()}`, {
          headers: clientHeaders(),
        })
        if (voResp.ok) {
          const voBlob = await voResp.blob()
          setLocalNarrUrl(URL.createObjectURL(voBlob))
          await idbPutFile(`${projectId}:vo:1`, voBlob, `pc:vo:${voFn.toLowerCase()}`)
          const voDir = chapterDirHandleRef.current || imageDirHandleRef.current
          if (voDir && voFn) {
            const wrote = await writeReplacedFileToFolder(voDir, voFn, voBlob)
            if (wrote) {
              folderMsg = ` · updated "${voFn}" in "${voDir.name}"`
            }
          }
        }
      } catch {
        /* ignore */
      }
      setLog(
        `✓ Replaced VO for ${screen} (${data.new_duration ?? data.duration ?? ''}s)${folderMsg}${
          data.timeline?.qa_summary ? ` · ${data.timeline.qa_summary}` : ''
        }`,
      )
    } catch (e) {
      setLog(`Scene VO upload error: ${e instanceof Error ? e.message : String(e)}`)
    } finally {
      setBusy(null)
    }
  }

  function applyPreset(name: string) {
    setPresetName(name)
    const preset = serverPresets[name]
    if (preset) {
      const next = { ...preset, preset_name: name }
      if (next.advanced_compression && next.compression_mode === 'none') {
        next.compression_mode = 'by_quality'
      }
      setExportSettings(next)
    }
  }

  return (
    <div
      className="filmora-shell"
      onClick={() => {
        if (showSaveMenu) setShowSaveMenu(false)
        if (showRecentMenu) setShowRecentMenu(false)
        if (showUpdates) setShowUpdates(false)
      }}
      onDragOver={(e) => {
        if (e.dataTransfer?.types?.includes('Files')) e.preventDefault()
      }}
      onDrop={(e) => {
        const dropped = e.dataTransfer?.files?.[0]
        if (!dropped || !/\.(wfpbundle|wfp|zip|dgsproj|json)$/i.test(dropped.name)) return
        e.preventDefault()
        void openProjectFile(dropped)
      }}
    >
      <header className="app-menubar">
        <div className="menubar-left-group" onClick={(e) => e.stopPropagation()}>
          <div className="brand-block">
            <DgsNeonBrandLogo />
            <div className="brand-copy">
              <strong>DGS Auto Editor</strong>
              <span>Script · VO · Timeline Studio</span>
            </div>
          </div>

          <div className="dropdown-wrap" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              className={`ghost dropdown-trigger ${showUpdates ? 'active' : ''}`}
              onClick={() => {
                setShowSaveMenu(false)
                setShowRecentMenu(false)
                setShowUpdates((open) => !open)
              }}
              title="Version and published changes"
            >
              <NeonIcon name="sparkles" size={14} tone="amber" /> Updates
              {appRelease?.updateAvailable ? ' · new' : ''}
            </button>
            {showUpdates && (
              <div className="dropdown-menu left-dropdown update-log">
                <div className="dropdown-header">
                  This copy {appRelease?.current || '…'}
                  {appRelease?.latest && appRelease.latest !== appRelease.current
                    ? ` · latest ${appRelease.latest}`
                    : ''}
                </div>
                {appRelease?.downloads?.win && (
                  <a
                    className="dropdown-item"
                    href={appRelease.platform === 'darwin' ? appRelease.downloads.mac || appRelease.downloads.win : appRelease.downloads.win}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <strong>{appRelease.updateAvailable ? `Download ${appRelease.latest}` : 'Update page'}</strong>
                    <span>{appRelease.platform === 'darwin' ? 'Mac DMG' : 'Windows EXE'} · version {appRelease.latest || appRelease.current}</span>
                  </a>
                )}
                {(appRelease?.history || []).map((entry) => (
                  <div key={entry.version} className="update-entry">
                    <strong>
                      {entry.version}
                      {entry.date ? ` · ${entry.date}` : ''}
                    </strong>
                    <ul>
                      {(entry.notes || []).map((note) => (
                        <li key={note}>{note}</li>
                      ))}
                    </ul>
                  </div>
                ))}
                <div className="dropdown-divider" />
                <div className="update-assets">
                  English cards {appAssets?.eng ? 'ready' : 'downloading'}
                  {' · '}
                  Marathi cards {appAssets?.mar ? 'ready' : 'downloading'}
                  {' · '}
                  Hearing {appAssets?.whisper === 'ready' ? 'ready' : appAssets?.whisper === 'downloading' ? 'downloading' : 'on first Auto-align'}
                </div>
                {appRelease?.feedError ? <div className="update-assets">{appRelease.feedError}</div> : null}
              </div>
            )}
          </div>

          <button
            type="button"
            className="ghost"
            disabled={!!busy}
            onClick={() => resetToNewSession()}
            title="Start a brand-new blank project session"
          >
            <NeonIcon name="sparkles" size={14} tone="cyan" /> New Session
          </button>

          <div className="dropdown-wrap">
            <button
              type="button"
              className={`ghost dropdown-trigger ${showSaveMenu ? 'active' : ''}`}
              disabled={!!busy}
              onClick={() => {
                setShowRecentMenu(false)
                setShowSaveMenu((v) => !v)
              }}
              title="Save .wfp project file or collect portable package"
            >
              <NeonIcon name="save" size={14} tone="cyan" /> Save (.wfp) ▾
            </button>
            {showSaveMenu && (
              <div className="dropdown-menu left-dropdown">
                <div className="dropdown-header">Save Project (.wfp)</div>
                <button
                  type="button"
                  className="dropdown-item"
                  disabled={!projectId}
                  onClick={() => {
                    setShowSaveMenu(false)
                    void saveProjectFile()
                  }}
                >
                  <strong>
                    <NeonIcon name="save" size={13} tone="cyan" /> Save .wfp Project
                  </strong>
                  <span>Saves {title || 'Project'}.wfp (opens here &amp; in Filmora 16)</span>
                </button>
                <button
                  type="button"
                  className="dropdown-item"
                  disabled={!projectId}
                  onClick={() => void saveWfpToChosenFolder()}
                >
                  <strong>
                    <NeonIcon name="folder" size={13} tone="violet" /> Save .wfp As (Choose Folder…)
                  </strong>
                  <span>Pick any folder on disk to save the .wfp file</span>
                </button>
                <div className="dropdown-divider" />
                <div className="dropdown-header">Collect Files (For Another PC &amp; Filmora 16)</div>
                <button
                  type="button"
                  className="dropdown-item"
                  disabled={!projectId}
                  onClick={() => {
                    setShowSaveMenu(false)
                    void collectProjectFiles('wfpbundle')
                  }}
                >
                  <strong>
                    <NeonIcon name="package" size={13} tone="emerald" /> Collect Files (.wfpbundle — Filmora 16 Native)
                  </strong>
                  <span>Saves {title || 'Project'}.wfpbundle with Medias/&#123;GUID&#125; + .wfp</span>
                </button>
                <button
                  type="button"
                  className="dropdown-item"
                  disabled={!projectId}
                  onClick={() => {
                    setShowSaveMenu(false)
                    void collectProjectFiles('folder')
                  }}
                >
                  <strong>
                    <NeonIcon name="folderOpen" size={13} tone="cyan" /> Collect Files + .wfpbundle to Folder
                  </strong>
                  <span>All images, videos, synced audio, .wfp &amp; .wfpbundle in one folder</span>
                </button>
                <button
                  type="button"
                  className="dropdown-item"
                  disabled={!projectId}
                  onClick={() => {
                    setShowSaveMenu(false)
                    void collectProjectFiles('zip')
                  }}
                >
                  <strong>
                    <NeonIcon name="zip" size={13} tone="amber" /> Collect Files + .wfp to .ZIP
                  </strong>
                  <span>Portable .zip archive with folder structure</span>
                </button>
                <div className="dropdown-divider" />
                <button
                  type="button"
                  className="dropdown-item"
                  disabled={!timeline}
                  onClick={() => {
                    setShowSaveMenu(false)
                    void exportSrt()
                  }}
                >
                  <strong>
                    <NeonIcon name="subtitles" size={13} tone="cyan" /> Download Standalone SRT Only (.srt)
                  </strong>
                  <span>Downloads SRT_Only_{title || 'Project'}.srt (never attached to video)</span>
                </button>
              </div>
            )}
          </div>

          <div className="dropdown-wrap">
            <button
              type="button"
              className={`ghost dropdown-trigger ${showRecentMenu ? 'active' : ''}`}
              disabled={!!busy}
              onClick={() => {
                setShowSaveMenu(false)
                const next = !showRecentMenu
                setShowRecentMenu(next)
                if (next) void refreshRecent()
              }}
              title="Open recent projects and recent folders without searching"
            >
              <NeonIcon name="clock" size={14} tone="violet" /> Recent Files &amp; Folders ▾
            </button>
            {showRecentMenu && (
              <div className="dropdown-menu left-dropdown wide">
                <div className="dropdown-header">Recent Projects (1-Click Open)</div>
                {recentProjects.length === 0 ? (
                  <div className="dropdown-empty">No recent projects yet</div>
                ) : (
                  recentProjects.slice(0, 10).map((p) => (
                    <button
                      key={p.project_id}
                      type="button"
                      className={`dropdown-item ${p.project_id === projectId ? 'current' : ''}`}
                      onClick={() => void loadRecentProject(p.project_id)}
                    >
                      <div className="dropdown-item-top">
                        <strong className="dropdown-title-wrap">
                          <span className="dropdown-proj-title">{p.title}</span>{' '}
                          <small className="dropdown-proj-id">({p.project_id})</small>
                        </strong>
                        {p.client_label && (
                          <span className={`pc-tag ${p.is_this_pc ? 'mine' : ''}`}>
                            <NeonIcon name="monitor" size={11} tone="cyan" />
                            <span>{p.is_this_pc ? `This PC (${p.client_label})` : p.client_label}</span>
                          </span>
                        )}
                      </div>
                      <span className="dropdown-item-sub">
                        {p.scene_count} scenes · {p.media_count} media · {fmt(p.total_duration)} ·{' '}
                        {p.updated_at}
                      </span>
                    </button>
                  ))
                )}
                {recentPaths.length > 0 && (
                  <>
                    <div className="dropdown-divider" />
                    <div className="dropdown-header">Recent Media Folders (1-Click Import)</div>
                    {recentPaths
                      .filter((rp) => rp.kind === 'images' || rp.kind === 'videos')
                      .slice(0, 6)
                      .map((rp, i) => (
                        <button
                          key={`${rp.kind}-${i}`}
                          type="button"
                          className="dropdown-item"
                          onClick={() =>
                            void importFromRecentPath(rp.kind as 'images' | 'videos', rp.path)
                          }
                        >
                          <strong>
                            {rp.kind === 'images' ? (
                              <>
                                <NeonIcon name="image" size={13} tone="cyan" /> Images:
                              </>
                            ) : (
                              <>
                                <NeonIcon name="video" size={13} tone="violet" /> Videos:
                              </>
                            )}{' '}
                            {rp.label}
                          </strong>
                          <span>{rp.path}</span>
                        </button>
                      ))}
                  </>
                )}
              </div>
            )}
          </div>

          <label
            className="ghost file-action"
            title="Open a saved Filmora 16 .wfp, .wfpbundle archive, collected .zip package, or .dgsproj project file"
            onClick={(e) => {
              const bridge = desktopBridge()
              if (!bridge?.pickProjectFile) return
              e.preventDefault()
              void bridge.pickProjectFile().then((picked) => {
                if (picked) void openProjectFromDisk(picked)
              })
            }}
          >
            <input
              type="file"
              accept=".wfp,.wfpbundle,.zip,.dgsproj,.json"
              onChange={(e) => {
                const f = e.target.files?.[0] || null
                e.currentTarget.value = ''
                void openProjectFile(f)
              }}
            />
            <NeonIcon name="folderOpen" size={14} tone="emerald" /> Open (.wfp / .wfpbundle)
          </label>
        </div>

        <div className="menubar-actions">
          <button
            type="button"
            className={`ghost ${renamePlan.steps.length > 0 ? 'export-cta-btn' : ''}`}
            disabled={!!busy || renumberBusy}
            onClick={() => void linkOrSyncSourceFolder()}
            title={
              renamePlan.steps.length > 0
                ? `Apply ${renamePlan.steps.length} pending replacement(s)/rename(s) directly inside your local source folder (${renamePlan.steps.map((s) => `${s.from}→${s.to}`).join(', ')})`
                : folderSyncGranted && linkedFolderName
                  ? `Live Folder Sync ON ("${linkedFolderName}") — all auto-swaps, timeline edits, replaced media & script changes automatically update your source folder`
                  : 'Link your local chapter / Scene Images folder so every replacement & timeline edit is also saved directly in the source folder'
            }
          >
            <NeonIcon
              name={folderSyncGranted && renamePlan.steps.length === 0 ? 'check' : 'folder'}
              size={14}
              tone={renamePlan.steps.length > 0 ? 'amber' : folderSyncGranted ? 'emerald' : 'cyan'}
            />{' '}
            {renumberBusy
              ? 'Syncing Folder…'
              : renamePlan.steps.length > 0
                ? `Sync Source Folder (${renamePlan.steps.length})`
                : folderSyncGranted && linkedFolderName
                  ? `Folder Synced (${linkedFolderName})`
                  : linkedFolderName
                    ? `Sync Folder (${linkedFolderName})`
                    : 'Link Source Folder'}
          </button>
          <button type="button" className="ghost" disabled={!!busy} onClick={build}>
            <NeonIcon name="wand" size={14} tone="cyan" /> Auto-align
          </button>
          <button
            type="button"
            className="ghost"
            disabled={!timeline || !!busy}
            onClick={exportSrt}
            title="Download standalone .srt subtitle file (never encoded or attached to video)"
          >
            <NeonIcon name="subtitles" size={14} tone="violet" /> Export SRT Only
          </button>
          <button
            type="button"
            className="ghost export-cta-btn"
            disabled={!timeline}
            onClick={async () => {
              setShowSaveMenu(false)
              setShowRecentMenu(false)
              setExportError(null)
              setExportNotice(null)
              setShowExport(true)
              if (projectId) {
                try {
                  const sr = await fetch(`${API}/api/projects/${projectId}/export/status`)
                  if (sr.ok) {
                    const st = await sr.json()
                    if (st && st.running) {
                      setExportProgress({
                        running: true,
                        percent: st.percent || 5,
                        message: st.message || 'Rendering on server…',
                      })
                    }
                  }
                } catch {
                  /* ignore */
                }
              }
            }}
          >
            <NeonIcon name="export" size={14} tone="emerald" /> Export Video
          </button>
          {exportProgress?.running && (
            <button
              type="button"
              className="fe-btn danger"
              style={{ minHeight: 28, padding: '0 10px', fontSize: 11.5 }}
              onClick={() => void cancelExport()}
              title="Stop the active render immediately"
            >
              <NeonIcon name="stop" size={12} tone="rose" /> Cancel Render ({exportProgress.percent}%)
            </button>
          )}
          <button
            type="button"
            className="ghost"
            disabled={!!busy}
            title="Start a brand-new blank project"
            onClick={async () => {
              setBusy('Creating new project…')
              try {
                const r = await fetch(`${API}/api/projects`, {
                  method: 'POST',
                  headers: clientHeaders({ 'Content-Type': 'application/json' }),
                  body: JSON.stringify({ client_id: clientId, client_label: clientLabel }),
                })
                const data = await r.json()
                setProjectId(data.project_id)
                setMedia([])
                setLocalMediaUrls({})
                setLocalThumbUrls({})
                setLocalNarrUrl(null)
                setLocalPoemUrl(null)
                setLocalLogoUrl(null)
                localMediaFilesRef.current = {}
                localVoSlotFilesRef.current = {}
                localPoemFileRef.current = null
                localLogoFileRef.current = null
                setSelectedMediaId(null)
                setScenes([])
                setVoInfo(null)
                setVoSlots([1])
                setVoFiles({})
                setPoemVoInfo(null)
                setLogoInfo({ ...DEFAULT_BRAND_LOGO })
                setLogoTransform({ ...DEFAULT_LOGO_TRANSFORM })
                setIgnoredQaKeys([])
                setPoemInfo(null)
                setTimeline(null)
                setTitle('Auto Edit')
                movePlayhead(0)
                setPlaying(false)
                setDirty(false)
                setSceneEdits({})
                setLog(`Created new project (${data.project_id}) on ${clientLabel} — import media, script & VO`)
              } catch (e) {
                setLog(String(e))
              } finally {
                setBusy(null)
              }
            }}
          >
            <NeonIcon name="plus" size={13} tone="cyan" /> New Project
          </button>
          <button
            type="button"
            className="pc-id-pill"
            onClick={renamePcLabel}
            title={`Individual PC Upload Identification: ${clientLabel} (${clientId}) — Click to rename this PC`}
          >
            <NeonIcon name="monitor" size={13} tone="cyan" /> {clientLabel}
          </button>
          <span className="proj-pill">{projectId ? projectId : 'New project'}</span>
        </div>
      </header>

      <div className="workspace">
        <aside className="media-panel">
          <div className="media-tabs">
            <button
              type="button"
              className={sideTab === 'media' ? 'active' : ''}
              onClick={() => setSideTab('media')}
            >
              <NeonIcon name="layers" size={13} tone="cyan" /> Media ({media.length})
            </button>
            <button
              type="button"
              className={sideTab === 'script' ? 'active' : ''}
              onClick={() => setSideTab('script')}
            >
              <NeonIcon name="script" size={13} tone="violet" /> Script ({scenes.length})
            </button>
            <button
              type="button"
              className={sideTab === 'voiceovers' ? 'active' : ''}
              onClick={() => setSideTab('voiceovers')}
            >
              <NeonIcon name="mic" size={13} tone="emerald" /> VO / Replace
            </button>
          </div>
          <div className="media-main">
            {sideTab === 'media' && (
              <>
                <div className="import-stack">
                  <input
                    id="cloud-img-folder-input"
                    type="file"
                    multiple
                    // @ts-expect-error webkitdirectory is standard in modern browsers for folder upload
                    webkitdirectory=""
                    directory=""
                    style={{ display: 'none' }}
                    onChange={(e) => {
                      const fl = e.target.files
                      void uploadMediaFolder('images', fl)
                      e.currentTarget.value = ''
                    }}
                  />
                  <input
                    id="cloud-img-files-input"
                    type="file"
                    multiple
                    accept="image/*,.png,.jpg,.jpeg,.webp,.bmp,.gif,.svg,.avif,.jfif,.heic"
                    style={{ display: 'none' }}
                    onChange={(e) => {
                      const fl = e.target.files
                      void uploadMediaFolder('images', fl)
                      e.currentTarget.value = ''
                    }}
                  />
                  <input
                    id="cloud-vid-folder-input"
                    type="file"
                    multiple
                    // @ts-expect-error webkitdirectory is standard in modern browsers for folder upload
                    webkitdirectory=""
                    directory=""
                    style={{ display: 'none' }}
                    onChange={(e) => {
                      const fl = e.target.files
                      void uploadMediaFolder('videos', fl)
                      e.currentTarget.value = ''
                    }}
                  />
                  <input
                    id="cloud-vid-files-input"
                    type="file"
                    multiple
                    accept="video/*,.mp4,.mov,.webm,.mkv,.avi,.m4v,.3gp,.ts,.mts,.flv,.wmv"
                    style={{ display: 'none' }}
                    onChange={(e) => {
                      const fl = e.target.files
                      void uploadMediaFolder('videos', fl)
                      e.currentTarget.value = ''
                    }}
                  />
                  <div className="import-row-pair">
                    <button
                      type="button"
                      className="import-btn"
                      disabled={!!busy}
                      onClick={() => void pickFolder('images')}
                      title="Select an entire folder of images"
                    >
                      <NeonIcon name="folder" size={14} tone="cyan" /> Image Folder
                    </button>
                    <button
                      type="button"
                      className="import-btn secondary"
                      disabled={!!busy}
                      onClick={() => pickFiles('images')}
                      title="Select individual or multiple image files"
                    >
                      <NeonIcon name="image" size={14} tone="cyan" /> + Image Files
                    </button>
                  </div>
                  <div className="import-row-pair">
                    <button
                      type="button"
                      className="import-btn"
                      disabled={!!busy}
                      onClick={() => void pickFolder('videos')}
                      title="Select an entire folder of videos (replaces any previous chapter videos)"
                    >
                      <NeonIcon name="video" size={14} tone="violet" /> Video Folder
                    </button>
                    <button
                      type="button"
                      className="import-btn secondary"
                      disabled={!!busy}
                      onClick={() => pickFiles('videos')}
                      title="Select individual or multiple video files"
                    >
                      <NeonIcon name="film" size={14} tone="violet" /> + Video Files
                    </button>
                  </div>
                  {media.some((m) => m.kind === 'video') && (
                    <button
                      type="button"
                      className="import-btn secondary"
                      style={{
                        width: '100%',
                        borderColor: 'rgba(239, 68, 68, 0.45)',
                        color: '#fca5a5',
                        background: 'rgba(239, 68, 68, 0.08)',
                        marginTop: 4,
                        marginBottom: 4,
                      }}
                      disabled={!!busy}
                      onClick={() => void clearMediaKind('videos')}
                      title="Purge all videos from this project and restore slide images on Video 1"
                    >
                      ✕ Clear Videos ({media.filter((m) => m.kind === 'video').length})
                    </button>
                  )}
                  <label className="import-btn secondary">
                    <input
                      type="file"
                      accept=".xlsx,.xlsm,.xls,.txt,.md,text/plain"
                      disabled={!!busy}
                      onChange={(e) => {
                        const f = e.target.files?.[0] || null
                        e.currentTarget.value = ''
                        void onScript(f)
                      }}
                    />
                    <NeonIcon name="script" size={14} tone="amber" />{' '}
                    {scenes.length ? `Replace Script (${scenes.length} scenes)` : 'Import Script (.xlsx / .txt)'}
                  </label>
                  <a
                    href="/Master_Script_Template.xlsx"
                    download="Master_Script_Template.xlsx"
                    className="import-btn secondary"
                    style={{ textDecoration: 'none', textAlign: 'center', fontSize: 11, padding: '5px 10px', marginTop: 2, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}
                    title="Download the official Excel Script Template (.xlsx) with English, Marathi and instruction sheets"
                  >
                    <NeonIcon name="save" size={13} tone="cyan" /> Download Script Template (.xlsx)
                  </a>
                  <div className="vo-slots-box">
                    {voSlots.map((slot) => {
                      const uploaded = voFiles[slot]
                      return (
                        <div key={slot} className="vo-slot-row">
                          <label className="import-btn secondary vo-slot-btn" title="Click to import or replace this VO slot">
                            <input
                              type="file"
                              accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac,.opus,.wma"
                              disabled={!!busy}
                              onChange={(e) => {
                                const f = e.target.files?.[0] || null
                                e.currentTarget.value = ''
                                void onVoice(f, slot)
                              }}
                            />
                            <NeonIcon name={uploaded ? 'refresh' : 'mic'} size={14} tone="emerald" />{' '}
                            {uploaded
                              ? `Replace VO ${slot}: ${uploaded.filename}${
                                  uploaded.duration ? ` (${fmt(uploaded.duration)})` : ''
                                }`
                              : `Import Narration VO ${slot}`}
                          </label>
                          {slot > 1 && (
                            <button
                              type="button"
                              className="vo-remove-btn"
                              disabled={!!busy}
                              onClick={() => void removeVoSlot(slot)}
                              title={`Remove VO ${slot}`}
                            >
                              ✕
                            </button>
                          )}
                        </div>
                      )
                    })}
                    {voSlots.length < 10 && (
                      <button
                        type="button"
                        className="add-vo-btn"
                        disabled={!!busy}
                        onClick={addNextVoSlot}
                      >
                        + Add VO {voSlots.length + 1} (up to 10 VOs)
                      </button>
                    )}
                  </div>
                  {hasPoem && (
                    <label className={`import-btn poem-cta-active ${busy ? 'disabled' : ''}`}>
                      <input
                        type="file"
                        accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac"
                        disabled={!!busy}
                        onChange={(e) => {
                          const f = e.target.files?.[0] || null
                          e.currentTarget.value = ''
                          void onPoemVoice(f)
                        }}
                      />
                      <NeonIcon name="music" size={15} tone="rose" />{' '}
                      {poemVoInfo
                        ? `✓ Poem VO: ${poemVoInfo.filename} (Replace)`
                        : poemRange
                          ? `🎵 Upload Poem VO (${poemRange.first.replace('screen_', 'Scene ')}–${poemRange.last.replace('screen_', 'Scene ')})`
                          : '🎵 Upload Poem VO / Suno'}
                    </label>
                  )}
                  <div className="brand-logo-card">
                    <div className="brand-logo-head">
                      <div className="brand-logo-title">
                        <NeonIcon name="tag" size={13} tone="cyan" />
                        <span>Brand Logo (All Screens)</span>
                      </div>
                      <button
                        type="button"
                        className={`logo-switch-pill ${logoInfo.enabled ? 'on' : 'off'}`}
                        onClick={() => void toggleClientLogo(!logoInfo.enabled)}
                        title={
                          logoInfo.enabled
                            ? 'Brand Logo is ON across all screens (click to turn OFF)'
                            : 'Brand Logo is OFF (click to turn ON across all screens)'
                        }
                      >
                        <span className="switch-dot" />
                        <span>{logoInfo.enabled ? 'ON' : 'OFF'}</span>
                      </button>
                    </div>

                    <div className="brand-logo-preview-row">
                      <div className="brand-logo-thumb">
                        <img
                          src={
                            localLogoUrl ||
                            (projectId && logoInfo.path && logoInfo.path !== '/eclass-logo.png'
                              ? `${API}/api/projects/${projectId}/logo-file`
                              : '/eclass-logo.png')
                          }
                          alt="Brand Logo"
                        />
                      </div>
                      <div className="brand-logo-meta">
                        <strong>{logoInfo.filename || 'E-Class Logo.png'}</strong>
                        <span>
                          Scale {logoTransform.scale_w.toFixed(2)}% · X {logoTransform.pos_x.toFixed(2)}, Y{' '}
                          {logoTransform.pos_y.toFixed(2)}
                        </span>
                      </div>
                    </div>

                    <div className="brand-logo-btn-row">
                      <label className="brand-logo-mini-btn" title="Upload a custom brand logo">
                        <input
                          type="file"
                          accept="image/*,.png,.jpg,.jpeg,.webp,.svg"
                          disabled={!!busy}
                          style={{ display: 'none' }}
                          onChange={(e) => {
                            const f = e.target.files?.[0] || null
                            e.currentTarget.value = ''
                            void onClientLogo(f)
                          }}
                        />
                        Change Logo…
                      </label>
                      <button
                        type="button"
                        className={`brand-logo-mini-btn ${showLogoPlacement ? 'active' : ''}`}
                        onClick={() => setShowLogoPlacement((v) => !v)}
                        title="Open Filmora Transform placement controls (Scale, Position, Anchor Point, Rotate) — or drag logo directly on Preview"
                      >
                        {showLogoPlacement ? '▴ Hide Placement' : '⚙ Placement / Transform'}
                      </button>
                      <button
                        type="button"
                        className="brand-logo-mini-btn"
                        onClick={() => void resetBrandLogoToDefault()}
                        title="Reset to default E-Class™ Logo & default Filmora placement (10%, Pos 1034.21/565.98, Anchor 1900/1065)"
                      >
                        ↺ Default
                      </button>
                    </div>

                    {showLogoPlacement && (
                      <div className="filmora-transform-box">
                        <div className="ft-head-row">
                          <span className="ft-head-title">▾ Transform</span>
                          <button
                            type="button"
                            className="ft-reset-btn"
                            onClick={() =>
                              updateLogoTransform({ ...DEFAULT_LOGO_TRANSFORM }, true)
                            }
                            title="Reset all Transform fields to default (10%, 1034.21/565.98, Anchor 1900/1065, 0°)"
                          >
                            ↺ Reset All
                          </button>
                        </div>

                        <div className="ft-section">
                          <div className="ft-label-col">
                            <span>Scale</span>
                          </div>
                          <div className="ft-controls-col">
                            <div className="ft-scale-row">
                              <span className="ft-sub-lbl">Width</span>
                              <input
                                type="range"
                                min={1}
                                max={50}
                                step={0.5}
                                value={logoTransform.scale_w}
                                onChange={(e) => {
                                  const w = Math.max(1, Math.min(100, Number(e.target.value) || 10))
                                  updateLogoTransform({
                                    ...logoTransform,
                                    scale_w: w,
                                    scale_h: logoTransform.lock_aspect ? w : logoTransform.scale_h,
                                  })
                                }}
                                onMouseUp={() => updateLogoTransform(logoTransform, true)}
                              />
                              <div className="ft-num-wrap">
                                <input
                                  type="number"
                                  step={0.5}
                                  min={1}
                                  max={100}
                                  value={logoTransform.scale_w}
                                  onChange={(e) => {
                                    const w = Math.max(1, Math.min(100, Number(e.target.value) || 10))
                                    updateLogoTransform(
                                      {
                                        ...logoTransform,
                                        scale_w: w,
                                        scale_h: logoTransform.lock_aspect ? w : logoTransform.scale_h,
                                      },
                                      true,
                                    )
                                  }}
                                />
                                <span>%</span>
                              </div>
                            </div>

                            <div className="ft-lock-row">
                              <button
                                type="button"
                                className={`ft-lock-btn ${logoTransform.lock_aspect ? 'locked' : ''}`}
                                onClick={() =>
                                  updateLogoTransform(
                                    {
                                      ...logoTransform,
                                      lock_aspect: !logoTransform.lock_aspect,
                                      scale_h: !logoTransform.lock_aspect
                                        ? logoTransform.scale_w
                                        : logoTransform.scale_h,
                                    },
                                    true,
                                  )
                                }
                                title={
                                  logoTransform.lock_aspect
                                    ? 'Aspect Ratio Locked (click to unlock Width/Height independently)'
                                    : 'Aspect Ratio Unlocked (click to lock)'
                                }
                              >
                                {logoTransform.lock_aspect ? '🔒 Lock Aspect' : '🔓 Unlock Aspect'}
                              </button>
                              <button
                                type="button"
                                className="ft-icon-reset"
                                onClick={() =>
                                  updateLogoTransform(
                                    {
                                      ...logoTransform,
                                      scale_w: DEFAULT_LOGO_TRANSFORM.scale_w,
                                      scale_h: DEFAULT_LOGO_TRANSFORM.scale_h,
                                    },
                                    true,
                                  )
                                }
                                title="Reset Scale to 10.00%"
                              >
                                ↺
                              </button>
                            </div>

                            <div className="ft-scale-row">
                              <span className="ft-sub-lbl">Height</span>
                              <input
                                type="range"
                                min={1}
                                max={50}
                                step={0.5}
                                value={logoTransform.scale_h}
                                onChange={(e) => {
                                  const h = Math.max(1, Math.min(100, Number(e.target.value) || 10))
                                  updateLogoTransform({
                                    ...logoTransform,
                                    scale_h: h,
                                    scale_w: logoTransform.lock_aspect ? h : logoTransform.scale_w,
                                  })
                                }}
                                onMouseUp={() => updateLogoTransform(logoTransform, true)}
                              />
                              <div className="ft-num-wrap">
                                <input
                                  type="number"
                                  step={0.5}
                                  min={1}
                                  max={100}
                                  value={logoTransform.scale_h}
                                  onChange={(e) => {
                                    const h = Math.max(1, Math.min(100, Number(e.target.value) || 10))
                                    updateLogoTransform(
                                      {
                                        ...logoTransform,
                                        scale_h: h,
                                        scale_w: logoTransform.lock_aspect ? h : logoTransform.scale_w,
                                      },
                                      true,
                                    )
                                  }}
                                />
                                <span>%</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="ft-xy-row">
                          <span className="ft-row-lbl">Position</span>
                          <label className="ft-xy-field">
                            <span>X</span>
                            <input
                              type="number"
                              step={1}
                              value={logoTransform.pos_x}
                              onChange={(e) =>
                                updateLogoTransform(
                                  { ...logoTransform, pos_x: Number(e.target.value) || 0 },
                                  true,
                                )
                              }
                            />
                          </label>
                          <label className="ft-xy-field">
                            <span>Y</span>
                            <input
                              type="number"
                              step={1}
                              value={logoTransform.pos_y}
                              onChange={(e) =>
                                updateLogoTransform(
                                  { ...logoTransform, pos_y: Number(e.target.value) || 0 },
                                  true,
                                )
                              }
                            />
                          </label>
                          <button
                            type="button"
                            className="ft-icon-reset"
                            onClick={() =>
                              updateLogoTransform(
                                {
                                  ...logoTransform,
                                  pos_x: DEFAULT_LOGO_TRANSFORM.pos_x,
                                  pos_y: DEFAULT_LOGO_TRANSFORM.pos_y,
                                },
                                true,
                              )
                            }
                            title="Reset Position to X: 1034.21, Y: 565.98"
                          >
                            ↺
                          </button>
                        </div>

                        <div className="ft-xy-row">
                          <span className="ft-row-lbl">Anchor Point</span>
                          <label className="ft-xy-field">
                            <span>X</span>
                            <input
                              type="number"
                              step={1}
                              value={logoTransform.anchor_x}
                              onChange={(e) =>
                                updateLogoTransform(
                                  { ...logoTransform, anchor_x: Number(e.target.value) || 0 },
                                  true,
                                )
                              }
                            />
                          </label>
                          <label className="ft-xy-field">
                            <span>Y</span>
                            <input
                              type="number"
                              step={1}
                              value={logoTransform.anchor_y}
                              onChange={(e) =>
                                updateLogoTransform(
                                  { ...logoTransform, anchor_y: Number(e.target.value) || 0 },
                                  true,
                                )
                              }
                            />
                          </label>
                          <button
                            type="button"
                            className="ft-icon-reset"
                            onClick={() =>
                              updateLogoTransform(
                                {
                                  ...logoTransform,
                                  anchor_x: DEFAULT_LOGO_TRANSFORM.anchor_x,
                                  anchor_y: DEFAULT_LOGO_TRANSFORM.anchor_y,
                                },
                                true,
                              )
                            }
                            title="Reset Anchor Point to X: 1900.00, Y: 1065.00"
                          >
                            ↺
                          </button>
                        </div>

                        <div className="ft-xy-row">
                          <span className="ft-row-lbl">Rotate</span>
                          <input
                            type="range"
                            min={-180}
                            max={180}
                            step={1}
                            value={logoTransform.rotate}
                            onChange={(e) =>
                              updateLogoTransform({
                                ...logoTransform,
                                rotate: Number(e.target.value) || 0,
                              })
                            }
                            onMouseUp={() => updateLogoTransform(logoTransform, true)}
                          />
                          <div className="ft-num-wrap">
                            <input
                              type="number"
                              step={1}
                              value={logoTransform.rotate}
                              onChange={(e) =>
                                updateLogoTransform(
                                  { ...logoTransform, rotate: Number(e.target.value) || 0 },
                                  true,
                                )
                              }
                            />
                            <span>°</span>
                          </div>
                          <button
                            type="button"
                            className="ft-icon-reset"
                            onClick={() =>
                              updateLogoTransform({ ...logoTransform, rotate: 0 }, true)
                            }
                            title="Reset Rotation to 0.00°"
                          >
                            ↺
                          </button>
                        </div>
                        <div className="ft-hint">
                          💡 Tip: You can also drag the logo directly on the video preview canvas to position it manually.
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {hasPoem && (
                  <div
                    className="poem-banner"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      flexWrap: 'wrap',
                      gap: 6,
                    }}
                  >
                    <span>
                      Poem: {poemRange ? `${poemRange.first}→${poemRange.last}` : 'Detected'}
                      {poemRange?.suno != null ? ` · ~${poemRange.suno}s` : ''}
                    </span>
                    <button
                      type="button"
                      className="brand-logo-mini-btn active"
                      style={{ padding: '2px 8px', fontSize: 10.5 }}
                      onClick={() => setShowPoemStudio((v) => !v)}
                      title="Open Poem Typography & Sticker Style Studio + Screen Area Selector"
                    >
                      <NeonIcon name="sparkles" size={11} tone="amber" /> {showPoemStudio ? 'Hide Studio' : 'Poem Studio'}
                    </button>
                  </div>
                )}

                <div className="media-grid">
                  {media.map((m) => {
                    const matchedClip = timeline?.clips?.find(
                      (c) => c.media_id === m.id || (m.screen && c.screen === m.screen),
                    )
                    return (
                      <div
                        key={m.id}
                        className={`media-thumb clickable`}
                        draggable
                        onDragStart={(e) => {
                          e.dataTransfer.setData('application/x-dgs-media', JSON.stringify(m))
                          e.dataTransfer.effectAllowed = 'copy'
                        }}
                        title={
                          matchedClip
                            ? `${m.filename} (${(m.screen || matchedClip.screen).replace(/^screen_/i, 'Scene ')}) — Click to jump to ${fmt(matchedClip.start)} · Drag onto Video 1 to place/replace`
                            : `${m.filename} (${m.screen ? m.screen.replace(/^screen_/i, 'Scene ') : 'Click to preview · Drag onto Video 1 to place'})`
                        }
                        onClick={() => {
                          setSelectedMediaId(m.id)
                          if (matchedClip) {
                            movePlayhead(matchedClip.start)
                          }
                        }}
                      >
                        <div className="media-thumb-preview">
                          {(localThumbUrls[m.id] || (m.kind === 'image' && localMediaUrls[m.id]) || projectId) && (
                            <img
                              src={
                                localThumbUrls[m.id] ||
                                (m.kind === 'image' ? localMediaUrls[m.id] : '') ||
                                `${API}/api/projects/${projectId}/media-thumb/${m.id}`
                              }
                              alt={m.filename}
                              loading="lazy"
                              onError={(e) => {
                                e.currentTarget.style.opacity = '0.2'
                              }}
                            />
                          )}
                          <span className={`kind ${m.kind}`}>{m.kind === 'image' ? 'IMG' : 'VID'}</span>
                          {m.duration != null && m.duration > 0 && (
                            <span className="media-dur">{fmt(m.duration)}</span>
                          )}
                        </div>
                        <div className="name">{m.filename}</div>
                        <div className="screen">{m.screen ? m.screen.replace(/^screen_/i, 'Scene ') : 'unmapped'}</div>
                      </div>
                    )
                  })}
                  {!media.length && <p className="empty-hint">Imported screen media appears here</p>}
                </div>
              </>
            )}

            {sideTab === 'script' && (
              <div className="replace-panel">
                <div className="replace-panel-top">
                  <label className="import-btn secondary" style={{ width: '100%', textAlign: 'center' }}>
                    <input
                      type="file"
                      accept=".xlsx,.xlsm,.xls,.txt,.md,text/plain"
                      disabled={!!busy}
                      onChange={(e) => {
                        const f = e.target.files?.[0] || null
                        e.currentTarget.value = ''
                        void onScript(f)
                      }}
                    />
                    <NeonIcon name="script" size={14} tone="amber" /> Replace Full Script File (.xlsx / .txt)
                  </label>
                  <input
                    className="scene-search-input"
                    placeholder="Filter scenes (e.g. screen_12 or words)…"
                    value={sceneFilter}
                    onChange={(e) => setSceneFilter(e.target.value)}
                  />
                </div>
                {!scenes.length ? (
                  <p className="empty-hint">No script uploaded yet — import a script above.</p>
                ) : (
                  <div className="scene-edit-list">
                    {scenes
                      .filter((s) => {
                        const q = sceneFilter.trim().toLowerCase()
                        if (!q) return true
                        return (
                          s.screen.toLowerCase().includes(q) ||
                          (s.voiceover_text || '').toLowerCase().includes(q) ||
                          (s.onscreen_text || '').toLowerCase().includes(q) ||
                          (s.text || '').toLowerCase().includes(q)
                        )
                      })
                      .map((s) => {
                        const clip = timeline?.clips?.find((c) => c.screen === s.screen)
                        const edit = sceneEdits[s.screen] ?? {
                          voiceover_text: s.voiceover_text ?? clip?.vo_text ?? s.text ?? '',
                          onscreen_text: s.onscreen_text ?? '',
                        }
                        return (
                          <div key={s.index} className="scene-edit-card">
                            <div className="scene-edit-head">
                              <strong>
                                {s.screen.replace(/^screen_/i, 'Scene ')}
                                {s.is_poem ? ' · Poem' : ''}
                              </strong>
                              {clip && (
                                <button
                                  type="button"
                                  className="scene-jump-btn"
                                  onClick={() => movePlayhead(clip.start)}
                                  title="Jump preview to this scene"
                                >
                                  ▶ {fmt(clip.start)}–{fmt(clip.end)}
                                </button>
                              )}
                            </div>
                            <label className="scene-edit-field">
                              <span>Spoken VO / Narration Text:</span>
                              <textarea
                                rows={2}
                                value={edit.voiceover_text}
                                onChange={(e) =>
                                  setSceneEdits((prev) => ({
                                    ...prev,
                                    [s.screen]: { ...edit, voiceover_text: e.target.value },
                                  }))
                                }
                              />
                            </label>
                            <label className="scene-edit-field">
                              <span>On-Screen Card Text:</span>
                              <input
                                value={edit.onscreen_text}
                                onChange={(e) =>
                                  setSceneEdits((prev) => ({
                                    ...prev,
                                    [s.screen]: { ...edit, onscreen_text: e.target.value },
                                  }))
                                }
                              />
                            </label>
                            <div className="scene-edit-actions">
                              <button
                                type="button"
                                className="scene-save-btn"
                                disabled={!!busy}
                                onClick={() => void saveSceneText(s.screen)}
                              >
                                <NeonIcon name="check" size={12} tone="emerald" /> Save Script Text
                              </button>
                              <label className="scene-vo-btn" title="Upload new audio for just this narrated scene">
                                <input
                                  type="file"
                                  accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac"
                                  disabled={!!busy}
                                  onChange={(e) => {
                                    const f = e.target.files?.[0] || null
                                    e.currentTarget.value = ''
                                    void replaceSceneVo(s.screen, f)
                                  }}
                                />
                                <NeonIcon name="mic" size={12} tone="cyan" /> Replace Scene VO
                              </label>
                            </div>
                          </div>
                        )
                      })}
                  </div>
                )}
              </div>
            )}

            {sideTab === 'voiceovers' && (
              <div className="replace-panel">
                <div className="replace-panel-top">
                  <strong style={{ fontSize: 12 }}>Full Voiceover Slots (VO 1–10)</strong>
                  <div className="vo-slots-box" style={{ marginTop: 4 }}>
                    {voSlots.map((slot) => {
                      const uploaded = voFiles[slot]
                      return (
                        <div key={slot} className="vo-slot-row">
                          <label className="import-btn secondary vo-slot-btn">
                            <input
                              type="file"
                              accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac,.opus,.wma"
                              disabled={!!busy}
                              onChange={(e) => {
                                const f = e.target.files?.[0] || null
                                e.currentTarget.value = ''
                                void onVoice(f, slot)
                              }}
                            />
                            <NeonIcon name={uploaded ? 'refresh' : 'mic'} size={14} tone="emerald" />{' '}
                            {uploaded
                              ? `Replace VO ${slot}: ${uploaded.filename}${
                                  uploaded.duration ? ` (${fmt(uploaded.duration)})` : ''
                                }`
                              : `Import Narration VO ${slot}`}
                          </label>
                          {slot > 1 && (
                            <button
                              type="button"
                              className="vo-remove-btn"
                              disabled={!!busy}
                              onClick={() => void removeVoSlot(slot)}
                            >
                              ✕
                            </button>
                          )}
                        </div>
                      )
                    })}
                    {voSlots.length < 10 && (
                      <button
                        type="button"
                        className="add-vo-btn"
                        disabled={!!busy}
                        onClick={addNextVoSlot}
                      >
                        + Add VO {voSlots.length + 1}
                      </button>
                    )}
                  </div>
                  <input
                    className="scene-search-input"
                    placeholder="Filter narrated sections (e.g. screen_05)…"
                    value={sceneFilter}
                    onChange={(e) => setSceneFilter(e.target.value)}
                  />
                </div>

                <div className="scene-edit-list">
                  {(scenes.length ? scenes : []).filter((s) => {
                    const q = sceneFilter.trim().toLowerCase()
                    if (!q) return true
                    return (
                      s.screen.toLowerCase().includes(q) ||
                      (s.voiceover_text || '').toLowerCase().includes(q) ||
                      (s.text || '').toLowerCase().includes(q)
                    )
                  }).map((s) => {
                    const clip = timeline?.clips?.find(
                      (c) => c.screen === s.screen && c.narration_in != null,
                    ) || timeline?.clips?.find((c) => c.screen === s.screen)
                    const edit = sceneEdits[s.screen] ?? {
                      voiceover_text: s.voiceover_text ?? clip?.vo_text ?? s.text ?? '',
                      onscreen_text: s.onscreen_text ?? '',
                    }
                    return (
                      <div key={s.index} className="scene-edit-card">
                        <div className="scene-edit-head">
                          <strong>{s.screen.replace(/^screen_/i, 'Scene ')}</strong>
                          {clip && (
                            <button
                              type="button"
                              className="scene-jump-btn"
                              onClick={() => movePlayhead(clip.start)}
                            >
                              ▶ {fmt(clip.start)}–{fmt(clip.end)}
                            </button>
                          )}
                        </div>
                        <label className="scene-edit-field">
                          <span>Matching Spoken Text (auto-updates script &amp; QA):</span>
                          <textarea
                            rows={2}
                            value={edit.voiceover_text}
                            onChange={(e) =>
                              setSceneEdits((prev) => ({
                                ...prev,
                                [s.screen]: { ...edit, voiceover_text: e.target.value },
                              }))
                            }
                          />
                        </label>
                        <div className="scene-edit-actions">
                          <label className="scene-vo-btn primary-vo" style={{ flex: 1, textAlign: 'center' }}>
                            <input
                              type="file"
                              accept="audio/*,.mp3,.wav,.m4a,.aac,.ogg,.flac"
                              disabled={!!busy}
                              onChange={(e) => {
                                const f = e.target.files?.[0] || null
                                e.currentTarget.value = ''
                                void replaceSceneVo(s.screen, f)
                              }}
                            />
                            <NeonIcon name="mic" size={12} tone="cyan" /> Replace VO Audio for {s.screen}
                          </label>
                          <button
                            type="button"
                            className="scene-save-btn"
                            disabled={!!busy}
                            onClick={() => void saveSceneText(s.screen)}
                          >
                            <NeonIcon name="check" size={12} tone="emerald" /> Save Text
                          </button>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
        </aside>

        <aside className="project-info">
          <h3>
            <NeonIcon name="sliders" size={13} tone="cyan" /> Project Specs
          </h3>
          <label>
            Name
            <input value={title} onChange={(e) => setTitle(e.target.value)} />
          </label>
          <div className="info-row">
            <span>Resolution</span>
            <strong>{exportSettings.resolution.replace('x', ' × ')}</strong>
          </div>
          <div className="info-row">
            <span>Frame Rate</span>
            <strong>{exportSettings.fps} fps</strong>
          </div>
          <div className="info-row">
            <span>Color Space</span>
            <strong>SDR · Rec.709</strong>
          </div>
          <div className="info-row">
            <span>Sample Rate</span>
            <strong>{exportSettings.audio_sample_rate} Hz</strong>
          </div>
          <div className="info-row">
            <span>Duration</span>
            <strong>{fmt(timeline?.total_duration || 0)}</strong>
          </div>
          <div className="info-row">
            <span>Preset</span>
            <strong>{presetName}</strong>
          </div>
          <div className="info-row">
            <span>Narration</span>
            <strong>{voInfo ? voInfo.filename : '—'}</strong>
          </div>
          {hasPoem && (
            <div className="info-row">
              <span>Poem VO</span>
              <strong>{poemVoInfo ? poemVoInfo.filename : 'needed'}</strong>
            </div>
          )}
          <label className="lang">
            Language
            <select value={language} onChange={(e) => setLanguage(e.target.value as typeof language)}>
              <option value="en+mr">English + Marathi</option>
              <option value="en">English</option>
              <option value="mr">Marathi</option>
              <option value="auto">Auto</option>
            </select>
          </label>
          <button type="button" className="align-btn" disabled={!!busy} onClick={build}>
            <NeonIcon name="wand" size={14} tone="cyan" /> Auto-align to script + VO
          </button>
        </aside>

        <PreviewPane
          api={API}
          projectId={projectId}
          plan={displayTimeline}
          media={media}
          scenes={scenes}
          selectedMediaId={selectedMediaId}
          playhead={playhead}
          playing={playing}
          onPlayhead={movePlayhead}
          onPlaying={setPlaying}
          onChangePlan={saveManualEdits}
          fps={exportSettings.fps}
          localMediaUrls={localMediaUrls}
          localThumbUrls={localThumbUrls}
          localNarrUrl={localNarrUrl}
          localPoemUrl={localPoemUrl}
          localLogoUrl={localLogoUrl}
          logoEnabled={logoInfo.enabled}
          logoTransform={logoTransform}
          onToggleLogo={(enabled) => void toggleClientLogo(enabled)}
          onChangeLogoTransform={(t) => updateLogoTransform(t, false)}
          poemOverlay={poemOverlay}
          onChangePoemOverlay={(p) => updatePoemOverlay(p, false)}
          showPoemStudio={showPoemStudio}
          onTogglePoemStudio={setShowPoemStudio}
          hasPoem={hasPoem}
        />
      </div>

      <TimelineEditor
        api={API}
        projectId={projectId}
        plan={displayTimeline}
        media={media}
        playhead={playhead}
        onPlayhead={movePlayhead}
        onChange={saveManualEdits}
        onReplaceClipMedia={replaceClipMediaOnTimeline}
        onAutoAlign={build}
        pxPerSec={pxPerSec}
        onPxPerSec={setPxPerSec}
        voFiles={voFiles}
        localMediaUrls={localMediaUrls}
        localThumbUrls={localThumbUrls}
        onIgnoreIssue={handleIgnoreQaIssue}
        onIgnoreAllIssues={handleIgnoreAllQaIssues}
        onRestoreIgnoredIssues={handleRestoreIgnoredQaIssues}
        ignoredIssueCount={ignoredIssueCount}
        onToggleLogo={(enabled) => void toggleClientLogo(enabled)}
      />

      <footer className="status-bar">
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span className={busy ? 'busy' : ''}>{busy || log}</span>
          {measuredSync && measuredSync.spoken_count > 0 && (
            <span
              className={`qa-strip ${measuredSync.ok ? 'ok' : ''}`}
              title={measuredSync.summary}
              style={{
                margin: 0,
                padding: '2px 8px',
                fontSize: 11,
                fontWeight: 600,
                borderRadius: 4,
                background: measuredSync.ok ? 'rgba(34,197,94,0.18)' : 'rgba(239,68,68,0.2)',
                color: measuredSync.ok ? '#86efac' : '#fca5a5',
                whiteSpace: 'nowrap',
              }}
            >
              {measuredSync.ok
                ? `SYNC OK · max drift ${measuredSync.max_drift.toFixed(3)}s`
                : `SYNC FAIL · ${measuredSync.drifted_count} drifted (max ${measuredSync.max_drift.toFixed(3)}s)`}
            </span>
          )}
          {ocrProgress && (
            <span className="busy" title="Reading the text on each image and comparing it with the script / VO">
              💭 Checking images vs script… {ocrProgress.done}/{ocrProgress.total}
            </span>
          )}
          {voQaProgress && (
            <span
              className="busy"
              title="Whisper is hearing the VO in short audio chunks (not scene/screen count). 120 screens can map to fewer or more chunks depending on VO length."
            >
              🎙 Hearing VO audio… chunk {voQaProgress.done}/{voQaProgress.total}
            </span>
          )}
          {exportProgress?.running && (
            <button
              type="button"
              className="fe-btn danger"
              style={{ minHeight: 22, padding: '0 8px', fontSize: 11 }}
              onClick={() => void cancelExport()}
            >
              ⏹ Cancel Render
            </button>
          )}
        </div>
        {dirty && <span className="dirty">Unsaved drag edits syncing…</span>}
      </footer>

      {showExport && (
        <div
          className="modal-backdrop"
          onClick={() => {
            if (!busy && !exportProgress?.running) {
              setShowAdvanced(false)
              setShowExport(false)
            }
          }}
        >
          <div className="filmora-export-window" onClick={(e) => e.stopPropagation()}>
            <div className="fe-titlebar" style={{ gridTemplateColumns: '110px 1fr 140px' }}>
              <div className="fe-dots">
                <button
                  type="button"
                  className="dot close"
                  title={exportProgress?.running || busy ? 'Cancel render & close' : 'Close'}
                  onClick={() => {
                    if (exportProgress?.running || busy) {
                      if (window.confirm('A render is currently running. Cancel the render and close this window?')) {
                        void cancelExport()
                        setShowAdvanced(false)
                        setShowExport(false)
                      }
                    } else {
                      setShowAdvanced(false)
                      setShowExport(false)
                    }
                  }}
                />
                <span className="dot min" />
                <span className="dot max" />
              </div>
              <span className="fe-title">Export</span>
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                {(exportProgress?.running || busy) && (
                  <button
                    type="button"
                    className="fe-btn danger"
                    style={{ minHeight: 24, padding: '0 10px', fontSize: 11 }}
                    onClick={() => void cancelExport()}
                  >
                    ⏹ Cancel Render
                  </button>
                )}
              </div>
            </div>

            {(renamePlan.steps.length > 0 || renumberResult) && (
              <div className="fe-renumber-banner">
                {renamePlan.steps.length > 0 ? (
                  <>
                    <div className="fe-renumber-text">
                      <strong>
                        📁 {renamePlan.steps.length} file{renamePlan.steps.length !== 1 ? 's were' : ' was'} swapped or
                        updated on the timeline. Sync these changes to your source folder?
                      </strong>
                      <span className="fe-renumber-list">
                        {renamePlan.steps.map((s) => `${s.from} → ${s.to}`).join(' · ')}
                      </span>
                      <span className="fe-renumber-hint">
                        {canRenameInPlace()
                          ? 'Writes the updated files directly into your Scene Images folder (originals are safely backed up in _dgs_backup_originals first).'
                          : 'This browser cannot rename files directly — you will get a ZIP of the image folder with the corrected names.'}
                        {renamePlan.skipped.length > 0 && ` Skipped: ${renamePlan.skipped.join('; ')}.`}
                      </span>
                    </div>
                    <button
                      type="button"
                      className="fe-btn primary"
                      disabled={renumberBusy}
                      onClick={() => void renumberImageFolder(true)}
                    >
                      {renumberBusy ? 'Syncing…' : canRenameInPlace() ? 'Sync source folder…' : 'Download updated folder (.zip)'}
                    </button>
                  </>
                ) : (
                  <div className="fe-renumber-text">
                    <strong>{renumberResult}</strong>
                  </div>
                )}
              </div>
            )}

            <div className="fe-tabs">
              <button
                type="button"
                className={`fe-tab ${exportTab === 'local' ? 'active' : ''}`}
                onClick={() => setExportTab('local')}
              >
                Local
              </button>
              <button
                type="button"
                className={`fe-tab ${exportTab === 'device' ? 'active' : ''}`}
                onClick={() => {
                  setExportTab('device')
                  setDeviceTarget('iPhone / iPad (1080p)')
                  setExportSettings((s) => ({ ...s, resolution: '1920x1080', video_bitrate_kbps: 15000 }))
                }}
              >
                Device
              </button>
              <button
                type="button"
                className={`fe-tab ${exportTab === 'social' ? 'active' : ''}`}
                onClick={() => {
                  setExportTab('social')
                  setDeviceTarget('YouTube HD (1080p)')
                  setExportSettings((s) => ({ ...s, resolution: '1920x1080', video_bitrate_kbps: 15000 }))
                }}
              >
                Social Media
              </button>
              <button
                type="button"
                className={`fe-tab ${exportTab === 'dvd' ? 'active' : ''}`}
                onClick={() => {
                  setExportTab('dvd')
                  setDeviceTarget('Full HD Blu-ray / USB (1080p)')
                  setExportSettings((s) => ({ ...s, resolution: '1920x1080', video_bitrate_kbps: 20000 }))
                }}
              >
                DVD
              </button>
            </div>

            <div className="fe-body">
              <div className="fe-thumb-col">
                <span className="fe-label">{exportProgress?.running ? 'Rendering:' : 'Thumbnail:'}</span>
                {(() => {
                  const clipsWithMedia = (timeline?.clips || []).filter((c) => Boolean(c.media_id))
                  const renderingNow = Boolean(exportProgress?.running && exportProgress.done && exportProgress.total)
                  const renderClip = renderingNow
                    ? (timeline?.clips || []).find(
                        (c) =>
                          (exportProgress?.mediaId && c.media_id === exportProgress.mediaId) ||
                          (exportProgress?.screen && c.screen === exportProgress.screen),
                      )
                    : null
                  const activeClip = renderClip
                    || (clipsWithMedia.length
                      ? clipsWithMedia[thumbClipIdx % clipsWithMedia.length]
                      : timeline?.clips?.[0])
                  const mId = activeClip?.media_id
                  const thumbSrc = mId
                    ? localThumbUrls[mId] ||
                      localMediaUrls[mId] ||
                      (projectId ? `${API}/api/projects/${projectId}/media-thumb/${mId}` : '')
                    : ''
                  const fileName = mId ? media.find((m) => m.id === mId)?.filename : ''
                  const showVideo = Boolean(renderingNow && activeClip?.kind === 'video' && thumbSrc && !localThumbUrls[mId || ''])
                  const sig = computeBitrateSignal(exportSettings, timeline)
                  return (
                    <>
                      <div className={`fe-thumb-box${renderingNow ? ' rendering' : ''}`} style={{ position: 'relative' }}>
                        {thumbSrc ? (
                          showVideo ? (
                            <video src={thumbSrc} muted playsInline autoPlay />
                          ) : (
                            <img src={thumbSrc} alt={renderingNow ? 'Screen being rendered' : 'Thumbnail'} />
                          )
                        ) : (
                          <div className="fe-thumb-placeholder">
                            <AiNeonThumbBadge />
                          </div>
                        )}
                        {renderingNow && (
                          <span className="fe-render-count">
                            {exportProgress?.done} / {exportProgress?.total}
                          </span>
                        )}
                        {activeClip && (
                          <span
                            style={{
                              position: 'absolute',
                              bottom: 6,
                              right: 6,
                              background: 'rgba(11, 22, 20, 0.85)',
                              border: '1px solid rgba(28, 214, 176, 0.45)',
                              color: '#5eead4',
                              fontSize: 10.5,
                              fontWeight: 700,
                              padding: '2px 7px',
                              borderRadius: 5,
                            }}
                          >
                            {activeClip.screen.replace('screen_', 'Scene ')}
                          </span>
                        )}
                      </div>
                      {renderingNow ? (
                        <div className="fe-render-file">
                          <strong>
                            {exportProgress?.done} / {exportProgress?.total} files
                          </strong>
                          <span>{fileName || activeClip?.screen.replace('screen_', 'Scene ') || 'Preparing…'}</span>
                        </div>
                      ) : (
                      <button
                        type="button"
                        className="fe-edit-btn"
                        onClick={() => {
                          const count = Math.max(1, clipsWithMedia.length)
                          const nextIdx = (thumbClipIdx + 1) % count
                          setThumbClipIdx(nextIdx)
                          const nextClip = clipsWithMedia[nextIdx]
                          if (nextClip) {
                            setExportNotice(
                              `✓ Cover thumbnail switched to ${nextClip.screen.replace('screen_', 'Scene ')} (${nextIdx + 1}/${count})`,
                            )
                          }
                        }}
                        title="Cycle cover thumbnail across project scenes"
                      >
                        Edit ({(thumbClipIdx % Math.max(1, clipsWithMedia.length)) + 1}/
                        {Math.max(1, clipsWithMedia.length)})
                      </button>
                      )}

                      <div className="fe-bitrate-mini" style={{ borderColor: `${sig.color}55` }}>
                        <div className="fe-bitrate-mini-head">
                          <span>
                            <NeonIcon name="signal" size={12} tone="emerald" /> Bitrate Signal
                          </span>
                          <span className="fe-signal-bars" title={`Signal strength: ${sig.bars}/4`}>
                            {[1, 2, 3, 4].map((b) => (
                              <i
                                key={b}
                                className={`bar b${b} ${b <= sig.bars ? 'on' : ''}`}
                                style={b <= sig.bars ? { background: sig.color } : undefined}
                              />
                            ))}
                          </span>
                        </div>
                        <strong style={{ color: sig.color, fontSize: 13 }}>
                          {exportSettings.video_bitrate_kbps.toLocaleString()} kbps
                        </strong>
                        <span style={{ fontSize: 11, color: '#cbd5e1' }}>
                          {sig.compActive
                            ? `Effective: ${sig.targetVideoKbps.toLocaleString()} kbps (${sig.compPct}% Compression)`
                            : `${sig.targetVideoMbps} Mbps · ${sig.modeUpper}`}
                        </span>
                        <span style={{ fontSize: 10.5, color: '#94a3b8' }}>
                          Audio: {sig.audioKbps} kbps · {exportSettings.audio_sample_rate} Hz
                        </span>
                      </div>
                    </>
                  )
                })()}
              </div>

              <div className="fe-settings-col">
                {exportProgress && exportProgress.running && (
                  <div className="fe-progress-box">
                    <div className="fe-progress-head">
                      <strong>{exportProgress.message}</strong>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <span>{exportProgress.percent}%</span>
                        <button
                          type="button"
                          className="fe-btn danger"
                          style={{ minHeight: 26, padding: '0 10px', fontSize: 11.5 }}
                          onClick={() => void cancelExport()}
                        >
                          <NeonIcon name="stop" size={12} tone="rose" /> Cancel Render
                        </button>
                      </div>
                    </div>
                    <div className="fe-progress-bar">
                      <div
                        className="fe-progress-fill"
                        style={{ width: `${Math.max(4, exportProgress.percent)}%` }}
                      />
                    </div>
                  </div>
                )}

                {exportError && (
                  <div className="fe-error-box">
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                      <strong>Export Alert: {exportError}</strong>
                      <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                        <button
                          type="button"
                          className="fe-btn teal"
                          disabled={!!busy}
                          onClick={() => void exportVideo()}
                        >
                          Retry Export
                        </button>
                        {renderEngine === 'machine' && (
                          <button
                            type="button"
                            className="fe-btn ghost"
                            disabled={!!busy}
                            onClick={() => {
                              setRenderEngine('server')
                              void exportVideo(true)
                            }}
                          >
                            <NeonIcon name="cloud" size={13} tone="cyan" /> Render on Cloud Server Instead
                          </button>
                        )}
                        <button
                          type="button"
                          className="fe-btn ghost"
                          onClick={() => setExportError(null)}
                        >
                          Dismiss
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                <div className="fe-card" style={{ padding: '9px 12px', gap: 6 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                    <span style={{ fontSize: 11.5, fontWeight: 700, color: '#e2e8f0', display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                      <NeonIcon name="cpu" size={14} tone="cyan" /> Render Engine:
                    </span>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      <button
                        type="button"
                        className={`fe-btn ${renderEngine === 'machine' ? 'teal' : 'ghost'}`}
                        style={{ minHeight: 28, padding: '0 12px', fontSize: 11.5 }}
                        onClick={() => setRenderEngine('machine')}
                      >
                        <NeonIcon name="bolt" size={13} tone="cyan" /> This PC (Local CPU / GPU · No Upload)
                      </button>
                      <button
                        type="button"
                        className={`fe-btn ${renderEngine === 'server' ? 'teal' : 'ghost'}`}
                        style={{ minHeight: 28, padding: '0 12px', fontSize: 11.5 }}
                        onClick={() => setRenderEngine('server')}
                      >
                        <NeonIcon name="cloud" size={13} tone="violet" /> Cloud Server (FFmpeg)
                      </button>
                    </div>
                  </div>
                  <span style={{ fontSize: 10.5, color: '#94a3b8' }}>
                    {renderEngine === 'machine'
                      ? 'Renders directly on your PC using your machine’s CPU or GPU encoder (no GPU required) — 0 MB uploaded to server & instant local save.'
                      : 'Uploads unsynced media to the cloud server and renders via server-side FFmpeg.'}
                  </span>
                </div>

                {exportNotice && !exportError && (
                  <div className="fe-render-notice" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 8 }}>
                    <span>{exportNotice}</span>
                    <button
                      type="button"
                      style={{ background: 'transparent', border: 0, color: '#5eead4', cursor: 'pointer', fontSize: 11, fontWeight: 700 }}
                      onClick={() => setExportNotice(null)}
                    >
                      ✕
                    </button>
                  </div>
                )}

                {exportTab !== 'local' && (
                  <label className="fe-field">
                    <span>
                      {exportTab === 'device'
                        ? 'Target Device Profile'
                        : exportTab === 'social'
                          ? 'Target Platform Profile'
                          : 'Disc / Media Profile'}
                    </span>
                    <select
                      value={deviceTarget}
                      onChange={(e) => {
                        const v = e.target.value
                        setDeviceTarget(v)
                        if (v.includes('720p') || v.includes('DVD')) {
                          setExportSettings((s) => ({ ...s, resolution: '1280x720', video_bitrate_kbps: 5000 }))
                        } else if (v.includes('4K')) {
                          setExportSettings((s) => ({ ...s, resolution: '3840x2160', video_bitrate_kbps: 30000 }))
                        } else if (v.includes('Shorts') || v.includes('Reels')) {
                          setExportSettings((s) => ({ ...s, resolution: '1080x1920', video_bitrate_kbps: 12000 }))
                        } else {
                          setExportSettings((s) => ({ ...s, resolution: '1920x1080', video_bitrate_kbps: 15000 }))
                        }
                      }}
                    >
                      {exportTab === 'device' && (
                        <>
                          <option value="iPhone / iPad (1080p)">iPhone / iPad (1080p)</option>
                          <option value="Android Phone / Tablet (1080p)">Android Phone / Tablet (1080p)</option>
                          <option value="Smart TV / Classroom Display (1080p)">
                            Smart TV / Classroom Display (1080p)
                          </option>
                          <option value="4K UHD Display (4K)">4K UHD Display (4K)</option>
                        </>
                      )}
                      {exportTab === 'social' && (
                        <>
                          <option value="YouTube HD (1080p)">YouTube HD (1080p)</option>
                          <option value="WhatsApp / Classroom Share (720p)">
                            WhatsApp / Classroom Share (720p)
                          </option>
                          <option value="YouTube Shorts / Reels (9:16)">
                            YouTube Shorts / Reels (9:16)
                          </option>
                        </>
                      )}
                      {exportTab === 'dvd' && (
                        <>
                          <option value="Standard DVD / USB Classroom (720p)">
                            Standard DVD / USB Classroom (720p)
                          </option>
                          <option value="Full HD Blu-ray / USB (1080p)">
                            Full HD Blu-ray / USB (1080p)
                          </option>
                        </>
                      )}
                    </select>
                  </label>
                )}

                <label className="fe-field">
                  <span>Title</span>
                  <input value={title} onChange={(e) => setTitle(e.target.value)} />
                </label>

                <label className="fe-field">
                  <span>Save to</span>
                  <div className="fe-save-row">
                    <input
                      value={saveTo}
                      placeholder={isRemoteServer ? 'Browser Downloads folder (Auto-Download to PC)' : 'Downloads folder'}
                      readOnly
                      title="Choose a destination using the folder button; typing a path does not grant file write access"
                    />
                    <button
                      type="button"
                      className="fe-folder-btn"
                      onClick={() => void pickSaveToFolder()}
                      title="Choose destination folder on your PC"
                    >
                      <NeonIcon name="folder" size={14} tone="cyan" />
                    </button>
                  </div>
                </label>

                <label className="fe-toggle-row">
                  <input
                    type="checkbox"
                    checked={Boolean(exportSettings.backup_to_cloud)}
                    onChange={(e) =>
                      setExportSettings((s) => ({ ...s, backup_to_cloud: e.target.checked }))
                    }
                  />
                  <span>Backup to the Cloud</span>
                </label>

                <label className="fe-field">
                  <span>Preset</span>
                  <select value={presetName} onChange={(e) => applyPreset(e.target.value)}>
                    {Object.keys(serverPresets).map((n) => (
                      <option key={n} value={n}>
                        {n}
                      </option>
                    ))}
                  </select>
                </label>

                <div className="fe-card">
                  <div className="fe-grid-2">
                    <label className="fe-field">
                      <span>Format</span>
                      <select
                        value={exportSettings.format}
                        onChange={(e) =>
                          setExportSettings((s) => ({
                            ...s,
                            format: e.target.value as ExportSettings['format'],
                          }))
                        }
                      >
                        <option value="mp4">MP4</option>
                        <option value="mov">MOV</option>
                        <option value="mkv">MKV</option>
                      </select>
                    </label>

                    <label className="fe-field">
                      <span>Resolution</span>
                      <select
                        value={exportSettings.resolution}
                        onChange={(e) => {
                          const res = e.target.value
                          setExportSettings((s) => ({
                            ...s,
                            resolution: res,
                            video_bitrate_kbps: computePresetBitrate(
                              res,
                              s.quality_preset,
                              s.encoder,
                              s.video_bitrate_kbps,
                            ),
                          }))
                        }}
                      >
                        <option value="1920x1080">1920*1080</option>
                        <option value="1280x720">1280*720</option>
                        <option value="3840x2160">3840*2160</option>
                        <option value="1080x1920">1080*1920</option>
                      </select>
                    </label>

                    <label className="fe-field">
                      <span>Encoder</span>
                      <select
                        value={exportSettings.encoder}
                        onChange={(e) => {
                          const enc = e.target.value as ExportSettings['encoder']
                          setExportSettings((s) => ({
                            ...s,
                            encoder: enc,
                            video_bitrate_kbps: computePresetBitrate(
                              s.resolution,
                              s.quality_preset,
                              enc,
                              s.video_bitrate_kbps,
                            ),
                          }))
                        }}
                      >
                        <option value="h264">H.264</option>
                        <option value="h265">H.265</option>
                        <option value="mpeg4">MPEG-4</option>
                      </select>
                    </label>

                    <label className="fe-field">
                      <span>Quality</span>
                      <select
                        value={exportSettings.quality_preset}
                        onChange={(e) => {
                          const q = e.target.value as ExportSettings['quality_preset']
                          setExportSettings((s) => ({
                            ...s,
                            quality_preset: q,
                            video_bitrate_kbps: computePresetBitrate(
                              s.resolution,
                              q,
                              s.encoder,
                              s.video_bitrate_kbps,
                            ),
                          }))
                        }}
                      >
                        <option value="high">High</option>
                        <option value="medium">Medium</option>
                        <option value="low">Low</option>
                        <option value="custom">Custom</option>
                      </select>
                    </label>
                  </div>

                  <div className="fe-summary-row">
                    <span>
                      {exportSettings.fps} fps &nbsp;&nbsp;|&nbsp;&nbsp; {exportSettings.video_bitrate_kbps} kbps &nbsp;&nbsp;|&nbsp;&nbsp;{' '}
                      {exportSettings.color_space === 'bt709' ? 'SDR - Rec.709' : 'SDR - Rec.601'}
                    </span>
                    <button
                      type="button"
                      className="fe-advanced-link"
                      onClick={() => setShowAdvanced(true)}
                    >
                      Advanced &gt;
                    </button>
                  </div>
                </div>

                {/* Filmora 16 Exact Advanced Compression Row (Toggle + By Quality | 70%) */}
                <div className="fe-card fe-adv-comp-card">
                  <div className="fe-adv-comp-row">
                    <label className="fe-toggle-row teal" style={{ margin: 0 }}>
                      <input
                        type="checkbox"
                        checked={exportSettings.advanced_compression}
                        onChange={(e) => {
                          const on = e.target.checked
                          setExportSettings((s) => ({
                            ...s,
                            advanced_compression: on,
                            compression_mode:
                              on && s.compression_mode === 'none' ? 'by_quality' : s.compression_mode,
                          }))
                        }}
                      />
                      <span>
                        <strong>Advanced Compression</strong>
                      </span>
                    </label>

                    <div className="fe-adv-comp-controls">
                      <select
                        className="fe-comp-select"
                        disabled={!exportSettings.advanced_compression}
                        value={
                          exportSettings.compression_mode === 'none'
                            ? 'by_quality'
                            : exportSettings.compression_mode
                        }
                        onChange={(e) => {
                          const mode = e.target.value as ExportSettings['compression_mode']
                          setExportSettings((s) => ({
                            ...s,
                            advanced_compression: true,
                            compression_mode: mode,
                          }))
                        }}
                      >
                        <option value="by_quality">By Quality</option>
                        <option value="by_bitrate">By Bitrate</option>
                      </select>

                      <select
                        className="fe-comp-select pct"
                        disabled={!exportSettings.advanced_compression}
                        value={exportSettings.compression_quality}
                        onChange={(e) =>
                          setExportSettings((s) => ({
                            ...s,
                            advanced_compression: true,
                            compression_mode:
                              s.compression_mode === 'none' ? 'by_quality' : s.compression_mode,
                            compression_quality: Number(e.target.value),
                          }))
                        }
                      >
                        {[30, 40, 50, 60, 70, 75, 80, 85, 90].map((pct) => (
                          <option key={pct} value={pct}>
                            {pct}%
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>

                <label className="fe-toggle-row">
                  <input
                    type="checkbox"
                    checked={Boolean(exportSettings.auto_highlight)}
                    onChange={(e) =>
                      setExportSettings((s) => ({ ...s, auto_highlight: e.target.checked }))
                    }
                  />
                  <span>Auto Highlight</span>
                </label>

                {/* Live Bitrate Signal & Direct Rate Controller */}
                {(() => {
                  const sig = computeBitrateSignal(exportSettings, timeline)
                  return (
                    <div className="fe-card fe-bitrate-signal-card" style={{ borderColor: `${sig.color}55` }}>
                      <div className="fe-bitrate-header">
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                          <span className="fe-signal-bars" title={`Bitrate Signal Strength: ${sig.bars}/4`}>
                            {[1, 2, 3, 4].map((b) => (
                              <i
                                key={b}
                                className={`bar b${b} ${b <= sig.bars ? 'on' : ''}`}
                                style={b <= sig.bars ? { background: sig.color } : undefined}
                              />
                            ))}
                          </span>
                          <strong style={{ fontSize: 12.5, color: '#f8fafc', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
                            <NeonIcon name="signal" size={14} tone="emerald" /> Live Bitrate Signal:
                          </strong>
                          <span
                            className="fe-bitrate-badge"
                            style={{
                              background: `${sig.color}22`,
                              borderColor: `${sig.color}88`,
                              color: sig.color,
                            }}
                          >
                            {sig.dot} {sig.badge}
                          </span>
                        </div>
                        <strong style={{ fontSize: 13.5, color: sig.color }}>
                          {exportSettings.video_bitrate_kbps.toLocaleString()} kbps Base → {sig.targetVideoKbps.toLocaleString()} kbps ({sig.targetVideoMbps} Mbps) · {sig.modeUpper}
                        </strong>
                      </div>

                      <div className="fe-bitrate-metrics">
                        <div className="fe-bm-box">
                          <span>Effective Video Bitrate</span>
                          <strong style={{ color: sig.color }}>
                            {sig.targetVideoKbps.toLocaleString()} kbps ({sig.targetVideoMbps} Mbps)
                          </strong>
                          <small>
                            {sig.compActive
                              ? `${sig.compPct}% Compression (CRF ${sig.crf} · ~${sig.effectiveStreamVideoKbps.toLocaleString()} kbps avg stream)`
                              : `Full ${sig.modeUpper} ceiling (CRF ${sig.crf})`}
                          </small>
                        </div>
                        <div className="fe-bm-box">
                          <span>Audio Stream Bitrate</span>
                          <strong style={{ color: '#e2e8f0' }}>
                            {sig.audioKbps} kbps {(exportSettings.audio_encoder || 'aac').toUpperCase()}
                          </strong>
                          <small>
                            {exportSettings.audio_sample_rate} Hz ·{' '}
                            {exportSettings.audio_channels === 'mono' ? 'Mono' : 'Stereo'}
                          </small>
                        </div>
                        <div className="fe-bm-box">
                          <span>Total Combined Bitrate</span>
                          <strong style={{ color: '#5eead4' }}>
                            {sig.totalKbps.toLocaleString()} kbps ({sig.totalMbps} Mbps)
                          </strong>
                          <small>{sig.advice}</small>
                        </div>
                      </div>
                    </div>
                  )
                })()}

                <div className="fe-logo-row">
                  <label className="fe-toggle-row teal">
                    <input
                      type="checkbox"
                      checked={Boolean(logoInfo?.enabled && exportSettings.include_logo !== false)}
                      disabled={!logoInfo}
                      onChange={(e) => {
                        const on = e.target.checked
                        setExportSettings((s) => ({ ...s, include_logo: on }))
                        void toggleClientLogo(on)
                      }}
                    />
                    <span>
                      Client Logo on Top-Right (Entire Video)
                      {logoInfo ? ` · ${logoInfo.filename}` : ' · None uploaded'}
                    </span>
                  </label>
                  <label className="fe-btn ghost small-upload">
                    <input
                      type="file"
                      accept="image/*,.png,.jpg,.jpeg,.webp,.svg"
                      onChange={(e) => {
                        const f = e.target.files?.[0] || null
                        e.currentTarget.value = ''
                        void onClientLogo(f)
                      }}
                    />
                    {logoInfo ? 'Change Logo' : 'Upload Logo'}
                  </label>
                </div>

                <div className="fe-card" style={{ marginTop: 6 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
                    <div>
                      <strong style={{ fontSize: 12.5, display: 'inline-flex', alignItems: 'center', gap: 6 }}>
                        <NeonIcon name="package" size={14} tone="emerald" /> Collect Project Files (.wfpbundle — Filmora 16 Archive)
                      </strong>
                      <div style={{ fontSize: 11, opacity: 0.8, marginTop: 2 }}>
                        Packs <code>Medias/&#123;GUID&#125;/</code> + <code>.wfp</code> into a single <code>.wfpbundle</code> file that opens identically in Filmora 16 and DGS Auto Editor on any PC.
                      </div>
                    </div>
                    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
                      <button
                        type="button"
                        className="fe-btn teal"
                        disabled={!projectId || !!busy}
                        onClick={() => void collectProjectFiles('wfpbundle')}
                      >
                        <NeonIcon name="package" size={13} tone="cyan" /> Collect (.wfpbundle)
                      </button>
                      <button
                        type="button"
                        className="fe-btn ghost"
                        disabled={!projectId || !!busy}
                        onClick={() => void collectProjectFiles('folder')}
                      >
                        Collect to Folder
                      </button>
                      <button
                        type="button"
                        className="fe-btn ghost"
                        disabled={!projectId || !!busy}
                        onClick={() => void collectProjectFiles('zip')}
                      >
                        Collect to .ZIP
                      </button>
                    </div>
                  </div>
                </div>

                {collectResult && (
                  <div className="fe-success-box">
                    <div className="fe-success-title">
                      ✓ {collectResult.mode === 'wfpbundle' ? 'Filmora 16 .wfpbundle Created' : 'Project Collected'} ({collectResult.size_mb} MB · {collectResult.file_count} files)
                    </div>
                    {collectResult.bundle_path && (
                      <div className="fe-success-path">
                        <strong>Filmora 16 .wfpbundle:</strong> {collectResult.bundle_path}
                      </div>
                    )}
                    {collectResult.mode !== 'wfpbundle' && (
                      <div className="fe-success-path">
                        <strong>Folder:</strong> {collectResult.folder_path}
                      </div>
                    )}
                    {collectResult.zip_path && (
                      <div className="fe-success-path">
                        <strong>Portable ZIP:</strong> {collectResult.zip_path}
                      </div>
                    )}
                    {collectResult.mode !== 'wfpbundle' && (
                      <div className="fe-success-path">
                        <strong>Filmora 16 &amp; DGS .wfp:</strong> {collectResult.wfp_path}
                      </div>
                    )}
                    <div className="fe-success-actions">
                      <button
                        type="button"
                        className="fe-btn teal"
                        onClick={() => void revealCollectInFolder()}
                      >
                        {isRemoteServer ? 'Save Bundle to PC' : 'Show in Folder'}
                      </button>
                      {collectResult.download_url && (
                        <a
                          className="fe-btn ghost"
                          href={collectResult.download_url}
                          download={
                            collectResult.mode === 'wfpbundle'
                              ? `${(title || 'Project').trim()}.wfpbundle`
                              : `${(title || 'Project').trim()}_Collected.zip`
                          }
                        >
                          {collectResult.mode === 'wfpbundle'
                            ? 'Download .wfpbundle Again'
                            : 'Download .ZIP Again'}
                        </a>
                      )}
                    </div>
                  </div>
                )}

                {exportResult && (
                  <div className="fe-success-box">
                    <div className="fe-success-title">
                      ✓ Export Completed Successfully!
                      {exportResult.size_mb ? ` (${exportResult.size_mb} MB)` : ''}
                    </div>
                    <div className="fe-success-path">
                      <strong>Video file:</strong> {exportResult.filename || exportResult.saved_to}
                    </div>
                    <div className="fe-success-path">
                      <strong>Bitrate Signal:</strong>{' '}
                      {exportResult.bitrate_info?.target_video_kbps
                        ? `${exportResult.bitrate_info.target_video_kbps.toLocaleString()} kbps (${exportResult.bitrate_info.target_video_mbps} Mbps) ${exportResult.bitrate_info.bitrate_mode || 'VBR'} + ${exportResult.bitrate_info.audio_kbps || 320} kbps Audio`
                        : `${computeBitrateSignal(exportSettings).targetVideoKbps.toLocaleString()} kbps (${computeBitrateSignal(exportSettings).targetVideoMbps} Mbps) ${computeBitrateSignal(exportSettings).modeUpper}`}
                      {exportResult.bitrate_info?.actual_total_kbps
                        ? ` · Measured Avg Stream: ${exportResult.bitrate_info.actual_total_kbps.toLocaleString()} kbps`
                        : ''}
                    </div>
                    <div className="fe-success-actions">
                      <button
                        type="button"
                        className="fe-btn teal"
                        onClick={() => void revealExportInFolder()}
                      >
                        {isRemoteServer ? 'Save Video to PC (.MP4)' : 'Show in Folder'}
                      </button>
                      <a
                        className="fe-btn ghost"
                        href={exportResult.download}
                        download={exportResult.filename}
                      >
                        Download Video Again
                      </a>
                      <button type="button" className="fe-btn ghost" onClick={exportSrt}>
                        Download Standalone SRT
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="fe-footer">
              <div className="fe-meta">
                <span>Duration: {fmt(timeline?.total_duration || 0)}</span>
                <span>
                  {(() => {
                    const { estimatedMb } = estimateExportSizeMb(
                      timeline,
                      exportSettings,
                    )
                    if (
                      exportSettings.advanced_compression &&
                      exportSettings.compression_mode !== 'none'
                    ) {
                      return `Size: Advanced Compression (~${estimatedMb} MB)`
                    }
                    return `Size: ~${estimatedMb} MB`
                  })()}
                </span>
                <span style={{ color: computeBitrateSignal(exportSettings, timeline).color, fontWeight: 700 }}>
                  {computeBitrateSignal(exportSettings, timeline).dot}{' '}
                  {exportSettings.video_bitrate_kbps.toLocaleString()} kbps ({computeBitrateSignal(exportSettings, timeline).modeUpper})
                </span>
              </div>
              <div className="fe-actions">
                <button type="button" className="fe-btn ghost" disabled={!!busy} onClick={exportSrt}>
                  Export SRT Only
                </button>
                <button
                  type="button"
                  className="fe-btn ghost"
                  disabled={!projectId || !!busy}
                  onClick={() => void saveProjectFile()}
                >
                  Save .wfp Project
                </button>
                {(exportProgress?.running || busy) && (
                  <button
                    type="button"
                    className="fe-btn danger"
                    onClick={() => void cancelExport()}
                    title="Stop the active render immediately"
                  >
                    <NeonIcon name="stop" size={12} tone="rose" /> Cancel Render
                  </button>
                )}
                <button
                  type="button"
                  className="fe-btn teal"
                  disabled={!!busy}
                  onClick={() => void exportVideo(false)}
                >
                  {busy
                    ? `Exporting ${exportProgress?.percent ?? 0}%…`
                    : 'Export'}
                </button>
              </div>
            </div>

            {showAdvanced && (
              <div className="fe-adv-backdrop" onClick={() => setShowAdvanced(false)}>
                <div className="fe-adv-window" onClick={(e) => e.stopPropagation()}>
                  <div className="fe-titlebar">
                    <div className="fe-dots">
                      <button
                        type="button"
                        className="dot close"
                        onClick={() => setShowAdvanced(false)}
                      />
                      <span className="dot min" />
                      <span className="dot max" />
                    </div>
                    <span className="fe-title">Advanced</span>
                    <span />
                  </div>

                  <div className="fe-adv-preset-bar">
                    <select value={presetName} onChange={(e) => applyPreset(e.target.value)}>
                      {Object.keys(serverPresets).map((n) => (
                        <option key={n} value={n}>
                          {n}
                        </option>
                      ))}
                    </select>
                    <button
                      type="button"
                      className="fe-btn reset"
                      onClick={() => applyPreset(presetName)}
                    >
                      Reset
                    </button>
                  </div>

                  <div className="fe-adv-scroll">
                    <label className="fe-field">
                      <span>Format</span>
                      <select
                        value={exportSettings.format}
                        onChange={(e) =>
                          setExportSettings((s) => ({
                            ...s,
                            format: e.target.value as ExportSettings['format'],
                          }))
                        }
                      >
                        <option value="mp4">MP4</option>
                        <option value="mov">MOV</option>
                        <option value="mkv">MKV</option>
                      </select>
                    </label>

                    <div className="fe-section-title">Video</div>

                    <label className="fe-field">
                      <span>Resolution</span>
                      <select
                        value={exportSettings.resolution}
                        onChange={(e) => {
                          const res = e.target.value
                          setExportSettings((s) => ({
                            ...s,
                            resolution: res,
                            video_bitrate_kbps: computePresetBitrate(
                              res,
                              s.quality_preset,
                              s.encoder,
                              s.video_bitrate_kbps,
                            ),
                          }))
                        }}
                      >
                        <option value="1920x1080">1920*1080</option>
                        <option value="1280x720">1280*720</option>
                        <option value="3840x2160">3840*2160</option>
                        <option value="1080x1920">1080*1920</option>
                      </select>
                    </label>

                    <label className="fe-field">
                      <span>Encoder</span>
                      <select
                        value={exportSettings.encoder}
                        onChange={(e) => {
                          const enc = e.target.value as ExportSettings['encoder']
                          setExportSettings((s) => ({
                            ...s,
                            encoder: enc,
                            video_bitrate_kbps: computePresetBitrate(
                              s.resolution,
                              s.quality_preset,
                              enc,
                              s.video_bitrate_kbps,
                            ),
                          }))
                        }}
                      >
                        <option value="h264">H.264</option>
                        <option value="h265">H.265</option>
                        <option value="mpeg4">MPEG-4</option>
                      </select>
                    </label>

                    <label className="fe-field">
                      <span>Frame Rate</span>
                      <select
                        value={exportSettings.fps}
                        onChange={(e) =>
                          setExportSettings((s) => ({ ...s, fps: Number(e.target.value) }))
                        }
                      >
                        {[24, 25, 30, 50, 60].map((f) => (
                          <option key={f} value={f}>
                            {f} fps
                          </option>
                        ))}
                      </select>
                    </label>

                    <label className="fe-field">
                      <span>Bitrate Mode</span>
                      <select
                        value={exportSettings.bitrate_mode}
                        onChange={(e) =>
                          setExportSettings((s) => ({
                            ...s,
                            bitrate_mode: e.target.value as ExportSettings['bitrate_mode'],
                          }))
                        }
                      >
                        <option value="vbr">VBR</option>
                        <option value="cbr">CBR</option>
                        <option value="crf">CRF</option>
                      </select>
                    </label>

                    <div className="fe-field">
                      <span>Bit Rate</span>
                      <div className="fe-grid-2 compact">
                        <select
                          value={exportSettings.quality_preset}
                          onChange={(e) => {
                            const q = e.target.value as ExportSettings['quality_preset']
                            const kbps =
                              q === 'high'
                                ? 20000
                                : q === 'medium'
                                  ? 10000
                                  : q === 'low'
                                    ? 5000
                                    : exportSettings.video_bitrate_kbps
                            setExportSettings((s) => ({
                              ...s,
                              quality_preset: q,
                              video_bitrate_kbps: kbps,
                            }))
                          }}
                        >
                          <option value="high">High</option>
                          <option value="medium">Medium</option>
                          <option value="low">Low</option>
                          <option value="custom">Custom</option>
                        </select>
                        <div className="fe-bitrate-unit-row">
                          <select
                            value={exportSettings.video_bitrate_kbps}
                            onChange={(e) =>
                              setExportSettings((s) => ({
                                ...s,
                                video_bitrate_kbps: Number(e.target.value),
                                quality_preset:
                                  Number(e.target.value) === 20000
                                    ? 'high'
                                    : Number(e.target.value) === 10000
                                      ? 'medium'
                                      : Number(e.target.value) === 5000
                                        ? 'low'
                                        : 'custom',
                              }))
                            }
                          >
                            {[3500, 5000, 8000, 10000, 15000, 20000, 25000, 30000, 50000].map(
                              (kbps) => (
                                <option key={kbps} value={kbps}>
                                  {kbps}
                                </option>
                              ),
                            )}
                          </select>
                          <span className="fe-unit-label">kbps</span>
                        </div>
                      </div>
                    </div>

                    <label className="fe-field">
                      <span>Export Color Space</span>
                      <select
                        value={exportSettings.color_space}
                        onChange={(e) =>
                          setExportSettings((s) => ({
                            ...s,
                            color_space: e.target.value as ExportSettings['color_space'],
                          }))
                        }
                      >
                        <option value="bt709">SDR - Rec.709</option>
                        <option value="bt601">SDR - Rec.601</option>
                      </select>
                    </label>

                    <label className="fe-field">
                      <span>Compression Quality</span>
                      <select
                        value={
                          !exportSettings.advanced_compression
                            ? 'none'
                            : exportSettings.compression_mode
                        }
                        onChange={(e) => {
                          const mode = e.target.value as ExportSettings['compression_mode']
                          setExportSettings((s) => ({
                            ...s,
                            advanced_compression: mode !== 'none',
                            compression_mode: mode,
                          }))
                        }}
                      >
                        <option value="none">None</option>
                        <option value="by_quality">By Quality ({exportSettings.compression_quality}%)</option>
                        <option value="by_bitrate">By Bitrate ({exportSettings.compression_quality}%)</option>
                      </select>
                    </label>

                    <div className="fe-section-title">Audio</div>

                    <label className="fe-field">
                      <span>Encoder</span>
                      <select
                        value={exportSettings.audio_encoder || 'aac'}
                        onChange={(e) =>
                          setExportSettings((s) => ({
                            ...s,
                            audio_encoder: e.target.value as NonNullable<
                              ExportSettings['audio_encoder']
                            >,
                          }))
                        }
                      >
                        <option value="aac">AAC</option>
                        <option value="mp3">MP3</option>
                        <option value="pcm">PCM</option>
                      </select>
                    </label>

                    <label className="fe-field">
                      <span>Channel</span>
                      <select
                        value={exportSettings.audio_channels}
                        onChange={(e) =>
                          setExportSettings((s) => ({
                            ...s,
                            audio_channels: e.target.value as ExportSettings['audio_channels'],
                          }))
                        }
                      >
                        <option value="stereo">Stereo</option>
                        <option value="mono">Mono</option>
                      </select>
                    </label>

                    <label className="fe-field">
                      <span>Sample Rate</span>
                      <select
                        value={exportSettings.audio_sample_rate}
                        onChange={(e) =>
                          setExportSettings((s) => ({
                            ...s,
                            audio_sample_rate: Number(e.target.value),
                          }))
                        }
                      >
                        <option value={44100}>44100 Hz</option>
                        <option value={48000}>48000 Hz</option>
                        <option value={32000}>32000 Hz</option>
                      </select>
                    </label>

                    <div className="fe-field">
                      <span>Bit Rate</span>
                      <div className="fe-bitrate-unit-row">
                        <select
                          value={exportSettings.audio_bitrate_kbps}
                          onChange={(e) =>
                            setExportSettings((s) => ({
                              ...s,
                              audio_bitrate_kbps: Number(e.target.value),
                            }))
                          }
                        >
                          {[320, 256, 192, 128, 96].map((b) => (
                            <option key={b} value={b}>
                              {b}
                            </option>
                          ))}
                        </select>
                        <span className="fe-unit-label">kbps</span>
                      </div>
                    </div>

                    <label className="fe-toggle-row">
                      <input
                        type="checkbox"
                        checked={Boolean(exportSettings.export_multitrack)}
                        onChange={(e) =>
                          setExportSettings((s) => ({ ...s, export_multitrack: e.target.checked }))
                        }
                      />
                      <span>Export multi-track video</span>
                    </label>

                    <label className="fe-toggle-row">
                      <input
                        type="checkbox"
                        checked={Boolean(exportSettings.export_video_only)}
                        onChange={(e) =>
                          setExportSettings((s) => ({ ...s, export_video_only: e.target.checked }))
                        }
                      />
                      <span>Export video only</span>
                    </label>
                  </div>

                  <div className="fe-adv-footer">
                    <button
                      type="button"
                      className="fe-btn teal"
                      onClick={() => {
                        setShowAdvanced(false)
                        setLog(
                          exportSettings.advanced_compression && exportSettings.compression_mode !== 'none'
                            ? `✓ Applied ${presetName} (${exportSettings.resolution.replace('x', '*')}, ${exportSettings.fps} fps, ${exportSettings.video_bitrate_kbps} kbps, By Quality ${exportSettings.compression_quality}%)`
                            : `✓ Applied ${presetName} (${exportSettings.resolution.replace('x', '*')}, ${exportSettings.fps} fps, ${exportSettings.video_bitrate_kbps} kbps)`,
                        )
                      }}
                    >
                      Apply
                    </button>
                    <button
                      type="button"
                      className="fe-btn reset"
                      onClick={() => void saveAsPreset()}
                    >
                      Save as Preset
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
