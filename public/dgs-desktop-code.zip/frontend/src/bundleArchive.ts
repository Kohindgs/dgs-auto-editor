// Instant Browser-Side .wfpbundle & .zip Reader and Builder
// Eliminates uploading/downloading 450+ MB over the network when opening or collecting Filmora 16 bundles in the browser.

const CRC32_TABLE = (() => {
  const table = new Uint32Array(256)
  for (let i = 0; i < 256; i++) {
    let c = i
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    }
    table[i] = c >>> 0
  }
  return table
})()

async function computeCrc32(blob: Blob): Promise<number> {
  let crc = 0xffffffff
  if (typeof blob.stream === 'function') {
    const reader = blob.stream().getReader()
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      if (value) {
        for (let i = 0; i < value.length; i++) {
          crc = CRC32_TABLE[(crc ^ value[i]) & 0xff] ^ (crc >>> 8)
        }
      }
    }
  } else {
    const buf = new Uint8Array(await blob.arrayBuffer())
    for (let i = 0; i < buf.length; i++) {
      crc = CRC32_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8)
    }
  }
  return (crc ^ 0xffffffff) >>> 0
}

async function inflateRawSlice(slice: Blob): Promise<Blob> {
  const DS = (window as unknown as { DecompressionStream?: typeof DecompressionStream }).DecompressionStream
  if (!DS) {
    throw new Error('DecompressionStream not supported in this browser')
  }
  const ds = new DS('deflate-raw')
  const decompressedStream = slice.stream().pipeThrough(ds)
  return await new Response(decompressedStream).blob()
}

export interface ExtractedBundleMedia {
  guid: string | null
  filename: string
  entryPath: string
  blob: Blob
}

export interface ExtractedBundleResult {
  innerWfpFile: File
  mediaEntries: ExtractedBundleMedia[]
}

function applyZip64Extra(
  extra: Uint8Array,
  entry: { compSize: number; uncompSize: number; localHeaderOffset: number },
) {
  if (!extra.length) return
  const view = new DataView(extra.buffer, extra.byteOffset, extra.byteLength)
  let p = 0
  while (p + 4 <= extra.length) {
    const id = view.getUint16(p, true)
    const size = view.getUint16(p + 2, true)
    const start = p + 4
    if (start + size > extra.length) break
    if (id === 0x0001) {
      let q = start
      const take = () => {
        const value = Number(view.getBigUint64(q, true))
        q += 8
        return value
      }
      if (entry.uncompSize === 0xffffffff && q + 8 <= start + size) entry.uncompSize = take()
      if (entry.compSize === 0xffffffff && q + 8 <= start + size) entry.compSize = take()
      if (entry.localHeaderOffset === 0xffffffff && q + 8 <= start + size) entry.localHeaderOffset = take()
    }
    p = start + size
  }
}

/**
 * Reads the Central Directory of a .wfpbundle or .zip File in < 25ms without loading the 450MB archive into RAM.
 * Extracts the inner .wfp (~300 KB) and zero-copy Blob slices for all Medias/{GUID}/<filename> entries.
 */
export async function extractBundleInBrowser(file: File): Promise<ExtractedBundleResult | null> {
  const fileSize = file.size
  if (fileSize < 22) return null

  // Read tail (up to 128 KB to accommodate 64 KB max ZIP comment + EOCD)
  const tailSize = Math.min(fileSize, 131072)
  const tailOffset = fileSize - tailSize
  const tailBuf = new Uint8Array(await file.slice(tailOffset, fileSize).arrayBuffer())
  const tailView = new DataView(tailBuf.buffer, tailBuf.byteOffset, tailBuf.byteLength)

  let eocdPos = -1
  for (let i = tailBuf.length - 22; i >= 0; i--) {
    if (tailView.getUint32(i, true) === 0x06054b50) {
      const commentLen = tailView.getUint16(i + 20, true)
      if (i + 22 + commentLen <= tailBuf.length) {
        eocdPos = i
        break
      }
    }
  }
  if (eocdPos < 0) return null

  let totalEntries = tailView.getUint16(eocdPos + 10, true)
  let cdSize = tailView.getUint32(eocdPos + 12, true)
  let cdOffset = tailView.getUint32(eocdPos + 16, true)
  if (totalEntries === 0xffff || cdSize === 0xffffffff || cdOffset === 0xffffffff) {
    const loc = eocdPos - 20
    if (loc < 0 || tailView.getUint32(loc, true) !== 0x07064b50) return null
    const zip64Off = Number(tailView.getBigUint64(loc + 8, true))
    const zip64Rel = zip64Off - tailOffset
    let zview = tailView
    let base = zip64Rel
    if (zip64Rel < 0 || zip64Rel + 56 > tailBuf.length) {
      const zbuf = new Uint8Array(await file.slice(zip64Off, zip64Off + 80).arrayBuffer())
      zview = new DataView(zbuf.buffer, zbuf.byteOffset, zbuf.byteLength)
      base = 0
    }
    if (zview.getUint32(base, true) !== 0x06064b50) return null
    totalEntries = Number(zview.getBigUint64(base + 32, true))
    cdSize = Number(zview.getBigUint64(base + 40, true))
    cdOffset = Number(zview.getBigUint64(base + 48, true))
  }
  if (!Number.isFinite(cdOffset) || !Number.isFinite(cdSize) || cdOffset < 0 || cdSize < 0 || cdOffset + cdSize > fileSize) {
    return null
  }

  const zipCommentLen = tailView.getUint16(eocdPos + 20, true)
  const outerCommentBytes = tailBuf.slice(eocdPos + 22, eocdPos + 22 + zipCommentLen)

  const cdBuf = new Uint8Array(await file.slice(cdOffset, cdOffset + cdSize).arrayBuffer())
  const cdView = new DataView(cdBuf.buffer, cdBuf.byteOffset, cdBuf.byteLength)
  const decoder = new TextDecoder('utf-8')

  interface CdEntry {
    name: string
    method: number
    compSize: number
    uncompSize: number
    localHeaderOffset: number
  }

  const entries: CdEntry[] = []
  let ptr = 0
  for (let idx = 0; idx < totalEntries && ptr + 46 <= cdBuf.length; idx++) {
    if (cdView.getUint32(ptr, true) !== 0x02014b50) break
    const method = cdView.getUint16(ptr + 10, true)
    const compSize = cdView.getUint32(ptr + 20, true)
    const uncompSize = cdView.getUint32(ptr + 24, true)
    const nameLen = cdView.getUint16(ptr + 28, true)
    const extraLen = cdView.getUint16(ptr + 30, true)
    const commentLen = cdView.getUint16(ptr + 32, true)
    const localHeaderOffset = cdView.getUint32(ptr + 42, true)
    const nameBytes = cdBuf.subarray(ptr + 46, ptr + 46 + nameLen)
    const name = decoder.decode(nameBytes).replace(/\\/g, '/')
    const extra = cdBuf.subarray(ptr + 46 + nameLen, ptr + 46 + nameLen + extraLen)
    const entry: CdEntry = { name, method, compSize, uncompSize, localHeaderOffset }
    applyZip64Extra(extra, entry)
    entries.push(entry)
    ptr += 46 + nameLen + extraLen + commentLen
  }

  // Check if this archive contains an inner .wfp file (i.e. it is a .wfpbundle or _Collected.zip)
  const wfpEntry =
    entries.find((e) => !e.name.endsWith('/') && e.name.toLowerCase().endsWith('.wfp') && !e.name.includes('/')) ||
    entries.find((e) => !e.name.endsWith('/') && e.name.toLowerCase().endsWith('.wfp'))

  if (!wfpEntry) {
    return null
  }

  const sliceEntryBlob = async (e: CdEntry): Promise<Blob> => {
    const lhBuf = new Uint8Array(await file.slice(e.localHeaderOffset, e.localHeaderOffset + 30).arrayBuffer())
    const lhView = new DataView(lhBuf.buffer, lhBuf.byteOffset, lhBuf.byteLength)
    if (lhView.getUint32(0, true) !== 0x04034b50) {
      throw new Error(`Invalid local header for ${e.name}`)
    }
    const lhNameLen = lhView.getUint16(26, true)
    const lhExtraLen = lhView.getUint16(28, true)
    const dataStart = e.localHeaderOffset + 30 + lhNameLen + lhExtraLen
    const rawSlice = file.slice(dataStart, dataStart + e.compSize)
    if (e.method === 0) {
      return rawSlice
    }
    if (e.method === 8) {
      return await inflateRawSlice(rawSlice)
    }
    throw new Error(`Unsupported ZIP compression method ${e.method}`)
  }

  let innerWfpBlob = await sliceEntryBlob(wfpEntry)

  // If the outer .wfpbundle had a DGS1: comment and the inner .wfp has an empty comment, attach the outer comment to innerWfpBlob
  if (outerCommentBytes.length > 5) {
    const wfpArr = new Uint8Array(await innerWfpBlob.arrayBuffer())
    const wfpView = new DataView(wfpArr.buffer, wfpArr.byteOffset, wfpArr.byteLength)
    for (let i = wfpArr.length - 22; i >= Math.max(0, wfpArr.length - 65558); i--) {
      if (wfpView.getUint32(i, true) === 0x06054b50) {
        const curCommentLen = wfpView.getUint16(i + 20, true)
        if (curCommentLen === 0) {
          const head = wfpArr.subarray(0, i + 20)
          const lenBuf = new Uint8Array(2)
          new DataView(lenBuf.buffer).setUint16(0, outerCommentBytes.length, true)
          innerWfpBlob = new Blob([head, lenBuf, outerCommentBytes], { type: 'application/octet-stream' })
        }
        break
      }
    }
  }

  const wfpBaseName = wfpEntry.name.split('/').pop() || file.name.replace(/\.(wfpbundle|zip)$/i, '.wfp')
  const innerWfpFile = new File([innerWfpBlob], wfpBaseName, { type: 'application/octet-stream' })

  const mediaEntries: ExtractedBundleMedia[] = []
  for (const e of entries) {
    if (e.name.endsWith('/') || e === wfpEntry) continue
    if (e.name.startsWith('ProjectFolder/') || e.name.includes('/ProjectFolder/')) continue
    if (
      e.name.startsWith('Medias/') ||
      e.name.includes('/Medias/') ||
      e.name.startsWith('Media/') ||
      e.name.includes('/Media/') ||
      e.name.startsWith('Resources/')
    ) {
      const base = e.name.split('/').pop() || ''
      if (!base || base === 'project_media.json' || base === 'medias_info.json') continue
      let guid: string | null = null
      const mIdx = e.name.indexOf('Medias/')
      if (mIdx >= 0) {
        const sub = e.name.slice(mIdx).split('/')
        if (sub.length >= 3 && sub[1]) guid = sub[1]
      }
      const blob = await sliceEntryBlob(e)
      mediaEntries.push({
        guid,
        filename: base,
        entryPath: e.name,
        blob,
      })
    }
  }

  return { innerWfpFile, mediaEntries }
}

export interface ZipBuildEntry {
  entryPath: string
  blob: Blob
}

/**
 * Builds a Filmora 16-compatible STORED (method=0) .wfpbundle or .zip archive directly in the browser
 * using zero-copy composite Blobs.
 */
export async function buildStoredZipArchiveInBrowser(
  entries: ZipBuildEntry[],
  zipComment = '',
  onProgress?: (pct: number, msg: string) => void,
): Promise<Blob> {
  const encoder = new TextEncoder()
  const parts: BlobPart[] = []
  const centralRecords: Uint8Array[] = []
  let offset = 0

  const now = new Date()
  const dosTime =
    ((now.getHours() & 0x1f) << 11) |
    ((now.getMinutes() & 0x3f) << 5) |
    ((now.getSeconds() >> 1) & 0x1f)
  const dosDate =
    (((now.getFullYear() - 1980) & 0x7f) << 9) |
    (((now.getMonth() + 1) & 0x0f) << 5) |
    (now.getDate() & 0x1f)

  const total = Math.max(1, entries.length)
  for (let idx = 0; idx < entries.length; idx++) {
    const item = entries[idx]
    const nameBytes = encoder.encode(item.entryPath.replace(/\\/g, '/'))
    const size = item.blob.size
    if (onProgress) {
      const pct = Math.min(95, 10 + Math.round(((idx + 1) / total) * 84))
      const shortName = item.entryPath.split('/').pop() || item.entryPath
      onProgress(pct, `Packing ${shortName} (${idx + 1}/${total})…`)
    }
    const crc = await computeCrc32(item.blob)

    // Local File Header (30 + nameLen)
    const lh = new Uint8Array(30 + nameBytes.length)
    const lhv = new DataView(lh.buffer)
    lhv.setUint32(0, 0x04034b50, true)
    lhv.setUint16(4, 20, true)
    lhv.setUint16(6, 0x0800, true) // UTF-8 flag
    lhv.setUint16(8, 0, true) // method = 0 (STORED)
    lhv.setUint16(10, dosTime, true)
    lhv.setUint16(12, dosDate, true)
    lhv.setUint32(14, crc, true)
    lhv.setUint32(18, size, true)
    lhv.setUint32(22, size, true)
    lhv.setUint16(26, nameBytes.length, true)
    lhv.setUint16(28, 0, true)
    lh.set(nameBytes, 30)

    // Central Directory File Header (46 + nameLen)
    const cd = new Uint8Array(46 + nameBytes.length)
    const cdv = new DataView(cd.buffer)
    cdv.setUint32(0, 0x02014b50, true)
    cdv.setUint16(4, 20, true)
    cdv.setUint16(6, 20, true)
    cdv.setUint16(8, 0x0800, true)
    cdv.setUint16(10, 0, true) // method = 0 (STORED)
    cdv.setUint16(12, dosTime, true)
    cdv.setUint16(14, dosDate, true)
    cdv.setUint32(16, crc, true)
    cdv.setUint32(20, size, true)
    cdv.setUint32(24, size, true)
    cdv.setUint16(28, nameBytes.length, true)
    cdv.setUint16(30, 0, true)
    cdv.setUint16(32, 0, true)
    cdv.setUint16(34, 0, true)
    cdv.setUint16(36, 0, true)
    cdv.setUint32(38, 0, true)
    cdv.setUint32(42, offset, true)
    cd.set(nameBytes, 46)

    parts.push(lh as unknown as BlobPart)
    parts.push(item.blob)
    centralRecords.push(cd)
    offset += lh.length + size
  }

  let cdTotalSize = 0
  for (const cd of centralRecords) {
    parts.push(cd as unknown as BlobPart)
    cdTotalSize += cd.length
  }

  const commentBytes = encoder.encode(zipComment || '')
  const safeCommentLen = Math.min(65535, commentBytes.length)
  const eocd = new Uint8Array(22 + safeCommentLen)
  const eocdv = new DataView(eocd.buffer)
  eocdv.setUint32(0, 0x06054b50, true)
  eocdv.setUint16(4, 0, true)
  eocdv.setUint16(6, 0, true)
  eocdv.setUint16(8, entries.length, true)
  eocdv.setUint16(10, entries.length, true)
  eocdv.setUint32(12, cdTotalSize, true)
  eocdv.setUint32(16, offset, true)
  eocdv.setUint16(20, safeCommentLen, true)
  if (safeCommentLen > 0) {
    eocd.set(commentBytes.subarray(0, safeCommentLen), 22)
  }
  parts.push(eocd as unknown as BlobPart)

  return new Blob(parts, { type: 'application/octet-stream' })
}
