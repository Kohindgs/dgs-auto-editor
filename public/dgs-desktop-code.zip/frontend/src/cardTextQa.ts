/**
 * Browser port of backend/app/qa_scan.py `_card_word_issue_english`.
 * Compares OCR text read from each image on Video 1 against the scene's
 * On-Screen Text / VO in the script, and reports wrong / shifted / blank-vs-answer cards
 * as yellow 💭 thought bubbles on the timeline.
 */
import type { QAIssue, Scene, TimelineClip } from './types.ts'

const DIGIT_RE = /^[\u0966-\u096F0-9]+$/
const DEVANAGARI_RE = /[\u0900-\u097F]/

export const EN_FUNCTION_WORDS = new Set([
  'the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'any', 'can', 'had',
  'her', 'was', 'one', 'our', 'out', 'has', 'his', 'how', 'its', 'let', 'may',
  'new', 'now', 'old', 'see', 'two', 'way', 'who', 'boy', 'did', 'get', 'him',
  'man', 'put', 'say', 'she', 'too', 'use', 'that', 'with', 'have', 'this',
  'will', 'your', 'from', 'they', 'know', 'want', 'been', 'good', 'much',
  'some', 'time', 'very', 'when', 'come', 'here', 'just', 'like', 'long',
  'make', 'many', 'more', 'only', 'over', 'such', 'take', 'than', 'them',
  'well', 'were', 'what', 'into', 'there', 'their', 'about', 'would', 'these',
  'other', 'words', 'which', 'could', 'write', 'first', 'water', 'after',
  'where', 'right', 'think', 'three', 'years', 'place', 'sound', 'great',
  'again', 'still', 'every', 'small', 'found', 'those', 'never',
  'mishka', 'om',
])

const META_NOTE_PATTERNS = [
  'no on-screen',
  'no onscreen',
  'no additional text',
  'image illustrates',
  'six insect drawings',
  'dotted blanks underneath',
  'observe the pictures',
  'instrumental',
]

function imageNo(screen: string): number | null {
  const m = /(\d+)$/.exec(screen || '')
  return m ? parseInt(m[1], 10) : null
}

function fmtTc(sec: number) {
  const s = Math.max(0, Math.floor(sec))
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`
}

function tokens(text: string): string[] {
  const re = /[\u0900-\u097F]+|[\u0600-\u06FF]+|[\p{L}\p{N}]+(?:'[\p{L}\p{N}]+)?/gu
  return (text || '').match(re)?.map((t) => t.toLowerCase()) || []
}

export function cleanExpectedCardText(raw: string): string {
  let text = (raw || '').trim()
  if (!text || ['—', '-', '–', 'None', 'none', 'N/A'].includes(text)) return ''
  const low = text.toLowerCase()
  if (META_NOTE_PATTERNS.some((p) => low.includes(p))) return ''
  text = text.replace(/\b(top|bottom|left|right)\s+row\s*:\s*/gi, ' ')
  return text.trim()
}

export function hasBlankPlaceholder(text: string): boolean {
  if (!text) return false
  return /(\.{3,}|_{3,}|…{2,}|\[blank\])/i.test(text)
}

function ocrHasVisualBlank(ocr: string): boolean {
  if (!ocr) return false
  if (/(\.{4,}|_{4,})/.test(ocr)) return true
  for (const tok of ocr.split(/\s+/)) {
    const clean = tok.replace(/[^a-zA-Z0-9@]/g, '')
    if (clean.length >= 7) {
      let c = 0
      for (const ch of clean.toLowerCase()) if ('oce09@s'.includes(ch)) c++
      if (c / clean.length >= 0.8) return true
    }
  }
  return false
}

export function engWords(text: string): string[] {
  const out: string[] = []
  for (const t of tokens(text)) {
    const clean = t.toLowerCase().replace(/[^a-z]/g, '')
    if (clean.length >= 2 && !DIGIT_RE.test(clean)) out.push(clean)
  }
  return out
}

function cardSame(left: string, right: string): boolean {
  if (!left || !right) return false
  if (left === right) return true
  const a = left
  const b = right
  if (Math.min(a.length, b.length) >= 4 && Math.abs(a.length - b.length) <= 1 && (a.includes(b) || b.includes(a))) {
    return true
  }
  if (a.length >= 5 && b.length >= 4 && Math.abs(a.length - b.length) <= 2) {
    if (a.slice(1) === b || b.slice(1) === a || a.slice(0, -1) === b || b.slice(0, -1) === a) return true
    const mid = a.slice(1, -1)
    if (mid && (b.includes(mid) || mid.includes(b))) return true
  }
  return false
}

export function wordInOcr(want: string, ocrWords: string[], ocrCompact: string): boolean {
  const w = want.toLowerCase().trim()
  if (!w) return true
  if (ocrWords.some((g) => cardSame(w, g))) return true
  if (w.length >= 3 && ocrCompact.includes(w)) return true
  if (w.length >= 4 && ocrCompact.includes(w.slice(1))) return true
  return false
}

export function cleanOcrPreview(ocr: string): string {
  const keep = new Set(['a', 'i', 'to', 'in', 'on', 'at', 'of', 'or', 'is', 'it', 'my', 'no', 'so', 'up', 'we', 'go', 'do', 'om', 'an', 'by', 'he', 'me', 'oh'])
  const words: string[] = []
  for (const tok of (ocr || '').split(/\s+/)) {
    if (!tok) continue
    const alnum = tok.replace(/[^a-zA-Z0-9\u0900-\u097F]/g, '')
    if (alnum.length >= 7) {
      let c = 0
      for (const ch of alnum.toLowerCase()) if ('oce09@s'.includes(ch)) c++
      if (c / alnum.length >= 0.8) {
        words.push('............')
        continue
      }
    }
    if (DEVANAGARI_RE.test(tok)) {
      if (alnum.length >= 2) words.push(tok)
      continue
    }
    const alpha = tok.replace(/[^a-zA-Z'-]/g, '')
    if (alpha.length >= 3 || keep.has(alpha.toLowerCase())) words.push(tok)
  }
  const preview = words.join(' ')
  return preview ? preview.slice(0, 160) : '(no readable text on card)'
}

// ---------------------------------------------------------------------------
// Evidence-based matching.
// A bubble is raised ONLY when the picture positively matches a DIFFERENT script
// line (or the blank/answer version of the same line). Stylised title lettering that
// OCR simply can't read (e.g. "Garden Walk" in leafy letters) never triggers a bubble.
// ---------------------------------------------------------------------------

type Profile = {
  screen: string
  ost: string
  words: string[] // distinct content words (len >= 3)
  blank: boolean
  answerWords: string[] // words that differ between the blank prompt and its answer slide
  counterpart: string | null // screen of the blank ↔ answer partner
}

type Ocr = { words: string[]; compact: string; visualBlank: boolean; raw: string }

function prepOcr(raw: string): Ocr {
  return {
    words: engWords(raw || ''),
    compact: (raw || '').toLowerCase().replace(/[^a-z]/g, ''),
    visualBlank: ocrHasVisualBlank(raw || ''),
    raw: raw || '',
  }
}

function has(o: Ocr, w: string) {
  return wordInOcr(w, o.words, o.compact)
}

export function buildProfiles(scenes: Scene[]): Map<string, Profile> {
  const base: Profile[] = scenes.map((s) => {
    const ost = cleanExpectedCardText(s.onscreen_text || '')
    const words = Array.from(new Set(engWords(ost).filter((w) => w.length >= 3)))
    return { screen: s.screen, ost, words, blank: hasBlankPlaceholder(s.onscreen_text || ''), answerWords: [], counterpart: null }
  })
  const idx = new Map(base.map((p, i) => [p.screen, i]))
  // Pair each fill-in-the-blank prompt with the nearest following answer slide
  for (let i = 0; i < base.length; i++) {
    const b = base[i]
    if (!b.blank || b.words.length < 2) continue
    for (let j = i + 1; j < Math.min(base.length, i + 4); j++) {
      const a = base[j]
      if (a.blank || !a.words.length) continue
      const shared = b.words.filter((w) => a.words.includes(w)).length
      const extra = a.words.filter((w) => !b.words.includes(w))
      if (shared >= Math.max(2, b.words.length - 1) && extra.length) {
        b.counterpart = a.screen
        a.counterpart = b.screen
        // Answer words = words the answer slide adds, minus words the blank line also says elsewhere
        b.answerWords = extra
        a.answerWords = extra
        break
      }
    }
  }
  void idx
  return new Map(base.map((p) => [p.screen, p]))
}

/** 0..1 — how well an OCR'd picture fits a script line. */
function fit(p: Profile, o: Ocr, vocab: Set<string>): number {
  if (p.words.length < 2) return 0
  const matched = p.words.filter((w) => has(o, w)).length
  let score = matched / p.words.length
  // Penalise real script words on the picture that this line doesn't contain (picture carries a longer / different line)
  const own = new Set(p.words)
  let extras = 0
  for (const w of new Set(o.words)) {
    if (w.length >= 4 && !own.has(w) && vocab.has(w) && !EN_FUNCTION_WORDS.has(w)) extras++
  }
  score -= Math.min(0.5, extras * 0.12)
  if (p.answerWords.length) {
    const ansSeen = p.answerWords.some((w) => has(o, w) || (w.length >= 5 && o.compact.includes(w.slice(0, 4))))
    if (p.blank) {
      if (ansSeen) score -= 0.5 // blank prompt line, but picture shows the answer
      else if (o.visualBlank) score += 0.05
    } else if (!ansSeen && o.visualBlank) {
      score -= 0.5 // answer line, but picture still shows the dotted blank
    }
  }
  return Math.max(0, Math.min(1, score))
}

function buildVocab(profiles: Map<string, Profile>) {
  const v = new Set<string>()
  for (const p of profiles.values()) for (const w of p.words) if (w.length >= 4) v.add(w)
  return v
}

type Evidence = { belongsTo: Profile; cur: number; other: number; kind: 'other_scene' | 'answer_shown' | 'blank_shown' }

function coverage(p: Profile, o: Ocr): number {
  if (!p.words.length) return 0
  return p.words.filter((w) => has(o, w)).length / p.words.length
}

/** The card must carry q's own words and not p's own words.

Rules out build-up cards (the whole line is still printed), answer cards
that repeat their question, and lines that quote a shorter line.
 */
function provesOtherLine(p: Profile, q: Profile, o: Ocr): boolean {
  if (coverage(p, o) >= 0.9) return false
  const qOnly = q.words.filter((w) => !p.words.includes(w) && !EN_FUNCTION_WORDS.has(w))
  if (!qOnly.length) return false
  const qShare = qOnly.filter((w) => has(o, w)).length / qOnly.length
  if (qShare < 0.5) return false
  const pOnly = p.words.filter((w) => !q.words.includes(w) && !EN_FUNCTION_WORDS.has(w))
  if (pOnly.length && pOnly.filter((w) => has(o, w)).length / pOnly.length >= 0.5) return false
  return true
}

/** Positive proof that a picture belongs to another script line. */
function mismatchEvidence(p: Profile, o: Ocr, profiles: Map<string, Profile>, vocab: Set<string>): Evidence | null {
  if (p.words.length < 2) return null
  const cur = fit(p, o, vocab)
  if (cur >= 0.8) return null
  let best: Profile | null = null
  let bestFit = 0
  for (const q of profiles.values()) {
    if (q.screen === p.screen || q.words.length < 3 || q.ost.toLowerCase() === p.ost.toLowerCase()) continue
    const f = fit(q, o, vocab)
    if (f > bestFit) {
      bestFit = f
      best = q
    }
  }
  if (!best || bestFit < 0.75 || bestFit < cur + 0.3) return null
  let kind: Evidence['kind'] = 'other_scene'
  if (p.counterpart === best.screen) kind = p.blank ? 'answer_shown' : 'blank_shown'
  if (kind === 'other_scene' && !provesOtherLine(p, best, o)) return null
  return { belongsTo: best, cur, other: bestFit, kind }
}

/** Stable cache key for an image (by media id). */
export function ocrKeyForClip(clip: TimelineClip): string | null {
  return clip.media_id || null
}

function sceneLabel(screen: string) {
  return `Scene ${imageNo(screen) ?? screen.replace('screen_', '')}`
}

/** True when the script is Marathi/Hindi so English OCR matching must not run. */
export function scriptLooksIndic(scenes: Scene[]): boolean {
  const sample = (scenes || [])
    .slice(0, 40)
    .map((s) => `${s.voiceover_text || ''} ${s.onscreen_text || ''} ${s.text || ''}`)
    .join(' ')
  const m = sample.match(/[\u0900-\u097F]/g)
  return Boolean(m && m.length >= 12)
}

/** Build yellow-bubble issues — only for pictures with positive proof of a mismatch. */
export function buildCardTextIssues(
  clips: TimelineClip[],
  scenes: Scene[],
  ocrTexts: Record<string, string>,
): QAIssue[] {
  const profiles = buildProfiles(scenes)
  const vocab = buildVocab(profiles)
  const issues: QAIssue[] = []
  const seen = new Set<string>()
  for (const clip of clips) {
    if (clip.fit === 'missing' || (clip.kind || '') !== 'image' || !clip.media_id) continue
    const scene = scenes.find((s) => s.screen === clip.screen)
    const p = profiles.get(clip.screen)
    if (!scene || !p) continue
    if (DEVANAGARI_RE.test(`${scene.onscreen_text || ''}${scene.voiceover_text || ''}`)) continue
    const raw = ocrTexts[clip.media_id]
    if (raw == null) continue
    const dedupe = `${clip.screen}|${clip.media_id}`
    if (seen.has(dedupe)) continue
    seen.add(dedupe)
    const ev = mismatchEvidence(p, prepOcr(raw), profiles, vocab)
    if (!ev) continue
    const n = imageNo(clip.screen)
    const tc = `${fmtTc(clip.start)}–${fmtTc(clip.end)}`
    const pic = clip.filename || `Image ${n}`
    let detail: string
    if (ev.kind === 'answer_shown') {
      detail = `This is a fill-in-the-blank line, but ${pic} already shows the answer ("${ev.belongsTo.ost.slice(0, 90)}") — that picture belongs to ${sceneLabel(ev.belongsTo.screen)}.`
    } else if (ev.kind === 'blank_shown') {
      detail = `VO gives the answer here, but ${pic} still shows the blank ("${ev.belongsTo.ost.slice(0, 90)}") — that picture belongs to ${sceneLabel(ev.belongsTo.screen)}.`
    } else {
      detail = `${pic} shows ${sceneLabel(ev.belongsTo.screen)}'s line ("${ev.belongsTo.ost.slice(0, 90)}"), not this scene's line.`
    }
    issues.push({
      kind: 'card_text',
      severity: 'warning',
      screen: clip.screen,
      image_no: n,
      time: clip.start,
      end: clip.end,
      timecode: tc,
      message: `${sceneLabel(clip.screen)} (${tc}): ${detail}`,
      expected: (p.ost || scene.voiceover_text || '').slice(0, 180),
      found: cleanOcrPreview(raw).slice(0, 180),
      missing_words: [],
      source: 'ocr_client',
    })
  }
  return issues
}

export type ImageCandidate = { id: string; filename: string; path?: string; kind?: string }
export type AutoMatch = { screen: string; fromId: string | null; to: ImageCandidate; score: number }

/**
 * Find the correct picture for every mismatched scene, using the text printed on each image.
 * Only moves pictures that are (a) on mismatched scenes or (b) not used on the timeline,
 * and only when the match is clear-cut — correctly placed scenes are never touched.
 */
export function proposeAutoMatches(
  clips: TimelineClip[],
  scenes: Scene[],
  images: ImageCandidate[],
  ocrTexts: Record<string, string>,
): AutoMatch[] {
  const profiles = buildProfiles(scenes)
  const vocab = buildVocab(profiles)
  const ocrById = new Map<string, Ocr>()
  for (const img of images) if (ocrTexts[img.id] != null) ocrById.set(img.id, prepOcr(ocrTexts[img.id]))

  const suspects: { screen: string; curId: string; cur: number }[] = []
  for (const c of clips) {
    if (c.fit === 'missing' || (c.kind || '') !== 'image' || !c.media_id) continue
    const p = profiles.get(c.screen)
    const o = ocrById.get(c.media_id)
    if (!p || !o) continue
    const scene = scenes.find((sc) => sc.screen === c.screen)
    if (scene && DEVANAGARI_RE.test(`${scene.onscreen_text || ''}${scene.voiceover_text || ''}`)) continue
    if (suspects.some((s) => s.screen === c.screen)) continue
    const ev = mismatchEvidence(p, o, profiles, vocab)
    if (ev) suspects.push({ screen: c.screen, curId: c.media_id, cur: ev.cur })
  }
  if (!suspects.length) return []

  const usedOnGood = new Set<string>()
  const suspectScreens = new Set(suspects.map((s) => s.screen))
  for (const c of clips) if (c.media_id && !suspectScreens.has(c.screen)) usedOnGood.add(c.media_id)
  const pool = images.filter((img) => ocrById.has(img.id) && !usedOnGood.has(img.id))

  const proposals: AutoMatch[] = []
  for (const s of suspects) {
    const p = profiles.get(s.screen)!
    const scored = pool
      .map((img) => ({ img, f: fit(p, ocrById.get(img.id)!, vocab) }))
      .sort((a, b) => b.f - a.f)
    const best = scored[0]
    const second = scored[1]
    if (!best || best.img.id === s.curId) continue
    if (best.f < 0.8 || best.f < s.cur + 0.3) continue
    if (second && second.f > best.f - 0.15) continue // ambiguous — leave it for the user
    proposals.push({ screen: s.screen, fromId: s.curId, to: best.img, score: best.f })
  }
  // One picture per scene; strongest matches first
  proposals.sort((a, b) => b.score - a.score)
  const taken = new Set<string>()
  return proposals.filter((m) => {
    if (taken.has(m.to.id)) return false
    taken.add(m.to.id)
    return true
  })
}

/** Apply auto-matches to the clip list (every clip of that scene that showed the wrong picture). */
export function applyAutoMatches(clips: TimelineClip[], matches: AutoMatch[]): TimelineClip[] {
  const byScreen = new Map(matches.map((m) => [m.screen, m]))
  return clips.map((c) => {
    const m = byScreen.get(c.screen)
    if (!m || c.media_id !== m.fromId) return c
    return {
      ...c,
      media_id: m.to.id,
      media_path: m.to.path ?? null, // server re-resolves the path from media_id when null
      filename: m.to.filename,
      kind: 'image',
      fit: 'hold',
    }
  })
}
