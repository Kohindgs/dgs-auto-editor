import type { CSSProperties } from 'react'

export type NeonIconName =
  | 'logo'
  | 'sparkles'
  | 'save'
  | 'folder'
  | 'folder-open'
  | 'folderOpen'
  | 'package'
  | 'zip'
  | 'clock'
  | 'image'
  | 'video'
  | 'film'
  | 'layers'
  | 'script'
  | 'mic'
  | 'music'
  | 'tag'
  | 'subtitles'
  | 'bolt'
  | 'wand'
  | 'export'
  | 'cloud'
  | 'cpu'
  | 'signal'
  | 'stop'
  | 'play'
  | 'pause'
  | 'step-start'
  | 'prev'
  | 'next'
  | 'volume'
  | 'mute'
  | 'enlarge'
  | 'minimize'
  | 'fullscreen'
  | 'close'
  | 'check'
  | 'alert'
  | 'plus'
  | 'refresh'
  | 'pc'
  | 'monitor'
  | 'eye'
  | 'eye-off'
  | 'lock'
  | 'unlock'
  | 'sliders'
  | 'align'
  | 'edit'
  | 'download'

interface NeonIconProps {
  name: NeonIconName
  size?: number
  tone?: 'cyan' | 'violet' | 'emerald' | 'rose' | 'amber' | 'ice'
  className?: string
  style?: CSSProperties
}

const TONE_COLORS: Record<NonNullable<NeonIconProps['tone']>, { stroke: string; glow: string }> = {
  cyan: { stroke: '#2dd4bf', glow: 'rgba(45, 212, 191, 0.48)' },
  violet: { stroke: '#c084fc', glow: 'rgba(192, 132, 252, 0.48)' },
  emerald: { stroke: '#34d399', glow: 'rgba(52, 211, 153, 0.48)' },
  rose: { stroke: '#fb7185', glow: 'rgba(251, 113, 133, 0.48)' },
  amber: { stroke: '#fbbf24', glow: 'rgba(251, 191, 36, 0.45)' },
  ice: { stroke: '#38bdf8', glow: 'rgba(56, 189, 248, 0.48)' },
}

export function NeonIcon({
  name,
  size = 15,
  tone = 'cyan',
  className = '',
  style,
}: NeonIconProps) {
  const palette = TONE_COLORS[tone] || TONE_COLORS.cyan
  const baseStyle: CSSProperties = {
    width: size,
    height: size,
    flexShrink: 0,
    verticalAlign: 'middle',
    filter: `drop-shadow(0 0 4px ${palette.glow})`,
    ...style,
  }

  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke={palette.stroke}
      strokeWidth={1.85}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={`neon-svg-icon ${className}`}
      style={baseStyle}
      aria-hidden="true"
    >
      {renderPath(name)}
    </svg>
  )
}

function renderPath(name: NeonIconName) {
  switch (name) {
    case 'logo':
      return (
        <>
          <rect x="2.5" y="4" width="19" height="16" rx="3.5" />
          <path d="M7.5 4v16M16.5 4v16M2.5 9h5M2.5 15h5M16.5 9h5M16.5 15h5" />
          <polygon points="10.2,9.2 15,12 10.2,14.8" fill="currentColor" fillOpacity="0.25" />
        </>
      )
    case 'sparkles':
      return (
        <>
          <path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3z" />
          <path d="M19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8L19 16z" />
        </>
      )
    case 'save':
      return (
        <>
          <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
          <polyline points="17 21 17 13 7 13 7 21" />
          <polyline points="7 3 7 8 15 8" />
        </>
      )
    case 'folder':
      return (
        <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
      )
    case 'folder-open':
    case 'folderOpen':
      return (
        <>
          <path d="M2 19a2 2 0 0 0 2 2h14.5a2 2 0 0 0 1.9-1.4l2.1-7.6H6.2L4 19H2z" />
          <path d="M4 19V5a2 2 0 0 1 2-2h4.5l2 2.5H19a2 2 0 0 1 2 2v4.5" />
        </>
      )
    case 'film':
      return (
        <>
          <rect x="2.5" y="3.5" width="19" height="17" rx="2.2" />
          <path d="M7 3.5v17M17 3.5v17M2.5 8.5h4.5M2.5 15.5h4.5M17 8.5h4.5M17 15.5h4.5M7 12h10" />
        </>
      )
    case 'layers':
      return (
        <>
          <polygon points="12 2 2 7 12 12 22 7 12 2" />
          <polyline points="2 12 12 17 22 12" />
          <polyline points="2 17 12 22 22 17" />
        </>
      )
    case 'wand':
      return (
        <>
          <path d="M15 4V2M15 16v-2M8 9h2M20 9h2M17.8 11.8L19 13M17.8 6.2L19 5M3 21l9-9M12.2 6.2L11 5" />
        </>
      )
    case 'export':
      return (
        <>
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="17 8 12 3 7 8" />
          <line x1="12" y1="3" x2="12" y2="15" />
        </>
      )
    case 'package':
      return (
        <>
          <path d="M16.5 9.4l-9-5.19" />
          <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
          <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
          <line x1="12" y1="22.08" x2="12" y2="12" />
        </>
      )
    case 'zip':
      return (
        <>
          <rect x="4" y="2.5" width="16" height="19" rx="2.5" />
          <path d="M11 5.5h2M11 8.5h2M11 11.5h2" />
          <rect x="10" y="14" width="4" height="4.5" rx="1" />
        </>
      )
    case 'clock':
      return (
        <>
          <circle cx="12" cy="12" r="9" />
          <polyline points="12 7 12 12 15.5 14" />
        </>
      )
    case 'image':
      return (
        <>
          <rect x="3" y="3" width="18" height="18" rx="2.5" />
          <circle cx="8.5" cy="8.5" r="1.6" />
          <polyline points="21 15 16 10 5 21" />
        </>
      )
    case 'video':
      return (
        <>
          <rect x="2.5" y="5" width="14" height="14" rx="2.2" />
          <polygon points="16.5 9.5 21.5 6.8 21.5 17.2 16.5 14.5" />
        </>
      )
    case 'script':
      return (
        <>
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
          <polyline points="14 2 14 8 20 8" />
          <line x1="8" y1="13" x2="16" y2="13" />
          <line x1="8" y1="17" x2="13.5" y2="17" />
        </>
      )
    case 'mic':
      return (
        <>
          <rect x="9" y="2.5" width="6" height="11" rx="3" />
          <path d="M19 10v1a7 7 0 0 1-14 0v-1" />
          <line x1="12" y1="18" x2="12" y2="21.5" />
          <line x1="8.5" y1="21.5" x2="15.5" y2="21.5" />
        </>
      )
    case 'music':
      return (
        <>
          <path d="M9 18V5l12-2v13" />
          <circle cx="6" cy="18" r="3" />
          <circle cx="18" cy="16" r="3" />
        </>
      )
    case 'tag':
      return (
        <>
          <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z" />
          <circle cx="7" cy="7" r="1.5" />
        </>
      )
    case 'subtitles':
      return (
        <>
          <rect x="2.5" y="4.5" width="19" height="15" rx="2.5" />
          <path d="M6.5 12h4.5M13 12h4.5M6.5 15.5h7M15.5 15.5h2" />
        </>
      )
    case 'bolt':
      return <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" />
    case 'cloud':
      return <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" />
    case 'cpu':
      return (
        <>
          <rect x="4" y="4" width="16" height="16" rx="2" />
          <rect x="9" y="9" width="6" height="6" />
          <path d="M9 1v3M15 1v3M9 20v3M15 20v3M20 9h3M20 14h3M1 9h3M1 14h3" />
        </>
      )
    case 'signal':
      return (
        <>
          <line x1="4" y1="20" x2="4" y2="16" />
          <line x1="9" y1="20" x2="9" y2="12" />
          <line x1="14" y1="20" x2="14" y2="8" />
          <line x1="19" y1="20" x2="19" y2="4" />
        </>
      )
    case 'stop':
      return <rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" fillOpacity="0.3" />
    case 'play':
      return <polygon points="6 4 20 12 6 20 6 4" fill="currentColor" fillOpacity="0.3" />
    case 'pause':
      return (
        <>
          <rect x="6" y="4" width="4" height="16" rx="1" />
          <rect x="14" y="4" width="4" height="16" rx="1" />
        </>
      )
    case 'step-start':
      return (
        <>
          <polygon points="19 20 9 12 19 4 19 20" />
          <line x1="5" y1="19" x2="5" y2="5" />
        </>
      )
    case 'prev':
      return <polyline points="15 18 9 12 15 6" />
    case 'next':
      return <polyline points="9 18 15 12 9 6" />
    case 'volume':
      return (
        <>
          <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
          <path d="M15.54 8.46a5 5 0 0 1 0 7.07M19.07 4.93a10 10 0 0 1 0 14.14" />
        </>
      )
    case 'mute':
      return (
        <>
          <polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
          <line x1="23" y1="9" x2="17" y2="15" />
          <line x1="17" y1="9" x2="23" y2="15" />
        </>
      )
    case 'enlarge':
      return (
        <>
          <polyline points="15 3 21 3 21 9" />
          <polyline points="9 21 3 21 3 15" />
          <line x1="21" y1="3" x2="14" y2="10" />
          <line x1="3" y1="21" x2="10" y2="14" />
        </>
      )
    case 'minimize':
      return (
        <>
          <polyline points="4 14 10 14 10 20" />
          <polyline points="20 10 14 10 14 4" />
          <line x1="14" y1="10" x2="21" y2="3" />
          <line x1="3" y1="21" x2="10" y2="14" />
        </>
      )
    case 'fullscreen':
      return (
        <path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3" />
      )
    case 'close':
      return (
        <>
          <line x1="18" y1="6" x2="6" y2="18" />
          <line x1="6" y1="6" x2="18" y2="18" />
        </>
      )
    case 'check':
      return <polyline points="20 6 9 17 4 12" />
    case 'alert':
      return (
        <>
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
          <line x1="12" y1="9" x2="12" y2="13" />
          <line x1="12" y1="17" x2="12.01" y2="17" />
        </>
      )
    case 'plus':
      return (
        <>
          <line x1="12" y1="5" x2="12" y2="19" />
          <line x1="5" y1="12" x2="19" y2="12" />
        </>
      )
    case 'refresh':
      return (
        <>
          <polyline points="23 4 23 10 17 10" />
          <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
        </>
      )
    case 'pc':
    case 'monitor':
      return (
        <>
          <rect x="2" y="3" width="20" height="14" rx="2" />
          <line x1="8" y1="21" x2="16" y2="21" />
          <line x1="12" y1="17" x2="12" y2="21" />
        </>
      )
    case 'eye':
      return (
        <>
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
          <circle cx="12" cy="12" r="3" />
        </>
      )
    case 'eye-off':
      return (
        <>
          <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
          <line x1="1" y1="1" x2="23" y2="23" />
        </>
      )
    case 'lock':
      return (
        <>
          <rect x="3" y="11" width="18" height="11" rx="2" />
          <path d="M7 11V7a5 5 0 0 1 10 0v4" />
        </>
      )
    case 'unlock':
      return (
        <>
          <rect x="3" y="11" width="18" height="11" rx="2" />
          <path d="M7 11V7a5 5 0 0 1 9.9-1" />
        </>
      )
    case 'sliders':
      return (
        <>
          <line x1="4" y1="21" x2="4" y2="14" />
          <line x1="4" y1="10" x2="4" y2="3" />
          <line x1="12" y1="21" x2="12" y2="12" />
          <line x1="12" y1="8" x2="12" y2="3" />
          <line x1="20" y1="21" x2="20" y2="16" />
          <line x1="20" y1="12" x2="20" y2="3" />
          <line x1="1" y1="14" x2="7" y2="14" />
          <line x1="9" y1="8" x2="15" y2="8" />
          <line x1="17" y1="16" x2="23" y2="16" />
        </>
      )
    case 'align':
      return (
        <>
          <rect x="3" y="4" width="18" height="5" rx="1.5" />
          <rect x="3" y="13" width="12" height="6" rx="1.5" />
          <path d="M18 13v6M15.5 16h5" />
        </>
      )
    case 'edit':
      return (
        <>
          <path d="M12 20h9" />
          <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z" />
        </>
      )
    case 'download':
      return (
        <>
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="7 10 12 15 17 10" />
          <line x1="12" y1="15" x2="12" y2="3" />
        </>
      )
  }
}

export function DgsNeonBrandLogo() {
  return (
    <div className="dgs-neon-logo" aria-hidden="true">
      <svg viewBox="0 0 38 38" width={32} height={32} fill="none">
        <defs>
          <linearGradient id="dgsNeonGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00f2fe" />
            <stop offset="50%" stopColor="#2dd4bf" />
            <stop offset="100%" stopColor="#a855f7" />
          </linearGradient>
          <filter id="dgsNeonGlow" x="-25%" y="-25%" width="150%" height="150%">
            <feGaussianBlur stdDeviation="2" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        <rect
          x="2.5"
          y="2.5"
          width="33"
          height="33"
          rx="9"
          stroke="url(#dgsNeonGrad)"
          strokeWidth="2"
          fill="rgba(13, 18, 28, 0.85)"
          filter="url(#dgsNeonGlow)"
        />
        <path
          d="M11 12.5L20.5 19L11 25.5V12.5Z"
          fill="url(#dgsNeonGrad)"
          fillOpacity="0.28"
          stroke="#2dd4bf"
          strokeWidth="1.8"
          strokeLinejoin="round"
        />
        <path
          d="M23 12V26M27 15.5V22.5"
          stroke="#c084fc"
          strokeWidth="2.1"
          strokeLinecap="round"
          filter="url(#dgsNeonGlow)"
        />
      </svg>
    </div>
  )
}

export function AiNeonThumbBadge() {
  return (
    <div className="fe-ai-neon-placeholder">
      <svg viewBox="0 0 80 64" width={64} height={52} fill="none">
        <defs>
          <linearGradient id="aiCardGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3b4454" />
            <stop offset="100%" stopColor="#232933" />
          </linearGradient>
          <linearGradient id="aiWandGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#5eead4" />
            <stop offset="100%" stopColor="#14b8a6" />
          </linearGradient>
        </defs>
        <rect
          x="10"
          y="8"
          width="54"
          height="38"
          rx="8"
          fill="url(#aiCardGrad)"
          stroke="rgba(255,255,255,0.16)"
          strokeWidth="1.5"
        />
        <circle cx="22" cy="19" r="3.5" fill="#64748b" />
        <path d="M14 40l11-11 8 7 8-6 9 10H14z" fill="#475569" opacity="0.65" />
        <text
          x="36"
          y="31"
          fill="#94a3b8"
          fontSize="15"
          fontWeight="800"
          fontFamily="system-ui, sans-serif"
          letterSpacing="0.5"
        >
          AI
        </text>
        <path
          d="M36 39L52 55"
          stroke="url(#aiWandGrad)"
          strokeWidth="3.2"
          strokeLinecap="round"
        />
        <path
          d="M33 34l1.5 3.5L38 39l-3.5 1.5L33 44l-1.5-3.5L28 39l3.5-1.5L33 34z"
          fill="#2dd4bf"
        />
        <circle cx="44" cy="34" r="1.6" fill="#5eead4" />
        <circle cx="31" cy="48" r="1.4" fill="#5eead4" />
      </svg>
    </div>
  )
}
