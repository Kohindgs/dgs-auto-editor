import type { PoemOverlayStyle, PoemPresetStyle } from '../types'
import {
  DEFAULT_POEM_OVERLAY_STYLE,
  normalizePoemOverlayStyle,
  POEM_CURATED_FONTS,
  POEM_STYLE_PRESETS,
} from '../types'
import { NeonIcon } from './NeonIcons'

type Props = {
  poemOverlay: PoemOverlayStyle
  onChange: (next: PoemOverlayStyle, commitImmediate?: boolean) => void
  onClose: () => void
  sampleLyric?: string
}

const TEXT_COLOR_SWATCHES = [
  '#ffffff',
  '#facc15',
  '#38bdf8',
  '#4ade80',
  '#f43f5e',
  '#fbbf24',
  '#a855f7',
  '#000000',
]

const BG_COLOR_SWATCHES = [
  '#0f172a',
  '#000000',
  '#020617',
  '#fef08a',
  '#ec4899',
  '#1e1b4b',
  '#064e3b',
  '#172554',
]

const BORDER_COLOR_SWATCHES = [
  '#38bdf8',
  '#eab308',
  '#06b6d4',
  '#f59e0b',
  '#000000',
  '#ffffff',
  '#475569',
  'transparent',
]

const AREA_PRESETS = [
  {
    name: '⬇ Lower Third',
    desc: 'Bottom screen standard (recommended)',
    x: 10,
    y: 72,
    w: 80,
    h: 20,
  },
  {
    name: '🔻 Bottom Subtitle',
    desc: 'Low cinematic subtitle bar',
    x: 12,
    y: 82,
    w: 76,
    h: 14,
  },
  {
    name: '⏹ Center Floating Box',
    desc: 'Center stage focus for animated cards',
    x: 15,
    y: 38,
    w: 70,
    h: 24,
  },
  {
    name: '⬆ Top Banner',
    desc: 'Upper screen header ribbon',
    x: 10,
    y: 6,
    w: 80,
    h: 18,
  },
]

export function PoemStyleStudio({
  poemOverlay,
  onChange,
  onClose,
  sampleLyric,
}: Props) {
  const norm = normalizePoemOverlayStyle(poemOverlay)

  const activeLyric =
    sampleLyric?.trim() ||
    'Solar lights shine, our village stays bright,\nClean green energy, working day and night! ☀️'

  function applyPreset(presetKey: PoemPresetStyle) {
    const p = POEM_STYLE_PRESETS[presetKey]
    onChange(
      {
        ...norm,
        preset_style: presetKey,
        font_family: p.font_family,
        text_color: p.text_color,
        bg_color: p.bg_color,
        bg_opacity: p.bg_opacity,
        border_color: p.border_color,
        border_width: p.border_width,
        border_radius: p.border_radius,
        box_shadow: p.box_shadow,
      },
      true,
    )
  }

  function applyAreaPreset(preset: (typeof AREA_PRESETS)[number]) {
    onChange(
      {
        ...norm,
        x_pct: preset.x,
        y_pct: preset.y,
        w_pct: preset.w,
        h_pct: preset.h,
      },
      true,
    )
  }

  return (
    <div className="poem-studio-drawer" role="region" aria-label="Poem Typography and Sticker Style Studio">
      <div className="ps-header">
        <div className="ps-header-left">
          <span className="ps-tag">Poem Mode</span>
          <h3 className="ps-title">
            <NeonIcon name="sparkles" size={15} tone="amber" /> Poem Typography &amp; Sticker Studio
          </h3>
        </div>
        <div className="ps-header-actions">
          <button
            type="button"
            className={`ps-lock-toggle ${norm.locked ? 'locked' : 'unlocked'}`}
            onClick={() => onChange({ ...norm, locked: !norm.locked }, true)}
            title={norm.locked ? 'Unlock area to drag or resize on screen' : 'Lock screen area and styling in place'}
          >
            <NeonIcon name={norm.locked ? 'lock' : 'unlock'} size={13} tone={norm.locked ? 'emerald' : 'cyan'} />
            {norm.locked ? '🔒 Area Locked' : '🔓 Drag & Resize Enabled'}
          </button>
          <button
            type="button"
            className="ps-reset-btn"
            onClick={() => onChange({ ...DEFAULT_POEM_OVERLAY_STYLE }, true)}
            title="Reset to default poem typography & placement"
          >
            ↺ Reset
          </button>
          <button
            type="button"
            className="ps-close-btn"
            onClick={onClose}
            title="Close Poem Style Palette (changes are saved)"
          >
            ✕
          </button>
        </div>
      </div>

      <div className="ps-body-scroll">
        {/* Curated Fonts Section (6) */}
        <section className="ps-section">
          <div className="ps-section-header">
            <span className="ps-section-title">
              <NeonIcon name="tag" size={13} tone="cyan" /> 1. Select Font (6 Curated Fonts)
            </span>
            <span className="ps-section-hint">Google Educational &amp; Story Fonts</span>
          </div>
          <div className="ps-font-grid">
            {POEM_CURATED_FONTS.map((f) => {
              const active = norm.font_family.toLowerCase().includes(f.id.toLowerCase())
              return (
                <button
                  key={f.id}
                  type="button"
                  className={`ps-font-chip ${active ? 'active' : ''}`}
                  onClick={() => onChange({ ...norm, font_family: f.id }, true)}
                >
                  <span className="ps-font-sample" style={{ fontFamily: f.family }}>
                    {f.label}
                  </span>
                  <span className="ps-font-desc">{f.desc}</span>
                </button>
              )
            })}
          </div>
        </section>

        {/* Sticker Styles Section (6) */}
        <section className="ps-section">
          <div className="ps-section-header">
            <span className="ps-section-title">
              <NeonIcon name="layers" size={13} tone="amber" /> 2. Sticker &amp; Card Style (6 Presets)
            </span>
            <span className="ps-section-hint">Instant Theme &amp; Effects</span>
          </div>
          <div className="ps-style-grid">
            {(Object.keys(POEM_STYLE_PRESETS) as PoemPresetStyle[]).map((key) => {
              const p = POEM_STYLE_PRESETS[key]
              const active = norm.preset_style === key
              return (
                <button
                  key={key}
                  type="button"
                  className={`ps-style-card ${active ? 'active' : ''}`}
                  onClick={() => applyPreset(key)}
                >
                  <div className="ps-style-badge-tag">{p.tag}</div>
                  <div
                    className="ps-style-preview"
                    style={{
                      background: p.bg_color,
                      opacity: p.bg_opacity,
                      borderColor: p.border_color,
                      borderWidth: `${p.border_width}px`,
                      borderRadius: `${p.border_radius}px`,
                      color: p.text_color,
                      fontFamily: p.font_family,
                    }}
                  >
                    <span>{p.name}</span>
                  </div>
                  <div className="ps-style-meta">
                    <span className="ps-style-title">{p.name}</span>
                    <span className="ps-style-desc">{p.desc}</span>
                  </div>
                </button>
              )
            })}
          </div>
        </section>

        {/* Custom Colors & Borders */}
        <section className="ps-section">
          <div className="ps-section-header">
            <span className="ps-section-title">
              <NeonIcon name="sliders" size={13} tone="cyan" /> 3. Colors, Sticker Pill &amp; Border
            </span>
            <span className="ps-section-hint">Fine-tune Palette</span>
          </div>

          <div className="ps-row-split">
            {/* Text Color */}
            <div className="ps-control-group">
              <label className="ps-label">Text Color</label>
              <div className="ps-swatches-row">
                {TEXT_COLOR_SWATCHES.map((hex) => (
                  <button
                    key={hex}
                    type="button"
                    className={`ps-swatch ${norm.text_color.toLowerCase() === hex.toLowerCase() ? 'active' : ''}`}
                    style={{ background: hex }}
                    onClick={() => onChange({ ...norm, text_color: hex }, true)}
                    title={hex}
                  />
                ))}
                <div className="ps-color-picker-wrap" title="Custom color picker">
                  <input
                    type="color"
                    value={norm.text_color}
                    onChange={(e) => onChange({ ...norm, text_color: e.target.value }, true)}
                  />
                </div>
              </div>
            </div>

            {/* Sticker / Card BG Color */}
            <div className="ps-control-group">
              <div className="ps-label-row">
                <label className="ps-label">Sticker Background</label>
                <span className="ps-val-tag">{Math.round(norm.bg_opacity * 100)}% Opacity</span>
              </div>
              <div className="ps-swatches-row">
                {BG_COLOR_SWATCHES.map((hex) => (
                  <button
                    key={hex}
                    type="button"
                    className={`ps-swatch ${norm.bg_color.toLowerCase() === hex.toLowerCase() ? 'active' : ''}`}
                    style={{ background: hex }}
                    onClick={() => onChange({ ...norm, bg_color: hex }, true)}
                    title={hex}
                  />
                ))}
                <div className="ps-color-picker-wrap" title="Custom background color">
                  <input
                    type="color"
                    value={norm.bg_color}
                    onChange={(e) => onChange({ ...norm, bg_color: e.target.value }, true)}
                  />
                </div>
              </div>
              <input
                type="range"
                className="ps-slider"
                min={0.1}
                max={1.0}
                step={0.05}
                value={norm.bg_opacity}
                onChange={(e) => onChange({ ...norm, bg_opacity: Number(e.target.value) }, true)}
              />
            </div>
          </div>

          <div className="ps-row-split">
            {/* Border / Outline */}
            <div className="ps-control-group">
              <div className="ps-label-row">
                <label className="ps-label">Border / Outline</label>
                <span className="ps-val-tag">{norm.border_width}px · {norm.border_radius}px Radius</span>
              </div>
              <div className="ps-swatches-row">
                {BORDER_COLOR_SWATCHES.map((hex) => (
                  <button
                    key={hex}
                    type="button"
                    className={`ps-swatch ${norm.border_color.toLowerCase() === hex.toLowerCase() ? 'active' : ''}`}
                    style={{
                      background: hex === 'transparent' ? 'repeating-linear-gradient(45deg,#222,#222 2px,#444 2px,#444 4px)' : hex,
                    }}
                    onClick={() => onChange({ ...norm, border_color: hex }, true)}
                    title={hex}
                  />
                ))}
                <div className="ps-color-picker-wrap" title="Custom border color">
                  <input
                    type="color"
                    value={norm.border_color === 'transparent' ? '#38bdf8' : norm.border_color}
                    onChange={(e) => onChange({ ...norm, border_color: e.target.value }, true)}
                  />
                </div>
              </div>
              <div className="ps-slider-pair">
                <div className="ps-slider-col">
                  <span className="ps-micro-lbl">Width ({norm.border_width}px)</span>
                  <input
                    type="range"
                    className="ps-slider"
                    min={0}
                    max={8}
                    step={0.5}
                    value={norm.border_width}
                    onChange={(e) => onChange({ ...norm, border_width: Number(e.target.value) }, true)}
                  />
                </div>
                <div className="ps-slider-col">
                  <span className="ps-micro-lbl">Corner Pill ({norm.border_radius}px)</span>
                  <input
                    type="range"
                    className="ps-slider"
                    min={0}
                    max={36}
                    step={2}
                    value={norm.border_radius}
                    onChange={(e) => onChange({ ...norm, border_radius: Number(e.target.value) }, true)}
                  />
                </div>
              </div>
            </div>

            {/* Font Size & Alignment */}
            <div className="ps-control-group">
              <div className="ps-label-row">
                <label className="ps-label">Font Size &amp; Align</label>
                <span className="ps-val-tag">{norm.font_size_px}px</span>
              </div>
              <input
                type="range"
                className="ps-slider"
                min={16}
                max={48}
                step={1}
                value={norm.font_size_px}
                onChange={(e) => onChange({ ...norm, font_size_px: Number(e.target.value) }, true)}
              />
              <div className="ps-align-row">
                {(['left', 'center', 'right'] as const).map((al) => (
                  <button
                    key={al}
                    type="button"
                    className={`ps-align-btn ${norm.text_align === al ? 'active' : ''}`}
                    onClick={() => onChange({ ...norm, text_align: al }, true)}
                  >
                    {al.toUpperCase()}
                  </button>
                ))}
                <button
                  type="button"
                  className={`ps-align-btn ${norm.box_shadow ? 'active' : ''}`}
                  onClick={() => onChange({ ...norm, box_shadow: !norm.box_shadow }, true)}
                  title="Toggle 3D Sticker Drop Shadow"
                >
                  Shadow {norm.box_shadow ? 'ON' : 'OFF'}
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Screen Area Selector & Presets */}
        <section className="ps-section">
          <div className="ps-section-header">
            <span className="ps-section-title">
              <NeonIcon name="monitor" size={13} tone="cyan" /> 4. Screen Selector Area &amp; Locking
            </span>
            <span className="ps-section-hint">Drag/Resize Directly on Preview Canvas</span>
          </div>

          <div className="ps-area-presets-grid">
            {AREA_PRESETS.map((ap) => (
              <button
                key={ap.name}
                type="button"
                className="ps-area-preset-btn"
                onClick={() => applyAreaPreset(ap)}
              >
                <span className="ps-area-name">{ap.name}</span>
                <span className="ps-area-desc">{ap.desc}</span>
              </button>
            ))}
          </div>

          <div className="ps-coords-bar">
            <div className="ps-coord">
              <span className="ps-coord-lbl">X Position:</span>
              <span className="ps-coord-val">{Math.round(norm.x_pct)}%</span>
            </div>
            <div className="ps-coord">
              <span className="ps-coord-lbl">Y Position:</span>
              <span className="ps-coord-val">{Math.round(norm.y_pct)}%</span>
            </div>
            <div className="ps-coord">
              <span className="ps-coord-lbl">Width:</span>
              <span className="ps-coord-val">{Math.round(norm.w_pct)}%</span>
            </div>
            <div className="ps-coord">
              <span className="ps-coord-lbl">Height:</span>
              <span className="ps-coord-val">{Math.round(norm.h_pct)}%</span>
            </div>
          </div>

          <div className="ps-lock-cta-wrap">
            <button
              type="button"
              className={`ps-main-lock-btn ${norm.locked ? 'is-locked' : 'is-unlocked'}`}
              onClick={() => onChange({ ...norm, locked: !norm.locked }, true)}
            >
              <NeonIcon name={norm.locked ? 'lock' : 'unlock'} size={16} tone={norm.locked ? 'emerald' : 'cyan'} />
              {norm.locked
                ? '✓ Position & Style Locked (Click to Unlock & Reposition)'
                : '🔒 Lock Area & Font on Screen (Ready for Playback)'}
            </button>
            <p className="ps-lock-help">
              {norm.locked
                ? 'Position is locked. As the video plays through poem scenes, the VO lyrics will animate inside this exact area with your chosen typography.'
                : 'You can drag the selected area or pull its corner handles directly on the video screen to place it anywhere, then click Lock.'}
            </p>
          </div>
        </section>

        {/* Live Preview Box */}
        <section className="ps-section ps-preview-section">
          <div className="ps-section-header">
            <span className="ps-section-title">
              <NeonIcon name="eye" size={13} tone="cyan" /> Live Lyric Typography Preview
            </span>
          </div>
          <div
            className="ps-live-card-preview"
            style={{
              fontFamily: norm.font_family,
              fontSize: `${norm.font_size_px}px`,
              color: norm.text_color,
              background: norm.bg_color,
              opacity: norm.bg_opacity,
              borderColor: norm.border_color,
              borderWidth: `${norm.border_width}px`,
              borderStyle: 'solid',
              borderRadius: `${norm.border_radius}px`,
              boxShadow: norm.box_shadow
                ? norm.preset_style === 'comic_pop'
                  ? '5px 5px 0px #000000'
                  : norm.preset_style === 'neon_glow'
                    ? '0 0 20px rgba(6,182,212,0.6)'
                    : '0 8px 24px rgba(0,0,0,0.5)'
                : 'none',
              textAlign: norm.text_align,
            }}
          >
            {activeLyric}
          </div>
        </section>
      </div>
    </div>
  )
}
