import { useEffect, useMemo, useRef, useState, useSyncExternalStore, type CSSProperties } from 'react'
import type { LogoTransform, MediaItem, PoemOverlayStyle, Scene, TimelineClip, TimelinePlan } from '../types'
import {
  computeLogoBox,
  DEFAULT_LOGO_TRANSFORM,
  DEFAULT_POEM_OVERLAY_STYLE,
  fmt,
  fmtFrames,
  normalizeLogoTransform,
  normalizePoemOverlayStyle,
} from '../types'
import { NeonIcon } from './NeonIcons'
import { PoemStyleStudio } from './PoemStyleStudio'
import { DgsPlaybackEngine } from '../playbackEngine'
import { playheadBus } from '../playheadBus'
import { voiceEngineSegments, voiceFileTimeAt } from '../voPieces'

function LiveTimecode({ fps, total }: { fps: number; total: number }) {
  const t = useSyncExternalStore(playheadBus.subscribe, playheadBus.get, playheadBus.get)
  return (
    <span className="timecode">
      {fmtFrames(t, fps)} / {fmtFrames(total, fps)}
    </span>
  )
}

function LiveScrub({ total, onPlayhead }: { total: number; onPlayhead: (t: number) => void }) {
  const t = useSyncExternalStore(playheadBus.subscribe, playheadBus.get, playheadBus.get)
  return (
    <input
      type="range"
      min={0}
      max={total || 1}
      step={0.01}
      value={Math.min(t, total || 1)}
      onChange={(e) => onPlayhead(Number(e.target.value))}
    />
  )
}

type Props = {
  api: string
  projectId: string | null
  plan: TimelinePlan | null
  media?: MediaItem[]
  scenes?: Scene[]
  selectedMediaId?: string | null
  playhead: number
  playing: boolean
  onPlayhead: (t: number | ((prev: number) => number)) => void
  onPlaying: (v: boolean) => void
  onChangePlan?: (plan: TimelinePlan) => void
  fps?: number
  localMediaUrls?: Record<string, string>
  localThumbUrls?: Record<string, string>
  localNarrUrl?: string | null
  localPoemUrl?: string | null
  localLogoUrl?: string | null
  logoEnabled?: boolean
  logoTransform?: LogoTransform
  onToggleLogo?: (enabled: boolean) => void
  onChangeLogoTransform?: (transform: LogoTransform) => void
  poemOverlay?: PoemOverlayStyle
  onChangePoemOverlay?: (overlay: PoemOverlayStyle) => void
  showPoemStudio?: boolean
  onTogglePoemStudio?: (show: boolean) => void
  hasPoem?: boolean
}

function syncAudio(
  el: HTMLAudioElement | null,
  shouldPlay: boolean,
  targetTime: number,
  playing: boolean,
) {
  if (!el) return
  if (!shouldPlay || targetTime < 0) {
    el.pause()
    return
  }
  if (Math.abs(el.currentTime - targetTime) > 0.3) {
    try {
      el.currentTime = targetTime
    } catch {
      /* ignore */
    }
  }
  if (playing) {
    if (el.paused) void el.play().catch(() => undefined)
  } else if (!el.paused) {
    el.pause()
  }
}

export function PreviewPane({
  api,
  projectId,
  plan,
  media = [],
  scenes = [],
  selectedMediaId = null,
  playhead,
  playing,
  onPlayhead,
  onPlaying,
  onChangePlan,
  fps = 30,
  localMediaUrls = {},
  localThumbUrls = {},
  localNarrUrl = null,
  localPoemUrl = null,
  localLogoUrl = null,
  logoEnabled,
  logoTransform,
  onToggleLogo,
  onChangeLogoTransform,
  poemOverlay,
  onChangePoemOverlay,
  showPoemStudio,
  onTogglePoemStudio,
  hasPoem,
}: Props) {
  const paneRef = useRef<HTMLElement | null>(null)
  const stageRef = useRef<HTMLDivElement | null>(null)
  const frameRef = useRef<HTMLDivElement | null>(null)
  const [frameStyle, setFrameStyle] = useState<CSSProperties>({})
  const [draggingLogo, setDraggingLogo] = useState(false)
  const [internalShowPoemStudio, setInternalShowPoemStudio] = useState(false)
  const [draggingPoemBox, setDraggingPoemBox] = useState(false)
  const [resizingPoemHandle, setResizingPoemHandle] = useState<string | null>(null)
  const [previewTab, setPreviewTab] = useState<'timeline' | 'source'>('timeline')
  const vidA = useRef<HTMLVideoElement | null>(null)
  const vidB = useRef<HTMLVideoElement | null>(null)
  const shownVideo = useRef<'a' | 'b'>('a')
  const [visible, setVisible] = useState<'a' | 'b' | 'image'>('image')
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [prevImageUrl, setPrevImageUrl] = useState<string | null>(null)
  const decodedImagesRef = useRef<Set<string>>(new Set())
  const narrRef = useRef<HTMLAudioElement | null>(null)
  const poemRef = useRef<HTMLAudioElement | null>(null)
  const engineRef = useRef<DgsPlaybackEngine | null>(null)
  if (!engineRef.current) engineRef.current = new DgsPlaybackEngine()
  const nativeReadyRef = useRef(false)
  const nativeDriveRef = useRef(false)
  const nativePlayerRef = useRef(false)
  const playingRef = useRef(playing)
  playingRef.current = playing
  const [nativeDrive, setNativeDrive] = useState(false)
  const [nativePlayer, setNativePlayer] = useState(false)
  const [playerChecked, setPlayerChecked] = useState(false)
  const [nativeFrame, setNativeFrame] = useState(0)
  const playheadRef = useRef(playhead)
  const publishedPlayheadRef = useRef(playhead)
  const publishedScreenRef = useRef('')
  const activeRef = useRef<TimelineClip | null>(null)
  const localMediaRef = useRef(localMediaUrls)
  localMediaRef.current = localMediaUrls
  const narrClipRef = useRef<string | null>(null)
  const [muted, setMuted] = useState(false)
  const [volume, setVolume] = useState(1)
  const [showSubtitles, setShowSubtitles] = useState(true)
  const [enlarged, setEnlarged] = useState(false)
  const [showAlignDock, setShowAlignDock] = useState(true)
  const [canvasFillMode, setCanvasFillMode] = useState<'fit' | 'fill'>('fit')
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [audioNote, setAudioNote] = useState('')

  useEffect(() => {
    const el = stageRef.current
    if (!el) return
    const updateSize = () => {
      const rect = el.getBoundingClientRect()
      const pad = enlarged ? 4 : 6
      const availW = Math.max(0, rect.width - pad * 2)
      const availH = Math.max(0, rect.height - pad * 2)
      if (availW > 40 && availH > 40) {
        if (canvasFillMode === 'fill') {
          setFrameStyle({
            width: `${Math.round(availW)}px`,
            height: `${Math.round(availH)}px`,
            ['--frame-w' as string]: `${Math.round(availW)}px`,
          })
        } else {
          const w = Math.min(availW, availH * (16 / 9))
          const h = w * (9 / 16)
          setFrameStyle({
            width: `${Math.round(w)}px`,
            height: `${Math.round(h)}px`,
            ['--frame-w' as string]: `${Math.round(w)}px`,
          })
        }
      } else {
        setFrameStyle({})
      }
    }
    updateSize()
    const raf = window.requestAnimationFrame(updateSize)
    const t1 = window.setTimeout(updateSize, 65)
    const ro = new ResizeObserver(updateSize)
    ro.observe(el)
    window.addEventListener('resize', updateSize)
    return () => {
      window.cancelAnimationFrame(raf)
      window.clearTimeout(t1)
      ro.disconnect()
      window.removeEventListener('resize', updateSize)
    }
  }, [enlarged, showAlignDock, canvasFillMode, isFullscreen])

  useEffect(() => {
    const onFsChange = () => {
      const fsActive = Boolean(document.fullscreenElement)
      setIsFullscreen(fsActive)
      if (fsActive && !enlarged) setEnlarged(true)
    }
    document.addEventListener('fullscreenchange', onFsChange)
    return () => document.removeEventListener('fullscreenchange', onFsChange)
  }, [enlarged])

  useEffect(() => {
    if (!enlarged) return
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (document.fullscreenElement) {
          void document.exitFullscreen().catch(() => undefined)
        }
        setEnlarged(false)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [enlarged])

  const srtCues = useMemo(() => {
    if (plan?.srt_cues?.length) {
      return plan.srt_cues.map((c) => ({ start: c.start, end: c.end, text: c.text }))
    }
    return [] as { start: number; end: number; text: string }[]
  }, [plan])

  const selectedMedia = useMemo(() => {
    if (!media.length) return null
    if (selectedMediaId) {
      const found = media.find((m) => m.id === selectedMediaId)
      if (found) return found
    }
    return media[0]
  }, [media, selectedMediaId])

  useEffect(() => {
    if (plan?.clips?.length) {
      setPreviewTab('timeline')
    }
  }, [plan?.clips?.length])

  const active = useMemo<TimelineClip | null>(() => {
    if (previewTab === 'source' && selectedMedia) {
      return {
        screen: selectedMedia.screen || 'source',
        media_id: selectedMedia.id,
        media_path: selectedMedia.path || '',
        kind: selectedMedia.kind,
        start: 0,
        end: selectedMedia.duration || 5,
        duration: selectedMedia.duration || 5,
        source_in: 0,
        source_out: selectedMedia.duration || 5,
        script_text: selectedMedia.filename,
        vo_text: '',
        fit: selectedMedia.kind === 'video' ? 'trim' : 'hold',
      }
    }
    if (plan?.clips?.length) {
      return (
        plan.clips.find((c) => playhead >= c.start && playhead < c.end) ||
        plan.clips.find((c) => Math.abs(playhead - c.start) < 0.06 || Math.abs(playhead - c.end) < 0.06) ||
        (playhead <= plan.clips[0].start ? plan.clips[0] : plan.clips[plan.clips.length - 1]) ||
        null
      )
    }
    if (selectedMedia) {
      return {
        screen: selectedMedia.screen || 'screen_1',
        media_id: selectedMedia.id,
        media_path: selectedMedia.path || '',
        kind: selectedMedia.kind,
        start: 0,
        end: selectedMedia.duration || 5,
        duration: selectedMedia.duration || 5,
        source_in: 0,
        source_out: selectedMedia.duration || 5,
        script_text: `${selectedMedia.filename} (Provisional preview — click Auto-align for full timeline)`,
        vo_text: '',
        fit: selectedMedia.kind === 'video' ? 'trim' : 'hold',
      }
    }
    return null
  }, [plan, playhead, previewTab, selectedMedia])
  activeRef.current = active

  const activeCaption = useMemo(() => {
    if (!showSubtitles) return ''
    if (srtCues.length) {
      const hits = srtCues.filter((c) => playhead >= c.start && playhead <= c.end)
      if (hits.length) return hits[hits.length - 1].text
      return ''
    }
    if (active && (active.vo_text || active.caption_text)) {
      return active.vo_text || active.caption_text || ''
    }
    return ''
  }, [showSubtitles, srtCues, playhead, active])

  const mediaById = useMemo(() => {
    const map = new Map<string, MediaItem>()
    for (const item of media) if (item.id) map.set(item.id, item)
    return map
  }, [media])

  // Video plays from the file on disk (byte ranges), the same way a desktop
  // editor does. A blob URL rebuffers on every seek.
  function seekableMediaUrl(mediaId: string | null | undefined, kind: string | null | undefined) {
    if (!mediaId) return null
    const onDisk = Boolean(projectId && mediaById.get(mediaId)?.path)
    const fileUrl = onDisk ? `${api}/api/projects/${projectId}/media-file/${mediaId}` : null
    // The linked file is in memory. Prefer it over a recorded disk path that is
    // often missing — a missing path left the 160px thumbnail stretched on screen.
    if (localMediaUrls[mediaId]) return localMediaUrls[mediaId]
    if (kind === 'video') return fileUrl || null
    return fileUrl
  }

  const mediaUrl = seekableMediaUrl(active?.media_id, active?.kind)

  const thumbUrl =
    (active?.media_id && (localThumbUrls[active.media_id] || (active.kind === 'image' ? localMediaUrls[active.media_id] : null))) ||
    (projectId && active?.media_id
      ? `${api}/api/projects/${projectId}/media-thumb/${active.media_id}`
      : null)

  // Full-resolution still for this screen. Video clips were painting a 160×90
  // JPEG across the preview until the video decoded, which is the blur.
  const stillUrl = useMemo(() => {
    if (!active || active.kind !== 'video') return null
    const num = String(active.screen || '').match(/(\d+)/)
    if (!num) return null
    const want = String(parseInt(num[1], 10))
    const still = media.find((item) => {
      if (item.kind !== 'image') return false
      const n = String(item.screen || '').match(/(\d+)/)
      return Boolean(n && String(parseInt(n[1], 10)) === want)
    })
    if (!still?.id) return null
    return (
      localMediaUrls[still.id] ||
      (projectId ? `${api}/api/projects/${projectId}/media-file/${still.id}` : null)
    )
  }, [active, media, localMediaUrls, projectId, api])

  const hasServerNarr =
    Boolean(plan?.voiceover_path) ||
    (Array.isArray(plan?.voiceover_slots) && plan.voiceover_slots.length > 0)
  const narrUrl =
    localNarrUrl ||
    (projectId && hasServerNarr
      ? `${api}/api/projects/${projectId}/audio/narration?d=${Math.round((plan?.total_duration || 0) * 100)}`
      : null)
  const poemUrl =
    localPoemUrl ||
    (projectId && (plan?.poem_voiceover_path || plan?.has_poem)
      ? `${api}/api/projects/${projectId}/audio/poem`
      : null)
  const isLogoEnabled = logoEnabled !== undefined ? logoEnabled : Boolean(plan?.logo_enabled)
  const effectiveLogoTransform = useMemo(
    () => normalizeLogoTransform(logoTransform || plan?.logo_transform || DEFAULT_LOGO_TRANSFORM),
    [logoTransform, plan?.logo_transform],
  )
  const logoBox = useMemo(
    () => computeLogoBox(effectiveLogoTransform, 1920, 1080),
    [effectiveLogoTransform],
  )
  const logoUrl = isLogoEnabled
    ? localLogoUrl ||
      (projectId && plan?.logo_path && plan.logo_path !== '/eclass-logo.png'
        ? `${api}/api/projects/${projectId}/logo-file`
        : '/eclass-logo.png')
    : null

  function emitLogoTransform(next: LogoTransform) {
    if (onChangeLogoTransform) onChangeLogoTransform(next)
    else if (plan && onChangePlan) {
      onChangePlan({
        ...plan,
        logo_transform: next,
        manual_override: true,
      })
    }
  }

  function handleToggleLogoClick() {
    const next = !isLogoEnabled
    if (onToggleLogo) onToggleLogo(next)
    else if (plan && onChangePlan) {
      onChangePlan({
        ...plan,
        logo_enabled: next,
      })
    }
  }

  function beginLogoDrag(e: React.MouseEvent<HTMLDivElement>) {
    if (plan?.logo_track_locked) return
    e.preventDefault()
    e.stopPropagation()
    const frameEl = frameRef.current
    if (!frameEl) return
    const rect = frameEl.getBoundingClientRect()
    if (rect.width < 20 || rect.height < 20) return
    const startX = e.clientX
    const startY = e.clientY
    const startT = { ...effectiveLogoTransform }
    setDraggingLogo(true)
    const onMove = (ev: MouseEvent) => {
      const dxPx = ev.clientX - startX
      const dyPx = ev.clientY - startY
      const deltaPosX = (dxPx / rect.width) * 1920
      const deltaPosY = -(dyPx / rect.height) * 1080
      const nextPosX = Math.round((startT.pos_x + deltaPosX) * 100) / 100
      const nextPosY = Math.round((startT.pos_y + deltaPosY) * 100) / 100
      emitLogoTransform({
        ...startT,
        pos_x: nextPosX,
        pos_y: nextPosY,
      })
    }
    const onUp = () => {
      setDraggingLogo(false)
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }
    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
  }

  const poemStart = plan?.poem_start_time || 0
  const poemEnd =
    plan?.poem_end_time && plan.poem_end_time > poemStart
      ? plan.poem_end_time
      : poemStart + 47.6

  const inPoem = Boolean(
    (plan?.has_poem && (plan?.poem_voiceover_path || poemUrl) && playhead >= poemStart && playhead < poemEnd) ||
      (active?.screen && scenes.find((s) => s.screen === active.screen)?.is_poem),
  )

  const isPoemStudioOpen = showPoemStudio !== undefined ? showPoemStudio : internalShowPoemStudio

  function togglePoemStudio(nextVal?: boolean) {
    const next = nextVal !== undefined ? nextVal : !isPoemStudioOpen
    if (onTogglePoemStudio) onTogglePoemStudio(next)
    else setInternalShowPoemStudio(next)
  }

  const effectivePoemOverlay = useMemo(
    () => normalizePoemOverlayStyle(poemOverlay || plan?.poem_overlay || DEFAULT_POEM_OVERLAY_STYLE),
    [poemOverlay, plan?.poem_overlay],
  )

  function emitPoemOverlay(next: PoemOverlayStyle) {
    const norm = normalizePoemOverlayStyle(next)
    if (onChangePoemOverlay) onChangePoemOverlay(norm)
    else if (plan && onChangePlan) {
      onChangePlan({
        ...plan,
        poem_overlay: norm,
        manual_override: true,
      })
    }
  }

  const isProjectPoemDetected = useMemo(() => {
    if (hasPoem) return true
    if (plan?.has_poem) return true
    if (plan?.poem_voiceover_path || localPoemUrl) return true
    return scenes.some(
      (s) =>
        s.is_poem ||
        /\bpoem\b/i.test(s.section || '') ||
        /\bpoem\s+visual\b/i.test(s.visual_direction || s.visual_type || '') ||
        /\b(stanza|couplet|lines?\s*\d+[-–—]\d+)\b/i.test(s.section || ''),
    )
  }, [hasPoem, plan?.has_poem, plan?.poem_voiceover_path, localPoemUrl, scenes])

  function beginPoemBoxDrag(e: React.MouseEvent<HTMLDivElement>) {
    if (effectivePoemOverlay.locked) return
    e.preventDefault()
    e.stopPropagation()
    const frameEl = frameRef.current
    if (!frameEl) return
    const rect = frameEl.getBoundingClientRect()
    if (rect.width < 20 || rect.height < 20) return

    const startClientX = e.clientX
    const startClientY = e.clientY
    const startX = effectivePoemOverlay.x_pct
    const startY = effectivePoemOverlay.y_pct
    const w = effectivePoemOverlay.w_pct
    const h = effectivePoemOverlay.h_pct

    setDraggingPoemBox(true)

    const onMove = (ev: MouseEvent) => {
      const dxPct = ((ev.clientX - startClientX) / rect.width) * 100
      const dyPct = ((ev.clientY - startClientY) / rect.height) * 100
      const nextX = Math.round(Math.max(0, Math.min(100 - w, startX + dxPct)) * 10) / 10
      const nextY = Math.round(Math.max(0, Math.min(100 - h, startY + dyPct)) * 10) / 10
      emitPoemOverlay({
        ...effectivePoemOverlay,
        x_pct: nextX,
        y_pct: nextY,
      })
    }

    const onUp = () => {
      setDraggingPoemBox(false)
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }

    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
  }

  function beginPoemResize(handle: string, e: React.MouseEvent<HTMLDivElement>) {
    if (effectivePoemOverlay.locked) return
    e.preventDefault()
    e.stopPropagation()
    const frameEl = frameRef.current
    if (!frameEl) return
    const rect = frameEl.getBoundingClientRect()
    if (rect.width < 20 || rect.height < 20) return

    const startClientX = e.clientX
    const startClientY = e.clientY
    const startX = effectivePoemOverlay.x_pct
    const startY = effectivePoemOverlay.y_pct
    const startW = effectivePoemOverlay.w_pct
    const startH = effectivePoemOverlay.h_pct

    setResizingPoemHandle(handle)

    const onMove = (ev: MouseEvent) => {
      const dxPct = ((ev.clientX - startClientX) / rect.width) * 100
      const dyPct = ((ev.clientY - startClientY) / rect.height) * 100

      let nextX = startX
      let nextY = startY
      let nextW = startW
      let nextH = startH

      if (handle.includes('e')) {
        nextW = Math.max(12, Math.min(100 - startX, startW + dxPct))
      }
      if (handle.includes('s')) {
        nextH = Math.max(6, Math.min(100 - startY, startH + dyPct))
      }
      if (handle.includes('w')) {
        const maxW = startX + startW
        nextW = Math.max(12, Math.min(maxW, startW - dxPct))
        nextX = maxW - nextW
      }
      if (handle.includes('n')) {
        const maxH = startY + startH
        nextH = Math.max(6, Math.min(maxH, startH - dyPct))
        nextY = maxH - nextH
      }

      emitPoemOverlay({
        ...effectivePoemOverlay,
        x_pct: Math.round(nextX * 10) / 10,
        y_pct: Math.round(nextY * 10) / 10,
        w_pct: Math.round(nextW * 10) / 10,
        h_pct: Math.round(nextH * 10) / 10,
      })
    }

    const onUp = () => {
      setResizingPoemHandle(null)
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }

    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
  }

  const fallbackPoemLyric = useMemo(() => {
    const poemScene = scenes.find((s) => s.is_poem || /\bpoem\b/i.test(s.section || ''))
    if (poemScene && (poemScene.voiceover_text || poemScene.text || poemScene.visual_direction)) {
      return poemScene.voiceover_text || poemScene.text || poemScene.visual_direction || ''
    }
    return 'Solar lights shine, our village stays bright,\nClean green energy, working day and night! ☀️'
  }, [scenes])

  const poemLyricToDisplay = useMemo(() => {
    if (inPoem && activeCaption) return activeCaption
    if (inPoem && active && (active.vo_text || active.caption_text)) {
      return active.vo_text || active.caption_text || ''
    }
    if (isPoemStudioOpen) {
      if (activeCaption) return activeCaption
      if (active && (active.vo_text || active.caption_text)) {
        return active.vo_text || active.caption_text || ''
      }
      return fallbackPoemLyric
    }
    return inPoem ? (activeCaption || '') : ''
  }, [inPoem, activeCaption, active, isPoemStudioOpen, fallbackPoemLyric])

  const isPoemOverlayVisible = Boolean(
    effectivePoemOverlay.enabled &&
    (inPoem || isPoemStudioOpen) &&
    (poemLyricToDisplay || !effectivePoemOverlay.locked),
  )

  // Scrubbing moves the clock. While playing, the clock only moves forward.
  // Copying the media element's position back into the playhead is what made
  // the picture skip backward.
  useEffect(() => {
    if (nativeDriveRef.current) {
      const userScrub = Math.abs(playhead - publishedPlayheadRef.current) > 0.45
      if (!playing || userScrub) {
        playheadRef.current = playhead
        publishedPlayheadRef.current = playhead
        void fetch(`${api}/api/engine/transport`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(nativeBody(playing ? 'seek' : 'hold', playhead)),
        }).then(() => setNativeFrame((n) => n + 1)).catch(() => undefined)
      }
      return
    }
    if (!playing) {
      playheadRef.current = playhead
      publishedPlayheadRef.current = playhead
      narrClipRef.current = null
      engineRef.current?.hold(playhead)
      return
    }
    const userScrub =
      Math.abs(playhead - publishedPlayheadRef.current) > 0.45 &&
      Math.abs(playhead - playheadRef.current) > 0.45
    if (userScrub) {
      playheadRef.current = playhead
      publishedPlayheadRef.current = playhead
      narrClipRef.current = null
      engineRef.current?.seek(playhead)
    }
  }, [playhead, playing, api])

  useEffect(() => {
    let cancel = false
    void fetch(`${api}/api/engine/status`)
      .then((r) => (r.ok ? r.json() : null))
      .then((st) => {
        if (cancel || !st) return
        const on = Boolean(st.play)
        nativePlayerRef.current = on
        setNativePlayer(on)
        setPlayerChecked(true)
        if (on) setAudioNote('PC player ready')
      })
      .catch(() => {
        if (!cancel) setPlayerChecked(true)
      })
    return () => {
      cancel = true
    }
  }, [api])

  useEffect(() => {
    if (!nativePlayer) return
    let queued = 0
    let lastSent = 0
    return playheadBus.subscribe(() => {
      if (playheadBus.fromClock() || !nativePlayerRef.current) return
      const t = playheadBus.get()
      if (queued) cancelAnimationFrame(queued)
      queued = requestAnimationFrame(() => {
        queued = 0
        const now = performance.now()
        if (now - lastSent < 180) return
        lastSent = now
        const action = playingRef.current ? 'play' : 'hold'
        void fetch(`${api}/api/engine/transport`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(nativeBody(action, t)),
        })
          .then(() => {
            if (!playingRef.current) setNativeFrame((n) => n + 1)
          })
          .catch(() => undefined)
      })
    })
    // nativeBody closes over the latest plan; the subscription is refreshed when the plan changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [nativePlayer, api, plan, volume, muted, poemStart, poemEnd])

  useEffect(() => {
    const engine = engineRef.current
    if (!engine || !playerChecked || nativePlayer) return
    let cancel = false
    if (narrUrl || poemUrl) setAudioNote('Preparing sound engine…')
    void (async () => {
      nativeReadyRef.current = false
      // Load independently — a missing poem file must not block narration.
      const results = await Promise.allSettled([
        engine.loadNarration(narrUrl),
        engine.loadPoem(poemUrl),
      ])
      if (cancel) return
      const narrOk = results[0].status === 'fulfilled' && engine.narrReady
      const poemOk = results[1].status === 'fulfilled' && engine.poemReady
      if (narrOk || poemOk) setAudioNote('Sound engine ready')
      else if (narrUrl || poemUrl) setAudioNote('Browser audio')
    })()
    return () => {
      cancel = true
    }
  }, [narrUrl, poemUrl, api, nativePlayer, playerChecked])

  useEffect(() => {
    if (!playing || !plan || !nativeDriveRef.current) return
    let stop = false
    let timer = 0
    const poll = async () => {
      if (stop) return
      try {
        const c = await fetch(`${api}/api/engine/clock`).then((r) => r.json())
        if (stop) return
        if (!c.running) {
          const at = Number(c.t)
          if (Number.isFinite(at)) {
            playheadRef.current = at
            publishedPlayheadRef.current = at
            onPlayhead(at)
          }
          onPlaying(false)
          return
        }
        const t = Number(c.t)
        if (Number.isFinite(t)) {
          playheadRef.current = t
          playheadBus.set(t, 'clock')
          const screen = plan.clips.find((c) => t >= c.start && t < c.end)?.screen || ''
          if (screen !== publishedScreenRef.current) {
            publishedScreenRef.current = screen
            publishedPlayheadRef.current = t
            onPlayhead(t)
          }
        }
        if (c.video) setNativeFrame((n) => n + 1)
      } catch {
        /* keep the last clock */
      }
      if (!stop) timer = window.setTimeout(poll, 80)
    }
    void poll()
    return () => {
      stop = true
      window.clearTimeout(timer)
    }
  }, [playing, plan, api, onPlayhead, onPlaying])

  useEffect(() => {
    if (!playing || !plan || nativeDriveRef.current) return
    let raf = 0
    let last = performance.now()

    const clipAt = (t: number) =>
      plan.clips.find((c) => t >= c.start && t < c.end) || null

    const narrSegments =
      plan.narration_segments && plan.narration_segments.length > 0
        ? plan.narration_segments
        : plan.clips

    const narrSegAt = (t: number) =>
      narrSegments.find((s) => t >= s.start && t < s.end) || null

    const hasAlignedNarration = narrSegments.some(
      (c) => c.narration_in != null && c.narration_out != null && c.narration_out > c.narration_in + 0.05,
    )

    const slaveTo = (el: HTMLMediaElement, want: number) => {
      if (el.seeking) return
      const ahead = el.currentTime - want
      if (ahead > 0.12) {
        if (!el.paused) el.pause()
        return
      }
      if (want - el.currentTime > 0.4) {
        try {
          el.currentTime = want
        } catch {
          /* ignore */
        }
      }
      if (el.paused) void el.play().catch(() => undefined)
    }

    const followAudio = (t: number) => {
      const narr = narrRef.current
      const poem = poemRef.current
      const poemNow = Boolean(
        plan.has_poem && (plan.poem_voiceover_path || poemUrl) && t >= poemStart && t < poemEnd,
      )
      if (poem && poemUrl) {
        poem.muted = muted || Boolean(plan.poem_muted)
        poem.volume = volume
        if (poemNow && !muted && !plan.poem_muted) slaveTo(poem, Math.max(0, t - poemStart))
        else if (!poem.paused) poem.pause()
      }
      if (!narr || !narrUrl) return
      narr.muted = muted || poemNow || Boolean(plan.vo_muted)
      narr.volume = poemNow ? 0 : volume
      if (poemNow || muted || plan.vo_muted) {
        if (!narr.paused) narr.pause()
        return
      }
      // Empty vo_pieces must not mute the whole chapter (treat as “not edited”).
      if (Array.isArray(plan.vo_pieces) && plan.vo_pieces.length > 0) {
        const gap = (plan.voiceover_slots || []).length >= 2 ? 0.5 : 0
        const fileT = voiceFileTimeAt(plan, t, gap)
        if (fileT == null) {
          if (!narr.paused) narr.pause()
          return
        }
        slaveTo(narr, fileT)
        return
      }
      if (!hasAlignedNarration) {
        slaveTo(narr, t)
        return
      }
      const clip = narrSegAt(t)
      const spoken =
        clip && clip.narration_in != null && clip.narration_out != null
          ? clip.narration_out - clip.narration_in
          : 0
      if (!clip || spoken < 0.05) {
        if (!narr.paused) narr.pause()
        return
      }
      const local = Math.max(0, t - clip.start)
      if (local > spoken + 0.08) {
        if (!narr.paused) narr.pause()
        return
      }
      slaveTo(narr, Number(clip.narration_in) + Math.min(local, spoken))
    }

    const engine = engineRef.current
    const voiceEdited = Array.isArray(plan.vo_pieces) && plan.vo_pieces.length > 0
    const voiceGap = (plan.voiceover_slots || []).length >= 2 ? 0.5 : 0
    engine?.setMap({
      duration: plan.total_duration,
      poemStart,
      poemEnd,
      hasPoem: Boolean(plan.has_poem && poemEnd > poemStart + 0.2),
      voiceEdited,
      segments: voiceEdited ? voiceEngineSegments(plan, voiceGap) : narrSegments,
    })
    engine?.setMix({
      volume,
      muted,
      voMuted: Boolean(plan.vo_muted),
      poemMuted: Boolean(plan.poem_muted),
    })

    const tick = (now: number) => {
      const dt = Math.min(0.05, Math.max(0, (now - last) / 1000))
      last = now
      const prev = playheadRef.current
      const t = engine?.isRunning() ? engine.position() : prev + dt
      if (t >= plan.total_duration) {
        playheadRef.current = plan.total_duration
        publishedPlayheadRef.current = plan.total_duration
        engine?.pause()
        onPlayhead(plan.total_duration)
        onPlaying(false)
        return
      }
      const prevClip = clipAt(prev)
      playheadRef.current = t
      playheadBus.set(t)
      if (engine?.isRunning()) engine.sync()
      else followAudio(t)
      const nextClip = clipAt(t)
      const sceneChanged = nextClip?.screen !== prevClip?.screen || nextClip?.start !== prevClip?.start
      if (sceneChanged) {
        publishedPlayheadRef.current = t
        onPlayhead(t)
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [playing, plan, onPlayhead, onPlaying, narrUrl, poemUrl, poemStart, poemEnd, muted, volume])

  useEffect(() => {
    if (plan && playhead >= plan.total_duration - 0.05) onPlaying(false)
  }, [playhead, plan, onPlaying])

  function clipLocal(clip: TimelineClip) {
    const srcIn = Number(clip.source_in || 0)
    const clipDur = Math.max(0.05, Number(clip.end) - Number(clip.start))
    const local = Math.max(0, playheadRef.current - Number(clip.start))
    const srcOutRaw = clip.source_out != null ? Number(clip.source_out) : NaN
    const srcSpan =
      Number.isFinite(srcOutRaw) && srcOutRaw > srcIn + 0.05 ? srcOutRaw - srcIn : clipDur
    // stretch / passthrough: map the full source take into the VO window
    if (clip.fit === 'stretch' || clip.fit === 'passthrough') {
      const u = Math.min(1, local / clipDur)
      return srcIn + u * srcSpan
    }
    // trim: 1:1 from source_in for the spoken/VO window
    return srcIn + Math.min(local, srcSpan)
  }

  const upcomingVideo = useMemo(() => {
    if (!plan?.clips?.length || !active) return null
    const idx = plan.clips.findIndex((c) => c.start === active.start && c.screen === active.screen)
    if (idx < 0) return null
    const nextVid = plan.clips.slice(idx + 1, idx + 6).find((c) => c.kind === 'video' && c.media_id)
    if (!nextVid?.media_id) return null
    const url = seekableMediaUrl(nextVid.media_id, 'video')
    if (!url) return null
    return { url, at: Math.max(0, Number(nextVid.source_in || 0)) }
  }, [plan, active, projectId, api, localMediaUrls, mediaById])

  function bufferFor(which: 'a' | 'b') {
    return which === 'a' ? vidA.current : vidB.current
  }

  function assignSrc(el: HTMLVideoElement, url: string) {
    if (el.getAttribute('data-src') === url) return
    el.setAttribute('data-src', url)
    el.src = url
  }

  function onVideoError(el: HTMLVideoElement) {
    const id = activeRef.current?.media_id
    const blob = id ? localMediaRef.current[id] : ''
    if (blob && el.getAttribute('data-src') !== blob) assignSrc(el, blob)
  }

  function warmVideo(el: HTMLVideoElement, url: string, atSec: number) {
    assignSrc(el, url)
    const park = () => {
      if (el.getAttribute('data-src') !== url) return
      try {
        const t = Math.max(0, atSec)
        if (Math.abs(el.currentTime - t) > 0.12) el.currentTime = t
      } catch {
        /* ignore */
      }
    }
    if (el.readyState >= 1) park()
    else el.addEventListener('loadedmetadata', park, { once: true })
  }

  // Preload & decode upcoming images/thumbnails (next 8 clips) into browser memory so image transitions never flash blank
  useEffect(() => {
    if (!plan?.clips?.length) return
    const idx = active
      ? plan.clips.findIndex((c) => c.start === active.start && c.screen === active.screen)
      : 0
    const startIdx = Math.max(0, idx)
    const slice = plan.clips.slice(startIdx, startIdx + 9)
    for (const cl of slice) {
      if (!cl.media_id) continue
      const urlsToWarm: string[] = []
      if (cl.kind !== 'video') {
        const u =
          localMediaUrls[cl.media_id] ||
          (projectId ? `${api}/api/projects/${projectId}/media-file/${cl.media_id}` : '')
        if (u) urlsToWarm.push(u)
      } else {
        const tu =
          localThumbUrls[cl.media_id] ||
          (projectId ? `${api}/api/projects/${projectId}/media-thumb/${cl.media_id}` : '')
        if (tu) urlsToWarm.push(tu)
      }
      for (const u of urlsToWarm) {
        if (decodedImagesRef.current.has(u)) continue
        const pre = new Image()
        pre.src = u
        if (typeof pre.decode === 'function') {
          pre.decode().then(() => decodedImagesRef.current.add(u)).catch(() => decodedImagesRef.current.add(u))
        } else {
          pre.onload = () => decodedImagesRef.current.add(u)
        }
      }
    }
  }, [plan, active, projectId, api, localMediaUrls, localThumbUrls])

  useEffect(() => {
    let cancelled = false
    const commitImageUrl = (targetUrl: string) => {
      if (!targetUrl) return
      if (targetUrl.startsWith('blob:') || decodedImagesRef.current.has(targetUrl)) {
        decodedImagesRef.current.add(targetUrl)
        setImageUrl((cur) => {
          if (cur && cur !== targetUrl) setPrevImageUrl(cur)
          return targetUrl
        })
        return
      }
      // Keep the previous imageUrl painted on screen until targetUrl finishes decoding — zero blank flash!
      const pre = new Image()
      pre.src = targetUrl
      const done = () => {
        decodedImagesRef.current.add(targetUrl)
        if (!cancelled) {
          setImageUrl((cur) => {
            if (cur && cur !== targetUrl) setPrevImageUrl(cur)
            return targetUrl
          })
        }
      }
      if (typeof pre.decode === 'function') {
        pre.decode().then(done).catch(done)
      } else {
        pre.onload = done
        pre.onerror = done
      }
    }

    if (!active || active.fit === 'missing' || !mediaUrl) {
      setImageUrl(null)
      setPrevImageUrl(null)
      setVisible('image')
      return
    }
    if (active.kind !== 'video') {
      setVisible('image')
      commitImageUrl(mediaUrl)
      if (upcomingVideo) {
        const idle: 'a' | 'b' = shownVideo.current === 'a' ? 'b' : 'a'
        const idleEl = bufferFor(idle)
        if (idleEl && idleEl.getAttribute('data-src') !== mediaUrl) {
          warmVideo(idleEl, upcomingVideo.url, upcomingVideo.at)
        }
      }
      return () => {
        cancelled = true
      }
    }
    // Full still first. The tiny video thumbnail is only a last resort.
    if (stillUrl) commitImageUrl(stillUrl)
    else if (thumbUrl) commitImageUrl(thumbUrl)
    const local = clipLocal(active)
    const currentId = shownVideo.current
    const current = bufferFor(currentId)
    const otherId: 'a' | 'b' = currentId === 'a' ? 'b' : 'a'
    const other = bufferFor(otherId)

    const preloadIdle = (activeWhich: 'a' | 'b') => {
      if (!upcomingVideo || upcomingVideo.url === mediaUrl) return
      const idleWhich: 'a' | 'b' = activeWhich === 'a' ? 'b' : 'a'
      const idleEl = bufferFor(idleWhich)
      if (idleEl) warmVideo(idleEl, upcomingVideo.url, upcomingVideo.at)
    }

    const reveal = (which: 'a' | 'b', el: HTMLVideoElement) => {
      if (cancelled || el.getAttribute('data-src') !== mediaUrl) return
      try {
        if (Number.isFinite(el.duration) && Math.abs(el.currentTime - local) > 0.2) {
          el.currentTime = Math.min(local, Math.max(0, el.duration - 0.05))
        }
      } catch {
        /* ignore */
      }
      shownVideo.current = which
      setVisible(which)
      const outgoing = which === 'a' ? vidB.current : vidA.current
      if (outgoing && outgoing !== el) outgoing.pause()
      if (playing) void el.play().catch(() => undefined)
      else el.pause()
      preloadIdle(which)
    }

    const ready = (el: HTMLVideoElement | null) =>
      Boolean(el && el.getAttribute('data-src') === mediaUrl && el.readyState >= 2)

    if (ready(current) && current) {
      reveal(currentId, current)
      return () => {
        cancelled = true
      }
    }
    if (ready(other) && other) {
      reveal(otherId, other)
      return () => {
        cancelled = true
      }
    }
    const el = (other && other.getAttribute('data-src') === mediaUrl ? other : null) || other || current
    if (!el) return
    const which = el === vidA.current ? 'a' : 'b'
    assignSrc(el, mediaUrl)
    if (el.readyState >= 2) {
      reveal(which, el)
      return () => {
        cancelled = true
      }
    }
    // Keep image/previous video layer visible until el decodes its first frame (loadeddata / canplay)
    const onReady = () => reveal(which, el)
    el.addEventListener('loadeddata', onReady, { once: true })
    el.addEventListener('canplay', onReady, { once: true })
    return () => {
      cancelled = true
      el.removeEventListener('loadeddata', onReady)
      el.removeEventListener('canplay', onReady)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active?.media_id, active?.kind, active?.start, active?.fit, mediaUrl, thumbUrl, stillUrl, upcomingVideo])

  useEffect(() => {
    if (playing || nativeDriveRef.current || !active || active.kind !== 'video' || visible === 'image') return
    const el = visible === 'a' ? vidA.current : vidB.current
    if (!el || el.getAttribute('data-src') !== mediaUrl) return
    el.pause()
    if (el.readyState >= 2) {
      const local = clipLocal(active)
      if (Math.abs(el.currentTime - local) > 0.12) {
        try {
          el.currentTime = Math.min(local, Math.max(0, (el.duration || local) - 0.05))
        } catch {
          /* ignore */
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, playhead, active?.media_id, active?.start, active?.end, active?.source_in, active?.source_out, visible, mediaUrl])

  useEffect(() => {
    if (!playing || nativeDriveRef.current) return
    let raf = 0
    let lastSeek = 0
    const follow = () => {
      const clip = activeRef.current
      const el = visible === 'a' ? vidA.current : visible === 'b' ? vidB.current : null
      if (clip && clip.kind === 'video' && el && el.getAttribute('data-src') === mediaUrl) {
        const srcIn = Number(clip.source_in || 0)
        const srcOut = clip.source_out != null ? Number(clip.source_out) : NaN
        const clipDur = Math.max(0.05, Number(clip.end) - Number(clip.start))
        const srcSpan = Number.isFinite(srcOut) && srcOut > srcIn + 0.05 ? srcOut - srcIn : clipDur
        const stretch = clip.fit === 'stretch' || clip.fit === 'passthrough'
        const wantRate = stretch ? Math.max(0.25, Math.min(4, srcSpan / clipDur)) : 1
        try {
          if (Math.abs(el.playbackRate - wantRate) > 0.02) el.playbackRate = wantRate
        } catch {
          /* ignore */
        }
        if (el.seeking || el.readyState < 2) {
          raf = requestAnimationFrame(follow)
          return
        }
        const local = clipLocal(clip)
        const ahead = el.currentTime - local
        if (ahead > 0.35 && performance.now() - lastSeek > 400) {
          try {
            el.currentTime = Math.min(local, Math.max(0, (el.duration || local) - 0.05))
          } catch {
            /* ignore */
          }
          lastSeek = performance.now()
        } else if (ahead > 0.08) {
          if (!el.paused) el.pause()
        } else {
          if (local - el.currentTime > 0.5 && performance.now() - lastSeek > 700) {
            try {
              el.currentTime = Math.min(local, Math.max(0, (el.duration || local) - 0.05))
            } catch {
              /* ignore */
            }
            lastSeek = performance.now()
          }
          if (el.paused) void el.play().catch(() => undefined)
        }
      }
      raf = requestAnimationFrame(follow)
    }
    raf = requestAnimationFrame(follow)
    return () => cancelAnimationFrame(raf)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing, visible, mediaUrl])

  // Narration muted during poem; poem VO only inside poem window
  useEffect(() => {
    const narr = narrRef.current
    const poem = poemRef.current
    if (narr) {
      narr.muted = muted || inPoem || Boolean(plan?.vo_muted)
      narr.volume = inPoem ? 0 : volume
    }
    if (poem) {
      poem.muted = muted || Boolean(plan?.poem_muted)
      poem.volume = volume
    }

    // While playing, the animation clock owns the audio so a short word is not cut.
    if (playing) return

    const narrSegments =
      plan?.narration_segments && plan.narration_segments.length > 0
        ? plan.narration_segments
        : plan?.clips || []
    const activeNarr =
      narrSegments.find((s) => playhead >= s.start && playhead < s.end) || active

    const spokenSpan =
      activeNarr && activeNarr.narration_in != null && activeNarr.narration_out != null
        ? Math.max(0, activeNarr.narration_out - activeNarr.narration_in)
        : 0
    const localOnClip = activeNarr ? Math.max(0, playhead - activeNarr.start) : 0
    const editedAt =
      plan && Array.isArray(plan.vo_pieces) && plan.vo_pieces.length > 0
        ? voiceFileTimeAt(plan, playhead, (plan.voiceover_slots || []).length >= 2 ? 0.5 : 0)
        : undefined
    const narrAt =
      editedAt !== undefined
        ? editedAt
        : activeNarr && activeNarr.narration_in != null && spokenSpan > 0 && localOnClip <= spokenSpan + 0.05
          ? activeNarr.narration_in + Math.min(localOnClip, spokenSpan)
          : null
    if (narr && narrUrl) {
      if (!narr.paused) narr.pause()
      if (narrAt != null) {
        try {
          narr.currentTime = Math.max(0, narrAt)
        } catch {
          /* ignore */
        }
      }
    }

    const poemLocal = playhead - poemStart
    const poemActive = Boolean(poemUrl) && inPoem && poemLocal >= 0
    syncAudio(poem, false, poemActive ? poemLocal : 0, false)

    if (!narrUrl && !poemUrl) {
      setAudioNote('No VO uploaded — import Narration / Poem audio for sound')
    } else if (playing && !muted) {
      setAudioNote(inPoem ? 'Poem / Suno' : narrUrl ? 'Narration' : 'Audio ready')
    } else if (muted) {
      setAudioNote('Muted')
    } else {
      setAudioNote('Audio ready — press Play')
    }
  }, [playhead, playing, muted, volume, narrUrl, poemUrl, poemStart, inPoem, active, plan])

  function nativeBody(action: string, t: number) {
    const segments =
      plan?.narration_segments && plan.narration_segments.length > 0
        ? plan.narration_segments
        : plan?.clips || []
    return {
      action,
      t,
      projectId,
      duration: plan?.total_duration || 0,
      poemStart,
      poemEnd,
      hasPoem: Boolean(plan?.has_poem && poemEnd > poemStart + 0.2),
      volume,
      muted,
      voMuted: Boolean(plan?.vo_muted),
      poemMuted: Boolean(plan?.poem_muted),
      segments: segments.map((s) => ({
        start: s.start,
        end: s.end,
        narration_in: s.narration_in ?? null,
        narration_out: s.narration_out ?? null,
      })),
      clips: (plan?.clips || []).map((c) => ({
        start: c.start,
        end: c.end,
        kind: c.kind,
        media_id: c.media_id,
        source_in: c.source_in || 0,
        source_out: c.source_out ?? null,
        fit: c.fit,
        screen: c.screen,
      })),
      voPieces: plan?.vo_pieces || null,
    }
  }

  // When user hits play, always unlock audio inside the user click gesture (browser autoplay policy)
  async function togglePlay() {
    const next = !playing
      if (next) {
      const at = playheadBus.get()
      if (plan && at >= plan.total_duration - 0.08) {
        playheadRef.current = 0
        playheadBus.set(0, 'user')
        onPlayhead(0)
      }
      if (nativePlayerRef.current) {
        nativeDriveRef.current = true
        setNativeDrive(true)
        engineRef.current?.pause()
        narrRef.current?.pause()
        poemRef.current?.pause()
        vidA.current?.pause()
        vidB.current?.pause()
        try {
          await fetch(`${api}/api/engine/transport`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(nativeBody('play', playheadRef.current)),
          })
          setAudioNote('PC player')
        } catch {
          nativeDriveRef.current = false
          setNativeDrive(false)
          setAudioNote('PC player did not start')
        }
      } else {
      nativeDriveRef.current = false
      setNativeDrive(false)
      try {
        const engine = engineRef.current
        if (engine) {
          const segments =
            plan?.narration_segments && plan.narration_segments.length > 0
              ? plan.narration_segments
              : plan?.clips || []
          const voiceEdited = Array.isArray(plan?.vo_pieces) && (plan?.vo_pieces.length || 0) > 0
          const voiceGap = (plan?.voiceover_slots || []).length >= 2 ? 0.5 : 0
          await engine.resume()
          // Reload in case VO arrived after the first decode attempt.
          if (narrUrl && !engine.narrReady) await engine.loadNarration(narrUrl)
          if (poemUrl && !engine.poemReady) await engine.loadPoem(poemUrl)
          engine.setMap({
            duration: plan?.total_duration || 0,
            poemStart,
            poemEnd,
            hasPoem: Boolean(plan?.has_poem && poemEnd > poemStart + 0.2),
            voiceEdited,
            segments: voiceEdited && plan ? voiceEngineSegments(plan, voiceGap) : segments,
          })
          engine.setMix({
            volume,
            muted,
            voMuted: Boolean(plan?.vo_muted),
            poemMuted: Boolean(plan?.poem_muted),
          })
          if (engine.narrReady || engine.poemReady) {
            engine.start(playheadRef.current)
            narrRef.current?.pause()
            poemRef.current?.pause()
            setAudioNote('Sound engine')
          } else {
            // Keep HTML <audio> path when WebAudio has nothing decoded yet.
            engine.pause()
            setAudioNote(narrUrl || poemUrl ? 'Browser audio' : 'No VO uploaded')
          }
        }
      } catch {
        setAudioNote('Press Play again to start the sound engine')
      }
      }
    } else {
      if (nativeDriveRef.current) {
        try {
          const r = await fetch(`${api}/api/engine/transport`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(nativeBody('pause', playheadRef.current)),
          })
          const data = r.ok ? await r.json() : null
          if (data && Number.isFinite(Number(data.t))) {
            playheadRef.current = Number(data.t)
            publishedPlayheadRef.current = Number(data.t)
            onPlayhead(Number(data.t))
          }
        } catch {
          /* clock already stopped */
        }
      } else {
        const at = engineRef.current?.pause()
        if (at != null) playheadRef.current = at
      }
      narrRef.current?.pause()
      poemRef.current?.pause()
      vidA.current?.pause()
      vidB.current?.pause()
    }
    onPlaying(next)
  }

  const mixKey = `${volume}|${muted}|${plan?.vo_muted}|${plan?.poem_muted}`
  const mixKeyRef = useRef(mixKey)
  useEffect(() => {
    if (mixKeyRef.current === mixKey) return
    mixKeyRef.current = mixKey
    if (!nativeDriveRef.current || !playing) return
    void fetch(`${api}/api/engine/transport`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(nativeBody('mix', playheadRef.current)),
    }).catch(() => undefined)
  }, [mixKey, playing, api])

  const activeClipIndex = useMemo(() => {
    if (!plan?.clips?.length || !active) return -1
    return plan.clips.findIndex((c) => c === active || (c.screen === active.screen && Math.abs(c.start - active.start) < 0.05))
  }, [plan, active])

  const activeSceneMeta = useMemo(() => {
    if (!active) return null
    return scenes.find((s) => s.screen === active.screen) || null
  }, [scenes, active])

  function jumpToAdjacentScene(dir: -1 | 1) {
    if (!plan?.clips?.length) return
    const curIdx = activeClipIndex >= 0 ? activeClipIndex : 0
    const nextIdx = Math.max(0, Math.min(plan.clips.length - 1, curIdx + dir))
    const target = plan.clips[nextIdx]
    if (target) onPlayhead(target.start)
  }

  function ensureNarrationSegments(p: TimelinePlan) {
    if (p.narration_segments && p.narration_segments.length > 0) {
      return p.narration_segments
    }
    return p.clips
      .filter((c) => c.narration_in != null || c.vo_text || c.script_text)
      .map((c) => ({
        screen: c.screen,
        start: c.start,
        end: c.end,
        narration_in: c.narration_in ?? null,
        narration_out: c.narration_out ?? null,
        vo_text: c.vo_text || '',
        script_text: c.script_text || '',
      }))
  }

  function deleteSceneAt(idx: number) {
    if (!plan || !onChangePlan || idx < 0 || idx >= plan.clips.length) return
    const narrSegs = ensureNarrationSegments(plan)
    const nextClips = plan.clips.filter((_, i) => i !== idx)
    onChangePlan({
      ...plan,
      clips: nextClips,
      narration_segments: narrSegs,
      manual_override: true,
    })
  }

  function deleteAndPullPrevToCover(idx: number) {
    if (!plan || !onChangePlan || idx < 0 || idx >= plan.clips.length) return
    const narrSegs = ensureNarrationSegments(plan)
    const target = plan.clips[idx]
    const remaining = plan.clips.filter((_, i) => i !== idx).map((c) => ({ ...c }))
    if (idx > 0 && remaining[idx - 1]) {
      const prev = remaining[idx - 1]
      prev.end = Math.max(prev.end, target.end)
      prev.duration = Math.max(0.2, Math.round((prev.end - prev.start) * 1000) / 1000)
    } else if (remaining[0]) {
      remaining[0].start = Math.min(remaining[0].start, target.start)
      remaining[0].duration = Math.max(
        0.2,
        Math.round((remaining[0].end - remaining[0].start) * 1000) / 1000,
      )
    }
    onChangePlan({
      ...plan,
      clips: remaining,
      narration_segments: narrSegs,
      manual_override: true,
    })
  }

  function pullSceneToCoverAdjacent(idx: number, dir: -1 | 1) {
    if (!plan || !onChangePlan || idx < 0 || idx >= plan.clips.length) return
    const narrSegs = ensureNarrationSegments(plan)
    const cur = plan.clips[idx]
    let newStart = cur.start
    let newEnd = cur.end
    if (dir === 1) {
      const nextClip = plan.clips[idx + 1]
      const nextNarr = narrSegs.find((s) => s.end > cur.end + 0.08)
      if (nextNarr) newEnd = nextNarr.end
      else if (nextClip) newEnd = nextClip.end
      else newEnd = cur.end + 2.0
    } else {
      const prevClip = idx > 0 ? plan.clips[idx - 1] : null
      const prevNarrs = narrSegs.filter((s) => s.start < cur.start - 0.08)
      const prevNarr = prevNarrs.length ? prevNarrs[prevNarrs.length - 1] : null
      if (prevNarr) newStart = prevNarr.start
      else if (prevClip) newStart = prevClip.start
      else newStart = Math.max(0, cur.start - 2.0)
    }

    const updated: TimelineClip[] = []
    for (let i = 0; i < plan.clips.length; i++) {
      if (i === idx) {
        updated.push({
          ...cur,
          start: newStart,
          end: newEnd,
          duration: Math.max(0.2, Math.round((newEnd - newStart) * 1000) / 1000),
        })
        continue
      }
      const c = plan.clips[i]
      if (c.end <= newStart + 0.01 || c.start >= newEnd - 0.01) {
        updated.push(c)
        continue
      }
      if (c.start >= newStart - 0.02 && c.end <= newEnd + 0.02) {
        continue
      }
      if (c.start < newEnd && c.end > newEnd + 0.2) {
        updated.push({
          ...c,
          start: newEnd,
          duration: Math.max(0.2, Math.round((c.end - newEnd) * 1000) / 1000),
        })
        continue
      }
      if (c.start < newStart - 0.2 && c.end > newStart) {
        updated.push({
          ...c,
          end: newStart,
          duration: Math.max(0.2, Math.round((newStart - c.start) * 1000) / 1000),
        })
      }
    }
    updated.sort((a, b) => a.start - b.start)
    onChangePlan({
      ...plan,
      clips: updated,
      narration_segments: narrSegs,
      manual_override: true,
      total_duration: Math.max(plan.total_duration, newEnd),
    })
  }

  function nudgeActiveSceneTiming(field: 'start' | 'end', delta: number) {
    if (!plan || !onChangePlan || activeClipIndex < 0) return
    const narrSegs = ensureNarrationSegments(plan)
    const clips = plan.clips.map((c) => ({ ...c }))
    const cur = clips[activeClipIndex]
    if (field === 'start') {
      const nextStart = Math.max(0, Math.min(cur.end - 0.3, Math.round((cur.start + delta) * 100) / 100))
      cur.start = nextStart
      cur.duration = Math.max(0.3, Math.round((cur.end - cur.start) * 100) / 100)
      if (activeClipIndex > 0) {
        const prev = clips[activeClipIndex - 1]
        if (prev.end > cur.start) {
          prev.end = cur.start
          prev.duration = Math.max(0.3, Math.round((prev.end - prev.start) * 100) / 100)
        }
      }
    } else {
      const nextEnd = Math.max(cur.start + 0.3, Math.round((cur.end + delta) * 100) / 100)
      cur.end = nextEnd
      cur.duration = Math.max(0.3, Math.round((cur.end - cur.start) * 100) / 100)
      if (activeClipIndex + 1 < clips.length) {
        const nxt = clips[activeClipIndex + 1]
        if (nxt.start < cur.end && nxt.end > cur.end + 0.3) {
          nxt.start = cur.end
          nxt.duration = Math.max(0.3, Math.round((nxt.end - nxt.start) * 100) / 100)
        }
      }
    }
    const total_duration = clips.reduce((m, c) => Math.max(m, c.end), plan.total_duration)
    onChangePlan({
      ...plan,
      clips,
      narration_segments: narrSegs,
      manual_override: true,
      total_duration,
    })
  }

  function snapActiveSceneToVo() {
    if (!plan || !onChangePlan || activeClipIndex < 0) return
    const cur = plan.clips[activeClipIndex]
    if (cur.narration_in == null || cur.narration_out == null) return
    const voLen = Math.max(0.4, cur.narration_out - cur.narration_in + 0.35)
    const targetEnd = Math.round((cur.start + voLen) * 100) / 100
    nudgeActiveSceneTiming('end', targetEnd - cur.end)
  }

  async function toggleNativeFullscreen() {
    try {
      if (document.fullscreenElement) {
        await document.exitFullscreen()
      } else if (paneRef.current) {
        setEnlarged(true)
        await paneRef.current.requestFullscreen()
      }
    } catch {
      setEnlarged((v) => !v)
    }
  }

  const hasTimelineClips = Boolean(plan?.clips?.length)

  return (
    <>
      {enlarged && (
        <div
          className="preview-enlarged-backdrop"
          onClick={() => {
            if (document.fullscreenElement) void document.exitFullscreen().catch(() => undefined)
            setEnlarged(false)
          }}
          title="Click outside or press Esc to exit enlarged view"
        />
      )}
      <section ref={paneRef} className={`preview-pane ${enlarged ? 'enlarged' : ''}`}>
        <div className="preview-tabs">
          <button
            type="button"
            className={`tab ${previewTab === 'timeline' ? 'active' : ''}`}
            onClick={() => setPreviewTab('timeline')}
          >
            <NeonIcon name="video" size={13} tone="cyan" /> Timeline
          </button>
          <button
            type="button"
            className={`tab ${previewTab === 'source' ? 'active' : ''}`}
            disabled={!media.length}
            onClick={() => setPreviewTab('source')}
            title={media.length ? 'Preview selected media asset directly' : 'Import media first'}
          >
            <NeonIcon name="image" size={13} tone="violet" /> Source
          </button>
          <span className="preview-top-meta">
            {active
              ? `${active.screen.replace(/^screen_/i, 'Scene ')}${active.kind ? ` · ${active.kind.toUpperCase()}` : ''}${
                  active.script_text ? ` · ${active.script_text.slice(0, 48)}` : ''
                }`
              : 'No clip loaded'}
            {audioNote ? ` · ${audioNote}` : ''}
          </span>

          {hasTimelineClips && (
            <div className="preview-top-scene-nav">
              <button
                type="button"
                className="preview-mini-btn"
                onClick={() => jumpToAdjacentScene(-1)}
                disabled={activeClipIndex <= 0}
                title="Previous Scene"
              >
                <NeonIcon name="prev" size={12} tone="cyan" /> Scene
              </button>
              <span className="preview-scene-counter">
                {activeClipIndex >= 0 ? `${activeClipIndex + 1}/${plan?.clips.length || 0}` : `0/${plan?.clips.length || 0}`}
              </span>
              <button
                type="button"
                className="preview-mini-btn"
                onClick={() => jumpToAdjacentScene(1)}
                disabled={!plan?.clips || activeClipIndex >= plan.clips.length - 1}
                title="Next Scene"
              >
                Scene <NeonIcon name="next" size={12} tone="cyan" />
              </button>
            </div>
          )}

          {isProjectPoemDetected && (
            <button
              type="button"
              className={`preview-mini-btn poem-studio-btn ${isPoemStudioOpen ? 'active' : ''}`}
              onClick={() => togglePoemStudio()}
              title="Open Poem Typography & Sticker Style Studio + Screen Area Selector"
            >
              <NeonIcon name="sparkles" size={12} tone="amber" /> Poem Lyrics Studio
            </button>
          )}

          <button
            type="button"
            className={`preview-mini-btn ${isLogoEnabled ? 'active' : ''}`}
            onClick={handleToggleLogoClick}
            title={isLogoEnabled ? 'Brand Logo is ON across all screens (click to turn OFF)' : 'Brand Logo is OFF (click to turn ON across all screens)'}
          >
            <NeonIcon name={isLogoEnabled ? 'eye' : 'eye-off'} size={12} tone={isLogoEnabled ? 'cyan' : 'rose'} />{' '}
            Logo {isLogoEnabled ? 'ON' : 'OFF'}
          </button>

          <button
            type="button"
            className={`preview-mini-btn ${canvasFillMode === 'fill' ? 'active' : ''}`}
            onClick={() => setCanvasFillMode((m) => (m === 'fit' ? 'fill' : 'fit'))}
            title="Switch between exact 16:9 Fit and Full Stage Fill"
          >
            {canvasFillMode === 'fill' ? 'Fill Stage' : '16:9 Fit'}
          </button>

          <button
            type="button"
            className={`preview-mini-btn ${showAlignDock ? 'active' : ''}`}
            onClick={() => setShowAlignDock((v) => !v)}
            title="Toggle Live Scene & Voiceover Alignment Inspector Dock"
          >
            <NeonIcon name="align" size={13} tone="cyan" /> {showAlignDock ? 'Align Dock' : 'Show Align'}
          </button>

          {enlarged && (
            <button
              type="button"
              className="preview-mini-btn"
              onClick={() => void toggleNativeFullscreen()}
              title="Toggle True Monitor Fullscreen (F11)"
            >
              <NeonIcon name="fullscreen" size={13} tone="ice" /> {isFullscreen ? 'Windowed' : 'Fullscreen'}
            </button>
          )}

          <button
            type="button"
            className={`enlarge-top-btn ${enlarged ? 'closing' : ''}`}
            onClick={() => {
              if (enlarged && document.fullscreenElement) {
                void document.exitFullscreen().catch(() => undefined)
              }
              setEnlarged((v) => !v)
            }}
            title={enlarged ? 'Close large screen (Esc)' : 'Enlarge video to cinema screen'}
          >
            <NeonIcon name={enlarged ? 'close' : 'enlarge'} size={13} tone={enlarged ? 'rose' : 'cyan'} />{' '}
            {enlarged ? 'Close (Esc)' : 'Enlarge'}
          </button>
        </div>

        <div
          className={`preview-body-grid ${showAlignDock ? 'with-dock' : ''} ${
            isPoemStudioOpen ? 'with-poem-studio' : ''
          }`}
        >
          {isPoemStudioOpen && (
            <PoemStyleStudio
              poemOverlay={effectivePoemOverlay}
              onChange={emitPoemOverlay}
              onClose={() => togglePoemStudio(false)}
              sampleLyric={poemLyricToDisplay || fallbackPoemLyric}
            />
          )}
          <div className="preview-stage" ref={stageRef}>
            <div
              ref={frameRef}
              className={`preview-frame ${canvasFillMode === 'fill' ? 'fill-mode' : ''}`}
              style={frameStyle}
            >
              {!active ? (
                <div className="preview-empty">Import media or open a project to preview</div>
              ) : active.fit === 'missing' || !mediaUrl ? (
                <div className="preview-empty">
                  Blank · Image {active.screen.replace('screen_', '')}
                  <br />
                  This picture does not match the script
                </div>
              ) : null}
              <div className={`preview-layer ${visible === 'image' || active?.kind !== 'video' ? 'on' : ''}`}>
                {prevImageUrl && prevImageUrl !== imageUrl && (
                  <img
                    src={prevImageUrl}
                    alt=""
                    style={{
                      position: 'absolute',
                      inset: 0,
                      width: '100%',
                      height: '100%',
                      objectFit: canvasFillMode === 'fill' ? 'cover' : 'contain',
                    }}
                  />
                )}
                {(imageUrl || (active?.kind !== 'video' ? mediaUrl : null)) && (
                  <img
                    src={imageUrl || (active?.kind !== 'video' ? mediaUrl : '') || ''}
                    alt=""
                    style={{
                      position: 'relative',
                      zIndex: 1,
                      width: '100%',
                      height: '100%',
                      objectFit: canvasFillMode === 'fill' ? 'cover' : 'contain',
                    }}
                    onLoad={() => {
                      if (prevImageUrl) setPrevImageUrl(null)
                    }}
                  />
                )}
              </div>
              {nativeDrive && active?.kind === 'video' && (
                <img
                  src={`${api}/api/engine/frame?v=${nativeFrame}`}
                  alt=""
                  style={{
                    position: 'absolute',
                    inset: 0,
                    width: '100%',
                    height: '100%',
                    objectFit: canvasFillMode === 'fill' ? 'cover' : 'contain',
                    zIndex: 2,
                  }}
                />
              )}
              <div className={`preview-layer ${!nativeDrive && visible === 'a' && active?.kind === 'video' ? 'on' : ''}`}>
                <video
                  ref={vidA}
                  muted
                  playsInline
                  preload="auto"
                  disablePictureInPicture
                  onError={(e) => onVideoError(e.currentTarget)}
                  style={{ objectFit: canvasFillMode === 'fill' ? 'cover' : 'contain' }}
                />
              </div>
              <div className={`preview-layer ${visible === 'b' && active?.kind === 'video' ? 'on' : ''}`}>
                <video
                  ref={vidB}
                  muted
                  playsInline
                  preload="auto"
                  disablePictureInPicture
                  onError={(e) => onVideoError(e.currentTarget)}
                  style={{ objectFit: canvasFillMode === 'fill' ? 'cover' : 'contain' }}
                />
              </div>
              {plan?.video_track_hidden && (
                <div
                  className="preview-track-hidden"
                  style={{ position: 'absolute', inset: 0, zIndex: 3, background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#64748b', fontSize: 12 }}
                >
                  Video 1 hidden (eye toggle in timeline)
                </div>
              )}
              {logoUrl && (
                <div
                  className={`preview-logo-overlay interactive ${draggingLogo ? 'dragging' : ''}`}
                  style={{
                    width: `${logoBox.widthPct}%`,
                    right: `${logoBox.rightPct}%`,
                    top: `${logoBox.topPct}%`,
                    transform: `rotate(${logoBox.rotateDeg}deg) scaleY(${logoBox.heightScaleRatio})`,
                    transformOrigin: 'top right',
                  }}
                  onMouseDown={beginLogoDrag}
                  onDoubleClick={(e) => {
                    e.stopPropagation()
                    emitLogoTransform({ ...DEFAULT_LOGO_TRANSFORM })
                  }}
                  title={`Brand Logo (All Screens) · Scale ${effectiveLogoTransform.scale_w.toFixed(1)}% · Pos (${effectiveLogoTransform.pos_x.toFixed(2)}, ${effectiveLogoTransform.pos_y.toFixed(2)}) — Drag to move, double-click to reset default placement`}
                >
                  <img src={logoUrl} alt="Brand Logo" draggable={false} />
                </div>
              )}
              {isPoemOverlayVisible && (
                <div
                  className={`preview-poem-overlay ${effectivePoemOverlay.locked ? 'is-locked' : 'is-unlocked'} ${draggingPoemBox ? 'dragging' : ''} ${resizingPoemHandle ? 'resizing' : ''}`}
                  style={{
                    position: 'absolute',
                    left: `${effectivePoemOverlay.x_pct}%`,
                    top: `${effectivePoemOverlay.y_pct}%`,
                    width: `${effectivePoemOverlay.w_pct}%`,
                    height: `${effectivePoemOverlay.h_pct}%`,
                    zIndex: 7,
                    pointerEvents: 'auto',
                  }}
                  onMouseDown={beginPoemBoxDrag}
                >
                  {!effectivePoemOverlay.locked && (
                    <div className="ppo-header-bar" onMouseDown={beginPoemBoxDrag}>
                      <span className="ppo-title">
                        <NeonIcon name="sparkles" size={11} tone="amber" /> Poem Lyrics Area ({Math.round(effectivePoemOverlay.w_pct)}% × {Math.round(effectivePoemOverlay.h_pct)}%)
                      </span>
                      <button
                        type="button"
                        className="ppo-lock-pill"
                        onClick={(e) => {
                          e.stopPropagation()
                          emitPoemOverlay({ ...effectivePoemOverlay, locked: true })
                        }}
                        title="Lock screen area & typography styling"
                      >
                        <NeonIcon name="lock" size={10} tone="emerald" /> Lock
                      </button>
                    </div>
                  )}

                  {effectivePoemOverlay.locked && (
                    <div
                      className="ppo-locked-pill"
                      onClick={(e) => {
                        e.stopPropagation()
                        emitPoemOverlay({ ...effectivePoemOverlay, locked: false })
                      }}
                      title="Click to unlock & reposition"
                    >
                      <NeonIcon name="lock" size={10} tone="emerald" /> Locked (Click to reposition)
                    </div>
                  )}

                  <div
                    className={`ppo-content-card preset-${effectivePoemOverlay.preset_style}`}
                    style={{
                      width: '100%',
                      height: '100%',
                      fontFamily: effectivePoemOverlay.font_family,
                      fontSize: `clamp(12px, calc(var(--frame-w, 640px) * ${effectivePoemOverlay.font_size_px / 960}), 42px)`,
                      color: effectivePoemOverlay.text_color,
                      backgroundColor: effectivePoemOverlay.bg_color,
                      opacity: effectivePoemOverlay.bg_opacity,
                      borderColor: effectivePoemOverlay.border_color,
                      borderWidth: `${effectivePoemOverlay.border_width}px`,
                      borderStyle: effectivePoemOverlay.border_width > 0 ? 'solid' : 'none',
                      borderRadius: `${effectivePoemOverlay.border_radius}px`,
                      textAlign: effectivePoemOverlay.text_align,
                      boxShadow: effectivePoemOverlay.box_shadow
                        ? effectivePoemOverlay.preset_style === 'comic_pop'
                          ? '4px 4px 0px #000000'
                          : effectivePoemOverlay.preset_style === 'neon_glow'
                            ? '0 0 16px rgba(6,182,212,0.6), inset 0 0 10px rgba(6,182,212,0.2)'
                            : '0 8px 24px rgba(0,0,0,0.5)'
                        : 'none',
                      textShadow: effectivePoemOverlay.preset_style === 'comic_pop'
                        ? '-1.5px -1.5px 0 #000, 1.5px -1.5px 0 #000, -1.5px 1.5px 0 #000, 1.5px 1.5px 0 #000'
                        : effectivePoemOverlay.preset_style === 'neon_glow'
                          ? '0 0 8px #38bdf8'
                          : '0 2px 4px rgba(0,0,0,0.7)',
                    }}
                  >
                    <div className="ppo-lyrics-inner">
                      {poemLyricToDisplay || (effectivePoemOverlay.locked ? '' : fallbackPoemLyric)}
                    </div>
                  </div>

                  {!effectivePoemOverlay.locked && (
                    <>
                      <div className="ppo-handle nw" onMouseDown={(e) => beginPoemResize('nw', e)} />
                      <div className="ppo-handle ne" onMouseDown={(e) => beginPoemResize('ne', e)} />
                      <div className="ppo-handle se" onMouseDown={(e) => beginPoemResize('se', e)} />
                      <div className="ppo-handle sw" onMouseDown={(e) => beginPoemResize('sw', e)} />
                      <div className="ppo-handle n" onMouseDown={(e) => beginPoemResize('n', e)} />
                      <div className="ppo-handle s" onMouseDown={(e) => beginPoemResize('s', e)} />
                      <div className="ppo-handle e" onMouseDown={(e) => beginPoemResize('e', e)} />
                      <div className="ppo-handle w" onMouseDown={(e) => beginPoemResize('w', e)} />
                    </>
                  )}
                </div>
              )}
              {showSubtitles && !plan?.script_track_hidden && activeCaption && (!isPoemOverlayVisible || !inPoem) && (
                <div className="preview-srt-overlay" aria-live="polite">
                  <span>{activeCaption}</span>
                </div>
              )}
            </div>

          </div>

          {showAlignDock && (
            <aside className="preview-align-dock">
              <div className="pad-header">
                <span className="pad-title">
                  <NeonIcon name="align" size={13} tone="cyan" /> Live Scene &amp; VO Alignment
                </span>
                {active && (
                  <span className={`pad-badge ${active.kind === 'video' ? 'vid' : 'img'}`}>
                    {active.screen.replace(/^screen_/i, 'Scene ')} · {(active.kind || 'image').toUpperCase()}
                  </span>
                )}
              </div>

              {active ? (
                <div className="pad-active-card">
                  <div className="pad-metrics-row">
                    <div className="pad-metric">
                      <span>Timeline Span</span>
                      <strong>
                        {fmt(active.start)} → {fmt(active.end)} ({active.duration.toFixed(2)}s)
                      </strong>
                    </div>
                    <div className="pad-metric">
                      <span>VO Sync Window</span>
                      <strong>
                        {active.narration_in != null && active.narration_out != null
                          ? `${fmt(active.narration_in)} → ${fmt(active.narration_out)} (${Math.max(0, active.narration_out - active.narration_in).toFixed(2)}s)`
                          : 'Hold / Pause'}
                      </strong>
                    </div>
                  </div>

                  {onChangePlan && (
                    <>
                      <div className="pad-nudge-bar">
                        <button
                          type="button"
                          onClick={() => nudgeActiveSceneTiming('start', -0.1)}
                          title="Shift scene start earlier by 0.10s"
                        >
                          In -0.1s
                        </button>
                        <button
                          type="button"
                          onClick={() => nudgeActiveSceneTiming('start', 0.1)}
                          title="Shift scene start later by 0.10s"
                        >
                          In +0.1s
                        </button>
                        <button
                          type="button"
                          onClick={() => nudgeActiveSceneTiming('end', -0.1)}
                          title="Trim scene end by 0.10s"
                        >
                          Out -0.1s
                        </button>
                        <button
                          type="button"
                          onClick={() => nudgeActiveSceneTiming('end', 0.1)}
                          title="Extend scene end by 0.10s"
                        >
                          Out +0.1s
                        </button>
                        {active.narration_in != null && active.narration_out != null && (
                          <button
                            type="button"
                            className="snap-vo"
                            onClick={snapActiveSceneToVo}
                            title="Snap scene duration tightly to spoken VO narration"
                          >
                            <NeonIcon name="bolt" size={11} tone="cyan" /> Snap VO
                          </button>
                        )}
                      </div>

                      <div className="pad-scene-cover-actions">
                        <button
                          type="button"
                          className="pad-cover-btn accent"
                          disabled={activeClipIndex < 0}
                          onClick={() => deleteAndPullPrevToCover(activeClipIndex)}
                          title="Delete this scene image and pull/stretch the previous screen to cover this timeline narration"
                        >
                          ⬅ Delete &amp; Pull Prev Screen to Cover
                        </button>
                        <div className="pad-cover-row-split">
                          <button
                            type="button"
                            className="pad-cover-btn"
                            disabled={activeClipIndex < 0}
                            onClick={() => pullSceneToCoverAdjacent(activeClipIndex, -1)}
                            title="Pull/stretch this screen leftward to cover the previous scene"
                          >
                            ⬅ Pull Over Prev
                          </button>
                          <button
                            type="button"
                            className="pad-cover-btn"
                            disabled={activeClipIndex < 0}
                            onClick={() => pullSceneToCoverAdjacent(activeClipIndex, 1)}
                            title="Pull/stretch this screen rightward to cover the next scene"
                          >
                            ➡ Pull Over Next
                          </button>
                          <button
                            type="button"
                            className="pad-cover-btn danger"
                            disabled={activeClipIndex < 0}
                            onClick={() => deleteSceneAt(activeClipIndex)}
                            title="Delete this scene image from Video 1 (VO narration stays locked)"
                          >
                            🗑 Delete Scene
                          </button>
                        </div>
                      </div>
                    </>
                  )}

                  <div className="pad-text-box">
                    <div className="pad-text-label">Spoken Voiceover / Script</div>
                    <div className="pad-text-body">
                      {active.vo_text || activeSceneMeta?.voiceover_text || active.script_text || '— No spoken narration for this scene —'}
                    </div>
                    {activeSceneMeta?.onscreen_text && (
                      <>
                        <div className="pad-text-label" style={{ marginTop: 4 }}>On-Screen Card</div>
                        <div className="pad-text-sub">{activeSceneMeta.onscreen_text}</div>
                      </>
                    )}
                  </div>
                </div>
              ) : (
                <div className="pad-empty">Build or open a timeline to inspect scene alignments.</div>
              )}

              <div className="pad-queue-head">
                <span>Scene Alignment Queue ({plan?.clips?.length || 0})</span>
                <span>Click to Jump</span>
              </div>
              <div className="pad-queue-list">
                {(plan?.clips || []).map((c, idx) => {
                  const isCur = idx === activeClipIndex
                  const hasVo = c.narration_in != null && c.narration_out != null && c.narration_out > c.narration_in
                  return (
                    <button
                      key={`${c.screen}-${idx}`}
                      type="button"
                      className={`pad-queue-item ${isCur ? 'active' : ''}`}
                      onClick={() => onPlayhead(c.start)}
                    >
                      <span className="pq-num">{c.screen.replace(/^screen_/i, 'S')}</span>
                      <span className={`pq-kind ${c.kind}`}>{c.kind === 'video' ? 'VID' : 'IMG'}</span>
                      <span className="pq-text">
                        {c.vo_text || c.script_text || (c.fit === 'missing' ? 'Missing media' : 'Visual hold')}
                      </span>
                      <span className={`pq-sync ${hasVo ? 'vo' : 'hold'}`}>{hasVo ? 'VO' : 'HOLD'}</span>
                      <span className="pq-time">{fmt(c.start)}</span>
                    </button>
                  )
                })}
                {!plan?.clips?.length && (
                  <div className="pad-empty">No timeline clips yet — click Auto-align to generate.</div>
                )}
              </div>
            </aside>
          )}
        </div>

        {/* Hidden timeline audio — narration + poem */}
        {narrUrl && (
          <audio
            ref={narrRef}
            src={narrUrl}
            preload="auto"
            onError={() => setAudioNote('Narration audio failed to load')}
          />
        )}
        {poemUrl && (
          <audio
            ref={poemRef}
            src={poemUrl}
            preload="auto"
            onError={() => setAudioNote('Poem audio failed to load')}
          />
        )}

        <div className="preview-transport">
          <LiveScrub total={plan?.total_duration || 0} onPlayhead={onPlayhead} />
          <div className="transport-row">
            <button type="button" onClick={() => onPlayhead(0)} title="Jump to Start (00:00)">
              <NeonIcon name="step-start" size={enlarged ? 16 : 13} tone="cyan" />
            </button>
            <button
              type="button"
              onClick={() => onPlayhead(Math.max(0, playheadBus.get() - 1 / fps))}
              title="Previous Frame"
            >
              <NeonIcon name="prev" size={enlarged ? 16 : 13} tone="cyan" />
            </button>
            <button
              type="button"
              className="play"
              onClick={() => void togglePlay()}
              title={playing ? 'Pause' : 'Play'}
            >
              <NeonIcon name={playing ? 'pause' : 'play'} size={enlarged ? 17 : 14} tone="rose" />
            </button>
            <button
              type="button"
              onClick={() => onPlayhead(Math.min(plan?.total_duration || 0, playheadBus.get() + 1 / fps))}
              title="Next Frame"
            >
              <NeonIcon name="next" size={enlarged ? 16 : 13} tone="cyan" />
            </button>
            <button
              type="button"
              onClick={() => {
                onPlaying(false)
                narrRef.current?.pause()
                poemRef.current?.pause()
              }}
              title="Stop"
            >
              <NeonIcon name="stop" size={enlarged ? 15 : 12} tone="cyan" />
            </button>
            <button
              type="button"
              className="mute-btn"
              onClick={() => setMuted((m) => !m)}
              title={muted ? 'Unmute' : 'Mute'}
            >
              <NeonIcon name={muted ? 'mute' : 'volume'} size={enlarged ? 16 : 13} tone={muted ? 'rose' : 'cyan'} />
            </button>
            <input
              className="vol"
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={volume}
              onChange={(e) => setVolume(Number(e.target.value))}
              title="Volume"
            />
            <LiveTimecode fps={fps} total={plan?.total_duration || 0} />
            <button
              type="button"
              className={`cc-btn ${showSubtitles ? 'active' : ''}`}
              onClick={() => setShowSubtitles((s) => !s)}
              title={showSubtitles ? 'Hide SRT preview overlay (not burned into video)' : 'Show SRT preview overlay'}
            >
              CC
            </button>
            <span className="aspect">16:9</span>
            <button
              type="button"
              className={`cc-btn ${enlarged ? 'active' : ''}`}
              onClick={() => {
                if (enlarged && document.fullscreenElement) {
                  void document.exitFullscreen().catch(() => undefined)
                }
                setEnlarged((v) => !v)
              }}
              title={enlarged ? 'Close large screen (Esc)' : 'Enlarge video screen'}
            >
              <NeonIcon name={enlarged ? 'minimize' : 'enlarge'} size={enlarged ? 15 : 13} tone="cyan" />
            </button>
          </div>
        </div>
      </section>
    </>
  )
}
