import {
  useEffect,
  useMemo,
  useRef,
  useState,
  useSyncExternalStore,
  type DragEvent as ReactDragEvent,
  type MouseEvent as ReactMouseEvent,
} from 'react'
import type { MediaItem, NarrationSegment, QAIssue, TimelineClip, TimelinePlan, VoPiece } from '../types'
import { displayVoPieces, splitVoPiece, trimVoPiece } from '../voPieces'
import { fmt } from '../types'
import { playheadBus } from '../playheadBus'
import { NeonIcon } from './NeonIcons'

type VoFile = { filename: string; duration?: number | null }

type Props = {
  api?: string
  projectId?: string | null
  plan: TimelinePlan | null
  media?: MediaItem[]
  playhead: number
  onPlayhead: (t: number) => void
  onChange: (plan: TimelinePlan, commitImmediate?: boolean) => void
  onReplaceClipMedia?: (screen: string, file: File) => Promise<void>
  onAutoAlign?: () => void
  pxPerSec: number
  onPxPerSec: (v: number) => void
  voFiles?: Record<number, VoFile>
  localMediaUrls?: Record<string, string>
  localThumbUrls?: Record<string, string>
  onIgnoreIssue?: (issue: QAIssue) => void
  onIgnoreAllIssues?: () => void
  onRestoreIgnoredIssues?: () => void
  ignoredIssueCount?: number
  onToggleLogo?: (enabled: boolean) => void
}

type DragMode = 'move' | 'resize-left' | 'resize-right' | 'poem' | 'vo-move' | 'vo-left' | 'vo-right'

type HistSnap = { clips: TimelineClip[]; vo: VoPiece[] | undefined }

type DragState = {
  mode: DragMode
  index: number
  originX: number
  originStart: number
  originEnd: number
  duration: number
  initialClips: TimelineClip[]
  pieceId?: string
  initialPieces?: VoPiece[]
}

type ContextMenuState = {
  x: number
  y: number
  clipIndex: number
}

function getEffectiveNarrationSegments(plan: TimelinePlan | null): NarrationSegment[] {
  if (!plan) return []
  if (plan.narration_segments && plan.narration_segments.length > 0) {
    return plan.narration_segments
  }
  return plan.clips
    .filter((c) => c.narration_in != null || c.vo_text || c.script_text)
    .map((c) => ({
      screen: c.screen,
      start: c.start,
      end: c.end,
      narration_in: c.narration_in ?? null,
      narration_out: c.narration_out ?? null,
      vo_text: c.vo_text || '',
      script_text: c.script_text || '',
    }))
}

export function TimelineEditor({
  api = '',
  projectId,
  plan,
  media: _media = [],
  playhead,
  onPlayhead,
  onChange,
  onReplaceClipMedia,
  onAutoAlign,
  pxPerSec,
  onPxPerSec,
  voFiles = {},
  localMediaUrls = {},
  localThumbUrls = {},
  onIgnoreIssue: _onIgnoreIssue,
  onIgnoreAllIssues: _onIgnoreAllIssues,
  onRestoreIgnoredIssues: _onRestoreIgnoredIssues,
  ignoredIssueCount: _ignoredIssueCount = 0,
  onToggleLogo,
}: Props) {
  const laneRef = useRef<HTMLDivElement | null>(null)
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const [replaceTargetScreen, setReplaceTargetScreen] = useState<string | null>(null)
  const [drag, setDrag] = useState<DragState | null>(null)
  const [selectedClipIdx, setSelectedClipIdx] = useState<number | null>(null)
  const [contextMenu, setContextMenu] = useState<ContextMenuState | null>(null)
  const [voMenu, setVoMenu] = useState<{ x: number; y: number; id: string } | null>(null)
  const [dragTooltip, setDragTooltip] = useState<{ x: number; text: string } | null>(null)
  const [undoStack, setUndoStack] = useState<HistSnap[]>([])
  const [redoStack, setRedoStack] = useState<HistSnap[]>([])
  const [selectedVoId, setSelectedVoId] = useState<string | null>(null)

  const narrSegments = useMemo(() => getEffectiveNarrationSegments(plan), [plan])

  // Ensure selectedClipIdx stays in bounds when clips change
  useEffect(() => {
    if (!plan || selectedClipIdx == null) return
    if (selectedClipIdx >= plan.clips.length) {
      setSelectedClipIdx(plan.clips.length ? plan.clips.length - 1 : null)
    }
  }, [plan, selectedClipIdx])

  // Close context menu on outside click
  useEffect(() => {
    if (!contextMenu && !voMenu) return
    const close = () => {
      setContextMenu(null)
      setVoMenu(null)
    }
    window.addEventListener('click', close)
    return () => window.removeEventListener('click', close)
  }, [contextMenu, voMenu])

  function captureSnap(): HistSnap {
    return {
      clips: (plan?.clips || []).map((c) => ({ ...c })),
      vo: plan?.vo_pieces?.map((p) => ({ ...p })),
    }
  }

  function pushUndo() {
    const snap = captureSnap()
    setUndoStack((prev) => [...prev.slice(-24), snap])
    setRedoStack([])
  }

  function restoreSnap(snap: HistSnap) {
    if (!plan) return
    const cleaned = snap.clips
      .map((c) => {
        const start = Math.max(0, Number(c.start.toFixed(3)))
        const end = Math.max(start + 0.2, Number(c.end.toFixed(3)))
        return { ...c, start, end, duration: Number((end - start).toFixed(3)) }
      })
      .sort((a, b) => a.start - b.start)
    onChange(
      {
        ...plan,
        clips: cleaned,
        vo_pieces: snap.vo,
        narration_segments: narrSegments,
        manual_override: true,
      },
      true,
    )
  }

  type TrackFlag =
    | 'logo_enabled'
    | 'logo_track_locked'
    | 'video_track_hidden'
    | 'video_track_locked'
    | 'script_track_hidden'
    | 'script_track_locked'
    | 'vo_muted'
    | 'vo_track_locked'
    | 'poem_muted'
    | 'poem_track_locked'

  // Track header toggles (eye / lock / speaker / music) — persisted on the plan
  function toggleTrack(flag: TrackFlag, e?: ReactMouseEvent) {
    e?.stopPropagation()
    if (!plan) return
    const cur = flag === 'logo_enabled' ? plan.logo_enabled !== false : Boolean(plan[flag])
    const nextVal = !cur
    if (flag === 'logo_enabled' && onToggleLogo) {
      onToggleLogo(nextVal)
    }
    onChange({ ...plan, [flag]: nextVal }, true)
  }

  function applyClipsUpdate(nextClips: TimelineClip[], commitImmediate = true) {
    if (!plan) return
    if (plan.video_track_locked) return
    const cleaned = nextClips
      .map((c) => {
        const start = Math.max(0, Number(c.start.toFixed(3)))
        const end = Math.max(start + 0.2, Number(c.end.toFixed(3)))
        const duration = Number((end - start).toFixed(3))
        return { ...c, start, end, duration }
      })
      .sort((a, b) => a.start - b.start)

    const maxClipEnd = cleaned.length ? Math.max(...cleaned.map((c) => c.end)) : 0
    const maxNarrEnd = narrSegments.length ? Math.max(...narrSegments.map((n) => n.end)) : 0
    const nextPlan: TimelinePlan = {
      ...plan,
      clips: cleaned,
      narration_segments: narrSegments,
      manual_override: true,
      total_duration: Math.max(plan.total_duration, maxClipEnd, maxNarrEnd),
    }
    onChange(nextPlan, commitImmediate)
  }

  function handleUndo() {
    if (!plan || undoStack.length === 0) return
    const prev = undoStack[undoStack.length - 1]
    setUndoStack((s) => s.slice(0, -1))
    setRedoStack((r) => [...r, captureSnap()])
    restoreSnap(prev)
  }

  function handleRedo() {
    if (!plan || redoStack.length === 0) return
    const next = redoStack[redoStack.length - 1]
    setRedoStack((r) => r.slice(0, -1))
    setUndoStack((u) => [...u, captureSnap()])
    restoreSnap(next)
  }

  function deleteClipAtIndex(idx: number) {
    if (!plan || idx < 0 || idx >= plan.clips.length) return
    pushUndo()
    const nextClips = plan.clips.filter((_, i) => i !== idx)
    setSelectedClipIdx(null)
    applyClipsUpdate(nextClips, true)
  }

  // Delete the image at `screen` AND elongate the immediately preceding clip on Video 1 to cover this narration!
  function deleteAndElongatePrevious(screen: string) {
    if (!plan) return
    pushUndo()
    const seg = narrSegments.find((s) => s.screen === screen)
    const targetClip = plan.clips.find((c) => c.screen === screen)
    const coverEnd = Math.max(seg?.end || 0, targetClip?.end || 0)
    const coverStart = seg?.start ?? targetClip?.start ?? 0

    // Remove the mismatched clip at `screen`
    const remaining = plan.clips.filter((c) => c.screen !== screen)
    // Find the clip immediately before `coverStart`
    let prevIdx = -1
    for (let i = 0; i < remaining.length; i++) {
      if (remaining[i].start < coverStart + 0.05) {
        prevIdx = i
      }
    }
    if (prevIdx >= 0 && coverEnd > remaining[prevIdx].start + 0.2) {
      remaining[prevIdx] = {
        ...remaining[prevIdx],
        end: Math.max(remaining[prevIdx].end, coverEnd),
        duration: Math.max(0.2, Math.max(remaining[prevIdx].end, coverEnd) - remaining[prevIdx].start),
      }
      setSelectedClipIdx(prevIdx)
    } else if (remaining.length > 0 && coverEnd > 0) {
      // If it was the very first clip, extend the next clip leftward to cover
      remaining[0] = {
        ...remaining[0],
        start: Math.min(remaining[0].start, coverStart),
        duration: Math.max(0.2, remaining[0].end - Math.min(remaining[0].start, coverStart)),
      }
      setSelectedClipIdx(0)
    }
    applyClipsUpdate(remaining, true)
  }

  // Elongate the clip at `idx` rightward so it covers the next narration segment (or uncovered gap)
  function elongateClipRight(idx: number) {
    if (!plan || idx < 0 || idx >= plan.clips.length) return
    pushUndo()
    const clip = plan.clips[idx]
    const nextSeg = narrSegments.find((s) => s.end > clip.end + 0.08)
    const nextClip = plan.clips[idx + 1]
    let targetEnd = clip.end + 2.0
    if (nextSeg) {
      targetEnd = nextSeg.end
    } else if (nextClip) {
      targetEnd = nextClip.end
    }

    const updated = resolveOverwrites(plan.clips, idx, clip.start, targetEnd)
    applyClipsUpdate(updated, true)
  }

  // Elongate the clip at `idx` leftward so it covers the previous narration segment (or uncovered gap)
  function elongateClipLeft(idx: number) {
    if (!plan || idx < 0 || idx >= plan.clips.length) return
    pushUndo()
    const clip = plan.clips[idx]
    const prevSegs = narrSegments.filter((s) => s.start < clip.start - 0.08)
    const prevSeg = prevSegs.length ? prevSegs[prevSegs.length - 1] : null
    const prevClip = idx > 0 ? plan.clips[idx - 1] : null
    let targetStart = Math.max(0, clip.start - 2.0)
    if (prevSeg) {
      targetStart = prevSeg.start
    } else if (prevClip) {
      targetStart = prevClip.start
    }

    const updated = resolveOverwrites(plan.clips, idx, targetStart, clip.end)
    applyClipsUpdate(updated, true)
  }

  // Fit selected clip to cover its own narration segment plus any adjacent uncovered narration gap
  function fitClipToNarration(idx: number) {
    if (!plan || idx < 0 || idx >= plan.clips.length) return
    pushUndo()
    const clip = plan.clips[idx]
    const ownSeg = narrSegments.find((s) => s.screen === clip.screen)
    let newStart = ownSeg ? Math.min(clip.start, ownSeg.start) : clip.start
    let newEnd = ownSeg ? Math.max(clip.end, ownSeg.end) : clip.end

    // Also absorb any immediately adjacent uncovered narration gap to the right or left
    const prevClipEnd = idx > 0 ? plan.clips[idx - 1].end : 0
    const nextClipStart = idx + 1 < plan.clips.length ? plan.clips[idx + 1].start : plan.total_duration
    if (newEnd < nextClipStart - 0.05) {
      newEnd = nextClipStart
    } else if (newStart > prevClipEnd + 0.05) {
      newStart = prevClipEnd
    }

    const updated = resolveOverwrites(plan.clips, idx, newStart, newEnd)
    applyClipsUpdate(updated, true)
  }

  function splitClipAtPlayhead(idx: number) {
    if (!plan || idx < 0 || idx >= plan.clips.length) return
    const clip = plan.clips[idx]
    if (playhead <= clip.start + 0.25 || playhead >= clip.end - 0.25) return
    pushUndo()
    const leftDur = Number((playhead - clip.start).toFixed(3))
    const rightDur = Number((clip.end - playhead).toFixed(3))
    const leftClip: TimelineClip = {
      ...clip,
      end: Number(playhead.toFixed(3)),
      duration: leftDur,
    }
    const rightClip: TimelineClip = {
      ...clip,
      start: Number(playhead.toFixed(3)),
      duration: rightDur,
    }
    const nextClips = [...plan.clips]
    nextClips.splice(idx, 1, leftClip, rightClip)
    applyClipsUpdate(nextClips, true)
  }

  const shownVoPieces = useMemo(() => displayVoPieces(plan), [plan])

  function commitVo(next: VoPiece[], immediate: boolean) {
    if (!plan || plan.vo_track_locked) return
    onChange({ ...plan, vo_pieces: next, manual_override: true }, immediate)
  }

  function baseVoPieces() {
    if (!plan) return [] as VoPiece[]
    return Array.isArray(plan.vo_pieces) ? plan.vo_pieces.map((p) => ({ ...p })) : displayVoPieces(plan).map((p) => ({ ...p }))
  }

  function deleteVoPiece(id: string) {
    if (!plan || plan.vo_track_locked) return
    pushUndo()
    commitVo(baseVoPieces().filter((p) => p.id !== id), true)
    setSelectedVoId(null)
  }

  function splitVoAtPlayhead(id: string) {
    if (!plan || plan.vo_track_locked) return
    const next = splitVoPiece(baseVoPieces(), id, playhead)
    if (!next) return
    pushUndo()
    commitVo(next, true)
    setSelectedVoId(next.find((p) => playhead >= p.start && playhead < p.end)?.id || id)
  }

  function assignMediaItemToScreen(screen: string, item: MediaItem) {
    if (!plan) return
    pushUndo()
    const existingIdx = plan.clips.findIndex((c) => c.screen === screen)
    const nextClips = [...plan.clips]
    if (existingIdx >= 0) {
      const dur = Math.max(0.2, nextClips[existingIdx].end - nextClips[existingIdx].start)
      nextClips[existingIdx] = {
        ...nextClips[existingIdx],
        media_id: item.id,
        media_path: item.path,
        filename: item.filename,
        kind: item.kind,
        source_in: 0,
        source_out: dur,
        fit: item.kind === 'image' ? 'hold' : 'passthrough',
      }
    } else {
      const seg = narrSegments.find((s) => s.screen === screen)
      const start = seg ? seg.start : playhead
      const end = seg ? seg.end : start + 3.0
      nextClips.push({
        screen,
        media_id: item.id,
        media_path: item.path,
        filename: item.filename,
        kind: item.kind,
        start,
        end,
        duration: Math.max(0.2, end - start),
        source_in: 0,
        source_out: Math.max(0.2, end - start),
        fit: item.kind === 'image' ? 'hold' : 'passthrough',
        script_text: seg?.script_text || '',
        vo_text: seg?.vo_text || '',
        narration_in: seg?.narration_in ?? null,
        narration_out: seg?.narration_out ?? null,
      })
    }
    applyClipsUpdate(nextClips, true)
  }

  function triggerUploadForScreen(screen: string, acceptKind: 'image' | 'video' | 'any' = 'any') {
    setReplaceTargetScreen(screen)
    if (fileInputRef.current) {
      if (acceptKind === 'image') {
        fileInputRef.current.accept = 'image/*,.png,.jpg,.jpeg,.webp,.bmp'
      } else if (acceptKind === 'video') {
        fileInputRef.current.accept = 'video/*,.mp4,.mov,.webm,.mkv,.avi,.m4v'
      } else {
        fileInputRef.current.accept = 'image/*,video/*,.png,.jpg,.jpeg,.webp,.mp4,.mov,.webm'
      }
      fileInputRef.current.click()
    }
  }

  // Keyboard shortcuts: Delete/Backspace deletes selected clip, Ctrl+Z / Ctrl+Y undo/redo, S splits clip
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName?.toLowerCase()
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') {
        e.preventDefault()
        if (e.shiftKey) handleRedo()
        else handleUndo()
        return
      }
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') {
        e.preventDefault()
        handleRedo()
        return
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedVoId) {
        e.preventDefault()
        deleteVoPiece(selectedVoId)
        return
      }
      if (e.key.toLowerCase() === 's' && !e.ctrlKey && !e.metaKey && selectedVoId) {
        e.preventDefault()
        splitVoAtPlayhead(selectedVoId)
        return
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedClipIdx != null) {
        e.preventDefault()
        deleteClipAtIndex(selectedClipIdx)
        return
      }
      if (e.key.toLowerCase() === 's' && !e.ctrlKey && !e.metaKey && selectedClipIdx != null) {
        e.preventDefault()
        splitClipAtPlayhead(selectedClipIdx)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  })

  // Resolve overwrites when clip `activeIdx` is resized/moved to `[newStart, newEnd]` on Video 1
  function resolveOverwrites(
    clips: TimelineClip[],
    activeIdx: number,
    newStart: number,
    newEnd: number,
  ): TimelineClip[] {
    const active = {
      ...clips[activeIdx],
      start: newStart,
      end: newEnd,
      duration: Math.max(0.2, newEnd - newStart),
    }
    const out: TimelineClip[] = []
    for (let i = 0; i < clips.length; i++) {
      if (i === activeIdx) {
        out.push(active)
        continue
      }
      const c = clips[i]
      // No overlap
      if (c.end <= newStart + 0.01 || c.start >= newEnd - 0.01) {
        out.push(c)
        continue
      }
      // Completely covered by the elongated clip -> absorbed
      if (c.start >= newStart - 0.02 && c.end <= newEnd + 0.02) {
        continue
      }
      // Overlaps on the right of active clip -> trim c.start to newEnd
      if (c.start < newEnd && c.end > newEnd + 0.2) {
        out.push({
          ...c,
          start: newEnd,
          duration: Math.max(0.2, c.end - newEnd),
        })
        continue
      }
      // Overlaps on the left of active clip -> trim c.end to newStart
      if (c.start < newStart - 0.2 && c.end > newStart) {
        out.push({
          ...c,
          end: newStart,
          duration: Math.max(0.2, newStart - c.start),
        })
      }
    }
    return out.sort((a, b) => a.start - b.start)
  }

  const voSlotBlocks = useMemo(() => {
    const fromPlan = (plan?.voiceover_slots || []).filter((s) => s.end > s.start + 0.05)
    if (fromPlan.length >= 2) {
      return fromPlan.map((s) => ({
        slot: s.slot,
        start: s.start,
        end: s.end,
        label: `VO ${s.slot} · ${s.filename}`,
      }))
    }
    const entries = Object.entries(voFiles)
      .map(([k, v]) => ({ slot: Number(k), filename: v.filename, duration: v.duration || 0 }))
      .filter((e) => e.slot >= 1 && e.duration > 0)
      .sort((a, b) => a.slot - b.slot)
    if (entries.length < 2) return [] as { slot: number; start: number; end: number; label: string }[]
    let t = 0
    return entries.map((e, i) => {
      const start = t
      const end = t + e.duration
      t = end + (i < entries.length - 1 ? 0.5 : 0)
      return { slot: e.slot, start, end, label: `VO ${e.slot} · ${e.filename}` }
    })
  }, [plan, voFiles])

  const total = Math.max(
    plan?.total_duration || 30,
    10,
    voSlotBlocks.length ? voSlotBlocks[voSlotBlocks.length - 1].end : 0,
  )
  const width = total * pxPerSec
  const ticks = useMemo(() => {
    const step = pxPerSec >= 24 ? 5 : pxPerSec >= 12 ? 10 : 20
    const out: number[] = []
    for (let t = 0; t <= total + 0.01; t += step) out.push(t)
    return out
  }, [total, pxPerSec])

  const poemBlock = useMemo(() => {
    if (!plan?.has_poem || !plan.poem_voiceover_path) return null
    const start = plan.poem_start_time || 0
    let poemEnd = plan.poem_end_time || 0
    if (poemEnd <= start) {
      for (const c of plan.clips) {
        if (c.start + 0.05 >= start && c.start <= Math.max(poemEnd, start) + 0.15) {
          poemEnd = Math.max(poemEnd, c.end)
        } else if (c.start > poemEnd + 0.5 && poemEnd > start) break
      }
    }
    if (poemEnd <= start) poemEnd = Math.min(total, start + 47.64)
    return { start, end: poemEnd, label: 'Poem / Suno VO' }
  }, [plan, total])

  // Detect any narration segments that have NO covering clip on Video 1 (e.g. after deleting an image)
  const uncoveredNarrations = useMemo(() => {
    if (!plan) return [] as NarrationSegment[]
    return narrSegments.filter((seg) => {
      if (seg.end <= seg.start + 0.1) return false
      const covered = plan.clips.some(
        (c) =>
          c.fit !== 'missing' &&
          Boolean(c.media_id || c.media_path) &&
          Math.min(c.end, seg.end) - Math.max(c.start, seg.start) > 0.15,
      )
      return !covered
    })
  }, [plan, narrSegments])

  // Snap candidate time to narration boundaries, playhead, or adjacent clip edges within 6px
  function snapTime(rawTime: number, ignoreClipIdx: number): number {
    const snapToleranceSec = Math.min(0.35, 7 / Math.max(4, pxPerSec))
    const candidates: number[] = [0, playhead, total]
    for (const seg of narrSegments) {
      candidates.push(seg.start, seg.end)
    }
    if (plan) {
      plan.clips.forEach((c, idx) => {
        if (idx !== ignoreClipIdx) {
          candidates.push(c.start, c.end)
        }
      })
    }
    let best = rawTime
    let bestDist = snapToleranceSec
    for (const pt of candidates) {
      const d = Math.abs(rawTime - pt)
      if (d < bestDist) {
        bestDist = d
        best = pt
      }
    }
    return Math.max(0, Number(best.toFixed(3)))
  }

  function clientXToTime(clientX: number) {
    const el = laneRef.current
    if (!el) return 0
    const rect = el.getBoundingClientRect()
    const x = clientX - rect.left + el.scrollLeft
    return Math.max(0, Math.min(total, x / pxPerSec))
  }

  function onLaneClick(e: ReactMouseEvent) {
    if (drag) return
    onPlayhead(clientXToTime(e.clientX))
  }

  function beginDrag(
    e: ReactMouseEvent,
    mode: DragMode,
    index: number,
    start: number,
    end: number,
    pieceId?: string,
  ) {
    e.stopPropagation()
    e.preventDefault()
    if (!plan) return
    if (mode === 'poem' && plan.poem_track_locked) return
    if (mode.startsWith('vo')) {
      if (plan.vo_track_locked) return
      setSelectedVoId(pieceId || null)
      setSelectedClipIdx(null)
      pushUndo()
    } else if (mode !== 'poem') {
      if (plan.video_track_locked) return
      setSelectedClipIdx(index)
      setSelectedVoId(null)
      pushUndo()
    }
    setDrag({
      mode,
      index,
      pieceId,
      originX: e.clientX,
      originStart: start,
      originEnd: end,
      duration: Math.max(0.2, end - start),
      initialClips: plan.clips.map((c) => ({ ...c })),
      initialPieces: baseVoPieces(),
    })
  }

  function onMouseMove(e: ReactMouseEvent) {
    if (!drag || !plan) return
    const dx = e.clientX - drag.originX
    const dt = dx / pxPerSec

    if (drag.mode === 'vo-move' || drag.mode === 'vo-left' || drag.mode === 'vo-right') {
      const id = drag.pieceId
      const base = drag.initialPieces || []
      if (!id) return
      const edge = drag.mode === 'vo-left' ? 'start' : drag.mode === 'vo-right' ? 'end' : 'move'
      const at = edge === 'move' ? drag.originStart + dt : edge === 'start' ? drag.originStart + dt : drag.originEnd + dt
      const next = trimVoPiece(base, id, edge, Math.max(0, at))
      const moved = next.find((p) => p.id === id)
      if (moved) {
        setDragTooltip({
          x: moved.start * pxPerSec,
          text: `${fmt(moved.start)} – ${fmt(moved.end)}`,
        })
      }
      commitVo(next, false)
      return
    }

    if (drag.mode === 'poem') {
      const nextStart = Math.max(0, drag.originStart + dt)
      const nextEnd = nextStart + drag.duration
      onChange(
        {
          ...plan,
          poem_start_time: nextStart,
          total_duration: Math.max(plan.total_duration, nextEnd),
        },
        false,
      )
      return
    }

    if (drag.mode === 'resize-right') {
      const rawEnd = Math.max(drag.originStart + 0.25, drag.originEnd + dt)
      const snappedEnd = Math.max(drag.originStart + 0.25, snapTime(rawEnd, drag.index))
      const nextClips = resolveOverwrites(drag.initialClips, drag.index, drag.originStart, snappedEnd)
      const newIdx = nextClips.findIndex(
        (c) => c.screen === drag.initialClips[drag.index]?.screen && Math.abs(c.start - drag.originStart) < 0.05,
      )
      if (newIdx >= 0) setSelectedClipIdx(newIdx)
      setDragTooltip({
        x: snappedEnd * pxPerSec,
        text: `Elongate End: ${fmt(snappedEnd)} (${(snappedEnd - drag.originStart).toFixed(1)}s)`,
      })
      applyClipsUpdate(nextClips, false)
    } else if (drag.mode === 'resize-left') {
      const rawStart = Math.max(0, Math.min(drag.originEnd - 0.25, drag.originStart + dt))
      const snappedStart = Math.min(drag.originEnd - 0.25, snapTime(rawStart, drag.index))
      const nextClips = resolveOverwrites(drag.initialClips, drag.index, snappedStart, drag.originEnd)
      const newIdx = nextClips.findIndex(
        (c) => c.screen === drag.initialClips[drag.index]?.screen && Math.abs(c.end - drag.originEnd) < 0.05,
      )
      if (newIdx >= 0) setSelectedClipIdx(newIdx)
      setDragTooltip({
        x: snappedStart * pxPerSec,
        text: `Trim Start: ${fmt(snappedStart)} (${(drag.originEnd - snappedStart).toFixed(1)}s)`,
      })
      applyClipsUpdate(nextClips, false)
    } else if (drag.mode === 'move') {
      const rawStart = Math.max(0, drag.originStart + dt)
      const snappedStart = snapTime(rawStart, drag.index)
      const nextEnd = snappedStart + drag.duration
      const nextClips = resolveOverwrites(drag.initialClips, drag.index, snappedStart, nextEnd)
      const newIdx = nextClips.findIndex(
        (c) => c.screen === drag.initialClips[drag.index]?.screen && Math.abs(c.start - snappedStart) < 0.05,
      )
      if (newIdx >= 0) setSelectedClipIdx(newIdx)
      setDragTooltip({
        x: snappedStart * pxPerSec,
        text: `${ fmt(snappedStart) } – ${ fmt(nextEnd) }`,
      })
      applyClipsUpdate(nextClips, false)
    }
  }

  function endDrag() {
    if (!drag || !plan) return
    setDrag(null)
    setDragTooltip(null)
    // Commit final state to backend so QA thought bubbles refresh immediately
    onChange(
      {
        ...plan,
        narration_segments: narrSegments,
        manual_override: true,
      },
      true,
    )
  }

  function nudgeClip(index: number, delta: number) {
    if (!plan) return
    pushUndo()
    const clip = plan.clips[index]
    if (!clip) return
    const start = Math.max(0, clip.start + delta)
    const end = start + clip.duration
    const updated = resolveOverwrites(plan.clips, index, start, end)
    applyClipsUpdate(updated, true)
  }

  // Handle drag-and-drop of media from Left Panel onto Video 1
  function handleVideoLaneDragOver(e: ReactDragEvent) {
    if (e.dataTransfer.types.includes('application/x-dgs-media')) {
      e.preventDefault()
      e.dataTransfer.dropEffect = 'copy'
    }
  }

  function handleVideoLaneDrop(e: ReactDragEvent, targetScreen?: string) {
    const raw = e.dataTransfer.getData('application/x-dgs-media')
    if (!raw || !plan) return
    e.preventDefault()
    e.stopPropagation()
    try {
      const item = JSON.parse(raw) as MediaItem
      if (targetScreen) {
        assignMediaItemToScreen(targetScreen, item)
        return
      }
      const dropTime = clientXToTime(e.clientX)
      const hitClip = plan.clips.find((c) => dropTime >= c.start && dropTime <= c.end)
      if (hitClip) {
        assignMediaItemToScreen(hitClip.screen, item)
        return
      }
      const hitSeg = narrSegments.find((s) => dropTime >= s.start && dropTime <= s.end)
      if (hitSeg) {
        assignMediaItemToScreen(hitSeg.screen, item)
      }
    } catch {
      /* ignore invalid drop payload */
    }
  }

  const effectiveClipIdx = useMemo(() => {
    if (!plan || !plan.clips.length) return null
    if (selectedClipIdx != null && plan.clips[selectedClipIdx]) return selectedClipIdx
    const atPlayhead = plan.clips.findIndex((c) => playhead >= c.start && playhead < c.end)
    if (atPlayhead >= 0) return atPlayhead
    return 0
  }, [plan, selectedClipIdx, playhead])

  const selectedClip =
    plan && effectiveClipIdx != null && plan.clips[effectiveClipIdx]
      ? plan.clips[effectiveClipIdx]
      : null
  const selectedSceneLabel = selectedClip ? selectedClip.screen.replace('screen_', 'S') : ''

  return (
    <section
      className="timeline-editor"
      onMouseUp={endDrag}
      onMouseLeave={endDrag}
      onMouseMove={onMouseMove}
    >
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,video/*,.png,.jpg,.jpeg,.webp,.mp4,.mov,.webm"
        style={{ display: 'none' }}
        onChange={async (e) => {
          const f = e.target.files?.[0] || null
          e.currentTarget.value = ''
          if (!f || !replaceTargetScreen || !onReplaceClipMedia) return
          await onReplaceClipMedia(replaceTargetScreen, f)
        }}
      />

      {/* Right-click Filmora Context Menu on Video 1 clips */}
      {contextMenu && plan && plan.clips[contextMenu.clipIndex] && (
        <div
          className="tl-context-menu"
          style={{ left: contextMenu.x, top: contextMenu.y }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="tl-ctx-header">
            {plan.clips[contextMenu.clipIndex].screen.replace('screen_', 'Scene ')} ·{' '}
            {plan.clips[contextMenu.clipIndex].filename || 'Clip'}
          </div>
          <button
            type="button"
            onClick={() => {
              elongateClipRight(contextMenu.clipIndex)
              setContextMenu(null)
            }}
          >
            ➡ Elongate Right (Cover Next VO)
          </button>
          <button
            type="button"
            onClick={() => {
              elongateClipLeft(contextMenu.clipIndex)
              setContextMenu(null)
            }}
          >
            ⬅ Elongate Left (Cover Prev VO)
          </button>
          <button
            type="button"
            onClick={() => {
              fitClipToNarration(contextMenu.clipIndex)
              setContextMenu(null)
            }}
          >
            ↔ Fit to Narration &amp; Fill Gap
          </button>
          <button
            type="button"
            onClick={() => {
              splitClipAtPlayhead(contextMenu.clipIndex)
              setContextMenu(null)
            }}
          >
            ✂ Split Clip at Playhead ({fmt(playhead)})
          </button>
          {onReplaceClipMedia && (
            <>
              <button
                type="button"
                onClick={() => {
                  const scr = plan.clips[contextMenu.clipIndex].screen
                  setContextMenu(null)
                  triggerUploadForScreen(scr, 'image')
                }}
              >
                🖼 {plan.clips[contextMenu.clipIndex].kind === 'video' ? 'Replace this Video with an Image…' : 'Replace this Image with another Image…'}
              </button>
              <button
                type="button"
                onClick={() => {
                  const scr = plan.clips[contextMenu.clipIndex].screen
                  setContextMenu(null)
                  triggerUploadForScreen(scr, 'video')
                }}
              >
                🎬 {plan.clips[contextMenu.clipIndex].kind === 'image' ? 'Replace this Image with a Video…' : 'Replace this Video with another Video…'}
              </button>
              <button
                type="button"
                onClick={() => {
                  const scr = plan.clips[contextMenu.clipIndex].screen
                  setContextMenu(null)
                  triggerUploadForScreen(scr, 'any')
                }}
              >
                ⇄ Replace with Image or Video…
              </button>
            </>
          )}
          <button
            type="button"
            className="danger"
            onClick={() => {
              const scr = plan.clips[contextMenu.clipIndex].screen
              setContextMenu(null)
              deleteAndElongatePrevious(scr)
            }}
          >
            ⬅ Delete &amp; Elongate Prev Image Over VO
          </button>
          <button
            type="button"
            className="danger"
            onClick={() => {
              deleteClipAtIndex(contextMenu.clipIndex)
              setContextMenu(null)
            }}
          >
            🗑 Delete Image (Del)
          </button>
        </div>
      )}

      {voMenu && plan && (
        <div
          className="tl-context-menu"
          style={{ left: voMenu.x, top: voMenu.y }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="tl-ctx-header">Voice · {fmt(playhead)}</div>
          <button
            type="button"
            onClick={() => {
              splitVoAtPlayhead(voMenu.id)
              setVoMenu(null)
            }}
          >
            ✂ Split voice at playhead
          </button>
          <button
            type="button"
            className="danger"
            onClick={() => {
              deleteVoPiece(voMenu.id)
              setVoMenu(null)
            }}
          >
            🗑 Delete this voice piece
          </button>
        </div>
      )}

      {/* Filmora-style Timeline Editing Toolbar */}
      <div className="timeline-toolbar">
        <div className="tl-tools">
          <span className="tool-label">Timeline</span>

          <div className="tl-edit-actions">
            <button
              type="button"
              className="tl-action-btn"
              disabled={undoStack.length === 0}
              onClick={handleUndo}
              title="Undo timeline edit (Ctrl+Z)"
            >
              ↶ Undo
            </button>
            <button
              type="button"
              className="tl-action-btn"
              disabled={redoStack.length === 0}
              onClick={handleRedo}
              title="Redo timeline edit (Ctrl+Y)"
            >
              ↷ Redo
            </button>

            <span className="tl-divider" />

            <button
              type="button"
              className="tl-action-btn danger"
              disabled={!selectedClip}
              onClick={() => effectiveClipIdx != null && deleteClipAtIndex(effectiveClipIdx)}
              title="Delete this scene image from Video 1 without changing VO sync (Delete / Backspace)"
            >
              🗑 Delete {selectedSceneLabel || 'Scene'}
            </button>
            <button
              type="button"
              className="tl-action-btn accent"
              disabled={!selectedClip}
              onClick={() => selectedClip && deleteAndElongatePrevious(selectedClip.screen)}
              title="Delete this scene image and pull/stretch the previous screen to cover its timeline narration"
            >
              ⬅ Delete {selectedSceneLabel} &amp; Pull Prev Screen to Cover
            </button>
            <button
              type="button"
              className="tl-action-btn"
              disabled={!selectedClip}
              onClick={() => effectiveClipIdx != null && elongateClipLeft(effectiveClipIdx)}
              title="Pull/stretch this screen leftward to cover previous narration or gap"
            >
              ⬅ Pull Screen Left
            </button>
            <button
              type="button"
              className="tl-action-btn accent"
              disabled={!selectedClip}
              onClick={() => effectiveClipIdx != null && elongateClipRight(effectiveClipIdx)}
              title="Pull/stretch this screen rightward to cover next narration or gap"
            >
              ➡ Pull {selectedSceneLabel} Over Next Scene
            </button>
            <button
              type="button"
              className="tl-action-btn"
              disabled={!selectedClip}
              onClick={() => effectiveClipIdx != null && fitClipToNarration(effectiveClipIdx)}
              title="Snap clip boundaries to cover its narration and any adjacent empty gap"
            >
              ↔ Fit to VO
            </button>
            <button
              type="button"
              className="tl-action-btn"
              disabled={
                !selectedClip ||
                playhead <= selectedClip.start + 0.25 ||
                playhead >= selectedClip.end - 0.25
              }
              onClick={() => effectiveClipIdx != null && splitClipAtPlayhead(effectiveClipIdx)}
              title="Split selected clip at playhead (S)"
            >
              ✂ Split
            </button>
            <button
              type="button"
              className="tl-action-btn"
              disabled={
                !selectedVoId ||
                !shownVoPieces.some(
                  (p) => p.id === selectedVoId && playhead > p.start + 0.12 && playhead < p.end - 0.12,
                )
              }
              onClick={() => selectedVoId && splitVoAtPlayhead(selectedVoId)}
              title="Split the selected voice at the playhead (S). Pictures stay where they are."
            >
              ✂ Split voice
            </button>
            <button
              type="button"
              className="tl-action-btn danger"
              disabled={!selectedVoId}
              onClick={() => selectedVoId && deleteVoPiece(selectedVoId)}
              title="Delete the selected voice piece and leave a gap (Delete). Pictures do not move."
            >
              🗑 Delete voice
            </button>
            {onReplaceClipMedia && (
              <>
                <button
                  type="button"
                  className="tl-action-btn"
                  disabled={!selectedClip}
                  onClick={() => selectedClip && triggerUploadForScreen(selectedClip.screen, 'image')}
                  title="Replace the selected scene (whether it is a video or an image) with an image"
                >
                  🖼 {selectedClip?.kind === 'video' ? 'Replace Video → Image' : 'Replace with Image'}
                </button>
                <button
                  type="button"
                  className="tl-action-btn"
                  disabled={!selectedClip}
                  onClick={() => selectedClip && triggerUploadForScreen(selectedClip.screen, 'video')}
                  title="Replace the selected scene (whether it is an image or a video) with a video"
                >
                  🎬 {selectedClip?.kind === 'image' ? 'Replace Image → Video' : 'Replace with Video'}
                </button>
              </>
            )}
          </div>

          {plan?.manual_override && (
            <span
              className="manual-override-pill"
              title="Manual timeline override is active — Video 1 edits are preserved while VO narration stays locked in sync. Click Auto-align to reset."
            >
              ⚡ Manual Override (VO Sync Locked)
              {onAutoAlign && (
                <button
                  type="button"
                  className="manual-reset-inline"
                  onClick={onAutoAlign}
                  title="Re-run Auto-align from script + VO"
                >
                  ↻ Auto-align
                </button>
              )}
            </span>
          )}

          <button
            type="button"
            className={`tl-action-btn ${plan?.logo_enabled ? 'accent' : ''}`}
            onClick={(e) => toggleTrack('logo_enabled', e)}
            title={plan?.logo_enabled ? 'Deactivate Brand Logo track (remove from timeline)' : 'Activate Brand Logo track (show on timeline)'}
          >
            <NeonIcon name="logo" size={13} tone={plan?.logo_enabled ? 'cyan' : 'ice'} />
            <span>{plan?.logo_enabled ? 'Logo Track: Active' : '+ Add Logo Track'}</span>
          </button>
        </div>
        <div className="zoom">
          <span>Zoom</span>
          <input
            type="range"
            min={4}
            max={48}
            value={pxPerSec}
            onChange={(e) => onPxPerSec(Number(e.target.value))}
          />
        </div>
      </div>

      <div className="timeline-body">
        <div className="track-labels">
          <div className="ruler-spacer" />
          {Boolean(plan?.logo_enabled) && (
            <div className="track-label">
              <span>Video 2 · Logo</span>
              <span className="icons track-toggles">
                <button
                  type="button"
                  className="track-toggle on"
                  onClick={(e) => toggleTrack('logo_enabled', e)}
                  title="Hide Brand Logo"
                >
                  <NeonIcon name="eye" size={12} tone="cyan" />
                </button>
              </span>
            </div>
          )}
          <div className={`track-label ${plan?.video_track_hidden ? 'track-off' : ''} ${plan?.video_track_locked ? 'track-locked' : ''}`}>
            <span>Video 1</span>
            <span className="icons track-toggles">
              <button
                type="button"
                className={`track-toggle ${plan?.video_track_hidden ? 'off' : 'on'}`}
                onClick={(e) => toggleTrack('video_track_hidden', e)}
                title={plan?.video_track_hidden ? 'Show Video 1 in preview' : 'Hide Video 1 in preview'}
              >
                <NeonIcon name={plan?.video_track_hidden ? 'eye-off' : 'eye'} size={12} tone={plan?.video_track_hidden ? 'rose' : 'cyan'} />
              </button>
              <button
                type="button"
                className={`track-toggle ${plan?.video_track_locked ? 'on' : 'off'}`}
                onClick={(e) => toggleTrack('video_track_locked', e)}
                title={plan?.video_track_locked ? 'Unlock Video 1 (allow editing)' : 'Lock Video 1 (prevent accidental edits)'}
              >
                <NeonIcon name={plan?.video_track_locked ? 'lock' : 'unlock'} size={11} tone={plan?.video_track_locked ? 'amber' : 'violet'} />
              </button>
            </span>
          </div>
          <div className={`track-label ${plan?.script_track_hidden ? 'track-off' : ''}`} title="Script stays locked to narration timestamps during manual Video 1 edits">
            <span>Script</span>
            <span className="icons track-toggles">
              <button
                type="button"
                className={`track-toggle ${plan?.script_track_hidden ? 'off' : 'on'}`}
                onClick={(e) => toggleTrack('script_track_hidden', e)}
                title={plan?.script_track_hidden ? 'Show script / subtitles in preview' : 'Hide script / subtitles in preview'}
              >
                <NeonIcon name={plan?.script_track_hidden ? 'eye-off' : 'script'} size={12} tone={plan?.script_track_hidden ? 'rose' : 'ice'} />
              </button>
            </span>
          </div>
          {voSlotBlocks.length >= 2 ? (
            voSlotBlocks.map((b) => (
              <div className={`track-label ${plan?.vo_muted ? 'track-off' : ''}`} key={`lbl-vo-${b.slot}`}>
                <span>Audio · VO {b.slot}</span>
                <span className="icons track-toggles">
                  <button
                    type="button"
                    className={`track-toggle ${plan?.vo_muted ? 'off' : 'on'}`}
                    onClick={(e) => toggleTrack('vo_muted', e)}
                    title={plan?.vo_muted ? 'Unmute VoiceOver' : 'Mute VoiceOver'}
                  >
                    <NeonIcon name={plan?.vo_muted ? 'mute' : 'volume'} size={12} tone={plan?.vo_muted ? 'rose' : 'emerald'} />
                  </button>
                  <button
                    type="button"
                    className={`track-toggle ${plan?.vo_track_locked ? 'on' : 'off'}`}
                    onClick={(e) => toggleTrack('vo_track_locked', e)}
                    title={plan?.vo_track_locked ? 'Unlock voice (allow split, trim, delete)' : 'Lock voice'}
                  >
                    <NeonIcon name={plan?.vo_track_locked ? 'lock' : 'unlock'} size={11} tone={plan?.vo_track_locked ? 'amber' : 'violet'} />
                  </button>
                </span>
              </div>
            ))
          ) : (
            <div className={`track-label ${plan?.vo_muted ? 'track-off' : ''}`} title="Split, trim, or delete a piece of the voice. Pictures stay put.">
              <span>Audio · VO</span>
              <span className="icons track-toggles">
                <button
                  type="button"
                  className={`track-toggle ${plan?.vo_muted ? 'off' : 'on'}`}
                  onClick={(e) => toggleTrack('vo_muted', e)}
                  title={plan?.vo_muted ? 'Unmute VoiceOver in preview' : 'Mute VoiceOver in preview'}
                >
                  <NeonIcon name={plan?.vo_muted ? 'mute' : 'volume'} size={12} tone={plan?.vo_muted ? 'rose' : 'emerald'} />
                </button>
                <button
                  type="button"
                  className={`track-toggle ${plan?.vo_track_locked ? 'on' : 'off'}`}
                  onClick={(e) => toggleTrack('vo_track_locked', e)}
                  title={plan?.vo_track_locked ? 'Unlock voice (allow split, trim, delete)' : 'Lock voice'}
                >
                  <NeonIcon name={plan?.vo_track_locked ? 'lock' : 'unlock'} size={11} tone={plan?.vo_track_locked ? 'amber' : 'violet'} />
                </button>
              </span>
            </div>
          )}
          {plan?.has_poem && (
            <div className={`track-label ${plan?.poem_muted ? 'track-off' : ''}`}>
              <span>Audio · Poem</span>
              <span className="icons track-toggles">
                <button
                  type="button"
                  className={`track-toggle ${plan?.poem_muted ? 'off' : 'on'}`}
                  onClick={(e) => toggleTrack('poem_muted', e)}
                  title={plan?.poem_muted ? 'Unmute Poem / Suno audio' : 'Mute Poem / Suno audio'}
                >
                  <NeonIcon name={plan?.poem_muted ? 'mute' : 'music'} size={12} tone={plan?.poem_muted ? 'rose' : 'violet'} />
                </button>
                <button
                  type="button"
                  className={`track-toggle ${plan?.poem_track_locked ? 'on' : 'off'}`}
                  onClick={(e) => toggleTrack('poem_track_locked', e)}
                  title={plan?.poem_track_locked ? 'Unlock Poem (allow dragging)' : 'Lock Poem position'}
                >
                  <NeonIcon name={plan?.poem_track_locked ? 'lock' : 'unlock'} size={11} tone={plan?.poem_track_locked ? 'amber' : 'violet'} />
                </button>
              </span>
            </div>
          )}
        </div>

        <div className="track-lanes" ref={laneRef} onClick={onLaneClick}>
          <div className="ruler" style={{ width }}>
            {ticks.map((t) => (
              <span key={t} className="tick" style={{ left: t * pxPerSec }}>
                {fmt(t)}
              </span>
            ))}
          </div>

          {Boolean(plan?.logo_enabled) && (
            <div className="lane logo-lane" style={{ width }}>
              <div
                className="clip logo-bar"
                style={{ left: 0, width: Math.max(40, total * pxPerSec) }}
                title="E-Class Brand Logo overlay across all screens (0:00 to end of video)"
              >
                <span>Brand Logo · E-Class™ Digital Education (All Screens · Scale {(plan?.logo_transform?.scale_w ?? 10).toFixed(0)}%)</span>
              </div>
            </div>
          )}

          {/* Video 1 Lane with Filmora Trim Handles + Uncovered Narration Slots */}
          <div
            className={`lane video-lane ${plan?.video_track_hidden ? 'lane-off' : ''} ${plan?.video_track_locked ? 'lane-locked' : ''}`}
            style={{ width }}
            onDragOver={handleVideoLaneDragOver}
            onDrop={(e) => handleVideoLaneDrop(e)}
          >
            {!plan?.clips?.length && !uncoveredNarrations.length && (
              <div className="lane-empty">
                Drag and drop media here after auto-align — or build timeline first
              </div>
            )}

            {/* Render dashed Uncovered Narration Gaps when an image is deleted */}
            {uncoveredNarrations.map((seg) => {
              const gapW = Math.max(18, (seg.end - seg.start) * pxPerSec)
              return (
                <div
                  key={`uncovered-${seg.screen}-${seg.start}`}
                  className="uncovered-vo-slot"
                  style={{ left: seg.start * pxPerSec, width: gapW }}
                  onDragOver={handleVideoLaneDragOver}
                  onDrop={(e) => handleVideoLaneDrop(e, seg.screen)}
                  title={`Uncovered Narration (${seg.screen.replace('screen_', 'Scene ')})\nVO: "${seg.vo_text || seg.script_text}"\nDrag an adjacent image's [ ] handle over this gap, click '⬅ Cover with Prev', or drop a new image here.`}
                >
                  <span className="uncovered-vo-lbl">
                    💭 {seg.screen.replace('screen_', 'S')} Uncovered VO
                  </span>
                  {gapW >= 95 && (
                    <div className="uncovered-vo-btns">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation()
                          deleteAndElongatePrevious(seg.screen)
                        }}
                        title="Elongate previous image to cover this narration"
                      >
                        ⬅ Cover
                      </button>
                      {onReplaceClipMedia && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation()
                            triggerUploadForScreen(seg.screen)
                          }}
                          title="Upload replacement image for this scene"
                        >
                          + Img
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )
            })}

            {plan?.clips.map((c, i) => (
              <ClipBlock
                key={`${c.screen}-${i}`}
                api={api}
                projectId={projectId}
                clip={c}
                pxPerSec={pxPerSec}
                selected={effectiveClipIdx === i}
                color={c.fit === 'missing' ? 'blank' : c.kind === 'image' ? 'image' : 'video'}
                localThumbUrl={
                  (c.media_id &&
                    (localThumbUrls[c.media_id] ||
                      (c.kind === 'image' ? localMediaUrls[c.media_id] : ''))) ||
                  ''
                }
                onSelect={(e) => {
                  e.stopPropagation()
                  setSelectedClipIdx(i)
                  setSelectedVoId(null)
                  // Jump the playhead onto this clip so the preview + Scene/VO info reflect it (same as scrubbing)
                  if (playhead < c.start || playhead >= c.end) onPlayhead(c.start + 0.01)
                }}
                onContextMenu={(e) => {
                  e.preventDefault()
                  e.stopPropagation()
                  setSelectedClipIdx(i)
                  setContextMenu({ x: e.clientX, y: e.clientY, clipIndex: i })
                }}
                onMouseDownBody={(e) => beginDrag(e, 'move', i, c.start, c.end)}
                onMouseDownLeftHandle={(e) => beginDrag(e, 'resize-left', i, c.start, c.end)}
                onMouseDownRightHandle={(e) => beginDrag(e, 'resize-right', i, c.start, c.end)}
                onNudgeLeft={() => nudgeClip(i, -0.25)}
                onNudgeRight={() => nudgeClip(i, 0.25)}
                onDropMedia={(e) => handleVideoLaneDrop(e, c.screen)}
              />
            ))}

            {dragTooltip && (
              <div className="tl-drag-tooltip" style={{ left: Math.max(8, dragTooltip.x) }}>
                {dragTooltip.text}
              </div>
            )}
          </div>

          {/* Script Lane (Anchored to narrationSegments so deleting/elongating Video 1 never breaks script sync) */}
          <div className={`lane script-lane ${plan?.script_track_hidden ? 'lane-off' : ''}`} style={{ width }}>
            {narrSegments.map((seg, i) => {
              const text = seg.script_text || seg.vo_text || ''
              const segDur = Math.max(0.2, seg.end - seg.start)
              const bar = Math.max(2, segDur * pxPerSec)
              let room = bar
              if (text) {
                let end = seg.end
                for (let j = i + 1; j < narrSegments.length; j++) {
                  const next = narrSegments[j]
                  if (next.script_text || next.vo_text) break
                  end = next.end
                }
                room = Math.max(bar, (end - seg.start) * pxPerSec - 8)
              }
              return (
                <div
                  key={`script-${i}`}
                  className="clip script"
                  style={{ left: seg.start * pxPerSec, width: bar, zIndex: text ? 2 : 1 }}
                  title={`${seg.screen.replace('screen_', 'Scene ')} (${fmt(seg.start)}–${fmt(seg.end)}): ${text || 'Pause'}`}
                >
                  <span style={{ width: text ? room : bar }}>{text || 'Pause'}</span>
                </div>
              )
            })}
          </div>

          {(voSlotBlocks.length >= 2 ? voSlotBlocks.map((b) => b.slot) : [0]).map((slotKey) => {
            const lanePieces = slotKey === 0 ? shownVoPieces : shownVoPieces.filter((p) => p.slot === slotKey)
            return (
              <div
                className={`lane audio-lane ${plan?.vo_muted ? 'lane-off' : ''} ${plan?.vo_track_locked ? 'lane-locked' : ''}`}
                style={{ width }}
                key={`lane-vo-${slotKey}`}
              >
                {lanePieces.map((p) => {
                  const bar = Math.max(8, (p.end - p.start) * pxPerSec)
                  const label = p.filename || 'Voice'
                  return (
                    <div
                      key={p.id}
                      className={`clip audio narration vo-slot vo-slot-${((p.slot - 1) % 4) + 1} ${selectedVoId === p.id ? 'selected' : ''}`}
                      style={{ left: p.start * pxPerSec, width: bar, zIndex: selectedVoId === p.id ? 5 : 2 }}
                      title={`${label}\n${fmt(p.start)}–${fmt(p.end)}\nDrag either end to trim. Press S to split at the playhead. Delete removes this piece and leaves a gap.`}
                      onClick={(e) => {
                        e.stopPropagation()
                        setSelectedVoId(p.id)
                        setSelectedClipIdx(null)
                        if (playhead < p.start || playhead >= p.end) onPlayhead(p.start + 0.01)
                      }}
                      onContextMenu={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        setSelectedVoId(p.id)
                        setSelectedClipIdx(null)
                        setVoMenu({ x: e.clientX, y: e.clientY, id: p.id })
                      }}
                      onMouseDown={(e) => {
                        if ((e.target as HTMLElement).classList.contains('clip-trim-handle')) return
                        beginDrag(e, 'vo-move', -1, p.start, p.end, p.id)
                      }}
                    >
                      <div
                        className="clip-trim-handle left"
                        onMouseDown={(e) => beginDrag(e, 'vo-left', -1, p.start, p.end, p.id)}
                      />
                      <span style={{ width: bar }}>{label}</span>
                      <div
                        className="clip-trim-handle right"
                        onMouseDown={(e) => beginDrag(e, 'vo-right', -1, p.start, p.end, p.id)}
                      />
                    </div>
                  )
                })}
                {!lanePieces.length && (
                  <div className="lane-empty subtle">{slotKey === 0 ? 'Upload narration VO' : 'Voice gap'}</div>
                )}
              </div>
            )
          })}

          {plan?.has_poem && (
            <div className={`lane audio-lane poem ${plan?.poem_muted ? 'lane-off' : ''} ${plan?.poem_track_locked ? 'lane-locked' : ''}`} style={{ width }}>
              {poemBlock ? (
                <div
                  className="clip audio poem"
                  style={{
                    left: poemBlock.start * pxPerSec,
                    width: Math.max(24, (poemBlock.end - poemBlock.start) * pxPerSec),
                  }}
                  onMouseDown={(e) =>
                    beginDrag(e, 'poem', 0, poemBlock.start, poemBlock.end)
                  }
                  title="Drag to shift poem / Suno start"
                >
                  <span>{poemBlock.label}</span>
                </div>
              ) : (
                <div className="lane-empty subtle">
                  Upload poem VO to place on timeline
                </div>
              )}
            </div>
          )}

          <PlayheadMark pxPerSec={pxPerSec} />
        </div>
      </div>
    </section>
  )
}

function PlayheadMark({ pxPerSec }: { pxPerSec: number }) {
  const t = useSyncExternalStore(playheadBus.subscribe, playheadBus.get, playheadBus.get)
  return <div className="playhead" style={{ left: t * pxPerSec }} />
}

function ClipBlock({
  api = '',
  projectId,
  clip,
  pxPerSec,
  selected,
  color,
  localThumbUrl = '',
  onSelect,
  onContextMenu,
  onMouseDownBody,
  onMouseDownLeftHandle,
  onMouseDownRightHandle,
  onNudgeLeft,
  onNudgeRight,
  onDropMedia,
}: {
  api?: string
  projectId?: string | null
  clip: TimelineClip
  pxPerSec: number
  selected?: boolean
  color: string
  localThumbUrl?: string
  onSelect: (e: ReactMouseEvent) => void
  onContextMenu: (e: ReactMouseEvent) => void
  onMouseDownBody: (e: ReactMouseEvent) => void
  onMouseDownLeftHandle: (e: ReactMouseEvent) => void
  onMouseDownRightHandle: (e: ReactMouseEvent) => void
  onNudgeLeft: () => void
  onNudgeRight: () => void
  onDropMedia: (e: ReactDragEvent) => void
}) {
  const width = Math.max(6, clip.duration * pxPerSec)
  const wide = width >= 58
  const showThumb = Boolean(
    (localThumbUrl || projectId) && clip.media_id && clip.fit !== 'missing' && width >= 34,
  )
  const thumbSrc =
    localThumbUrl ||
    (projectId && clip.media_id ? `${api}/api/projects/${projectId}/media-thumb/${clip.media_id}` : '')

  return (
    <div
      className={`clip ${color} ${showThumb ? 'has-thumb' : ''} ${selected ? 'selected' : ''}`}
      style={{ left: clip.start * pxPerSec, width }}
      onClick={onSelect}
      onContextMenu={onContextMenu}
      onMouseDown={onMouseDownBody}
      onDragOver={(e) => {
        if (e.dataTransfer.types.includes('application/x-dgs-media')) {
          e.preventDefault()
          e.dataTransfer.dropEffect = 'copy'
        }
      }}
      onDrop={onDropMedia}
      title={`${clip.screen} · ${clip.filename || 'Blank'} (${fmt(clip.start)}–${fmt(clip.end)} · ${clip.duration.toFixed(1)}s)\nDrag [ or ] edges to elongate · Press Delete to remove`}
    >
      {/* Left Filmora Trim / Elongate Handle `[` */}
      <div
        className="clip-trim-handle left"
        onMouseDown={onMouseDownLeftHandle}
        title="Drag left edge [ to elongate or trim start time"
      />

      {showThumb && thumbSrc && (
        <img
          className="clip-thumb"
          src={thumbSrc}
          alt=""
          loading="lazy"
          onError={(e) => {
            e.currentTarget.style.display = 'none'
          }}
        />
      )}
      {wide && (
        <button
          type="button"
          className="nudge"
          onClick={(e) => {
            e.stopPropagation()
            onNudgeLeft()
          }}
        >
          ‹
        </button>
      )}
      <span>
        {clip.fit === 'missing'
          ? `Blank · ${clip.screen.replace('screen_', 'S')}`
          : `${clip.screen.replace('screen_', 'S')}${clip.kind === 'image' ? ' ▭' : ' ▶'}`}
      </span>
      {wide && (
        <button
          type="button"
          className="nudge"
          onClick={(e) => {
            e.stopPropagation()
            onNudgeRight()
          }}
        >
          ›
        </button>
      )}

      {/* Right Filmora Trim / Elongate Handle `]` */}
      <div
        className="clip-trim-handle right"
        onMouseDown={onMouseDownRightHandle}
        title="Drag right edge ] to elongate image over adjacent narration"
      />
    </div>
  )
}
