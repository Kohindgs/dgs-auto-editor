/**
 * Live Source-Folder Sync & Image/Media Renumbering.
 *
 * Ensures that any replacement or edit made by the software (OCR auto-swaps) or by the user
 * on the timeline / in the software (manual image/video swap, upload/replace media,
 * delete & elongate previous/next clip, delete clip, script text edit, VO replacement)
 * is also applied directly inside the local folder the files were pulled from.
 *
 * Chrome / Edge: writes changes in place in the user's folder (File System Access API),
 *                preserving the original untouched files in a "_dgs_backup_<project>" subfolder.
 * Firefox / others: downloads a ZIP of the updated folder.
 */
import type { MediaItem, NarrationSegment, TimelineClip } from './types'

export type AutoSwapRecord = { screen: string; mediaId: string; filename: string }
export type RenameStep = {
  mediaId: string
  from: string
  to: string
  screen: string
  action?: 'rename' | 'copy' | 'replace' | 'delete'
}

export type FsFileHandle = {
  name?: string
  getFile: () => Promise<File>
  createWritable: () => Promise<{ write: (d: BlobPart) => Promise<void>; close: () => Promise<void> }>
}

export type FsDirHandle = {
  name: string
  kind?: 'directory'
  getFileHandle: (name: string, opts?: { create?: boolean }) => Promise<FsFileHandle>
  getDirectoryHandle: (name: string, opts?: { create?: boolean }) => Promise<FsDirHandle>
  removeEntry: (name: string) => Promise<void>
  values?: () => AsyncIterable<{ kind: 'file' | 'directory'; name: string }>
  entries?: () => AsyncIterable<[string, { kind: 'file' | 'directory'; name: string }]>
  queryPermission?: (opts: { mode: 'read' | 'readwrite' }) => Promise<'granted' | 'denied' | 'prompt'>
  requestPermission?: (opts: { mode: 'read' | 'readwrite' }) => Promise<'granted' | 'denied' | 'prompt'>
}

const SWAP_KEY = (pid: string) => `dgs-autoswaps:${pid}`
const IDB_HANDLE_DB = 'dgs_folder_handles_v1'
const IDB_HANDLE_STORE = 'handles'

let handleDbPromise: Promise<IDBDatabase | null> | null = null

function openHandleDb(): Promise<IDBDatabase | null> {
  if (typeof indexedDB === 'undefined') return Promise.resolve(null)
  if (!handleDbPromise) {
    handleDbPromise = new Promise((resolve) => {
      try {
        const req = indexedDB.open(IDB_HANDLE_DB, 1)
        req.onupgradeneeded = () => {
          const db = req.result
          if (!db.objectStoreNames.contains(IDB_HANDLE_STORE)) {
            db.createObjectStore(IDB_HANDLE_STORE)
          }
        }
        req.onsuccess = () => resolve(req.result)
        req.onerror = () => {
          handleDbPromise = null
          resolve(null)
        }
      } catch {
        handleDbPromise = null
        resolve(null)
      }
    })
  }
  return handleDbPromise
}

export async function saveDirHandleToIdb(key: string, handle: FsDirHandle, fallbackKey?: string): Promise<void> {
  const db = await openHandleDb()
  if (!db) return
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(IDB_HANDLE_STORE, 'readwrite')
      const store = tx.objectStore(IDB_HANDLE_STORE)
      store.put(handle, key)
      if (fallbackKey && fallbackKey !== key && !fallbackKey.startsWith('pc:dir:')) {
        store.put(handle, fallbackKey)
      }
      tx.oncomplete = () => resolve()
      tx.onerror = () => resolve()
    } catch {
      resolve()
    }
  })
}

export async function loadDirHandleFromIdb(key: string, fallbackKey?: string): Promise<FsDirHandle | null> {
  const db = await openHandleDb()
  if (!db) return null
  const getOne = (k: string): Promise<FsDirHandle | null> =>
    new Promise((resolve) => {
      try {
        const tx = db.transaction(IDB_HANDLE_STORE, 'readonly')
        const req = tx.objectStore(IDB_HANDLE_STORE).get(k)
        req.onsuccess = () => resolve((req.result as FsDirHandle) || null)
        req.onerror = () => resolve(null)
      } catch {
        resolve(null)
      }
    })
  const primary = await getOne(key)
  if (primary) return primary
  if (fallbackKey && !fallbackKey.startsWith('pc:dir:')) return await getOne(fallbackKey)
  return null
}

export async function hasReadWritePermission(handle: FsDirHandle | null, requestIfPrompt = false): Promise<boolean> {
  if (!handle) return false
  try {
    if (typeof handle.queryPermission === 'function') {
      const st = await handle.queryPermission({ mode: 'readwrite' })
      if (st === 'granted') return true
      if (requestIfPrompt && typeof handle.requestPermission === 'function') {
        const req = await handle.requestPermission({ mode: 'readwrite' })
        return req === 'granted'
      }
      return false
    }
    return true
  } catch {
    return false
  }
}

export function loadSwaps(pid: string | null): AutoSwapRecord[] {
  if (!pid) return []
  try {
    return JSON.parse(localStorage.getItem(SWAP_KEY(pid)) || '[]') as AutoSwapRecord[]
  } catch {
    return []
  }
}

export function saveSwaps(pid: string | null, swaps: AutoSwapRecord[]) {
  if (!pid) return
  try {
    if (swaps.length) localStorage.setItem(SWAP_KEY(pid), JSON.stringify(swaps))
    else localStorage.removeItem(SWAP_KEY(pid))
  } catch {
    /* ignore */
  }
}

export function sceneNo(screen: string): number | null {
  const m = /(\d+)$/.exec(screen || '')
  return m ? parseInt(m[1], 10) : null
}

/** "45.png" → "42.png", "Scene 45.png" → "Scene 42.png" (replaces the last number in the name). */
export function renamedFor(filename: string, n: number, referenceNames?: string[]): string | null {
  const dot = filename.lastIndexOf('.')
  const stem = dot > 0 ? filename.slice(0, dot) : filename
  const ext = dot > 0 ? filename.slice(dot) : '.png'
  const m = /(\d+)(?!.*\d)/.exec(stem)
  if (m) {
    return `${stem.slice(0, m.index)}${n}${stem.slice(m.index + m[1].length)}${ext}`
  }
  // If an uploaded replacement file had no number in its name (e.g. "fixed_card.png"),
  // match the naming pattern of the existing folder ("Scene N.ext" vs "N.ext")
  const hasScenePrefix = (referenceNames || []).some((r) => /^scene[\s_-]*\d+/i.test(r))
  return hasScenePrefix ? `Scene ${n}${ext}` : `${n}${ext}`
}

/**
 * Build the complete folder sync plan from BOTH auto-swaps AND manual timeline/clip changes:
 * - Auto-swapped or manually reassigned images/videos on scenes (`screen_42` showing `45.png` → `42.png`)
 * - Elongated clips where an adjacent scene's image was stretched to cover another scene's narration (`copy`)
 * - Uploaded replacement images/videos (`replace`)
 */
export function buildRenamePlan(
  swaps: AutoSwapRecord[],
  clips: TimelineClip[],
  allImageNames: string[],
  narrationSegments?: NarrationSegment[],
  mediaList?: MediaItem[],
): { steps: RenameStep[]; skipped: string[] } {
  const skipped: string[] = []
  const steps: RenameStep[] = []
  const byId = new Map<string, MediaItem>()
  for (const m of mediaList || []) byId.set(m.id, m)

  const usesByMedia = new Map<string, Set<string>>()
  for (const c of clips) {
    if (!c.media_id) continue
    if (!usesByMedia.has(c.media_id)) usesByMedia.set(c.media_id, new Set())
    usesByMedia.get(c.media_id)!.add(c.screen)
  }

  const addedTargetKeys = new Set<string>()
  const addStep = (st: RenameStep) => {
    const k = st.to.toLowerCase()
    if (addedTargetKeys.has(k)) return
    addedTargetKeys.add(k)
    steps.push(st)
  }

  // 1. Check every clip currently on the timeline (catches both OCR auto-swaps and manual timeline swaps/replacements)
  for (const c of clips) {
    if (!c.media_id) continue
    const m = byId.get(c.media_id)
    const curFilename = m?.filename || c.filename || ''
    if (!curFilename) continue
    if (c.kind === 'video') continue
    const n = sceneNo(c.screen)
    if (n == null) continue
    const to = renamedFor(curFilename, n, allImageNames)
    if (!to || to.toLowerCase() === curFilename.toLowerCase()) continue
    const useCount = usesByMedia.get(c.media_id)?.size || 1
    addStep({
      mediaId: c.media_id,
      from: curFilename,
      to,
      screen: c.screen,
      action: useCount > 1 ? 'copy' : 'rename',
    })
  }

  // 2. Also include any explicit swap records still active on the timeline
  for (const s of swaps) {
    const stillThere = clips.some((c) => c.screen === s.screen && c.media_id === s.mediaId)
    if (!stillThere) continue
    const n = sceneNo(s.screen)
    const to = n != null ? renamedFor(s.filename, n, allImageNames) : null
    if (!to || to.toLowerCase() === s.filename.toLowerCase()) continue
    const useCount = usesByMedia.get(s.mediaId)?.size || 1
    addStep({
      mediaId: s.mediaId,
      from: s.filename,
      to,
      screen: s.screen,
      action: useCount > 1 ? 'copy' : 'rename',
    })
  }

  // 3. Check if any scene's clip was deleted and covered by elongating a neighboring imageclip over its narration
  if (narrationSegments && narrationSegments.length > 0) {
    const screensWithOwnClip = new Set(clips.map((c) => c.screen))
    for (const seg of narrationSegments) {
      if (screensWithOwnClip.has(seg.screen)) continue
      const n = sceneNo(seg.screen)
      if (n == null) continue
      const mid = (seg.start + seg.end) / 2
      const coveringClip = clips.find((c) => c.kind !== 'video' && c.media_id && mid >= c.start && mid <= c.end)
      if (coveringClip && coveringClip.media_id) {
        const m = byId.get(coveringClip.media_id)
        const curFilename = m?.filename || coveringClip.filename || ''
        if (!curFilename) continue
        const to = renamedFor(curFilename, n, allImageNames)
        if (to && to.toLowerCase() !== curFilename.toLowerCase()) {
          addStep({
            mediaId: coveringClip.media_id,
            from: curFilename,
            to,
            screen: seg.screen,
            action: 'copy',
          })
        }
      }
    }
  }

  return { steps, skipped }
}

export function canRenameInPlace(): boolean {
  return typeof (window as unknown as { showDirectoryPicker?: unknown }).showDirectoryPicker === 'function'
}

async function writeFile(dir: FsDirHandle, name: string, data: ArrayBuffer | Blob) {
  const fh = await dir.getFileHandle(name, { create: true })
  const w = await fh.createWritable()
  await w.write(data)
  await w.close()
}

async function fileExistsInDir(dir: FsDirHandle, name: string): Promise<boolean> {
  try {
    await dir.getFileHandle(name)
    return true
  } catch {
    return false
  }
}

/**
 * Backup `name` inside `dir/_dgs_backup` only if not already backed up there,
 * so the very first original file from the user's folder is never overwritten by later edits.
 */
export async function backupFileOnceInDir(dir: FsDirHandle, backupDirName: string, filename: string): Promise<void> {
  try {
    const origFh = await dir.getFileHandle(filename)
    const backup = await dir.getDirectoryHandle(backupDirName, { create: true })
    const alreadyBackedUp = await fileExistsInDir(backup, filename)
    if (!alreadyBackedUp) {
      const origFile = await origFh.getFile()
      await writeFile(backup, filename, await origFile.arrayBuffer())
    }
  } catch {
    /* file didn't exist in dir yet — nothing to back up */
  }
}

/**
 * Write a single replacement or updated file (image, video, script .xlsx, VO .mp3, .srt, .wfp)
 * directly into `dir` after backing up any existing file of the same name.
 */
export async function writeReplacedFileToFolder(
  dir: FsDirHandle,
  filename: string,
  data: Blob | ArrayBuffer,
  backupDirName = '_dgs_backup_originals',
): Promise<boolean> {
  try {
    const ok = await hasReadWritePermission(dir, false)
    if (!ok) return false
    await backupFileOnceInDir(dir, backupDirName, filename)
    await writeFile(dir, filename, data)
    return true
  } catch {
    return false
  }
}

/**
 * Open a folder with readwrite access via File System Access API and read all matching media files.
 * If the user selects a parent chapter folder that contains a "Scene Images" or "Scene Videos" subfolder,
 * automatically resolves both the parent chapter handle and the media subfolder handle.
 */
export async function pickMediaDirectoryHandle(
  kind: 'images' | 'videos',
): Promise<{
  files: File[]
  mediaDirHandle: FsDirHandle
  chapterDirHandle: FsDirHandle | null
} | null> {
  if (!canRenameInPlace()) return null
  const picker = (window as unknown as {
    showDirectoryPicker: (o: { id?: string; mode: 'readwrite' }) => Promise<FsDirHandle>
  }).showDirectoryPicker

  const picked = await picker({
    mode: 'readwrite',
  })

  const allowedExt =
    kind === 'images'
      ? /\.(png|jpe?g|webp|bmp|gif|svg|avif|jfif|heic)$/i
      : /\.(mp4|mov|webm|mkv|avi|m4v|3gp|ts|mts|flv|wmv|mpe?g)$/i

  const readMatchingFiles = async (dir: FsDirHandle): Promise<File[]> => {
    const out: File[] = []
    if (typeof dir.values === 'function') {
      for await (const entry of dir.values()) {
        if (entry.kind === 'file' && allowedExt.test(entry.name)) {
          const fh = await dir.getFileHandle(entry.name)
          out.push(await fh.getFile())
        }
      }
    }
    return out
  }

  let files = await readMatchingFiles(picked)
  let mediaDirHandle = picked
  let chapterDirHandle: FsDirHandle | null = null

  // If the user picked the root Chapter folder (which has a "Scene Images" / "Scene Videos" subfolder),
  // step into that subfolder automatically while keeping `chapterDirHandle` for script/VO sync!
  if (files.length === 0 && typeof picked.values === 'function') {
    for await (const entry of picked.values()) {
      if (entry.kind === 'directory' && !entry.name.startsWith('_dgs_backup') && !entry.name.startsWith('.')) {
        const sub = await picked.getDirectoryHandle(entry.name)
        const subFiles = await readMatchingFiles(sub)
        if (subFiles.length > files.length) {
          files = subFiles
          mediaDirHandle = sub
          chapterDirHandle = picked
        }
      }
    }
  }

  return { files, mediaDirHandle, chapterDirHandle }
}

/**
 * Apply `steps` in place inside `existingDir` (if provided and permitted) or prompt for the folder.
 * Uses `localFileBlobs` (in-memory/IndexedDB Blobs keyed by mediaId or lowercase filename) first,
 * falling back to reading from `dir` on disk, so circular swaps and multi-scene copies always succeed.
 */
export async function renameInFolder(
  steps: RenameStep[],
  existingDir?: FsDirHandle | null,
  localFileBlobs?: Map<string, Blob>,
  promptIfNeeded = true,
): Promise<{ folder: string; backup: string; buffers: Map<string, ArrayBuffer>; dirHandle: FsDirHandle }> {
  let dir = existingDir || null
  if (dir) {
    const ok = await hasReadWritePermission(dir, promptIfNeeded)
    if (!ok) dir = null
  }
  if (!dir) {
    if (!promptIfNeeded) {
      throw new Error('Folder permission requires user click')
    }
    const picker = (window as unknown as {
      showDirectoryPicker: (o: { id?: string; mode: 'readwrite' }) => Promise<FsDirHandle>
    }).showDirectoryPicker
    dir = await picker({ id: 'dgs-scene-images', mode: 'readwrite' })
  }

  // Read every source into memory first (from localFileBlobs or from the directory on disk)
  const buffers = new Map<string, ArrayBuffer>()
  const missing: string[] = []
  for (const st of steps) {
    if (buffers.has(st.from)) continue
    try {
      const memBlob =
        localFileBlobs?.get(st.mediaId) ||
        localFileBlobs?.get(st.from.toLowerCase()) ||
        null
      if (memBlob) {
        buffers.set(st.from, await memBlob.arrayBuffer())
      } else {
        const f = await (await dir.getFileHandle(st.from)).getFile()
        buffers.set(st.from, await f.arrayBuffer())
      }
    } catch {
      missing.push(st.from)
    }
  }
  if (missing.length) {
    throw new Error(
      `"${dir.name}" doesn't contain ${missing.slice(0, 4).join(', ')}${missing.length > 4 ? '…' : ''}. Please pick the Scene Images folder you imported.`,
    )
  }

  const backupName = `_dgs_backup_originals`
  for (const st of steps) {
    await backupFileOnceInDir(dir, backupName, st.from)
    await backupFileOnceInDir(dir, backupName, st.to)
  }

  const backup = await dir.getDirectoryHandle(backupName, { create: true })
  const stamp = new Date().toISOString().replace('T', ' ').slice(0, 19)
  const note = steps
    .map((s) => `[${stamp}] ${s.action === 'copy' ? 'COPY' : 'RENAME'} ${s.from} -> ${s.to} (${s.screen.replace('screen_', 'Scene ')})`)
    .join('\r\n')
  await writeFile(
    backup,
    'RENAMES.txt',
    new TextEncoder().encode(`DGS Auto Editor — Folder Sync Log\r\n\r\n${note}\r\n`).buffer as ArrayBuffer,
  )

  // Write every target
  for (const st of steps) {
    const buf = buffers.get(st.from)
    if (buf) await writeFile(dir, st.to, buf)
  }

  // Remove old source filenames only when action === 'rename' and no step writes to `st.from`
  const targets = new Set(steps.map((s) => s.to.toLowerCase()))
  const copiedSources = new Set(steps.filter((s) => s.action === 'copy').map((s) => s.from.toLowerCase()))
  for (const st of steps) {
    const fromLow = st.from.toLowerCase()
    if (st.action !== 'copy' && !targets.has(fromLow) && !copiedSources.has(fromLow)) {
      try {
        await dir.removeEntry(st.from)
      } catch {
        /* ignore */
      }
    }
  }
  return { folder: dir.name, backup: backupName, buffers, dirHandle: dir }
}
