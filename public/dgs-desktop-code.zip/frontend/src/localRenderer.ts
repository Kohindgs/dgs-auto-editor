import { Muxer, ArrayBufferTarget } from 'mp4-muxer';
import type { LogoTransform, NarrationSegment, TimelineClip, VoPiece, VoiceoverSlot } from './types';
import { slotOrigin } from './voPieces';
import { computeLogoBox } from './types';

export type LocalRenderClip = TimelineClip & { source_out?: number | null };

export interface LocalRenderOptions {
  clips: LocalRenderClip[];
  narrationSegments?: NarrationSegment[];
  voPieces?: VoPiece[];
  voSlots?: VoiceoverSlot[];
  totalDuration: number;
  width: number;
  height: number;
  fps: number;
  videoBitrateKbps: number;
  bitrateMode: 'vbr' | 'cbr';
  audioBitrateKbps: number;
  audioSampleRate: number;
  audioChannels: 1 | 2;
  exportVideoOnly: boolean;
  resolveMediaUrl: (clip: LocalRenderClip) => string | null;
  logoUrl: string | null;
  logoTransform?: LogoTransform;
  voBlobs: Array<File | Blob>;
  voFallbackUrl: string | null;
  poemBlob: File | Blob | null;
  poemFallbackUrl: string | null;
  hasPoem: boolean;
  poemStartTime: number;
  poemEndTime: number;
  isCancelled: () => boolean;
  onProgress: (
    percent: number,
    message: string,
    detail?: { done: number; total: number; screen: string; mediaId: string | null },
  ) => void;
}

export interface LocalRenderResult {
  blob: Blob;
  sizeMb: number;
  actualTotalKbps: number;
  actualVideoKbps: number;
  durationSec: number;
}

export function isLocalWebCodecsSupported(): boolean {
  return (
    typeof window !== 'undefined' &&
    typeof (window as unknown as { VideoEncoder?: unknown }).VideoEncoder !== 'undefined' &&
    typeof (window as unknown as { VideoFrame?: unknown }).VideoFrame !== 'undefined'
  );
}

function loadImageElement(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error(`Failed to load image: ${url}`));
    img.src = url;
  });
}

function loadVideoElement(url: string): Promise<HTMLVideoElement> {
  return new Promise((resolve, reject) => {
    const vid = document.createElement('video');
    vid.crossOrigin = 'anonymous';
    vid.muted = true;
    vid.playsInline = true;
    vid.preload = 'auto';
    let settled = false;
    const finish = (ok: boolean, err?: Error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      if (ok) resolve(vid);
      else reject(err || new Error('Video load failed'));
    };
    const timer = setTimeout(() => finish(false, new Error('Video load timeout')), 12000);
    vid.onloadeddata = () => finish(true);
    vid.onerror = () => finish(false, new Error(`Video error: ${url}`));
    vid.src = url;
    vid.load();
  });
}

function seekVideoWithTimeout(vid: HTMLVideoElement, targetSec: number, timeoutMs = 400): Promise<void> {
  return new Promise((resolve) => {
    const clamped = Math.max(0, Math.min(Number.isFinite(vid.duration) ? Math.max(0, vid.duration - 0.01) : targetSec, targetSec));
    if (Math.abs(vid.currentTime - clamped) < 0.008 && vid.readyState >= 2) {
      resolve();
      return;
    }
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(t);
      vid.removeEventListener('seeked', finish);
      resolve();
    };
    const t = setTimeout(finish, timeoutMs);
    vid.addEventListener('seeked', finish, { once: true });
    try {
      vid.currentTime = clamped;
    } catch {
      finish();
    }
  });
}

function drawFittedSourceAndLogo(
  ctx: CanvasRenderingContext2D,
  canvasW: number,
  canvasH: number,
  source: HTMLImageElement | HTMLVideoElement | null,
  srcW: number,
  srcH: number,
  logoImg: HTMLImageElement | null,
  logoTransform?: LogoTransform,
) {
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, canvasW, canvasH);
  if (source && srcW > 0 && srcH > 0) {
    const scale = Math.min(canvasW / srcW, canvasH / srcH);
    const drawW = Math.round(srcW * scale);
    const drawH = Math.round(srcH * scale);
    const dx = Math.round((canvasW - drawW) / 2);
    const dy = Math.round((canvasH - drawH) / 2);
    ctx.drawImage(source, dx, dy, drawW, drawH);
  }
  if (logoImg && logoImg.naturalWidth > 0 && logoImg.naturalHeight > 0) {
    const box = computeLogoBox(
      logoTransform,
      canvasW,
      canvasH,
      logoImg.naturalWidth,
      logoImg.naturalHeight,
    );
    if (Math.abs(box.rotateDeg) > 0.01) {
      ctx.save();
      const cx = box.leftPx + box.logoW / 2;
      const cy = box.topPx + box.logoH / 2;
      ctx.translate(cx, cy);
      ctx.rotate((box.rotateDeg * Math.PI) / 180);
      ctx.drawImage(logoImg, -box.logoW / 2, -box.logoH / 2, box.logoW, box.logoH);
      ctx.restore();
    } else {
      ctx.drawImage(logoImg, box.leftPx, box.topPx, box.logoW, box.logoH);
    }
  }
}

async function decodeBlobOrUrlToAudioBuffer(
  decodeCtx: BaseAudioContext,
  blobOrFile: Blob | null,
  fallbackUrl: string | null,
): Promise<AudioBuffer | null> {
  try {
    let ab: ArrayBuffer | null = null;
    if (blobOrFile) {
      ab = await blobOrFile.arrayBuffer();
    } else if (fallbackUrl) {
      const resp = await fetch(fallbackUrl);
      if (!resp.ok) return null;
      ab = await resp.arrayBuffer();
    }
    if (!ab || ab.byteLength === 0) return null;
    return await decodeCtx.decodeAudioData(ab.slice(0));
  } catch {
    return null;
  }
}

async function buildMixedTimelineAudioBuffer(opts: LocalRenderOptions): Promise<AudioBuffer | null> {
  if (opts.exportVideoOnly) return null;
  const hasAnyVoSource = opts.voBlobs.length > 0 || Boolean(opts.voFallbackUrl);
  const hasAnyPoemSource = opts.hasPoem && (Boolean(opts.poemBlob) || Boolean(opts.poemFallbackUrl));
  if (!hasAnyVoSource && !hasAnyPoemSource) return null;

  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!AudioCtx || typeof OfflineAudioContext === 'undefined') return null;

  const sr = opts.audioSampleRate || 44100;
  const ch = opts.audioChannels || 2;
  const totalSec = Math.max(1, opts.totalDuration);
  const totalSamples = Math.ceil(totalSec * sr);

  const decodeCtx = new AudioCtx({ sampleRate: sr });
  try {
    // 1. Decode voiceover (merge multiple VO parts in sequence if multiple files were selected)
    let voBuffers: AudioBuffer[] = [];
    if (opts.voBlobs.length > 0) {
      for (const f of opts.voBlobs) {
        const b = await decodeBlobOrUrlToAudioBuffer(decodeCtx, f, null);
        if (b) voBuffers.push(b);
      }
    } else if (opts.voFallbackUrl) {
      const b = await decodeBlobOrUrlToAudioBuffer(decodeCtx, null, opts.voFallbackUrl);
      if (b) voBuffers.push(b);
    }

    let poemBuffer: AudioBuffer | null = null;
    if (hasAnyPoemSource) {
      poemBuffer = await decodeBlobOrUrlToAudioBuffer(decodeCtx, opts.poemBlob, opts.poemFallbackUrl);
    }

    if (voBuffers.length === 0 && !poemBuffer) return null;

    const offline = new OfflineAudioContext(ch, totalSamples, sr);

    // Combine voBuffers into a single virtual timeline buffer if multiple VO slots exist
    let mergedVoBuffer: AudioBuffer | null = null;
    if (voBuffers.length === 1) {
      mergedVoBuffer = voBuffers[0];
    } else if (voBuffers.length > 1) {
      const sumLen = voBuffers.reduce((acc, b) => acc + b.length, 0);
      mergedVoBuffer = offline.createBuffer(ch, Math.max(1, sumLen), sr);
      let offsetSamples = 0;
      for (const b of voBuffers) {
        for (let cIdx = 0; cIdx < ch; cIdx++) {
          const srcData = b.getChannelData(Math.min(cIdx, b.numberOfChannels - 1));
          mergedVoBuffer.getChannelData(cIdx).set(srcData, offsetSamples);
        }
        offsetSamples += b.length;
      }
    }

    if (mergedVoBuffer) {
      if (Array.isArray(opts.voPieces)) {
        for (const piece of opts.voPieces) {
          const origin = slotOrigin(opts.voSlots, piece.slot, 0);
          const safeIn = Math.max(0, Math.min(mergedVoBuffer.duration, origin + piece.source_in));
          const want = Math.max(0.05, piece.source_out - piece.source_in);
          const safeDur = Math.max(0.05, Math.min(mergedVoBuffer.duration - safeIn, want));
          if (safeDur <= 0.02 || piece.end <= piece.start + 0.04) continue;
          const src = offline.createBufferSource();
          src.buffer = mergedVoBuffer;
          src.connect(offline.destination);
          src.start(Math.max(0, piece.start), safeIn, safeDur);
        }
      } else {
      // Group continuous narration runs so continuous speech is never chopped at scene boundaries
      const narrRuns: Array<[number, number, number]> = [];
      const narrSource =
        opts.narrationSegments && opts.narrationSegments.length > 0 ? opts.narrationSegments : opts.clips;
      for (const c of narrSource) {
        if (c.narration_in == null || c.narration_out == null) continue;
        const ni = Number(c.narration_in);
        const no = Number(c.narration_out);
        if (no <= ni + 0.05) continue;
        const cs = Number(c.start || 0);
        if (narrRuns.length > 0) {
          const prev = narrRuns[narrRuns.length - 1];
          const prevOffset = prev[0] - prev[1];
          const curOffset = cs - ni;
          const prevTlEnd = prev[0] + (prev[2] - prev[1]);
          if (ni >= prev[2] - 0.5 && Math.abs(curOffset - prevOffset) < 1.5 && cs - prevTlEnd < 6.0) {
            prev[2] = Math.max(prev[2], no);
            continue;
          }
        }
        narrRuns.push([cs, ni, no]);
      }

      if (narrRuns.length === 0) {
        const src = offline.createBufferSource();
        src.buffer = mergedVoBuffer;
        src.connect(offline.destination);
        src.start(0);
      } else {
        for (const [tlStart, voIn, voOut] of narrRuns) {
          const safeIn = Math.max(0, Math.min(mergedVoBuffer.duration, voIn));
          const safeDur = Math.max(0.05, Math.min(mergedVoBuffer.duration - safeIn, voOut - safeIn));
          if (safeDur <= 0.02) continue;
          const src = offline.createBufferSource();
          src.buffer = mergedVoBuffer;
          src.connect(offline.destination);
          src.start(Math.max(0, tlStart), safeIn, safeDur);
        }
      }
      }
    }

    if (poemBuffer) {
      const pStart = Math.max(0, Number(opts.poemStartTime || 0));
      const pEnd = Number(opts.poemEndTime || 0);
      const pDur = pEnd > pStart ? pEnd - pStart : poemBuffer.duration;
      const src = offline.createBufferSource();
      src.buffer = poemBuffer;
      src.connect(offline.destination);
      src.start(pStart, 0, Math.min(poemBuffer.duration, pDur));
    }

    return await offline.startRendering();
  } finally {
    try {
      await decodeCtx.close();
    } catch {}
  }
}

async function resampleAudioBuffer(src: AudioBuffer, targetSampleRate: number): Promise<AudioBuffer> {
  if (src.sampleRate === targetSampleRate) return src;
  const ch = src.numberOfChannels;
  const totalSamples = Math.max(1, Math.ceil(src.duration * targetSampleRate));
  const offline = new OfflineAudioContext(ch, totalSamples, targetSampleRate);
  const node = offline.createBufferSource();
  node.buffer = src;
  node.connect(offline.destination);
  node.start(0);
  return await offline.startRendering();
}

interface PreEncodedAudioTrack {
  muxCodec: 'aac' | 'opus';
  sampleRate: number;
  numberOfChannels: number;
  chunks: Array<{ chunk: EncodedAudioChunk; meta?: EncodedAudioChunkMetadata }>;
}

async function encodeAudioTrackWithFallback(
  mixedAudioBuffer: AudioBuffer,
  requestedKbps: number,
  isCancelled: () => boolean,
): Promise<PreEncodedAudioTrack | null> {
  if (typeof AudioEncoder === 'undefined' || typeof AudioData === 'undefined') return null;

  // Windows MediaFoundation AAC MFT (mp4a.40.2) strictly requires bitrate in {96000, 128000, 160000, 192000} bps.
  // Passing 320000 bps causes Windows MediaFoundation to close the AudioEncoder on the first frame!
  const reqBps = Math.max(64_000, Math.round(requestedKbps * 1000));
  const mfSafeAacBitrates = Array.from(
    new Set([
      reqBps <= 96_000 ? 96_000 : reqBps <= 128_000 ? 128_000 : reqBps <= 160_000 ? 160_000 : 192_000,
      192_000,
      160_000,
      128_000,
    ]),
  );

  const candidates: Array<{
    muxCodec: 'aac' | 'opus';
    codec: string;
    sampleRate: number;
    bitrate: number;
  }> = [
    ...mfSafeAacBitrates.map((br) => ({
      muxCodec: 'aac' as const,
      codec: 'mp4a.40.2',
      sampleRate: mixedAudioBuffer.sampleRate === 48000 ? 48000 : 44100,
      bitrate: br,
    })),
    {
      muxCodec: 'opus' as const,
      codec: 'opus',
      sampleRate: 48000,
      bitrate: 192_000,
    },
    {
      muxCodec: 'opus' as const,
      codec: 'opus',
      sampleRate: 48000,
      bitrate: 128_000,
    },
  ];

  for (const cand of candidates) {
    let encoder: AudioEncoder | null = null;
    try {
      const workBuf =
        mixedAudioBuffer.sampleRate === cand.sampleRate
          ? mixedAudioBuffer
          : await resampleAudioBuffer(mixedAudioBuffer, cand.sampleRate);

      const cfg: AudioEncoderConfig = {
        codec: cand.codec,
        sampleRate: workBuf.sampleRate,
        numberOfChannels: workBuf.numberOfChannels,
        bitrate: cand.bitrate,
      };
      const sup = await AudioEncoder.isConfigSupported(cfg);
      if (!sup.supported) continue;

      const chunks: Array<{ chunk: EncodedAudioChunk; meta?: EncodedAudioChunkMetadata }> = [];
      let encErr: Error | null = null;

      encoder = new AudioEncoder({
        output: (chunk, meta) => {
          chunks.push({ chunk, meta });
        },
        error: (err) => {
          encErr = err instanceof Error ? err : new Error(String(err));
        },
      });
      encoder.configure(sup.config || cfg);

      const numCh = workBuf.numberOfChannels;
      const sr = workBuf.sampleRate;
      const totalFrames = workBuf.length;
      const chunkFrames = 4096;
      const channelArrays: Float32Array[] = [];
      for (let c = 0; c < numCh; c++) {
        channelArrays.push(workBuf.getChannelData(c));
      }

      for (let offset = 0; offset < totalFrames; offset += chunkFrames) {
        if (isCancelled()) {
          try {
            if (encoder.state !== 'closed') encoder.close();
          } catch {}
          throw new Error('Export cancelled');
        }
        if (encErr || encoder.state !== 'configured') break;

        const framesHere = Math.min(chunkFrames, totalFrames - offset);
        const planar = new Float32Array(framesHere * numCh);
        for (let c = 0; c < numCh; c++) {
          planar.set(channelArrays[c].subarray(offset, offset + framesHere), c * framesHere);
        }
        const tsUs = Math.round((offset / sr) * 1_000_000);
        const ad = new AudioData({
          format: 'f32-planar',
          sampleRate: sr,
          numberOfFrames: framesHere,
          numberOfChannels: numCh,
          timestamp: tsUs,
          data: planar,
        });
        try {
          if (encoder.state === 'configured') {
            encoder.encode(ad);
          }
        } finally {
          ad.close();
        }
        if (encoder.encodeQueueSize > 24) {
          await new Promise((r) => setTimeout(r, 4));
        }
      }

      if (!encErr && encoder.state === 'configured') {
        await encoder.flush();
      }
      try {
        if (encoder.state !== 'closed') encoder.close();
      } catch {}

      if (!encErr && chunks.length > 0) {
        return {
          muxCodec: cand.muxCodec,
          sampleRate: workBuf.sampleRate,
          numberOfChannels: workBuf.numberOfChannels,
          chunks,
        };
      }
    } catch (e) {
      if (e instanceof Error && e.message === 'Export cancelled') throw e;
      try {
        if (encoder && encoder.state !== 'closed') encoder.close();
      } catch {}
    }
  }

  return null;
}

async function probeWorkingVideoEncoderConfig(
  width: number,
  height: number,
  fps: number,
  targetVideoBps: number,
  bitrateMode: 'vbr' | 'cbr',
): Promise<VideoEncoderConfig> {
  // Include Constrained Baseline & Baseline profiles so CPU-only systems (OpenH264 software encoder) work 100% without a GPU
  const candidateCodecs = [
    'avc1.64002a', // High Profile Level 4.2
    'avc1.640028', // High Profile Level 4.0
    'avc1.4d002a', // Main Profile Level 4.2
    'avc1.4d0028', // Main Profile Level 4.0
    'avc1.420028', // Baseline Profile Level 4.0 (CPU OpenH264 friendly)
    'avc1.42E01F', // Constrained Baseline Level 3.1 (Universal CPU software fallback)
    'avc1.42001f', // Baseline Level 3.1
  ];

  const testCanvas = document.createElement('canvas');
  testCanvas.width = width;
  testCanvas.height = height;
  const testCtx = testCanvas.getContext('2d', { alpha: false });
  if (testCtx) {
    testCtx.fillStyle = '#000000';
    testCtx.fillRect(0, 0, width, height);
  }

  // Test hardware first, then no-preference, then explicit software CPU encoding
  for (const hw of ['prefer-hardware', 'no-preference', 'prefer-software'] as const) {
    for (const codec of candidateCodecs) {
      let testEnc: VideoEncoder | null = null;
      try {
        const cfg: VideoEncoderConfig = {
          codec,
          width,
          height,
          bitrate: targetVideoBps,
          bitrateMode: bitrateMode === 'cbr' ? 'constant' : 'variable',
          framerate: fps,
          hardwareAcceleration: hw,
        };
        const sup = await VideoEncoder.isConfigSupported(cfg);
        if (!sup.supported) continue;
        const resolvedCfg = sup.config || cfg;

        // Run a real 1-frame encode + flush test so GPU-less PCs immediately skip broken hardware MFTs
        let producedChunk = false;
        let testError: Error | null = null;
        testEnc = new VideoEncoder({
          output: () => {
            producedChunk = true;
          },
          error: (err) => {
            testError = err instanceof Error ? err : new Error(String(err));
          },
        });
        testEnc.configure(resolvedCfg);
        const vf = new VideoFrame(testCanvas, { timestamp: 0, duration: Math.round((1 / fps) * 1_000_000) });
        try {
          if (testEnc.state === 'configured') {
            testEnc.encode(vf, { keyFrame: true });
          }
        } finally {
          vf.close();
        }
        if (!testError && testEnc.state === 'configured') {
          await testEnc.flush();
        }
        try {
          if (testEnc.state !== 'closed') testEnc.close();
        } catch {}

        if (!testError && producedChunk) {
          return resolvedCfg;
        }
      } catch {
        try {
          if (testEnc && testEnc.state !== 'closed') testEnc.close();
        } catch {}
      }
    }
  }

  throw new Error('No working H.264 VideoEncoder found on this PC (switching to Cloud Server FFmpeg is recommended).');
}

export async function renderProjectLocallyOnMachine(opts: LocalRenderOptions): Promise<LocalRenderResult> {
  if (!isLocalWebCodecsSupported()) {
    throw new Error('WebCodecs API is not supported in this browser.');
  }

  const width = Math.max(320, Math.round(opts.width / 2) * 2);
  const height = Math.max(240, Math.round(opts.height / 2) * 2);
  const fps = Math.max(15, Math.min(60, Math.round(opts.fps || 30)));
  const targetVideoBps = Math.max(300_000, Math.round(opts.videoBitrateKbps * 1000));

  opts.onProgress(3, `Initializing local PC encoder (CPU / GPU · ${opts.videoBitrateKbps} kbps ${opts.bitrateMode.toUpperCase()})…`);

  // 1. Probe & verify a working H.264 VideoEncoder (works on both CPU-only and GPU machines)
  const chosenVideoConfig = await probeWorkingVideoEncoderConfig(
    width,
    height,
    fps,
    targetVideoBps,
    opts.bitrateMode,
  );

  // 2. Mix & pre-encode audio in memory with automatic bitrate/codec fallback (prevents closed AudioEncoder flush errors)
  opts.onProgress(6, `Mixing & encoding voiceover audio on PC…`);
  const mixedAudioBuffer = await buildMixedTimelineAudioBuffer(opts);
  const encodedAudio = mixedAudioBuffer
    ? await encodeAudioTrackWithFallback(mixedAudioBuffer, opts.audioBitrateKbps, opts.isCancelled)
    : null;

  // 3. Create MP4 Muxer with verified audio configuration
  const target = new ArrayBufferTarget();
  const muxer = new Muxer({
    target,
    video: {
      codec: 'avc',
      width,
      height,
    },
    audio: encodedAudio
      ? {
          codec: encodedAudio.muxCodec,
          numberOfChannels: encodedAudio.numberOfChannels,
          sampleRate: encodedAudio.sampleRate,
        }
      : undefined,
    fastStart: 'in-memory',
    firstTimestampBehavior: 'offset',
  });

  if (encodedAudio) {
    for (const item of encodedAudio.chunks) {
      muxer.addAudioChunk(item.chunk, item.meta);
    }
  }

  let videoEncodingError: Error | null = null;
  const videoEncoder = new VideoEncoder({
    output: (chunk, meta) => {
      muxer.addVideoChunk(chunk, meta);
    },
    error: (err) => {
      videoEncodingError = err instanceof Error ? err : new Error(String(err));
    },
  });
  videoEncoder.configure(chosenVideoConfig);

  const safeEncodeVideoFrame = (vf: VideoFrame, keyFrame: boolean) => {
    try {
      if (videoEncodingError) throw videoEncodingError;
      if (videoEncoder.state !== 'configured') {
        throw new Error('Local video encoder closed unexpectedly on this machine.');
      }
      videoEncoder.encode(vf, { keyFrame });
    } finally {
      vf.close();
    }
  };

  // 5. Prepare offscreen canvas & pre-load client logo
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { alpha: false });
  if (!ctx) throw new Error('Could not initialize 2D canvas context');

  let logoImg: HTMLImageElement | null = null;
  if (opts.logoUrl) {
    try {
      logoImg = await loadImageElement(opts.logoUrl);
    } catch (error) {
      throw new Error(`Logo is enabled but could not be loaded for export: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  const imageCache = new Map<string, HTMLImageElement>();
  const videoStepSec = 1 / fps;
  // Static image slides step at 10 fps (every 3rd frame of 30fps) — 100% visually identical since pixels are static, 3x fewer frames!
  const staticSlideStepSec = 3 / fps;

  let globalTimelineCursorSec = 0;
  const sortedClips = [...opts.clips].sort((a, b) => Number(a.start || 0) - Number(b.start || 0));

  const encodeBlackSpan = (startSec: number, endSec: number) => {
    if (endSec - startSec <= 0.01) return;
    drawFittedSourceAndLogo(ctx, width, height, null, 0, 0, logoImg, opts.logoTransform);
    let t = startSec;
    let isFirst = true;
    while (t < endSec - 0.002) {
      const nextT = Math.min(endSec, t + staticSlideStepSec);
      const durSec = Math.max(0.01, nextT - t);
      const vf = new VideoFrame(canvas, {
        timestamp: Math.round(t * 1_000_000),
        duration: Math.round(durSec * 1_000_000),
      });
      safeEncodeVideoFrame(vf, isFirst);
      isFirst = false;
      t = nextT;
    }
  };

  for (let i = 0; i < sortedClips.length; i++) {
    if (opts.isCancelled()) {
      try {
        if (videoEncoder.state !== 'closed') videoEncoder.close();
      } catch {}
      throw new Error('Export cancelled');
    }
    if (videoEncodingError) throw videoEncodingError;

    const clip = sortedClips[i];
    const requestedStart = Math.max(globalTimelineCursorSec, Number(clip.start || 0));
    if (requestedStart - globalTimelineCursorSec > 0.04) {
      encodeBlackSpan(globalTimelineCursorSec, requestedStart);
      globalTimelineCursorSec = requestedStart;
    }
    const rawClipEnd = Number(clip.end || 0);
    const clipDur = Math.max(
      0.2,
      rawClipEnd > globalTimelineCursorSec
        ? rawClipEnd - globalTimelineCursorSec
        : Number(clip.duration) || 2.0,
    );
    const sceneStartSec = globalTimelineCursorSec;
    const sceneEndSec = sceneStartSec + clipDur;

    const pct = 10 + Math.round(((i + 1) / sortedClips.length) * 85);
    opts.onProgress(
      pct,
      `Rendering on PC (CPU / GPU): scene ${i + 1}/${sortedClips.length} (${clip.screen} · ${opts.videoBitrateKbps} kbps)…`,
      {
        done: i + 1,
        total: sortedClips.length,
        screen: clip.screen,
        mediaId: clip.media_id || null,
      },
    );
    // Yield to browser UI thread so progress bar & Cancel button stay responsive
    await new Promise((r) => setTimeout(r, 0));

    const mediaUrl = opts.resolveMediaUrl(clip);

    if (!mediaUrl || clip.fit === 'missing') {
      // Draw black frame + logo once
      drawFittedSourceAndLogo(ctx, width, height, null, 0, 0, logoImg, opts.logoTransform);
      let t = sceneStartSec;
      let isFirst = true;
      while (t < sceneEndSec - 0.002) {
        const nextT = Math.min(sceneEndSec, t + staticSlideStepSec);
        const durSec = Math.max(0.01, nextT - t);
        const vf = new VideoFrame(canvas, {
          timestamp: Math.round(t * 1_000_000),
          duration: Math.round(durSec * 1_000_000),
        });
        safeEncodeVideoFrame(vf, isFirst);
        isFirst = false;
        t = nextT;
      }
    } else if (clip.kind === 'image') {
      let img = imageCache.get(mediaUrl) || null;
      if (!img) {
        try {
          img = await loadImageElement(mediaUrl);
          if (imageCache.size > 16) {
            const firstKey = imageCache.keys().next().value;
            if (firstKey) imageCache.delete(firstKey);
          }
          imageCache.set(mediaUrl, img);
        } catch {}
      }
      drawFittedSourceAndLogo(
        ctx,
        width,
        height,
        img,
        img ? img.naturalWidth : 0,
        img ? img.naturalHeight : 0,
        logoImg,
        opts.logoTransform,
      );

      let t = sceneStartSec;
      let isFirst = true;
      while (t < sceneEndSec - 0.002) {
        if (videoEncoder.encodeQueueSize > 12) {
          await new Promise((r) => setTimeout(r, 4));
        }
        const nextT = Math.min(sceneEndSec, t + staticSlideStepSec);
        const durSec = Math.max(0.01, nextT - t);
        const vf = new VideoFrame(canvas, {
          timestamp: Math.round(t * 1_000_000),
          duration: Math.round(durSec * 1_000_000),
        });
        safeEncodeVideoFrame(vf, isFirst);
        isFirst = false;
        t = nextT;
      }
    } else {
      // Video clip: decode frames sequentially via <video> element
      let vid: HTMLVideoElement | null = null;
      try {
        vid = await loadVideoElement(mediaUrl);
      } catch {}

      if (!vid) {
        drawFittedSourceAndLogo(ctx, width, height, null, 0, 0, logoImg, opts.logoTransform);
        let t = sceneStartSec;
        let isFirst = true;
        while (t < sceneEndSec - 0.002) {
          const nextT = Math.min(sceneEndSec, t + staticSlideStepSec);
          const vf = new VideoFrame(canvas, {
            timestamp: Math.round(t * 1_000_000),
            duration: Math.round(Math.max(0.01, nextT - t) * 1_000_000),
          });
          safeEncodeVideoFrame(vf, isFirst);
          isFirst = false;
          t = nextT;
        }
      } else {
        const srcIn = Math.max(0, Number(clip.source_in || 0));
        const vidNaturalDur = Number.isFinite(vid.duration) && vid.duration > 0 ? vid.duration : clipDur + srcIn;
        const rawSrcOut = clip.source_out && Number(clip.source_out) > srcIn ? Number(clip.source_out) : vidNaturalDur;
        const srcSpan = Math.max(0.08, rawSrcOut - srcIn);
        const stretch = clip.fit === 'stretch' || clip.fit === 'passthrough';
        // Stretch: whole take fills the VO window. Trim: only the first clipDur of source.
        const activeEndSec = sceneStartSec + clipDur;
        const rate = stretch
          ? Math.max(0.25, Math.min(4, srcSpan / Math.max(0.08, clipDur)))
          : Math.max(1, Math.min(2.5, srcSpan / Math.max(0.08, Math.min(clipDur, srcSpan))));

        await seekVideoWithTimeout(vid, srcIn, 400);
        let playingFast = false;
        try {
          vid.playbackRate = rate;
          await vid.play();
          playingFast = true;
        } catch {
          playingFast = false;
        }

        let t = sceneStartSec;
        let isFirst = true;
        let lastKeySec = t;

        while (t < activeEndSec - 0.002) {
          if (opts.isCancelled()) {
            try { vid.pause(); vid.src = ''; } catch {}
            try {
              if (videoEncoder.state !== 'closed') videoEncoder.close();
            } catch {}
            throw new Error('Export cancelled');
          }
          if (videoEncoder.encodeQueueSize > 10) {
            if (playingFast && !vid.paused) {
              try { vid.pause(); } catch {}
            }
            while (videoEncoder.encodeQueueSize > 4) {
              await new Promise((r) => setTimeout(r, 4));
            }
            if (playingFast && vid.paused && !vid.ended) {
              try { await vid.play(); } catch {}
            }
          }

          const relSec = t - sceneStartSec;
          const fileEnd = Math.max(srcIn + 0.04, vidNaturalDur - 0.001);
          const rawTarget = stretch
            ? srcIn + Math.min(srcSpan, (relSec / Math.max(0.08, clipDur)) * srcSpan)
            : srcIn + Math.min(srcSpan, relSec);
          const targetMediaTime = Math.min(fileEnd, rawTarget);
          const holding = vid.ended || targetMediaTime >= fileEnd - 0.03;

          if (!holding && playingFast && !vid.ended) {
            const waitStart = performance.now();
            while (vid.currentTime < targetMediaTime - 0.012 && !vid.ended && performance.now() - waitStart < 90) {
              await new Promise((r) => setTimeout(r, 3));
            }
            if (Math.abs(vid.currentTime - targetMediaTime) > 0.28) {
              await seekVideoWithTimeout(vid, targetMediaTime, 200);
            }
          } else if (!holding) {
            await seekVideoWithTimeout(vid, targetMediaTime, 200);
          }

          drawFittedSourceAndLogo(
            ctx,
            width,
            height,
            vid,
            vid.videoWidth || width,
            vid.videoHeight || height,
            logoImg,
            opts.logoTransform,
          );

          const nextT = Math.min(activeEndSec, t + videoStepSec);
          const durSec = Math.max(0.005, nextT - t);
          const needKey = isFirst || (t - lastKeySec >= 2.0);
          if (needKey) lastKeySec = t;

          const vf = new VideoFrame(canvas, {
            timestamp: Math.round(t * 1_000_000),
            duration: Math.round(durSec * 1_000_000),
          });
          safeEncodeVideoFrame(vf, needKey);
          isFirst = false;
          t = nextT;
        }

        try {
          vid.pause();
          vid.removeAttribute('src');
          vid.load();
        } catch {}

        while (t < sceneEndSec - 0.002) {
          const nextT = Math.min(sceneEndSec, t + staticSlideStepSec);
          const durSec = Math.max(0.01, nextT - t);
          const vf = new VideoFrame(canvas, {
            timestamp: Math.round(t * 1_000_000),
            duration: Math.round(durSec * 1_000_000),
          });
          safeEncodeVideoFrame(vf, false);
          t = nextT;
        }
      }
    }

    globalTimelineCursorSec = sceneEndSec;
  }

  if (opts.totalDuration - globalTimelineCursorSec > 0.05 || globalTimelineCursorSec === 0) {
    encodeBlackSpan(globalTimelineCursorSec, Math.max(0.2, opts.totalDuration));
    globalTimelineCursorSec = Math.max(0.2, opts.totalDuration);
  }

  opts.onProgress(96, 'Finalizing MP4 container on PC…');
  if (!videoEncodingError && videoEncoder.state === 'configured') {
    await videoEncoder.flush();
  }
  try {
    if (videoEncoder.state !== 'closed') videoEncoder.close();
  } catch {}
  if (videoEncodingError) throw videoEncodingError;

  muxer.finalize();
  const buffer = target.buffer;
  const blob = new Blob([buffer], { type: 'video/mp4' });
  const sizeMb = Number((blob.size / (1024 * 1024)).toFixed(2));
  const finalDur = Math.max(1, globalTimelineCursorSec || opts.totalDuration || 1);
  const actualTotalKbps = Math.round(((blob.size * 8) / finalDur) / 1000);
  const actualVideoKbps = Math.max(100, actualTotalKbps - (opts.exportVideoOnly ? 0 : opts.audioBitrateKbps));

  return {
    blob,
    sizeMb,
    actualTotalKbps,
    actualVideoKbps,
    durationSec: finalDur,
  };
}
