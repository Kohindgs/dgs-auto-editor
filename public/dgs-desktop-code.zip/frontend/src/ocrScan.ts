/**
 * In-browser OCR of the images placed on Video 1 (tesseract.js, English, sparse-text mode).
 * Runs one worker in the background, caches text per image in localStorage so a reload is instant.
 */
const CACHE_PREFIX = 'dgs-ocr-v3:'
const CONF_PREFIX = 'dgs-ocrw-v1:'

type TesseractWorker = {
  recognize: (img: string | Blob) => Promise<{ data: { text: string; words?: { text: string; confidence: number }[] } }>
  setParameters: (p: Record<string, string>) => Promise<unknown>
  terminate: () => Promise<unknown>
}

/** Words OCR read with ≥85% confidence on this image (null if the image was read before this was added). */
export function readCachedConfWords(projectId: string | null, key: string): string[] | null {
  try {
    const raw = localStorage.getItem(`${CONF_PREFIX}${projectId || 'local'}:${key}`)
    return raw ? (JSON.parse(raw) as string[]) : null
  } catch {
    return null
  }
}

let workerPromise: Promise<TesseractWorker> | null = null

async function getWorker(): Promise<TesseractWorker> {
  if (!workerPromise) {
    workerPromise = (async () => {
      const mod = await import('tesseract.js')
      const worker = (await mod.createWorker('eng')) as unknown as TesseractWorker
      // PSM 11 = sparse text: best for illustrated cards with scattered dialogue text
      await worker.setParameters({ tessedit_pageseg_mode: '11' })
      return worker
    })().catch((err) => {
      workerPromise = null
      throw err
    })
  }
  return workerPromise
}

export function readCachedOcr(projectId: string | null, key: string): string | null {
  try {
    return localStorage.getItem(`${CACHE_PREFIX}${projectId || 'local'}:${key}`)
  } catch {
    return null
  }
}

function writeCachedOcr(projectId: string | null, key: string, text: string) {
  try {
    localStorage.setItem(`${CACHE_PREFIX}${projectId || 'local'}:${key}`, text)
  } catch {
    /* storage full — ignore */
  }
}

export type OcrJob = { key: string; url: string }

/** One OCR job per project image (keyed by media id), skipping ones already read. */
export function collectOcrJobs(
  items: { id: string; kind: string }[],
  resolveUrl: (id: string) => string | null,
  already: Record<string, string>,
): OcrJob[] {
  const jobs: OcrJob[] = []
  const seen = new Set<string>()
  for (const it of items) {
    if (it.kind !== 'image' || seen.has(it.id) || already[it.id] != null) continue
    const url = resolveUrl(it.id)
    if (!url) continue
    seen.add(it.id)
    jobs.push({ key: it.id, url })
  }
  return jobs
}

/** OCR each job sequentially; calls onResult as each finishes. Returns a cancel function. */
export function runOcrJobs(
  projectId: string | null,
  jobs: OcrJob[],
  onResult: (key: string, text: string) => void,
  onProgress?: (done: number, total: number) => void,
): () => void {
  let cancelled = false
  void (async () => {
    let done = 0
    for (const job of jobs) {
      if (cancelled) return
      const cached = readCachedOcr(projectId, job.key)
      if (cached != null) {
        onResult(job.key, cached)
      } else {
        try {
          const worker = await getWorker()
          if (cancelled) return
          const { data } = await worker.recognize(job.url)
          const text = (data?.text || '').replace(/\s+/g, ' ').trim()
          // Keep the words Tesseract is sure about (used for card spelling checks, so OCR noise never raises a bubble)
          const sure = (data?.words || [])
            .filter((w) => (w.confidence ?? 0) >= 85 && /^[A-Za-z][A-Za-z'’-]*[A-Za-z][.,!?;:]?$/.test(w.text || ''))
            .map((w) => (w.text || '').replace(/[.,!?;:]$/, ''))
          writeCachedOcr(projectId, job.key, text)
          try {
            localStorage.setItem(`${CONF_PREFIX}${projectId || 'local'}:${job.key}`, JSON.stringify(sure))
          } catch {
            /* ignore */
          }
          if (!cancelled) onResult(job.key, text)
          await new Promise((r) => setTimeout(r, 0))
        } catch {
          // unreadable image or OCR load failure — mark as read (no text) so matching can proceed
          if (!cancelled) onResult(job.key, '')
        }
      }
      done += 1
      onProgress?.(done, jobs.length)
    }
  })()
  return () => {
    cancelled = true
  }
}
