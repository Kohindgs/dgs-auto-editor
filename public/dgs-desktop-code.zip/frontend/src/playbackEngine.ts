/**
 * DGS playback engine.
 * One audio-device clock. Narration and poem are decoded once and played from
 * that clock. The timeline position is only ever derived from the clock, so a
 * buffer stall cannot pull the picture backward.
 */

export type EngineSegment = {
  start: number
  end: number
  narration_in?: number | null
  narration_out?: number | null
}

export type EngineMap = {
  duration: number
  poemStart: number
  poemEnd: number
  hasPoem: boolean
  segments: EngineSegment[]
  /** True after the voice lane was split, trimmed, or had a piece deleted. Empty segments are silence. */
  voiceEdited?: boolean
}

type Mix = {
  volume: number
  muted: boolean
  voMuted: boolean
  poemMuted: boolean
}

type Slot = {
  url: string
  buffer: AudioBuffer | null
  source: AudioBufferSourceNode | null
  gain: GainNode
  startedAt: number
  startedOffset: number
  live: boolean
}

function narrFileAt(map: EngineMap, t: number): number | null {
  if (map.hasPoem && t >= map.poemStart - 0.02 && t < map.poemEnd - 0.02) return null
  const seg = map.segments.find(
    (s) =>
      t >= s.start &&
      t < s.end &&
      s.narration_in != null &&
      s.narration_out != null &&
      Number(s.narration_out) - Number(s.narration_in) > 0.05,
  )
  if (!seg || seg.narration_in == null || seg.narration_out == null) {
    if (!map.segments.length && !map.voiceEdited) return t
    return null
  }
  const spoken = Number(seg.narration_out) - Number(seg.narration_in)
  const local = Math.max(0, t - seg.start)
  if (local > spoken + 0.08) return null
  return Number(seg.narration_in) + Math.min(local, spoken)
}

export class DgsPlaybackEngine {
  readonly ctx: AudioContext
  private narr: Slot
  private poem: Slot
  private running = false
  private originCtx = 0
  private originTimeline = 0
  private held = 0
  private map: EngineMap = {
    duration: 0,
    poemStart: 0,
    poemEnd: 0,
    hasPoem: false,
    segments: [],
    voiceEdited: false,
  }
  private mix: Mix = { volume: 1, muted: false, voMuted: false, poemMuted: false }
  private narrToken = 0
  private poemToken = 0

  constructor() {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    this.ctx = new Ctx()
    this.narr = this.makeSlot()
    this.poem = this.makeSlot()
  }

  private makeSlot(): Slot {
    const gain = this.ctx.createGain()
    gain.connect(this.ctx.destination)
    return {
      url: '',
      buffer: null,
      source: null,
      gain,
      startedAt: 0,
      startedOffset: 0,
      live: false,
    }
  }

  setMap(map: EngineMap) {
    this.map = map
  }

  setMix(mix: Mix) {
    this.mix = mix
    const vol = mix.muted ? 0 : mix.volume
    this.narr.gain.gain.value = mix.voMuted ? 0 : vol
    this.poem.gain.gain.value = mix.poemMuted ? 0 : vol
  }

  get narrReady() {
    return Boolean(this.narr.buffer)
  }

  get poemReady() {
    return Boolean(this.poem.buffer)
  }

  isRunning() {
    return this.running
  }

  async resume() {
    if (this.ctx.state !== 'running') await this.ctx.resume()
  }

  async loadNarration(url: string | null) {
    await this.loadInto(this.narr, url, 'narr')
  }

  async loadPoem(url: string | null) {
    await this.loadInto(this.poem, url, 'poem')
  }

  private async loadInto(slot: Slot, url: string | null, which: 'narr' | 'poem') {
    const token = which === 'narr' ? ++this.narrToken : ++this.poemToken
    this.stopSlot(slot)
    slot.buffer = null
    slot.url = url || ''
    if (!url) return
    const res = await fetch(url)
    if (!res.ok) throw new Error(`Sound file failed (${res.status})`)
    const raw = await res.arrayBuffer()
    const copy = raw.slice(0)
    const audio = await this.ctx.decodeAudioData(copy)
    const current = which === 'narr' ? this.narrToken : this.poemToken
    if (token !== current) return
    slot.buffer = audio
    if (this.running) this.sync()
  }

  hold(timelineSec: number) {
    this.held = Math.max(0, timelineSec)
  }

  start(timelineSec: number) {
    this.originTimeline = Math.max(0, timelineSec)
    this.originCtx = this.ctx.currentTime
    this.held = this.originTimeline
    this.running = true
    this.rearm(this.originTimeline, true)
  }

  seek(timelineSec: number) {
    if (!this.running) {
      this.hold(timelineSec)
      return
    }
    this.start(timelineSec)
  }

  pause(): number {
    const at = this.position()
    this.running = false
    this.held = at
    this.stopSlot(this.narr)
    this.stopSlot(this.poem)
    return at
  }

  /** Timeline seconds. Never moves backward while running. */
  position(): number {
    if (!this.running) return this.held
    const elapsed = this.ctx.currentTime - this.originCtx
    const t = this.originTimeline + Math.max(0, elapsed)
    const cap = this.map.duration > 0.2 ? this.map.duration : t
    return Math.min(cap, t)
  }

  sync() {
    if (!this.running) return
    this.rearm(this.position(), false)
  }

  private rearm(t: number, force: boolean) {
    const poemNow =
      this.map.hasPoem && t >= this.map.poemStart - 0.02 && t < this.map.poemEnd - 0.02
    if (poemNow && this.poem.buffer && !this.mix.poemMuted) {
      this.ensure(this.poem, Math.max(0, t - this.map.poemStart), force)
      this.stopSlot(this.narr)
      return
    }
    this.stopSlot(this.poem)
    if (!this.narr.buffer || this.mix.voMuted) {
      this.stopSlot(this.narr)
      return
    }
    const fileT = narrFileAt(this.map, t)
    if (fileT == null) {
      this.stopSlot(this.narr)
      return
    }
    this.ensure(this.narr, fileT, force)
  }

  private ensure(slot: Slot, offset: number, force: boolean) {
    if (!slot.buffer) return
    if (slot.live && !force) {
      const expected = slot.startedOffset + (this.ctx.currentTime - slot.startedAt)
      if (Math.abs(expected - offset) < 0.22) return
    }
    this.stopSlot(slot)
    const src = this.ctx.createBufferSource()
    src.buffer = slot.buffer
    src.connect(slot.gain)
    const off = Math.max(0, Math.min(offset, Math.max(0, slot.buffer.duration - 0.02)))
    try {
      src.start(0, off)
    } catch {
      return
    }
    slot.source = src
    slot.startedAt = this.ctx.currentTime
    slot.startedOffset = off
    slot.live = true
    src.onended = () => {
      if (slot.source === src) slot.live = false
    }
  }

  private stopSlot(slot: Slot) {
    const src = slot.source
    slot.source = null
    slot.live = false
    if (!src) return
    try {
      src.onended = null
      src.stop()
    } catch {
      /* already stopped */
    }
    try {
      src.disconnect()
    } catch {
      /* ignore */
    }
  }

  dispose() {
    this.pause()
    void this.ctx.close()
  }
}
