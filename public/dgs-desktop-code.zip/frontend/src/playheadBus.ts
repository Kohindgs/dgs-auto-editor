/**
 * The playhead clock lives outside React.
 * Filmora paints the playhead on the native timeline. Rebuilding every clip
 * in React to move one line is what made scrubbing and playback feel stuck.
 * Subscribers are the playhead line and the timecode. The rest of the page
 * updates only when the scene changes.
 */
type Listener = () => void

let time = 0
let clockWrite = false
const listeners = new Set<Listener>()

export const playheadBus = {
  get(): number {
    return time
  },
  /** True while a playback tick is writing the clock. Those ticks must not rebuild the page. */
  fromClock(): boolean {
    return clockWrite
  },
  set(next: number, origin: 'user' | 'clock' = 'user') {
    if (!Number.isFinite(next)) return
    if (Math.abs(next - time) < 0.0005) return
    time = next
    clockWrite = origin === 'clock'
    listeners.forEach((fn) => fn())
    clockWrite = false
  },
  subscribe(fn: Listener) {
    listeners.add(fn)
    return () => {
      listeners.delete(fn)
    }
  },
}
