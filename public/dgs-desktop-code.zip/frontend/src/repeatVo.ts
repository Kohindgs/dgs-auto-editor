/**
 * Extra hearings of one sentence, for the desktop engine.
 * A later copy of a sentence that belongs to one card is cut from the voice.
 * The same ending on several cards is reported and left in the voice.
 */
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)
const gap = require('../../hostinger_deploy/script_led_gap.js') as {
  findRepeatedHearings: (words: unknown[], lines: unknown[]) => unknown[]
  expressionLeaks: (words: unknown[], lines: unknown[]) => unknown[]
}

function poemScene(scene: { is_poem?: boolean; kind?: string; screen?: string }) {
  return Boolean(scene && (scene.is_poem || scene.kind === 'poem'))
}

export function narrationRepeatReport(words: unknown[], scenes: unknown[], poemWords: unknown[] = []) {
  const rows = Array.isArray(scenes) ? scenes : []
  const narration = gap.findRepeatedHearings(
    Array.isArray(words) ? words : [],
    rows.filter((s) => s && !poemScene(s as { is_poem?: boolean })),
  )
  const poem = gap.findRepeatedHearings(
    Array.isArray(poemWords) ? poemWords : [],
    rows.filter((s) => s && poemScene(s as { is_poem?: boolean })),
  )
  return {
    narration,
    poem,
    tags: gap.expressionLeaks(Array.isArray(words) ? words : [], rows),
  }
}
