/**
 * Force Video 1 (images + videos) onto the spoken VO clock.
 * Same rule we used successfully before: picture span = narration span
 * (hold through silence until the next line). Videos longer than the line
 * are time-stretched to fill that window so the whole take plays with the VO.
 */
import type { MediaItem, SrtCue, TimelineClip, TimelinePlan } from './types'

const LOCK_EPS = 0.001

function lockPictureToAudio(
  audioIn: number,
  audioOut: number,
  nextAudioIn: number | null,
  minDur = 0.2,
): [number, number] {
  const picIn = Math.round(Math.max(0, audioIn) * 1000) / 1000
  let picOut =
    nextAudioIn != null && nextAudioIn > audioOut
      ? Math.round(nextAudioIn * 1000) / 1000
      : Math.round(Math.max(audioOut, picIn + minDur) * 1000) / 1000
  if (picOut - picIn < minDur) picOut = Math.round((picIn + minDur) * 1000) / 1000
  return [picIn, picOut]
}

function mediaFileDuration(clip: TimelineClip, mediaDurById?: Map<string, number>): number {
  if (clip.media_id && mediaDurById?.has(clip.media_id)) {
    const d = Number(mediaDurById.get(clip.media_id))
    if (Number.isFinite(d) && d > 0.2) return d
  }
  const srcOut = Number(clip.source_out)
  const srcIn = Number(clip.source_in || 0)
  // Only trust source_out as file length when it looks longer than the timeline slot
  // (trim mode stores source_out ≈ clip duration, which is NOT the file length).
  if (Number.isFinite(srcOut) && srcOut > srcIn + 0.05 && srcOut > Number(clip.duration || 0) + 0.25) {
    return srcOut - srcIn
  }
  return Math.max(0.2, Number(clip.duration) || 0.2)
}

/**
 * Copy of clips: every spoken line's picture/video is cut (and stretched
 * if needed) to the VO. Returns { clips, changed }.
 */
export function stretchClipsToVo(
  clipsIn: TimelineClip[],
  media?: MediaItem[],
  poem?: { start: number; end: number } | null,
): { clips: TimelineClip[]; changed: number } {
  const mediaDurById = new Map<string, number>()
  for (const m of media || []) {
    if (m.id && m.duration != null && Number(m.duration) > 0.2) {
      mediaDurById.set(m.id, Number(m.duration))
    }
  }
  const clips = clipsIn.map((c) => ({ ...c }))
  const poemStart = Number(poem?.start || 0)
  const poemEnd = Number(poem?.end || 0)
  const poemSpan = poemEnd > poemStart + 0.3 ? poemEnd - poemStart : 0
  const inPoemPicture = (c: TimelineClip) =>
    poemSpan > 0 && Number(c.start) >= poemStart - 0.05 && Number(c.start) < poemEnd - 0.02
  const spoken = clips
    .map((c, idx) => ({ c, idx }))
    .filter(
      ({ c }) =>
        !inPoemPicture(c) &&
        c.narration_in != null &&
        c.narration_out != null &&
        Number(c.narration_out) - Number(c.narration_in) >= 0.15,
    )
    .sort((a, b) => Number(a.c.narration_in) - Number(b.c.narration_in))

  let changed = 0
  for (let i = 0; i < spoken.length; i++) {
    const { c, idx } = spoken[i]
    const ni = Number(c.narration_in)
    const no = Number(c.narration_out)
    const nxt = i + 1 < spoken.length ? Number(spoken[i + 1].c.narration_in) : null
    let [picIn, picOut] = lockPictureToAudio(ni, no, nxt)
    if (poemSpan > 0 && ni >= poemStart - 0.08) {
      picIn = Math.round((picIn + poemSpan) * 1000) / 1000
      picOut = Math.round((picOut + poemSpan) * 1000) / 1000
    }
    const dur = Math.round((picOut - picIn) * 1000) / 1000
    const kind = String(c.kind || 'image')
    const fileDur = mediaFileDuration(c, mediaDurById)

    let fit = c.fit || (kind === 'video' ? 'trim' : 'hold')
    let sourceIn = Number(c.source_in || 0)
    let sourceOut = Number(c.source_out != null ? c.source_out : dur)
    const missingCard = String(c.screen || '').startsWith('missing_vo_')

    if (missingCard) {
      fit = 'missing'
      sourceIn = 0
      sourceOut = dur
    } else if (kind === 'video') {
      // Play at 1× inside the VO window (trim). Never stretch — that made videos look sped-up.
      fit = 'trim'
      sourceIn = 0
      sourceOut = Math.round(Math.min(Math.max(0.2, fileDur), dur) * 1000) / 1000
    } else {
      // Still image: held (aligned) for the full VO window through to the next line.
      fit = 'hold'
      sourceIn = 0
      sourceOut = dur
    }

    const prev = clips[idx]
    if (
      Math.abs(Number(prev.start) - picIn) > LOCK_EPS ||
      Math.abs(Number(prev.end) - picOut) > LOCK_EPS ||
      prev.fit !== fit ||
      Math.abs(Number(prev.source_out || 0) - sourceOut) > LOCK_EPS
    ) {
      changed += 1
    }
    clips[idx] = {
      ...prev,
      start: picIn,
      end: picOut,
      duration: dur,
      source_in: sourceIn,
      source_out: sourceOut,
      fit,
    }
  }

  clips.sort((a, b) => Number(a.start) - Number(b.start) || Number(a.end) - Number(b.end))
  for (let k = 0; k < clips.length - 1; k++) {
    if (Number(clips[k].end) > Number(clips[k + 1].start)) {
      clips[k] = {
        ...clips[k],
        end: Number(clips[k + 1].start),
        duration: Math.max(0.2, Number(clips[k + 1].start) - Number(clips[k].start)),
      }
      changed += 1
    }
  }

  return { clips, changed }
}

function rebuildSrtFromClips(clips: TimelineClip[]): SrtCue[] {
  const cues: SrtCue[] = []
  for (const c of clips) {
    const txt = String(c.vo_text || c.caption_text || '').trim()
    if (!txt || /^[—–\-]+$/.test(txt)) continue
    const spoken =
      c.narration_in != null &&
      c.narration_out != null &&
      Number(c.narration_out) - Number(c.narration_in) >= 0.2
    if (!spoken) continue
    const fileIn = Number(c.narration_in)
    const fileOut = Number(c.narration_out)
    const onFileClock = Math.abs(Number(c.start) - fileIn) <= 0.2
    const start = Math.round((onFileClock ? fileIn : Number(c.start)) * 1000) / 1000
    const end = Math.round(
      (onFileClock ? Math.max(fileOut, start + 0.4) : Math.min(Number(c.end), start + Math.max(0.4, fileOut - fileIn))) * 1000,
    ) / 1000
    cues.push({
      index: cues.length + 1,
      screen: c.screen,
      start,
      end,
      text: txt,
    })
  }
  cues.sort((a, b) => a.start - b.start || a.end - b.end)
  for (let i = 0; i < cues.length - 1; i++) {
    if (cues[i].end > cues[i + 1].start) {
      cues[i] = { ...cues[i], end: cues[i + 1].start }
    }
  }
  return cues.map((c, i) => ({ ...c, index: i + 1 }))
}

/**
 * Align + cut + stretch: lock every picture/video to heard VO, stretch video takes
 * into that window, rebuild narration lanes + SRT from the same clock.
 */
export function applyStretchAlignToPlan(plan: TimelinePlan, media?: MediaItem[]): TimelinePlan {
  const poemStart = Number(plan.poem_start_time || 0)
  const poemEnd = Number(plan.poem_end_time || 0)
  const { clips } = stretchClipsToVo(
    plan.clips || [],
    media,
    plan.has_poem && poemEnd > poemStart ? { start: poemStart, end: poemEnd } : null,
  )
  const total = clips.length ? Math.max(...clips.map((c) => Number(c.end || 0))) : plan.total_duration
  const narration_segments = (plan.narration_segments || []).map((seg) => {
    const clip = clips.find((c) => c.screen === seg.screen && c.narration_in != null)
    if (!clip) return seg
    return {
      ...seg,
      start: Number(clip.start),
      end: Number(clip.end),
      narration_in: clip.narration_in,
      narration_out: clip.narration_out,
    }
  })
  const srt_cues = rebuildSrtFromClips(clips)
  return {
    ...plan,
    clips,
    narration_segments: narration_segments.length ? narration_segments : plan.narration_segments,
    srt_cues: srt_cues.length ? srt_cues : plan.srt_cues,
    total_duration: Math.round(total * 1000) / 1000,
    manual_override: false,
  }
}
