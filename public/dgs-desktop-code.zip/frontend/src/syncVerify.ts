/**
 * Client-side VO↔picture sync audit (mirrors VoAlignBrain.verifyAndRepairSync).
 * Measures |picture.start − narration_in|; never claims "all synced" without measuring.
 */
import type { QAIssue, SyncReport, TimelineClip } from './types'

export const SYNC_DRIFT_LIMIT = 0.35

/** Poem window for sync checks. Empty when this timeline has no separate poem file. */
export function poemSyncArgs(
  plan: { has_poem?: boolean; poem_start_time?: number | null; poem_end_time?: number | null } | null | undefined,
  sceneList: { screen: string; is_poem?: boolean; section?: string }[] | null | undefined,
): Pick<VerifySyncOpts, 'poemStart' | 'poemEnd' | 'poemScreens'> {
  const poemStart = Number(plan?.poem_start_time || 0)
  const poemEnd = Number(plan?.poem_end_time || 0)
  const poemScreens = (sceneList || [])
    .filter((s) => s.is_poem || /\bpoem\b/i.test(String(s.section || '')))
    .map((s) => s.screen)
  if (!(plan?.has_poem && poemEnd > poemStart + 0.3 && poemScreens.length)) return {}
  return { poemStart, poemEnd, poemScreens }
}

function lockPictureToAudio(
  audioIn: number,
  audioOut: number,
  nextAudioIn: number | null,
  minDur = 0.2,
): [number, number] {
  const picIn = Math.round(Math.max(0, audioIn) * 1000) / 1000
  let picOut =
    nextAudioIn != null && nextAudioIn > audioOut
      ? Math.round(nextAudioIn * 1000) / 1000
      : Math.round(Math.max(audioOut, picIn + minDur) * 1000) / 1000
  if (picOut - picIn < minDur) picOut = Math.round((picIn + minDur) * 1000) / 1000
  return [picIn, picOut]
}

function poemShift(opts: VerifySyncOpts): { start: number; end: number; span: number; screens: Set<string> } {
  const start = Number(opts.poemStart || 0)
  const end = Number(opts.poemEnd || 0)
  const span = end > start + 0.3 ? end - start : 0
  return { start, end, span, screens: new Set(opts.poemScreens || []) }
}

/** Picture time for a spoken line. After a poem, the file time stays in narration_in and the picture moves later by the poem length. */
function expectedPicture(ni: number, no: number, nextIn: number | null, poem: { start: number; span: number }): [number, number] {
  let [picIn, picOut] = lockPictureToAudio(ni, no, nextIn)
  if (poem.span > 0 && ni >= poem.start - 0.08) {
    picIn = Math.round((picIn + poem.span) * 1000) / 1000
    picOut = Math.round((picOut + poem.span) * 1000) / 1000
  }
  return [picIn, picOut]
}

export type VerifySyncOpts = {
  repair?: boolean
  driftLimit?: number
  voDuration?: number
  /** Timeline time where the poem file is inserted. */
  poemStart?: number
  poemEnd?: number
  /** Poem / instrumental screens. Their pictures stay on the poem clock. */
  poemScreens?: Iterable<string>
}

/**
 * Measure (and optionally repair) picture cuts vs narration_in.
 * Mutates clips in place when repair=true.
 */
export function verifySync(clips: TimelineClip[], opts: VerifySyncOpts = {}): SyncReport {
  const repair = opts.repair === true
  const limit = Number(opts.driftLimit != null ? opts.driftLimit : SYNC_DRIFT_LIMIT)
  const list = Array.isArray(clips) ? clips : []
  const poem = poemShift(opts)
  const spoken = list.filter(
    (c) =>
      c.narration_in != null &&
      c.narration_out != null &&
      Number(c.narration_out) - Number(c.narration_in) >= 0.15 &&
      !poem.screens.has(String(c.screen)),
  )
  const driftOf = (c: TimelineClip) => {
    if (c.narration_in == null || c.narration_out == null) return 0
    const [picIn] = expectedPicture(Number(c.narration_in), Number(c.narration_out), null, poem)
    return Math.abs(picIn - Number(c.start))
  }

  let drifted = spoken
    .filter((c) => driftOf(c) > limit)
    .map((c) => ({
      screen: c.screen,
      drift: Math.round(driftOf(c) * 1000) / 1000,
      picture_start: Math.round(Number(c.start) * 1000) / 1000,
      narration_in: Math.round(Number(c.narration_in) * 1000) / 1000,
    }))

  let repaired = 0
  if (repair && drifted.length) {
    const sorted = [...spoken].sort((a, b) => Number(a.narration_in) - Number(b.narration_in))
    for (let i = 0; i < sorted.length; i++) {
      const c = sorted[i]
      const ni = Number(c.narration_in)
      const no = Number(c.narration_out)
      const nxt = i + 1 < sorted.length ? Number(sorted[i + 1].narration_in) : null
      const [picIn, picOut] = expectedPicture(ni, no, nxt, poem)
      if (Math.abs(Number(c.start) - picIn) > 0.001 || Math.abs(Number(c.end) - picOut) > 0.001) {
        repaired += 1
      }
      c.start = picIn
      c.end = picOut
      c.duration = Math.round((picOut - picIn) * 1000) / 1000
    }
    drifted = spoken
      .filter((c) => driftOf(c) > limit)
      .map((c) => ({
        screen: c.screen,
        drift: Math.round(driftOf(c) * 1000) / 1000,
        picture_start: Math.round(Number(c.start) * 1000) / 1000,
        narration_in: Math.round(Number(c.narration_in) * 1000) / 1000,
      }))
  }

  let maxDrift = 0
  for (const c of spoken) maxDrift = Math.max(maxDrift, driftOf(c))
  const voDur = Number(opts.voDuration || 0)
  const lastEnd = list.length ? Math.max(...list.map((c) => Number(c.end || 0))) : 0
  const voDelta = voDur > 1 ? Math.round((lastEnd - voDur - poem.span) * 1000) / 1000 : 0
  const voLenOk = voDur > 1 ? Math.abs(voDelta) <= 1.0 : true
  const ok = drifted.length === 0 && voLenOk && spoken.length > 0

  let summary: string
  if (ok) {
    summary = `SYNC OK · ${spoken.length}/${spoken.length} spoken scenes locked to VO · max drift ${maxDrift.toFixed(3)}s · timeline ${lastEnd.toFixed(2)}s`
    if (voDur > 1) summary += ` / VO ${voDur.toFixed(2)}s`
  } else if (!spoken.length) {
    summary = 'SYNC FAIL · no spoken narration_in on clips — Auto-align did not lock to VO'
  } else {
    summary = `SYNC FAIL · ${drifted.length} scene(s) drift >${limit.toFixed(2)}s (max ${maxDrift.toFixed(3)}s)`
    if (!voLenOk) summary += ` · timeline–VO gap ${voDelta >= 0 ? '+' : ''}${voDelta.toFixed(2)}s`
    if (repaired) summary += ` · auto-repaired ${repaired} cut(s)`
  }

  const issues: QAIssue[] = drifted.slice(0, 40).map((d) => ({
    kind: 'vo_sync',
    severity: 'error',
    screen: d.screen,
    time: d.picture_start,
    end: d.narration_in,
    timecode: '',
    message: `${String(d.screen).replace('screen_', 'Scene ')}: picture at ${d.picture_start.toFixed(2)}s but VO line starts at ${d.narration_in.toFixed(2)}s (drift ${d.drift.toFixed(2)}s)`,
    expected: `narration_in=${d.narration_in}`,
    found: `picture_start=${d.picture_start}`,
  }))
  if (!voLenOk) {
    issues.push({
      kind: 'vo_sync',
      severity: 'error',
      screen: 'timeline',
      time: lastEnd,
      end: voDur,
      timecode: '',
      message: `Timeline length ${lastEnd.toFixed(2)}s vs VO ${voDur.toFixed(2)}s (gap ${voDelta >= 0 ? '+' : ''}${voDelta.toFixed(2)}s)`,
      expected: `VO duration ${voDur.toFixed(2)}s`,
      found: `timeline ${lastEnd.toFixed(2)}s`,
    })
  }

  return {
    ok,
    summary,
    spoken_count: spoken.length,
    drifted_count: drifted.length,
    max_drift: Math.round(maxDrift * 1000) / 1000,
    repaired,
    vo_duration: voDur,
    timeline_end: Math.round(lastEnd * 1000) / 1000,
    vo_delta: voDelta,
    issues,
  }
}
