export type MediaItem = {
  id: string
  filename: string
  path?: string
  kind: string
  screen: string | null
  duration?: number | null
}

export type Scene = {
  screen: string
  text: string
  index: number
  section?: string
  duration?: number | null
  voiceover_text?: string
  onscreen_text?: string
  source?: string
  is_poem?: boolean
  visual_type?: string
  visual_direction?: string
  audio_start?: number | null
  audio_end?: number | null
}

export type PoemInfo = {
  has_poem: boolean
  scene_count?: number
  first_screen?: string
  last_screen?: string
  suno_duration?: number | null
  note?: string
}

export type TimelineClip = {
  screen: string
  media_id?: string | null
  media_path?: string | null
  filename?: string | null
  kind?: string | null
  start: number
  end: number
  duration: number
  source_in?: number
  source_out?: number | null
  fit: string
  script_text: string
  vo_text: string
  narration_in?: number | null
  narration_out?: number | null
  caption_in?: number | null
  caption_out?: number | null
  caption_text?: string
}

export type NarrationSegment = {
  screen: string
  start: number
  end: number
  narration_in?: number | null
  narration_out?: number | null
  vo_text: string
  script_text: string
}

export type VoiceoverSlot = {
  slot: number
  filename: string
  duration?: number
  start_offset?: number
  end_offset?: number
  start: number
  end: number
  path?: string | null
}

/** One audible piece of narration on the timeline. A gap between pieces is silence. */
export type VoPiece = {
  id: string
  slot: number
  filename: string
  path?: string | null
  start: number
  end: number
  source_in: number
  source_out: number
  file_duration: number
}

export type SrtCue = {
  index: number
  screen: string
  start: number
  end: number
  text: string
}

export type QAIssue = {
  kind:
    | 'missing_card'
    | 'missing_video'
    | 'missing_narration'
    | 'card_text'
    | 'vo_mismatch'
    | 'poem_mismatch'
    | 'vo_sync'
  severity: 'error' | 'warning' | 'ok'
  screen: string
  image_no?: number | null
  time: number
  end?: number
  timecode: string
  message: string
  expected?: string
  found?: string
  missing_words?: string[]
  source?: 'ocr_client'
}

/** Measured picture↔VO drift audit. Never claim synced without this. */
export type SyncReport = {
  ok: boolean
  summary: string
  spoken_count: number
  drifted_count: number
  max_drift: number
  repaired: number
  vo_duration: number
  timeline_end: number
  vo_delta: number
  issues: QAIssue[]
}

export type LogoTransform = {
  scale_w: number
  scale_h: number
  lock_aspect: boolean
  pos_x: number
  pos_y: number
  anchor_x: number
  anchor_y: number
  rotate: number
}

export const DEFAULT_LOGO_TRANSFORM: LogoTransform = {
  scale_w: 10.0,
  scale_h: 10.0,
  lock_aspect: true,
  pos_x: 1034.21,
  pos_y: 565.98,
  anchor_x: 1900.0,
  anchor_y: 1065.0,
  rotate: 0.0,
}

export function normalizeLogoTransform(raw?: Partial<LogoTransform> | null): LogoTransform {
  return {
    scale_w: Number.isFinite(Number(raw?.scale_w)) ? Math.max(1, Math.min(100, Number(raw!.scale_w))) : DEFAULT_LOGO_TRANSFORM.scale_w,
    scale_h: Number.isFinite(Number(raw?.scale_h)) ? Math.max(1, Math.min(100, Number(raw!.scale_h))) : DEFAULT_LOGO_TRANSFORM.scale_h,
    lock_aspect: raw?.lock_aspect !== undefined ? Boolean(raw.lock_aspect) : DEFAULT_LOGO_TRANSFORM.lock_aspect,
    pos_x: Number.isFinite(Number(raw?.pos_x)) ? Number(raw!.pos_x) : DEFAULT_LOGO_TRANSFORM.pos_x,
    pos_y: Number.isFinite(Number(raw?.pos_y)) ? Number(raw!.pos_y) : DEFAULT_LOGO_TRANSFORM.pos_y,
    anchor_x: Number.isFinite(Number(raw?.anchor_x)) ? Number(raw!.anchor_x) : DEFAULT_LOGO_TRANSFORM.anchor_x,
    anchor_y: Number.isFinite(Number(raw?.anchor_y)) ? Number(raw!.anchor_y) : DEFAULT_LOGO_TRANSFORM.anchor_y,
    rotate: Number.isFinite(Number(raw?.rotate)) ? Number(raw!.rotate) : DEFAULT_LOGO_TRANSFORM.rotate,
  }
}

/**
 * Convert Filmora 1920x1080 Transform values into canvas pixel / CSS percentage placement.
 * At DEFAULT_LOGO_TRANSFORM (10% scale, pos 1034.21/565.98, anchor 1900/1065), places the logo
 * at the exact default top-right position (width = 10% of canvasW, right margin = 0.78125% = 15px, top margin = 1.759% = 19px).
 */
export function computeLogoBox(
  rawTransform: Partial<LogoTransform> | null | undefined,
  canvasW: number,
  canvasH: number,
  naturalW = 0,
  naturalH = 0,
) {
  const t = normalizeLogoTransform(rawTransform)
  const scaleWFrac = Math.max(0.01, t.scale_w / 100)
  const scaleHFrac = Math.max(0.01, t.scale_h / 100)
  const logoW = Math.max(16, Math.round(canvasW * scaleWFrac))
  const aspect = naturalW > 0 && naturalH > 0 ? naturalH / naturalW : 0.36
  const logoH = Math.max(10, Math.round(canvasW * scaleWFrac * aspect * (scaleHFrac / scaleWFrac)))

  const dxFrac = ((t.pos_x - DEFAULT_LOGO_TRANSFORM.pos_x) - (t.anchor_x - DEFAULT_LOGO_TRANSFORM.anchor_x) * scaleWFrac) / 1920
  const dyFrac = (-(t.pos_y - DEFAULT_LOGO_TRANSFORM.pos_y) + (t.anchor_y - DEFAULT_LOGO_TRANSFORM.anchor_y) * scaleHFrac) / 1080

  const defaultRightPx = canvasW * (15 / 1920)
  const defaultTopPx = canvasH * (19 / 1080)
  const leftPx = Math.round(canvasW - logoW - defaultRightPx + dxFrac * canvasW)
  const topPx = Math.round(defaultTopPx + dyFrac * canvasH)

  const rightPct = (15 / 1920 - dxFrac) * 100
  const topPct = (19 / 1080 + dyFrac) * 100

  return {
    transform: t,
    logoW,
    logoH,
    leftPx,
    topPx,
    widthPct: t.scale_w,
    heightScaleRatio: t.scale_h / Math.max(0.1, t.scale_w),
    rightPct,
    topPct,
    rotateDeg: t.rotate,
  }
}

export function getQaIssueKey(q: QAIssue): string {
  return `${q.screen}::${q.kind}::${(q.message || '').slice(0, 120)}`
}

export type PoemPresetStyle =
  | 'badge_pill'
  | 'neon_glow'
  | 'karaoke_box'
  | 'pastel_banner'
  | 'comic_pop'
  | 'clean_subtitle'

export type PoemOverlayStyle = {
  enabled: boolean
  locked: boolean
  font_family: string
  font_size_px: number
  preset_style: PoemPresetStyle
  text_color: string
  bg_color: string
  bg_opacity: number
  border_color: string
  border_width: number
  border_radius: number
  box_shadow: boolean
  shadow_color?: string
  text_align: 'center' | 'left' | 'right'
  x_pct: number
  y_pct: number
  w_pct: number
  h_pct: number
  word_balls?: boolean
  ball_color?: string
  changeover?: 'none' | 'fade' | 'slide' | 'pop'
  apply_all?: boolean
}

export const POEM_CURATED_FONTS = [
  { id: 'Poppins', label: 'Poppins', family: "'Poppins', sans-serif", desc: 'Crisp & Modern Geometric Sans' },
  { id: 'Baloo 2', label: 'Baloo 2', family: "'Baloo 2', cursive, sans-serif", desc: 'Playful & Friendly Rounded' },
  { id: 'Fredoka', label: 'Fredoka', family: "'Fredoka', cursive, sans-serif", desc: 'Chunky & Bubbly Pop' },
  { id: 'Comic Neue', label: 'Comic Neue', family: "'Comic Neue', cursive, sans-serif", desc: 'Storybook & Comic Script' },
  { id: 'Montserrat', label: 'Montserrat', family: "'Montserrat', sans-serif", desc: 'Punchy Bold Uppercase' },
  { id: 'Bubblegum Sans', label: 'Bubblegum', family: "'Bubblegum Sans', cursive, sans-serif", desc: 'Sweet & Bouncy Play' },
] as const

export const POEM_STYLE_PRESETS: Record<
  PoemPresetStyle,
  {
    name: string
    tag: string
    desc: string
    font_family: string
    text_color: string
    bg_color: string
    bg_opacity: number
    border_color: string
    border_width: number
    border_radius: number
    box_shadow: boolean
  }
> = {
  badge_pill: {
    name: 'Badge Pill Sticker',
    tag: 'Sticker',
    desc: 'Capsule badge with cyan border and sticker shadow',
    font_family: 'Poppins',
    text_color: '#ffffff',
    bg_color: '#0f172a',
    bg_opacity: 0.88,
    border_color: '#38bdf8',
    border_width: 2,
    border_radius: 24,
    box_shadow: true,
  },
  neon_glow: {
    name: 'Neon Glow Box',
    tag: 'Cyber Glow',
    desc: 'Glowing cyan borders with futuristic aura',
    font_family: 'Montserrat',
    text_color: '#38bdf8',
    bg_color: '#020617',
    bg_opacity: 0.82,
    border_color: '#06b6d4',
    border_width: 2,
    border_radius: 14,
    box_shadow: true,
  },
  karaoke_box: {
    name: 'Karaoke Contrast',
    tag: 'Karaoke',
    desc: 'High-contrast sunshine yellow on dark sing-along bar',
    font_family: 'Baloo 2',
    text_color: '#facc15',
    bg_color: '#000000',
    bg_opacity: 0.92,
    border_color: '#eab308',
    border_width: 3,
    border_radius: 12,
    box_shadow: true,
  },
  pastel_banner: {
    name: 'Pastel Banner',
    tag: 'Pastel',
    desc: 'Soft candy lemon banner with deep indigo text',
    font_family: 'Fredoka',
    text_color: '#1e1b4b',
    bg_color: '#fef08a',
    bg_opacity: 0.94,
    border_color: '#f59e0b',
    border_width: 2,
    border_radius: 20,
    box_shadow: true,
  },
  comic_pop: {
    name: 'Comic Pop Sticker',
    tag: 'Pop Art',
    desc: 'Hot pink sticker with heavy ink outline & cutout shadow',
    font_family: 'Bubblegum Sans',
    text_color: '#ffffff',
    bg_color: '#ec4899',
    bg_opacity: 0.96,
    border_color: '#000000',
    border_width: 3.5,
    border_radius: 16,
    box_shadow: true,
  },
  clean_subtitle: {
    name: 'Clean Subtitle Card',
    tag: 'Subtitle',
    desc: 'Modern translucent backdrop for maximum focus',
    font_family: 'Comic Neue',
    text_color: '#ffffff',
    bg_color: '#000000',
    bg_opacity: 0.65,
    border_color: '#475569',
    border_width: 1,
    border_radius: 8,
    box_shadow: false,
  },
}

export const DEFAULT_POEM_OVERLAY_STYLE: PoemOverlayStyle = {
  enabled: true,
  locked: false,
  font_family: 'Poppins',
  font_size_px: 28,
  preset_style: 'badge_pill',
  text_color: '#ffffff',
  bg_color: '#0f172a',
  bg_opacity: 0.88,
  border_color: '#38bdf8',
  border_width: 2,
  border_radius: 24,
  box_shadow: true,
  text_align: 'center',
  x_pct: 10,
  y_pct: 72,
  w_pct: 80,
  h_pct: 20,
}

export function normalizePoemOverlayStyle(raw?: Partial<PoemOverlayStyle> | null): PoemOverlayStyle {
  if (!raw) return { ...DEFAULT_POEM_OVERLAY_STYLE }
  const presetKey = (raw.preset_style && raw.preset_style in POEM_STYLE_PRESETS)
    ? (raw.preset_style as PoemPresetStyle)
    : DEFAULT_POEM_OVERLAY_STYLE.preset_style
  return {
    enabled: raw.enabled !== undefined ? Boolean(raw.enabled) : true,
    locked: raw.locked !== undefined ? Boolean(raw.locked) : false,
    font_family: raw.font_family || POEM_STYLE_PRESETS[presetKey].font_family,
    font_size_px: Number.isFinite(Number(raw.font_size_px))
      ? Math.max(14, Math.min(64, Number(raw.font_size_px)))
      : DEFAULT_POEM_OVERLAY_STYLE.font_size_px,
    preset_style: presetKey,
    text_color: raw.text_color || POEM_STYLE_PRESETS[presetKey].text_color,
    bg_color: raw.bg_color || POEM_STYLE_PRESETS[presetKey].bg_color,
    bg_opacity: Number.isFinite(Number(raw.bg_opacity))
      ? Math.max(0, Math.min(1, Number(raw.bg_opacity)))
      : POEM_STYLE_PRESETS[presetKey].bg_opacity,
    border_color: raw.border_color || POEM_STYLE_PRESETS[presetKey].border_color,
    border_width: Number.isFinite(Number(raw.border_width))
      ? Math.max(0, Math.min(12, Number(raw.border_width)))
      : POEM_STYLE_PRESETS[presetKey].border_width,
    border_radius: Number.isFinite(Number(raw.border_radius))
      ? Math.max(0, Math.min(48, Number(raw.border_radius)))
      : POEM_STYLE_PRESETS[presetKey].border_radius,
    box_shadow: raw.box_shadow !== undefined ? Boolean(raw.box_shadow) : POEM_STYLE_PRESETS[presetKey].box_shadow,
    text_align: raw.text_align === 'left' || raw.text_align === 'right' ? raw.text_align : 'center',
    x_pct: Number.isFinite(Number(raw.x_pct)) ? Math.max(0, Math.min(90, Number(raw.x_pct))) : DEFAULT_POEM_OVERLAY_STYLE.x_pct,
    y_pct: Number.isFinite(Number(raw.y_pct)) ? Math.max(0, Math.min(90, Number(raw.y_pct))) : DEFAULT_POEM_OVERLAY_STYLE.y_pct,
    w_pct: Number.isFinite(Number(raw.w_pct)) ? Math.max(10, Math.min(100, Number(raw.w_pct))) : DEFAULT_POEM_OVERLAY_STYLE.w_pct,
    h_pct: Number.isFinite(Number(raw.h_pct)) ? Math.max(6, Math.min(80, Number(raw.h_pct))) : DEFAULT_POEM_OVERLAY_STYLE.h_pct,
    shadow_color: raw.shadow_color || '#000000',
    word_balls: Boolean(raw.word_balls),
    ball_color: raw.ball_color || '#facc15',
    changeover: raw.changeover === 'none' || raw.changeover === 'slide' || raw.changeover === 'pop' || raw.changeover === 'fade'
      ? raw.changeover
      : 'fade',
    apply_all: raw.apply_all !== false,
  }
}

export type TimelinePlan = {
  project_id: string
  total_duration: number
  clips: TimelineClip[]
  narration_segments?: NarrationSegment[]
  manual_override?: boolean
  voiceover_path?: string | null
  poem_voiceover_path?: string | null
  voiceover_slots?: VoiceoverSlot[]
  /** Present only after the voice lane has been split, trimmed, or had a piece deleted. */
  vo_pieces?: VoPiece[]
  poem_start_time?: number
  poem_end_time?: number
  poem_lyric_start?: number
  has_poem?: boolean
  poem_overlay?: PoemOverlayStyle
  logo_path?: string | null
  logo_enabled?: boolean
  logo_transform?: LogoTransform
  logo_track_locked?: boolean
  video_track_hidden?: boolean
  video_track_locked?: boolean
  script_track_hidden?: boolean
  script_track_locked?: boolean
  vo_muted?: boolean
  vo_track_locked?: boolean
  muted_vo_slots?: number[]
  poem_muted?: boolean
  poem_track_locked?: boolean
  language: string
  align_engine?: 'english' | 'marathi' | string
  /** Poem lyric lock: `poem_word` = heard Poem VO; `estimate` = duration scale. */
  poem_align_engine?: 'poem_word' | 'estimate' | string | null
  align_note?: string
  srt_cues?: SrtCue[]
  qa_issues?: QAIssue[]
  qa_summary?: string
  /** Measured VO↔picture audit from Auto-align / client verifySync. */
  sync_report?: SyncReport | null
  ignored_qa_keys?: string[]
}

export type ExportSettings = {
  format: 'mp4' | 'mov' | 'mkv'
  resolution: string
  fps: number
  encoder: 'h264' | 'h265' | 'mpeg4'
  quality_preset: 'low' | 'medium' | 'high' | 'custom'
  bitrate_mode: 'vbr' | 'cbr' | 'crf'
  video_bitrate_kbps: number
  compression_mode: 'none' | 'by_quality' | 'by_bitrate'
  compression_quality: number
  audio_encoder?: 'aac' | 'mp3' | 'pcm'
  audio_bitrate_kbps: number
  audio_sample_rate: number
  audio_channels: 'stereo' | 'mono'
  color_space: 'bt709' | 'bt601'
  advanced_compression: boolean
  export_multitrack?: boolean
  export_video_only?: boolean
  backup_to_cloud?: boolean
  auto_highlight?: boolean
  export_srt_sidecar?: boolean
  include_logo?: boolean
  save_to?: string | null
  preset_name: string
}

export function fmt(sec: number) {
  const s = Math.max(0, Math.floor(sec))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const r = s % 60
  if (h > 0) return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`
  return `${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`
}

export function fmtFrames(sec: number, fps = 30) {
  const total = Math.max(0, sec)
  const h = Math.floor(total / 3600)
  const m = Math.floor((total % 3600) / 60)
  const s = Math.floor(total % 60)
  const f = Math.floor((total % 1) * fps)
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}:${String(f).padStart(2, '0')}`
}
