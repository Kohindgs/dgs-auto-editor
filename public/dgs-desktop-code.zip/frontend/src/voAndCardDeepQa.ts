/**
 * Deep browser QA for English chapters:
 *  1. Missing text in the image card as per the VoiceOver (VO).
 *  2. Extra word / sentence printed on the image card that is NOT in the VO / Poem.
 *  3. Spelling mistakes / typos on the image card or script (e.g. "caterpiller" → "caterpillar", "taxy" → "taxi").
 *  4. Words said wrongly or skipped in the VO audio (via in-browser Whisper word-level ASR).
 *  5. Half-eaten / clipped words at the start or end of a scene's VO cut (`narration_in` / `narration_out`).
 *
 * Quality bar (see AGENTS.md):
 *  - Zero false errors on stylised title lettering (e.g. leafy "Garden Walk" on Scene 1) or single glossy-font OCR dropouts.
 *  - Every bubble requires positive evidence.
 */
import {
  cleanExpectedCardText,
  cleanOcrPreview,
  EN_FUNCTION_WORDS,
  engWords,
  hasBlankPlaceholder,
  scriptLooksIndic,
  wordInOcr,
} from './cardTextQa.ts'
import { readCachedConfWords } from './ocrScan.ts'
import type { QAIssue, Scene, TimelineClip } from './types.ts'

export type AsrWord = {
  text: string
  start: number
  end: number
}

export type BoundaryCutInfo = {
  /** RMS amplitude (0..1) in a ±35ms window around narration_in */
  startRms: number
  /** RMS amplitude (0..1) in a ±35ms window around narration_out */
  endRms: number
}

const ASR_CACHE_PREFIX = 'dgs-vo-asr-v3:'
const DEVANAGARI_RE = /[\u0900-\u097F]/

// Known textbook / script typos -> canonical English spelling
const KNOWN_TYPOS: Record<string, string> = {
  caterpiller: 'caterpillar',
  caterpillers: 'caterpillars',
  catapillar: 'caterpillar',
  catapilla: 'caterpillar',
  taxy: 'taxi',
  mosqito: 'mosquito',
  mosquitos: 'mosquitoes',
  buterfly: 'butterfly',
  butterfy: 'butterfly',
  colision: 'collision',
  collison: 'collision',
  vehical: 'vehicle',
  vehicals: 'vehicles',
  obstacels: 'obstacles',
  obsticles: 'obstacles',
  convesation: 'conversation',
  conversaton: 'conversation',
  cleanlines: 'cleanliness',
  imortance: 'importance',
  importence: 'importance',
  diffrent: 'different',
  beautifull: 'beautiful',
  sentenses: 'sentences',
  picturs: 'pictures',
  creaturs: 'creatures',
  insecst: 'insects',
  folow: 'follow',
  mornig: 'morning',
  gardn: 'garden',
  colourfull: 'colourful',
  colorfull: 'colorful',
}

// Names, proper nouns, and valid British/American variants that should never be flagged as typos
const VALID_WORDS_AND_NAMES = new Set([
  ...EN_FUNCTION_WORDS,
  'mishka', 'om', 'jane', 'lear', 'talley', 'tally', 'suno', 'balbharati', 'sundharam',
  'garden', 'walk', 'walks', 'walking', 'ready', 'like', 'likes', 'observe', 'creatures',
  'because', 'learn', 'live', 'move', 'moves', 'moving', 'think', 'insects', 'insect',
  'follow', 'following', 'rules', 'while', 'human', 'traffic', 'their', 'senses', 'help',
  'around', 'obstacles', 'other', 'read', 'enjoy', 'summer', 'time', 'street', 'many',
  'bugs', 'bug', 'run', 'down', 'with', 'tiny', 'little', 'feet', 'ants', 'ant', 'shiny',
  'taxi', 'cabs', 'cab', 'fast', 'comes', 'caterpillar', 'bus', 'slow', 'travels', 'past',
  'sure', 'must', 'some', 'very', 'special', 'vision', 'never', 'seen', 'mobile',
  'collision', 'path', 'inside', 'here', 'that', 'behaves', 'vehicle', 'vehicles',
  'things', 'bumping', 'into', 'each', 'baby', 'butterfly', 'butterflies', 'pictures',
  'write', 'name', 'names', 'mosquito', 'fly', 'frame', 'sentences', 'using', 'given',
  'words', 'along', 'leaf', 'find', 'colourful', 'colorful', 'flowers', 'flower', 'crawl',
  'green', 'stem', 'imagine', 'draw', 'your', 'own', 'city', 'showing', 'different',
  'types', 'poet', 'uses', 'describe', 'short', 'paragraph', 'express', 'views',
  'beautiful', 'near', 'school', 'trees', 'tree', 'every', 'morning', 'watch', 'birds',
  'bird', 'harm', 'keep', 'clean', 'water', 'plants', 'plant', 'complete', 'conversation',
  'look', 'looks', 'busy', 'right', 'those', 'will', 'bump', 'teacher', 'highlight',
  'importance', 'nature', 'cleanliness', 'caring', 'motivate', 'them', 'underneath',
  'dotted', 'blanks', 'drawings', 'illustrates', 'additional', 'bottom', 'possible',
  'answer', 'question', 'heading', 'lyrics', 'subtitles', 'screen', 'scene',
])

// Equivalent British/American or ASR phonetic homophone pairs so they don't false-trigger VO mismatch
const EQUIVALENT_WORDS: Record<string, string> = {
  colorful: 'colourful',
  colourful: 'colourful',
  tally: 'talley',
  talley: 'talley',
  leer: 'lear',
  lea: 'lear',
  lear: 'lear',
  catapilla: 'caterpillar',
  caterpiller: 'caterpillar',
  taxy: 'taxi',
}

const ASR_HOMOPHONE_PAIRS = new Set([
  'ant|and',
  'and|ant',
  'lear|lea',
  'lea|lear',
  'lear|leer',
  'leer|lear',
  'talley|tally',
  'tally|talley',
  'its|it',
  'it|its',
])

function canonicalWord(w: string): string {
  const clean = w.toLowerCase().replace(/[^a-z]/g, '')
  return EQUIVALENT_WORDS[clean] || KNOWN_TYPOS[clean] || clean
}

function imageNo(screen: string): number | null {
  const m = /(\d+)$/.exec(screen || '')
  return m ? parseInt(m[1], 10) : null
}

function sceneLabel(screen: string) {
  return `Scene ${imageNo(screen) ?? screen.replace('screen_', '')}`
}

function fmtTc(sec: number) {
  const s = Math.max(0, Math.floor(sec))
  return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`
}

function editDistance(a: string, b: string): number {
  if (a === b) return 0
  if (Math.abs(a.length - b.length) > 2) return 3
  const dp = Array.from({ length: a.length + 1 }, (_, i) => i)
  for (let j = 1; j <= b.length; j++) {
    let prev = dp[0]
    dp[0] = j
    for (let i = 1; i <= a.length; i++) {
      const tmp = dp[i]
      dp[i] = a[i - 1] === b[j - 1] ? prev : 1 + Math.min(prev, dp[i], dp[i - 1])
      prev = tmp
    }
  }
  return dp[a.length]
}

function phoneticSame(a: string, b: string): boolean {
  const rawA = a.toLowerCase().replace(/[^a-z]/g, '')
  const rawB = b.toLowerCase().replace(/[^a-z]/g, '')
  if (ASR_HOMOPHONE_PAIRS.has(`${rawA}|${rawB}`)) return true
  const ca = canonicalWord(rawA)
  const cb = canonicalWord(rawB)
  if (!ca || !cb) return false
  if (ca === cb) return true
  if (ASR_HOMOPHONE_PAIRS.has(`${ca}|${cb}`)) return true
  if (Math.min(ca.length, cb.length) >= 4 && editDistance(ca, cb) <= 1) return true
  if (Math.min(ca.length, cb.length) >= 3 && (ca + 's' === cb || cb + 's' === ca)) return true
  return false
}

/** Tokenize VO text preserving "a" and "i" so substitutions like "seen her" vs "seen a" are caught. */
function voTokens(text: string): string[] {
  const out: string[] = []
  const matches = (text || '').toLowerCase().match(/[a-z]+(?:'[a-z]+)?/g) || []
  for (const m of matches) {
    const clean = m.replace(/[^a-z]/g, '')
    if (clean.length >= 2 || clean === 'a' || clean === 'i') {
      out.push(clean)
    }
  }
  return out
}

// ---------------------------------------------------------------------------
// 1. Browser Whisper ASR runner (cached in localStorage per project + VO duration)
// ---------------------------------------------------------------------------

type WhisperPipeline = (
  audio: Float32Array,
  opts: { return_timestamps: 'word' },
) => Promise<{ chunks?: Array<{ text?: string; timestamp?: [number, number | null] }> }>

let whisperPromise: Promise<WhisperPipeline> | null = null
let voWorkerInstance: Worker | null = null
let nextVoJobId = 1
/** Only one Whisper job at a time — a second run used to cancel the first with no result (Auto-align → 0 words). */
let activeVoScanStop: (() => void) | null = null
let voScanChain: Promise<void> = Promise.resolve()

function getVoWorker(): Worker | null {
  if (typeof Worker === 'undefined') return null
  if (!voWorkerInstance) {
    try {
      voWorkerInstance = new Worker(new URL('./voQaWorker.ts', import.meta.url), {
        type: 'module',
      })
    } catch {
      voWorkerInstance = null
    }
  }
  return voWorkerInstance
}

/** Stop any in-flight browser Whisper scan (background QA or a stuck Auto-align hear). */
export function cancelBrowserVoQaScan(): void {
  if (activeVoScanStop) {
    try {
      activeVoScanStop()
    } catch {
      /* ignore */
    }
    activeVoScanStop = null
  }
}

const WASM_CDN = 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/'

async function getWhisperFallback(): Promise<WhisperPipeline> {
  if (!whisperPromise) {
    whisperPromise = (async () => {
      const mod = (await import('@huggingface/transformers')) as {
        env?: {
          allowLocalModels?: boolean
          useBrowserCache?: boolean
          backends?: {
            onnx?: {
              wasm?: {
                wasmPaths?: string
                numThreads?: number
                proxy?: boolean
              }
            }
          }
        }
        pipeline: (task: string, model: string, opts: { dtype: string }) => Promise<WhisperPipeline>
      }
      if (mod.env) {
        mod.env.allowLocalModels = false
        mod.env.useBrowserCache = true
        if (mod.env.backends?.onnx?.wasm) {
          mod.env.backends.onnx.wasm.wasmPaths = WASM_CDN
          mod.env.backends.onnx.wasm.numThreads = 1
          mod.env.backends.onnx.wasm.proxy = false
        }
      }
      const pipe = await mod.pipeline('automatic-speech-recognition', 'Xenova/whisper-base.en', {
        dtype: 'q8',
      })
      return pipe as unknown as WhisperPipeline
    })().catch((err) => {
      whisperPromise = null
      throw err
    })
  }
  return whisperPromise
}

function resetVoWorker() {
  if (voWorkerInstance) {
    try {
      voWorkerInstance.terminate()
    } catch {
      /* ignore */
    }
    voWorkerInstance = null
  }
}

export function readCachedVoAsr(projectId: string | null, sig: string): AsrWord[] | null {
  try {
    const raw = localStorage.getItem(`${ASR_CACHE_PREFIX}${projectId || 'local'}:${sig}`)
    return raw ? (JSON.parse(raw) as AsrWord[]) : null
  } catch {
    return null
  }
}

function writeCachedVoAsr(projectId: string | null, sig: string, words: AsrWord[]) {
  try {
    localStorage.setItem(`${ASR_CACHE_PREFIX}${projectId || 'local'}:${sig}`, JSON.stringify(words))
  } catch {
    /* ignore quota errors */
  }
}

/** Decode any audio URL/Blob into a 16 kHz mono Float32Array in the browser. */
async function decodeAudioTo16kMono(source: string | Blob): Promise<Float32Array> {
  const buf =
    typeof source === 'string'
      ? await fetch(source).then((r) => {
          if (!r.ok) throw new Error(`HTTP ${r.status}`)
          return r.arrayBuffer()
        })
      : await source.arrayBuffer()
  const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
  const ctx = new AudioCtx()
  try {
    const decoded = await ctx.decodeAudioData(buf.slice(0))
    const targetSr = 16000
    const length = Math.max(1, Math.ceil(decoded.duration * targetSr))
    const offline = new OfflineAudioContext(1, length, targetSr)
    const src = offline.createBufferSource()
    src.buffer = decoded
    src.connect(offline.destination)
    src.start(0)
    const rendered = await offline.startRendering()
    return rendered.getChannelData(0)
  } finally {
    void ctx.close().catch(() => {})
  }
}

function rmsAround(audio16k: Float32Array, timeSec: number, halfWinSec = 0.035): number {
  const sr = 16000
  const i0 = Math.max(0, Math.floor((timeSec - halfWinSec) * sr))
  const i1 = Math.min(audio16k.length, Math.ceil((timeSec + halfWinSec) * sr))
  if (i1 <= i0) return 0
  let sum = 0
  for (let i = i0; i < i1; i++) sum += audio16k[i] * audio16k[i]
  return Math.sqrt(sum / (i1 - i0))
}

/**
 * Whisper's word-timestamp attention often assigns the start of a post-silence word to the start
 * of the silence gap. Trim leading/trailing silence (< 0.018 RMS) from each word's [start, end]
 * so timestamps reflect actual acoustic speech.
 */
export function tightenWordTimestamps(audio16k: Float32Array, words: AsrWord[]): AsrWord[] {
  return words.map((w) => {
    let s = w.start
    let e = Math.max(s, w.end)
    if (e - s > 0.12) {
      while (s + 0.04 < e && rmsAround(audio16k, s + 0.015, 0.015) < 0.018) {
        s += 0.02
      }
      while (e - 0.04 > s && rmsAround(audio16k, e - 0.015, 0.015) < 0.018) {
        e -= 0.02
      }
    }
    return {
      text: w.text,
      start: Number(s.toFixed(3)),
      end: Number(e.toFixed(3)),
    }
  })
}

export function computeBoundaryCuts(
  audio16k: Float32Array,
  clips: TimelineClip[],
): Record<string, BoundaryCutInfo> {
  const out: Record<string, BoundaryCutInfo> = {}
  for (const c of clips) {
    if (c.narration_in == null || c.narration_out == null) continue
    out[c.screen] = {
      startRms: rmsAround(audio16k, c.narration_in, 0.03),
      endRms: rmsAround(audio16k, c.narration_out, 0.03),
    }
  }
  return out
}

/**
 * Slice the 16 kHz audio into 4..9s silence-aligned windows so Whisper never cuts across a spoken word
 * and never deduplicates repeated fill-in-the-blank prompt/answer lines.
 */
function buildSilenceAlignedWindows(audio16k: Float32Array): Array<[number, number]> {
  const sr = 16000
  const totalSec = audio16k.length / sr
  const silences: Array<[number, number]> = []
  let silStart: number | null = null
  for (let t = 0; t < totalSec; t += 0.05) {
    const rms = rmsAround(audio16k, t + 0.025, 0.025)
    if (rms < 0.015) {
      if (silStart === null) silStart = t
    } else {
      if (silStart !== null && t - silStart >= 0.32) silences.push([silStart, t])
      silStart = null
    }
  }
  const windows: Array<[number, number]> = []
  let cur = 0
  for (const [s0, s1] of silences) {
    const mid = (s0 + s1) / 2
    if (mid - cur >= 4.2) {
      windows.push([cur, mid])
      cur = mid
    }
  }
  while (totalSec - cur > 9.5) {
    windows.push([cur, cur + 8.0])
    cur += 8.0
  }
  if (totalSec - cur > 0.25) windows.push([cur, totalSec])
  return windows
}

export type HearVoResult = {
  words: AsrWord[]
  /** Seconds of last heard word (0 if none). */
  maxWordT: number
  /** Why hearing stopped short of a full lock. */
  reason: 'ok' | 'empty' | 'partial' | 'decode_failed' | 'asr_failed' | 'cancelled' | 'timeout'
  detail?: string
}

/**
 * Promise API: hear the VO in the browser and return word timestamps.
 * Used by Auto-align so cuts never run blind when Whisper can hear the file.
 * Never wipes a partial transcript to [] — caller decides coverage.
 */
export function hearVoiceoverWords(
  projectId: string | null,
  voSignature: string,
  voSource: string | Blob,
  clips: TimelineClip[],
  onProgress?: (done: number, total: number) => void,
  opts?: { expectDurationSec?: number; skipCache?: boolean; exclusive?: boolean },
): Promise<HearVoResult> {
  return new Promise((resolve) => {
    let settled = false
    const finish = (result: HearVoResult) => {
      if (settled) return
      settled = true
      resolve(result)
    }
    const expect = Number(opts?.expectDurationSec || 0)
    const stop = runBrowserVoQaScan(
      projectId,
      voSignature,
      voSource,
      clips,
      (words, _cuts, meta) => {
        let maxWordT = 0
        for (const w of words) maxWordT = Math.max(maxWordT, Number(w.end || w.start || 0))
        if (meta?.error) {
          const err = meta.error
          const reason =
            err === 'cancelled'
              ? 'cancelled'
              : err.includes('decode') || err.includes('HTTP')
                ? 'decode_failed'
                : 'asr_failed'
          finish({ words, maxWordT, reason, detail: err })
          return
        }
        if (!words.length) {
          finish({ words, maxWordT: 0, reason: 'empty', detail: meta?.error })
          return
        }
        if (expect > 30 && maxWordT < expect * 0.82) {
          finish({
            words,
            maxWordT,
            reason: 'partial',
            detail: `heard through ${maxWordT.toFixed(1)}s of ${expect.toFixed(1)}s`,
          })
          return
        }
        finish({ words, maxWordT, reason: 'ok' })
      },
      onProgress,
      undefined,
      { skipCache: opts?.skipCache, exclusive: opts?.exclusive !== false },
    )
    window.setTimeout(() => {
      stop()
      finish({ words: [], maxWordT: 0, reason: 'timeout', detail: 'Whisper hear timed out after 10 minutes' })
    }, 600_000)
  })
}

export function runBrowserVoQaScan(
  projectId: string | null,
  voSignature: string,
  voSource: string | Blob,
  clips: TimelineClip[],
  onResult: (
    words: AsrWord[],
    boundaryCuts: Record<string, BoundaryCutInfo>,
    meta?: { error?: string },
  ) => void,
  onProgress?: (done: number, total: number) => void,
  onDecodedAudio?: (audio16k: Float32Array, boundaryCuts: Record<string, BoundaryCutInfo>) => void,
  scanOpts?: { skipCache?: boolean; exclusive?: boolean },
): () => void {
  let cancelled = false
  const jobId = nextVoJobId++
  let detachWorkerListener: (() => void) | null = null
  let releaseChain: (() => void) | null = null

  let notified = false
  const notifyCancelOrEmpty = (error?: string) => {
    if (notified || !cancelled) return
    notified = true
    try {
      onResult([], {}, { error: error || 'cancelled' })
    } catch {
      /* ignore */
    }
  }
  const stop = () => {
    cancelled = true
    if (detachWorkerListener) detachWorkerListener()
    notifyCancelOrEmpty('cancelled')
    if (activeVoScanStop === stop) activeVoScanStop = null
    if (releaseChain) {
      releaseChain()
      releaseChain = null
    }
  }

  const runBody = async () => {
    try {
      if (cancelled) {
        onResult([], {}, { error: 'cancelled' })
        return
      }
      let audio16k: Float32Array
      try {
        audio16k = await decodeAudioTo16kMono(voSource)
      } catch (decErr) {
        const msg = decErr instanceof Error ? decErr.message : String(decErr)
        console.warn('[VO ASR] decode failed', decErr)
        if (!cancelled && !notified) {
          notified = true
          onResult([], {}, { error: `decode failed: ${msg}` })
        }
        return
      }
      if (cancelled) return
      const audioSec = audio16k.length / 16000
      if (audioSec < 0.4) {
        if (!cancelled && !notified) {
          notified = true
          onResult([], {}, { error: `decoded audio too short (${audioSec.toFixed(2)}s)` })
        }
        return
      }
      const boundaryCuts = computeBoundaryCuts(audio16k, clips)
      onDecodedAudio?.(audio16k, boundaryCuts)
      const cached = scanOpts?.skipCache ? null : readCachedVoAsr(projectId, voSignature)
      if (cached && cached.length > 0) {
        if (!cancelled) {
          notified = true
          onResult(tightenWordTimestamps(audio16k, cached), boundaryCuts)
        }
        return
      }
      // Real progress: decoding finished, windows not built yet
      onProgress?.(0, Math.max(1, Math.ceil(audioSec / 6)))
      const windows = buildSilenceAlignedWindows(audio16k)
      onProgress?.(0, windows.length)

      const worker = getVoWorker()
      let workerOk = false
      if (worker) {
        try {
          await new Promise<void>((resolve, reject) => {
            const onMsg = (ev: MessageEvent) => {
              const m = ev.data
              if (!m || m.jobId !== jobId) return
              if (m.type === 'progress') {
                if (!cancelled) onProgress?.(m.done, m.total)
              } else if (m.type === 'result') {
                cleanup()
                if (!cancelled && !notified) {
                  notified = true
                  workerOk = true
                  const tightened = tightenWordTimestamps(audio16k, (m.rawWords || []) as AsrWord[])
                  writeCachedVoAsr(projectId, voSignature, tightened)
                  onResult(tightened, boundaryCuts)
                }
                resolve()
              } else if (m.type === 'error') {
                cleanup()
                reject(new Error(m.error || 'Worker ASR failed'))
              }
            }
            const cleanup = () => {
              worker.removeEventListener('message', onMsg)
              detachWorkerListener = null
            }
            detachWorkerListener = () => {
              cleanup()
              try {
                worker.postMessage({ type: 'cancel', jobId })
              } catch {
                /* ignore */
              }
              resolve()
            }
            worker.addEventListener('message', onMsg)
            // Copy buffer into the worker (do not transfer — main thread still needs audio16k for tighten).
            worker.postMessage({
              type: 'run',
              jobId,
              audio16k,
              windows,
            })
          })
          if (workerOk || cancelled || notified) return
        } catch (workerErr) {
          console.warn('[VO ASR] worker failed — falling back to main-thread Whisper', workerErr)
          resetVoWorker()
        }
      }

      const asr = await getWhisperFallback()
      if (cancelled) return
      const rawWords: AsrWord[] = []
      const sr = 16000
      for (let i = 0; i < windows.length; i++) {
        if (cancelled) return
        const [w0, w1] = windows[i]
        const slice = audio16k.subarray(Math.floor(w0 * sr), Math.floor(w1 * sr))
        const out = await asr(slice, { return_timestamps: 'word' })
        for (const ch of out.chunks || []) {
          const [s, e] = ch.timestamp || [0, 0]
          const text = String(ch.text || '').trim()
          if (!text) continue
          rawWords.push({
            text,
            start: Number((w0 + (s ?? 0)).toFixed(3)),
            end: Number((w0 + (e ?? s ?? 0)).toFixed(3)),
          })
        }
        onProgress?.(i + 1, windows.length)
      }
      const tightened = tightenWordTimestamps(audio16k, rawWords)
      if (!cancelled && !notified) {
        notified = true
        writeCachedVoAsr(projectId, voSignature, tightened)
        onResult(tightened, boundaryCuts)
      }
    } catch (err) {
      console.warn('[VO ASR]', err)
      if (!cancelled && !notified) {
        notified = true
        onResult([], {}, { error: err instanceof Error ? err.message : String(err) })
      }
    } finally {
      if (activeVoScanStop === stop) activeVoScanStop = null
      if (releaseChain) {
        releaseChain()
        releaseChain = null
      }
    }
  }

  // Exclusive queue: cancel the previous scan, then run this one.
  if (scanOpts?.exclusive !== false) {
    cancelBrowserVoQaScan()
    activeVoScanStop = stop
    const prev = voScanChain
    voScanChain = new Promise<void>((res) => {
      releaseChain = res
    })
    void prev.then(() => {
      if (!cancelled) void runBody()
      else if (releaseChain) {
        releaseChain()
        releaseChain = null
      }
    })
  } else {
    activeVoScanStop = stop
    void runBody()
  }

  return stop
}

// ---------------------------------------------------------------------------
// 2. Deep QA analyzer across Card OCR, Script, and VO ASR words
// ---------------------------------------------------------------------------

function extractRawAlphaWords(text: string): string[] {
  return (text || '')
    .split(/[^A-Za-z]+/)
    .map((w) => w.trim())
    .filter((w) => w.length >= 2)
}

function findSpellingTypos(
  wordsToCheck: string[],
  referenceVocab: Set<string>,
): Array<{ wrong: string; right: string }> {
  const found: Array<{ wrong: string; right: string }> = []
  const seen = new Set<string>()
  for (const raw of wordsToCheck) {
    const w = raw.toLowerCase()
    if (w.length < 4 || seen.has(w)) continue
    seen.add(w)
    if (KNOWN_TYPOS[w]) {
      found.push({ wrong: raw, right: KNOWN_TYPOS[w] })
      continue
    }
    if (VALID_WORDS_AND_NAMES.has(w) || referenceVocab.has(w)) continue
    let match: string | null = null
    for (const cand of referenceVocab) {
      if (cand.length >= 5 && Math.abs(cand.length - w.length) <= 1 && editDistance(w, cand) === 1) {
        match = cand
        break
      }
    }
    if (match) {
      found.push({ wrong: raw, right: match })
    }
  }
  return found
}

export function buildDeepVoAndCardIssues(
  clips: TimelineClip[],
  scenes: Scene[],
  ocrTexts: Record<string, string>,
  alreadyFlaggedCardScreens: Set<string>,
  asrWords?: AsrWord[] | null,
  boundaryCuts?: Record<string, BoundaryCutInfo> | null,
  projectId?: string | null,
): QAIssue[] {
  if (!scenes.length || scriptLooksIndic(scenes)) return []

  const issues: QAIssue[] = []
  const sceneByScreen = new Map(scenes.map((s) => [s.screen, s]))

  // Build canonical reference vocabulary from ASR words + valid words
  const referenceVocab = new Set<string>(VALID_WORDS_AND_NAMES)
  if (asrWords && asrWords.length > 0) {
    for (const aw of asrWords) {
      const clean = aw.text.toLowerCase().replace(/[^a-z]/g, '')
      if (clean.length >= 4 && !KNOWN_TYPOS[clean]) referenceVocab.add(clean)
    }
  }

  const chapterVocab = new Set<string>()
  for (const s of scenes) {
    for (const w of engWords(`${s.voiceover_text || ''} ${s.onscreen_text || ''}`)) {
      if (w.length >= 4) chapterVocab.add(w)
    }
  }

  const seenScreenKind = new Set<string>()

  for (const clip of clips) {
    const scene = sceneByScreen.get(clip.screen)
    if (!scene) continue
    if (DEVANAGARI_RE.test(`${scene.onscreen_text || ''}${scene.voiceover_text || ''}`)) continue

    const n = imageNo(clip.screen)
    const tc = `${fmtTc(clip.start)}–${fmtTc(clip.end)}`
    const pic = clip.filename || (n != null ? `Image ${n}` : clip.screen)
    const rawOcr = clip.media_id ? ocrTexts[clip.media_id] : undefined
    const ocrWords = rawOcr ? engWords(rawOcr) : []
    const ocrCompact = (rawOcr || '').toLowerCase().replace(/[^a-z]/g, '')
    const confWords =
      clip.media_id && projectId !== undefined
        ? readCachedConfWords(projectId ?? null, clip.media_id) || []
        : []

    const ostClean = cleanExpectedCardText(scene.onscreen_text || '')
    const voText = (scene.voiceover_text || clip.vo_text || '').trim()
    const isBlank = hasBlankPlaceholder(scene.onscreen_text || '') || hasBlankPlaceholder(voText)

    // -----------------------------------------------------------------------
    // A. Missing text in image as per VO  &  B. Extra word in image not in VO
    // -----------------------------------------------------------------------
    if (
      !alreadyFlaggedCardScreens.has(clip.screen) &&
      !seenScreenKind.has(`${clip.screen}:missing_extra`) &&
      clip.fit !== 'missing' &&
      clip.kind === 'image' &&
      rawOcr != null &&
      ostClean &&
      !isBlank &&
      !scene.is_poem
    ) {
      const voContentWords = engWords(voText).filter(
        (w) => w.length >= 3 && !['mishka', 'om', 'teacher'].includes(w),
      )
      const ostWords = engWords(ostClean).filter(
        (w) => w.length >= 3 && !['mishka', 'om', 'teacher', 'top', 'bottom', 'row'].includes(w),
      )
      // Only inspect cards where OCR clearly read at least 3 words (never flag unreadable decorative titles like Scene 1 "Garden Walk")
      const readableCardWords = ostWords.filter((w) => wordInOcr(w, ocrWords, ocrCompact))
      if (readableCardWords.length >= 3) {
        const ostCanonSet = new Set(ostWords.map(canonicalWord))
        const voCanonSet = new Set(voContentWords.map(canonicalWord))

        // 1) Words spoken in VO that are missing from BOTH the card's on-screen text and OCR (e.g. Scene 5)
        const missingFromCardVsVo = voContentWords.filter(
          (w) =>
            w.length >= 4 &&
            !EN_FUNCTION_WORDS.has(w) &&
            !ostCanonSet.has(canonicalWord(w)) &&
            !wordInOcr(w, ocrWords, ocrCompact),
        )
        // Also check if a whole clause (>= 3 content words) from VO is missing from the card's OCR even if listed in ost
        const missingFromOcrOnly = voContentWords.filter(
          (w) => w.length >= 4 && !EN_FUNCTION_WORDS.has(w) && !wordInOcr(w, ocrWords, ocrCompact),
        )
        const effectiveMissing =
          missingFromCardVsVo.length > 0
            ? Array.from(new Set(missingFromCardVsVo))
            : missingFromOcrOnly.length >= 3
              ? Array.from(new Set(missingFromOcrOnly))
              : []

        // 2) Words printed on the image that are NOT in the VO (e.g. "use" on Scene 5)
        const extraInOstAndOcr = ostWords.filter(
          (w) =>
            w.length >= 3 &&
            !voCanonSet.has(canonicalWord(w)) &&
            wordInOcr(w, ocrWords, ocrCompact),
        )
        const extraFromHighConfOcr = confWords
          .map((w) => w.toLowerCase())
          .filter(
            (w) =>
              w.length >= 4 &&
              chapterVocab.has(w) &&
              !EN_FUNCTION_WORDS.has(w) &&
              !voCanonSet.has(canonicalWord(w)) &&
              !ostCanonSet.has(canonicalWord(w)),
          )
        const effectiveExtra = Array.from(new Set([...extraInOstAndOcr, ...extraFromHighConfOcr]))

        if (effectiveMissing.length > 0 || effectiveExtra.length > 0) {
          seenScreenKind.add(`${clip.screen}:missing_extra`)
          const parts: string[] = []
          if (effectiveMissing.length > 0) {
            parts.push(
              `Missing text in ${pic} as per VO: "${effectiveMissing.join(', ')}"`,
            )
          }
          if (effectiveExtra.length > 0) {
            parts.push(
              `Word${effectiveExtra.length > 1 ? 's' : ''} in ${pic} not in VO: "${effectiveExtra.join(', ')}"`,
            )
          }
          issues.push({
            kind: 'card_text',
            severity: 'warning',
            screen: clip.screen,
            image_no: n,
            time: clip.start,
            end: clip.end,
            timecode: tc,
            message: `${sceneLabel(clip.screen)} (${tc}): ${parts.join(' · ')}.`,
            expected: voText.slice(0, 180),
            found: (ostClean || cleanOcrPreview(rawOcr)).slice(0, 180),
            missing_words: effectiveMissing.length ? effectiveMissing : effectiveExtra,
            source: 'ocr_client',
          })
        }
      }
    }

    // -----------------------------------------------------------------------
    // C. Spelling mistakes on the image card or script (e.g. caterpiller, taxy)
    // -----------------------------------------------------------------------
    if (!seenScreenKind.has(`${clip.screen}:spelling`)) {
      const ostRawWords = extractRawAlphaWords(ostClean)
      const voRawWords = extractRawAlphaWords(voText)
      const candidateWordsForSpelling = [...ostRawWords, ...voRawWords, ...confWords]
      const typos = findSpellingTypos(candidateWordsForSpelling, referenceVocab)
      if (typos.length > 0) {
        seenScreenKind.add(`${clip.screen}:spelling`)
        const typoDesc = typos.map((t) => `"${t.wrong}" → "${t.right}"`).join(', ')
        const ostLowSet = new Set(ostRawWords.map((w) => w.toLowerCase()))
        const onCard =
          clip.kind === 'image' &&
          typos.some(
            (t) =>
              ostLowSet.has(t.wrong.toLowerCase()) ||
              (rawOcr && wordInOcr(t.wrong, ocrWords, ocrCompact)),
          )
        issues.push({
          kind: 'card_text',
          severity: 'warning',
          screen: clip.screen,
          image_no: n,
          time: clip.start,
          end: clip.end,
          timecode: tc,
          message: `${sceneLabel(clip.screen)} (${tc}): Spelling mistake ${onCard ? `on ${pic}` : 'in script'} — ${typoDesc}.`,
          expected: `Correct spelling: "${typos.map((t) => t.right).join(', ')}"`,
          found: (onCard ? ostClean || cleanOcrPreview(rawOcr || '') : voText || ostClean).slice(0, 180),
          missing_words: typos.map((t) => `${t.wrong} → ${t.right}`),
          source: 'ocr_client',
        })
      }
    }

    // -----------------------------------------------------------------------
    // D. Words said wrongly in VO  &  E. Half-eaten / clipped words in VO
    // -----------------------------------------------------------------------
    const nin = clip.narration_in
    const nout = clip.narration_out
    if (
      !seenScreenKind.has(`${clip.screen}:vo`) &&
      asrWords &&
      asrWords.length > 0 &&
      nin != null &&
      nout != null &&
      nout > nin + 0.2 &&
      !scene.is_poem &&
      voText
    ) {
      const validAsr = asrWords.filter((w) => w.end >= w.start)
      const spokenInSeg = validAsr.filter((w) => w.end > nin + 0.06 && w.start < nout - 0.06)
      const spokenTranscript = spokenInSeg.map((w) => w.text).join(' ').trim()

      // E. Check for half-eaten / clipped words straddling narration_in or narration_out
      // Requires BOTH an ASR word straddling the cut AND non-silent audio waveform energy at the cut.
      const clippedParts: string[] = []
      const cutInfo = boundaryCuts?.[clip.screen]
      if (cutInfo) {
        for (const w of validAsr) {
          const dur = Math.max(0.1, w.end - w.start)
          const cleanW = w.text.replace(/[^A-Za-z']/g, '')
          if (cleanW.length < 2) continue
          if (
            cutInfo.startRms >= 0.03 &&
            w.start < nin - 0.06 &&
            w.end > nin + 0.08 &&
            (nin - w.start) / dur >= 0.3
          ) {
            clippedParts.push(`start of "${cleanW}" is half-eaten at ${nin.toFixed(2)}s`)
          }
          if (
            cutInfo.endRms >= 0.03 &&
            w.start < nout - 0.08 &&
            w.end > nout + 0.06 &&
            (w.end - nout) / dur >= 0.3
          ) {
            clippedParts.push(`end of "${cleanW}" is half-eaten at ${nout.toFixed(2)}s`)
          }
        }
      }

      if (clippedParts.length > 0) {
        seenScreenKind.add(`${clip.screen}:vo`)
        issues.push({
          kind: 'vo_mismatch',
          severity: 'warning',
          screen: clip.screen,
          image_no: n,
          time: clip.start,
          end: clip.end,
          timecode: tc,
          message: `${sceneLabel(clip.screen)} (${tc}): Half-eaten word in VO — ${clippedParts.join('; ')}.`,
          expected: voText.slice(0, 180),
          found: spokenTranscript ? `Spoken VO: "${spokenTranscript}"` : undefined,
          source: 'ocr_client',
        })
      }

      // D. Check for words said wrongly in the VO compared to the script
      if (spokenInSeg.length >= 2) {
        const expTokens = voTokens(voText)
        const spkTokens = voTokens(spokenTranscript)
        if (expTokens.length >= 3 && spkTokens.length >= 2) {
          const unexpectedSpoken = spkTokens.filter(
            (sw) => !expTokens.some((ew) => phoneticSame(sw, ew)),
          )
          const missingExpected = expTokens.filter(
            (ew) => !spkTokens.some((sw) => phoneticSame(ew, sw)),
          )

          if (unexpectedSpoken.length > 0 && missingExpected.length > 0) {
            const wrongW = unexpectedSpoken[0]
            const rightW = missingExpected[0]
            const prevScene = scenes[scene.index - 1]
            const nextScene = scenes[scene.index + 1]
            const adjWords = new Set(
              voTokens(`${prevScene?.voiceover_text || ''} ${nextScene?.voiceover_text || ''}`),
            )
            if (!adjWords.has(wrongW) || (expTokens.length <= 7 && spkTokens.length === expTokens.length)) {
              seenScreenKind.add(`${clip.screen}:vo`)
              issues.push({
                kind: 'vo_mismatch',
                severity: 'warning',
                screen: clip.screen,
                image_no: n,
                time: clip.start,
                end: clip.end,
                timecode: tc,
                message: `${sceneLabel(clip.screen)} (${tc}): Word said wrongly in VO — speaker says "${wrongW}" instead of "${rightW}" ("${spokenTranscript}").`,
                expected: voText.slice(0, 180),
                found: `Spoken in VO: "${spokenTranscript}"`,
                missing_words: [`"${wrongW}" (expected "${rightW}")`],
                source: 'ocr_client',
              })
            }
          }
        }
      }
    }
  }

  return issues
}
