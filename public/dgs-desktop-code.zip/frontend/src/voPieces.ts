import type { TimelinePlan, VoPiece, VoiceoverSlot } from './types'

function r3(n: number) {
  return Math.round(n * 1000) / 1000
}

function poemHole(plan: TimelinePlan): { start: number; end: number } | null {
  const start = Number(plan.poem_start_time || 0)
  const end = Number(plan.poem_end_time || 0)
  if (!plan.has_poem || end <= start + 0.3) return null
  return { start, end }
}

function splitHole(piece: VoPiece, hole: { start: number; end: number } | null): VoPiece[] {
  if (!hole) return [piece]
  const a = piece.start
  const b = piece.end
  if (hole.end <= a + 0.05 || hole.start >= b - 0.05) return [piece]
  const span = Math.max(0.001, b - a)
  const srcSpan = piece.source_out - piece.source_in
  const cutSrc = (t: number) => piece.source_in + ((t - a) / span) * srcSpan
  const out: VoPiece[] = []
  if (hole.start > a + 0.12) {
    out.push({
      ...piece,
      id: `${piece.id}-before`,
      end: r3(hole.start),
      source_out: r3(cutSrc(hole.start)),
    })
  }
  if (hole.end < b - 0.12) {
    out.push({
      ...piece,
      id: `${piece.id}-after`,
      start: r3(hole.end),
      source_in: r3(cutSrc(hole.end)),
    })
  }
  return out.filter((p) => p.end > p.start + 0.08 && p.source_out > p.source_in + 0.04)
}

function slotPiece(slot: VoiceoverSlot, plan: TimelinePlan): VoPiece {
  const start = Number(slot.start) || 0
  const end = Number(slot.end) || start
  const span = Math.max(0.2, end - start)
  const fileDur = Math.max(span, Number(slot.duration) || span)
  return {
    id: `vo-slot-${slot.slot}`,
    slot: Number(slot.slot) || 1,
    filename: slot.filename || `VO ${slot.slot}`,
    path: slot.path || plan.voiceover_path || null,
    start: r3(start),
    end: r3(end),
    source_in: 0,
    source_out: r3(Math.min(fileDur, span)),
    file_duration: r3(fileDur),
  }
}

function spokenPieces(plan: TimelinePlan): VoPiece[] {
  const segs =
    plan.narration_segments && plan.narration_segments.length > 0
      ? plan.narration_segments
      : plan.clips || []
  const out: VoPiece[] = []
  for (const seg of segs) {
    if (seg.narration_in == null || seg.narration_out == null) continue
    const spoken = Number(seg.narration_out) - Number(seg.narration_in)
    if (spoken < 0.05) continue
    const start = Number(seg.start) || 0
    const end = Math.min(Number(seg.end) || start + spoken, start + spoken)
    if (end <= start + 0.05) continue
    out.push({
      id: `vo-${seg.screen}`,
      slot: 1,
      filename: seg.vo_text || seg.script_text || 'Narration',
      path: plan.voiceover_path || null,
      start: r3(start),
      end: r3(end),
      source_in: r3(Number(seg.narration_in)),
      source_out: r3(Number(seg.narration_out)),
      file_duration: r3(Math.max(Number(seg.narration_out), spoken)),
    })
  }
  return out
}

/** Bars to draw before the voice lane has been edited. */
export function deriveVoPieces(plan: TimelinePlan): VoPiece[] {
  const hole = poemHole(plan)
  const slots = (plan.voiceover_slots || []).filter((s) => Number(s.end) > Number(s.start) + 0.05)
  if (slots.length >= 2) return slots.flatMap((s) => splitHole(slotPiece(s, plan), hole))
  const spoken = spokenPieces(plan)
  if (spoken.length) return spoken.flatMap((p) => splitHole(p, hole))
  if (slots.length === 1) return splitHole(slotPiece(slots[0], plan), hole)
  if (plan.voiceover_path) {
    const end = Math.max(1, Number(plan.total_duration) || 1)
    return splitHole(
      {
        id: 'vo-file',
        slot: 1,
        filename: 'Narration',
        path: plan.voiceover_path,
        start: 0,
        end: r3(end),
        source_in: 0,
        source_out: r3(end),
        file_duration: r3(end),
      },
      hole,
    )
  }
  return []
}

/** Saved pieces after an edit, otherwise the derived bars. */
export function displayVoPieces(plan: TimelinePlan | null): VoPiece[] {
  if (!plan) return []
  if (Array.isArray(plan.vo_pieces)) return plan.vo_pieces
  return deriveVoPieces(plan)
}

export function slotOrigin(slots: VoiceoverSlot[] | undefined, slot: number, gapSec: number): number {
  const ordered = [...(slots || [])].sort((a, b) => Number(a.slot) - Number(b.slot))
  if (ordered.length < 2) return 0
  let t = 0
  for (const s of ordered) {
    if (Number(s.slot) === Number(slot)) return t
    const dur = Math.max(0.2, Number(s.duration) || Number(s.end) - Number(s.start) || 0)
    t += dur + gapSec
  }
  return 0
}

/** Time inside the preview narration file, or null when this moment is a gap. */
export function voiceFileTimeAt(
  plan: TimelinePlan | null,
  t: number,
  gapSec: number,
): number | null {
  // Empty array is not an edit — callers must treat it as unedited VO.
  if (!plan || !Array.isArray(plan.vo_pieces) || plan.vo_pieces.length === 0) return null
  const piece = plan.vo_pieces.find((p) => t >= p.start && t < p.end - 0.001)
  if (!piece) return null
  const local = Math.max(0, t - piece.start)
  const origin = slotOrigin(plan.voiceover_slots, piece.slot, gapSec)
  return origin + piece.source_in + Math.min(local, Math.max(0, piece.source_out - piece.source_in))
}

export function voiceEngineSegments(plan: TimelinePlan, gapSec: number) {
  return (plan.vo_pieces || []).map((p) => {
    const origin = slotOrigin(plan.voiceover_slots, p.slot, gapSec)
    return {
      start: p.start,
      end: p.end,
      narration_in: origin + p.source_in,
      narration_out: origin + p.source_out,
    }
  })
}

export function splitVoPiece(pieces: VoPiece[], id: string, at: number): VoPiece[] | null {
  const idx = pieces.findIndex((p) => p.id === id)
  if (idx < 0) return null
  const piece = pieces[idx]
  if (at <= piece.start + 0.12 || at >= piece.end - 0.12) return null
  const span = piece.end - piece.start
  const srcCut = piece.source_in + ((at - piece.start) / span) * (piece.source_out - piece.source_in)
  const left: VoPiece = {
    ...piece,
    id: `${piece.id}-L${Math.round(at * 1000)}`,
    end: r3(at),
    source_out: r3(srcCut),
  }
  const right: VoPiece = {
    ...piece,
    id: `${piece.id}-R${Math.round(at * 1000)}`,
    start: r3(at),
    source_in: r3(srcCut),
  }
  const next = pieces.slice()
  next.splice(idx, 1, left, right)
  return next
}

export function trimVoPiece(
  pieces: VoPiece[],
  id: string,
  edge: 'start' | 'end' | 'move',
  timelineAt: number,
): VoPiece[] {
  const piece = pieces.find((p) => p.id === id)
  if (!piece) return pieces
  const sameLane = pieces
    .filter((p) => p.id !== id && p.slot === piece.slot)
    .sort((a, b) => a.start - b.start)
  const prevEnd = sameLane.filter((p) => p.end <= piece.start + 0.02).reduce((m, p) => Math.max(m, p.end), 0)
  const nextStart = sameLane
    .filter((p) => p.start >= piece.end - 0.02)
    .reduce((m, p) => Math.min(m, p.start), Number.POSITIVE_INFINITY)
  const span = piece.end - piece.start
  const srcSpan = piece.source_out - piece.source_in
  const rate = span > 0.001 ? srcSpan / span : 1
  let start = piece.start
  let end = piece.end
  let sourceIn = piece.source_in
  let sourceOut = piece.source_out
  if (edge === 'move') {
    const dur = span
    start = Math.max(prevEnd, timelineAt)
    if (Number.isFinite(nextStart)) start = Math.min(start, nextStart - dur)
    start = Math.max(0, start)
    end = start + dur
  } else if (edge === 'start') {
    const maxStart = piece.end - 0.12
    start = Math.max(prevEnd, Math.min(maxStart, timelineAt))
    const delta = start - piece.start
    sourceIn = Math.max(0, Math.min(piece.source_out - 0.08, piece.source_in + delta * rate))
  } else {
    const minEnd = piece.start + 0.12
    const cap = Number.isFinite(nextStart) ? nextStart : timelineAt
    end = Math.max(minEnd, Math.min(cap, timelineAt))
    const delta = end - piece.end
    sourceOut = Math.max(piece.source_in + 0.08, Math.min(piece.file_duration || sourceOut, piece.source_out + delta * rate))
  }
  return pieces.map((p) =>
    p.id === id
      ? { ...p, start: r3(start), end: r3(end), source_in: r3(sourceIn), source_out: r3(sourceOut) }
      : p,
  )
}
