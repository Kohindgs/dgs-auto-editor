/**
 * Dedicated Web Worker for in-browser Whisper word-level ASR (Deep VO QA).
 * Bundles @huggingface/transformers via Vite (CDN ESM breaks on bare "onnxruntime-common").
 */

import { env, pipeline } from '@huggingface/transformers'

type WhisperPipeline = (
  audio: Float32Array,
  opts: { return_timestamps: 'word' },
) => Promise<{ chunks?: Array<{ text?: string; timestamp?: [number, number | null] }> }>

type WorkerWord = {
  text: string
  start: number
  end: number
}

type RunMessage = {
  type: 'run'
  jobId: number
  audio16k: Float32Array
  windows: Array<[number, number]>
}

type CancelMessage = {
  type: 'cancel'
  jobId: number
}

/** ORT WASM assets ship in the transformers dist/ folder on jsDelivr. */
const WASM_CDN = 'https://cdn.jsdelivr.net/npm/@huggingface/transformers@3.8.1/dist/'

let whisperPromise: Promise<WhisperPipeline> | null = null
let activeJobId = 0

async function getWhisper(): Promise<WhisperPipeline> {
  if (!whisperPromise) {
    whisperPromise = (async () => {
      env.allowLocalModels = false
      env.useBrowserCache = true
      if (env.backends?.onnx?.wasm) {
        env.backends.onnx.wasm.wasmPaths = WASM_CDN
        env.backends.onnx.wasm.numThreads = 1
        env.backends.onnx.wasm.proxy = false
      }
      const pipe = await pipeline('automatic-speech-recognition', 'Xenova/whisper-base.en', {
        dtype: 'q8',
      })
      return pipe as unknown as WhisperPipeline
    })().catch((err) => {
      whisperPromise = null
      throw err
    })
  }
  return whisperPromise
}

self.onmessage = async (ev: MessageEvent<RunMessage | CancelMessage>) => {
  const msg = ev.data
  if (!msg) return
  if (msg.type === 'cancel') {
    if (activeJobId === msg.jobId) activeJobId = 0
    return
  }
  if (msg.type === 'run') {
    const { jobId, audio16k, windows } = msg
    activeJobId = jobId
    try {
      const asr = await getWhisper()
      if (activeJobId !== jobId) return
      const rawWords: WorkerWord[] = []
      const sr = 16000
      for (let i = 0; i < windows.length; i++) {
        if (activeJobId !== jobId) return
        const [w0, w1] = windows[i]
        const slice = audio16k.subarray(Math.floor(w0 * sr), Math.floor(w1 * sr))
        const out = await asr(slice, { return_timestamps: 'word' })
        if (activeJobId !== jobId) return
        for (const ch of out.chunks || []) {
          const [s, e] = ch.timestamp || [0, 0]
          const text = String(ch.text || '').trim()
          if (!text) continue
          rawWords.push({
            text,
            start: Number((w0 + (s ?? 0)).toFixed(3)),
            end: Number((w0 + (e ?? s ?? 0)).toFixed(3)),
          })
        }
        self.postMessage({ type: 'progress', jobId, done: i + 1, total: windows.length })
      }
      if (activeJobId === jobId) {
        self.postMessage({ type: 'result', jobId, rawWords })
      }
    } catch (err) {
      if (activeJobId === jobId) {
        self.postMessage({
          type: 'error',
          jobId,
          error: err instanceof Error ? err.message : String(err),
        })
      }
    }
  }
}
