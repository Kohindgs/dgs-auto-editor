// DGS engine host for the native editor.
//
// Runs the same chapter engine as the website (hostinger_deploy/server.js) and
// the editor's timeline logic (frontend/src/*.ts) inside one hidden Node
// process. Nothing listens on a network port: server.js is bound to a private
// Windows named pipe, and the native program talks to this host only through
// stdin/stdout, one JSON message per line.
//
//   -> {"id":1,"op":"http","method":"POST","path":"/api/projects/x/build","body":{...}}
//   <- {"id":1,"ok":true,"status":200,"json":{...}}
//   -> {"id":2,"op":"fn","module":"stretchClipsToVo","name":"applyStretchAlignToPlan","args":[plan, media]}
//   <- {"id":2,"ok":true,"result":{...}}

'use strict';

const fs = require('fs');
const path = require('path');
const http = require('http');
const crypto = require('crypto');
const readline = require('readline');
const { pathToFileURL } = require('url');

const rpcOut = process.stdout.write.bind(process.stdout);
const toErr = (...a) => process.stderr.write(a.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ') + '\n');
console.log = toErr;
console.info = toErr;
console.warn = toErr;
console.debug = toErr;

const SERVER_JS = process.env.DGS_SERVER_JS || path.resolve(__dirname, '..', '..', 'hostinger_deploy', 'server.js');
const FRONTEND_SRC = process.env.DGS_FRONTEND_SRC || path.resolve(__dirname, '..', '..', 'frontend', 'src');
const LOGIC_DIR = process.env.DGS_LOGIC_DIR || path.join(__dirname, 'logic');
const PIPE = process.platform === 'win32' ? `\\\\.\\pipe\\dgs-engine-${process.pid}-${crypto.randomBytes(4).toString('hex')}` : path.join(require('os').tmpdir(), `dgs-engine-${process.pid}-${crypto.randomBytes(4).toString('hex')}.sock`);
if (process.platform !== 'win32') { process.on('exit', () => { try { fs.unlinkSync(PIPE); } catch {} }); }
process.env.PORT = PIPE;
delete process.env.DGS_BIND;

function send(msg) {
  rpcOut(JSON.stringify(msg) + '\n');
}

// Frontend logic modules -------------------------------------------------------
// frontend/src/*.ts are imported as they are: Node 24 strips the type
// annotations itself. Packaged builds carry a copy of those files in ./logic.

const logicCache = new Map();

async function loadLogic(name) {
  const key = name.replace(/\.(ts|js)$/, '');
  if (!logicCache.has(key)) {
    const packed = path.join(LOGIC_DIR, `${key}.ts`);
    const file = fs.existsSync(packed) ? packed : path.join(FRONTEND_SRC, `${key}.ts`);
    logicCache.set(key, import(pathToFileURL(file).href));
  }
  return logicCache.get(key);
}

// HTTP over the private pipe ---------------------------------------------------

function pipeRequest({ method = 'GET', path: p, body, timeout = 30 * 60 * 1000, save_to }) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? null : Buffer.from(JSON.stringify(body));
    const req = http.request(
      {
        socketPath: PIPE,
        method,
        path: p,
        headers: {
          'Content-Type': 'application/json',
          'X-Client-Id': 'native-editor',
          'X-Client-Label': 'DGS native editor',
          ...(payload ? { 'Content-Length': payload.length } : {}),
        },
        timeout,
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const buf = Buffer.concat(chunks);
          const out = { status: res.statusCode, headers: res.headers };
          if (save_to && res.statusCode < 400) {
            fs.mkdirSync(path.dirname(save_to), { recursive: true });
            fs.writeFileSync(save_to, buf);
            out.saved = save_to;
            out.bytes = buf.length;
          } else if (String(res.headers['content-type'] || '').includes('json')) {
            try {
              out.json = JSON.parse(buf.toString('utf8'));
            } catch {
              out.text = buf.toString('utf8');
            }
          } else {
            out.text = buf.toString('utf8').slice(0, 20000);
          }
          resolve(out);
        });
      },
    );
    req.on('timeout', () => req.destroy(new Error('engine request timed out')));
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function handle(msg) {
  const { id, op } = msg;
  try {
    if (op === 'http') {
      const r = await pipeRequest(msg);
      send({ id, ok: true, ...r });
    } else if (op === 'fn') {
      const mod = await loadLogic(msg.module);
      const f = mod[msg.name];
      if (typeof f !== 'function') throw new Error(`${msg.module}.${msg.name} is not a function`);
      const result = await f(...(msg.args || []));
      send({ id, ok: true, result: result === undefined ? null : result });
    } else if (op === 'ping') {
      send({ id, ok: true, pipe: PIPE, node: process.version });
    } else if (op === 'quit') {
      send({ id, ok: true });
      setTimeout(() => process.exit(0), 50);
    } else {
      throw new Error(`unknown op ${op}`);
    }
  } catch (e) {
    send({ id, ok: false, error: e && e.message ? e.message : String(e) });
  }
}

// Start ------------------------------------------------------------------------

const readyTimer = setInterval(() => {
  http
    .get({ socketPath: PIPE, path: '/api/health', timeout: 2000 }, (res) => {
      res.resume();
      if (res.statusCode < 500) {
        clearInterval(readyTimer);
        send({ event: 'ready', pipe: PIPE });
      }
    })
    .on('error', () => {});
}, 150);

try {
  require(SERVER_JS);
} catch (e) {
  send({ event: 'fatal', error: e && e.message ? e.message : String(e) });
  process.exit(1);
}

const rl = readline.createInterface({ input: process.stdin });
rl.on('line', (line) => {
  if (!line.trim()) return;
  let msg;
  try {
    msg = JSON.parse(line);
  } catch {
    return;
  }
  handle(msg);
});
rl.on('close', () => process.exit(0));
