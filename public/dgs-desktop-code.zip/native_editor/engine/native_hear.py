"""Hear an English narration or poem with the local faster-whisper install.

Prints one JSON object on stdout: {"words":[{"word","text","start","end"}]}.
This is the English module. Marathi and Hindi are refused here and heard by the Marathi engine.
"""
import json
import os
import sys

from faster_whisper import WhisperModel


def model_kwargs(device: str, compute: str) -> dict:
    kwargs = {"device": device, "compute_type": compute}
    root = os.environ.get("DGS_MODEL_DIR") or ""
    if root:
        os.makedirs(root, exist_ok=True)
        kwargs["download_root"] = root
    return kwargs


def main() -> None:
    if len(sys.argv) < 2:
        print(json.dumps({"words": [], "error": "missing audio path"}))
        return
    if sys.argv[1] == "--download":
        WhisperModel("base", **model_kwargs("cpu", "int8"))
        sys.stdout.write(json.dumps({"ok": True, "model": "base"}))
        return
    audio = sys.argv[1]
    language = sys.argv[2].strip().lower() if len(sys.argv) > 2 else "en"
    if language in ("", "auto"):
        language = "en"
    if language not in ("en", "english"):
        sys.stdout.write(json.dumps({"words": [], "error": "The English hearer does not run on a Marathi chapter"}))
        sys.exit(2)
    language = "en"
    model_size = sys.argv[3] if len(sys.argv) > 3 else "base"
    device = sys.argv[4] if len(sys.argv) > 4 else "cpu"
    compute = sys.argv[5] if len(sys.argv) > 5 else "int8"
    prompt = sys.argv[6] if len(sys.argv) > 6 else ""
    vad = not (len(sys.argv) > 7 and sys.argv[7] == "0")
    model = WhisperModel(model_size, **model_kwargs(device, compute))
    opts = {
        "language": language,
        "word_timestamps": True,
        "vad_filter": vad,
        "initial_prompt": prompt or None,
    }
    if not vad:
        # Sung lines are music. Keep them, and stay in the poem's script.
        opts.update({
            "no_speech_threshold": 0.1,
            "log_prob_threshold": -1.5,
            "compression_ratio_threshold": 3.0,
            "condition_on_previous_text": False,
        })
    segments, _info = model.transcribe(audio, **opts)
    words = []
    for seg in segments:
        if getattr(seg, "words", None):
            for w in seg.words:
                text = (w.word or "").strip()
                if not text:
                    continue
                words.append(
                    {
                        "word": text,
                        "text": text,
                        "start": float(w.start),
                        "end": float(w.end),
                    }
                )
        elif (seg.text or "").strip():
            text = seg.text.strip()
            words.append(
                {
                    "word": text,
                    "text": text,
                    "start": float(seg.start),
                    "end": float(seg.end),
                }
            )
    sys.stdout.write(json.dumps({"words": words}, ensure_ascii=False))


if __name__ == "__main__":
    main()
